<?php 
	require_once '../../start.php';	
	
	$modalidade = $_GET['modalidade'];
	Estatistica::calculaTurmas($inep, $txtano, $modalidade);

	redirect("escola/nota/estatistica_refatoracao.php?modalidade={$modalidade}");

 ?>