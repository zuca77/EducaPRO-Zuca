<?
header("location:http://www.seduc.ro.gov.br/portal/");
?>
