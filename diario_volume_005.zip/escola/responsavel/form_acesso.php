<?php
header('Location: ../../responsavel.php');die;