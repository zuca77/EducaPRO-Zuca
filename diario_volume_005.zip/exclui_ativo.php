<?
include ("conexao_mysql.php");

$id=$_GET["codigo"];
$sql="delete from ativo where codigo = $id";
$qry = mysql_query($sql,$conexao);
mysql_close($conexao);
header("Location: formcadativo.php"); 
?>
