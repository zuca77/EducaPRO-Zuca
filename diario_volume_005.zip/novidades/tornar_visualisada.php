<?php
require '../start.php';

if ($_SERVER["REQUEST_METHOD"] === 'POST') {
    Novidades::tornarVisualizadas();
    return true;
}

return false;

