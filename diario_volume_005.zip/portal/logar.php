<?php
require 'start.php';

$responsavel = Responsavel::get($_POST['cpf'], $_POST['password']);
if (!$responsavel) {
	Notification::error("Usu�rio ou senha incorretos! Verifique suas informa��es!");

	redirectBackWithInputsInSession();
}

$_SESSION['responsavel'] = $responsavel;

redirect('portal/index.php');