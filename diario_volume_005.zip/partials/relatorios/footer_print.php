
<?php if (!isset($grupo)): ?>
<div class="page-break"></div>
<?php endif ?>

<div class="hidden-print text-center hidden-xs">
	<button class="btn btn-primary" onclick="window.print()"><i class="fa fa-print fa-2x"></i> Imprimir</button>
	<button class="btn btn-default" onclick="window.history.back()">Voltar</button>
</div>