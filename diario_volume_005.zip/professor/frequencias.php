<?php
require_once '../start.php';

if (empty($_GET['tp']) || (empty($_GET['e']) && empty($_GET['m']))) {
	redirect('professor/form_frequencia.php');
}

$_GET['mes'] = $_GET['m'];
$_GET['id_etapa'] = $_GET['e'];
$_GET['id_turmaprofessor'] = $_GET['tp'];
$_GET['checkUsuario'] = true;

include '../relatorios/frequencia.php';