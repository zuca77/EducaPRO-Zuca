<?
function listrada($num)
{

$resto = $num%2;
if($resto == 0){

return "#E8E8E8";
}
else{
return "#FFFFFF";
}
}
?>