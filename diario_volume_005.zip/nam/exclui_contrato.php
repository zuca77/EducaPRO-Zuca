<?
include ("../conexao_mysql.php");

$id=$_GET["codigo"];


$sql="delete from contrato where id = $id";
$qry = mysql_query($sql,$conexao);
mysql_close($conexao);
header("Location: mnnam.php"); 
?>
