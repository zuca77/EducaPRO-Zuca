<?php
require '../classes/autoload.php';

$id_parcela 	= $_POST['id_parcela'];
$valor_parcela	= $_POST['valor_parcela'];

$vo = new ParcelaCompraVO;
$vo->valor_parcela = $valor_parcela;

$dao = new ParcelaCompraDAO;
if($dao->update($vo))
	die('Parcela paga com sucesso!');
else
	die('Não foi possível pagar parcela da compra.');