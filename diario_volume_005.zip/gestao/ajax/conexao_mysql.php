<?php
$dbname="nte";
$usuario="nte";
$password="andromeda478050";
$conexao=mysql_connect("localhost",$usuario,$password);
$banco=mysql_select_db($dbname,$conexao);
?>