<?php




$id = intval($_REQUEST['id']);
//$id = ($_POST['id']);

echo "passou $id";
include ("conexao_mysql.php");

$sql = "select * from servidorrec where id='$id'";
mysql_query($sql);
echo json_encode(array('success'=>true));
?>