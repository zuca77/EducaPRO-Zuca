<?php
$dbname="nte";
$usuario="root";
$password="";
$conexao=mysql_connect("localhost",$usuario,$password);
$banco=mysql_select_db($dbname,$conexao);
?>