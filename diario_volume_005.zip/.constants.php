<?php

define('BASE_URL', 'http://localhost');
define('DEBUG', false);

define('REDIS_URL', 'tcp://redis');
define('SESSION_TIME', 60 * 15);

define('GUSER', '');
define('GPWD', '');

define('TAWK_KEY', '');

define('MANUAL_URL', 'http://diario.seduc.ro.gov.br/manual');
