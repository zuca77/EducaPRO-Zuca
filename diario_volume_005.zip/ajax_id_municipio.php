<?php
require 'start.php';
$pdo = new Conexao;

$sql = "SELECT codigo FROM municipio WHERE descricao = :municipio;";
$sth = $pdo->prepare($sql);
$sth->bindParam(':municipio', $_GET['municipio']);

$id_municipio = $sth->execute() ? $sth->fetchColumn() : null;

die($id_municipio);