<?php

session_start();
$login =$_SESSION["login_usuario"];
include ("conexao_mysql.php");

$descricao       = $_POST['descricao'];
$sql = "insert into ativo (descricao) values ('$descricao')";
$qry = mysql_query($sql);


header("Location: formcadativo.php"); 
mysql_close($conexao);
?>

