<?php
require_once "../classes/autoload.php";

$b = new LojaDAO;
$selected = $_POST['selected'];

foreach($b->listAll() as $reg)
{
	echo $reg->id == $selected ? "<option value=\"{$reg->id}\" selected=\"selected\">{$reg->loja}</option>\n" : "<option value=\"{$reg->id}\">{$reg->loja}</option>\n";
}
?>