<?
include ("conexao_mysql.php");

$id=$_GET["codigo"];

echo "$id";

$sql="delete from chamado where codigo = $id";
$qry = mysql_query($sql,$conexao);
mysql_close($conexao);
echo "<script>document.location.href('consulta_chamado.php');</script>";
?>
