<?php
class Gerencia
{
    public static function getAll()
    {
        $pdo = new Conexao;
        $sql = "SELECT codigo, descricao
                  FROM gerencia WHERE ativo = 'S'
                  ORDER BY descricao";
        return $pdo->query($sql)->fetchAll();
    }
}