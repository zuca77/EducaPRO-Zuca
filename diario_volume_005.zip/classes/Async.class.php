<?php

	class Async {

		public static function run($file, $args) {
			$phpbindir = exec("which php");
			$cmd = "{$phpbindir} -f {$file} ";
			foreach ($args as $arg) {
				$cmd = $cmd.$arg.' ';
			}
			$cmd = $cmd.'> /dev/null &';
			exec($cmd);
		}

	}

?>