<?php

class SituacaoReserva {

//Status usados no matricula online

	const RESERVADA = 1;
	const CONSOLIDADA = 2;
	const EXPIRADA = 3;
	const INVALIDADA = 4;
	const CANCELADA = 5;

}