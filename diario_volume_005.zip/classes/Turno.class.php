<?php
/**
* Turno
*/
class Turno {

	public static function getAll() {
		$pdo = new Conexao;
		$sql = "SELECT id, descricao FROM turno ORDER BY descricao";
		return $pdo->query($sql)->fetchAll();
	}
}