<header>

    <?php
        $novidadesNotificacoes = Novidades::getComEstatus();

        $naoVisualisadas = array_filter($novidadesNotificacoes, function ($item) {
            return $item["visualisada"] === null && $item["created_at"] >= "2017-05-22";
        });

        $iniciarPassoAPasso = (bool)array_filter($naoVisualisadas, function ($item){
           return $item['id'] === '14';
        });

        $totalNaoVisualisadas = count($naoVisualisadas);
    ?>

    <nav class="navbar navbar-masthead navbar-default hidden-print">
        <div class="container nav-responsive">
            <div class='wrapper navbar-header collapsed' data-toggle="collapse-side" data-target=".side-collapse">
                <div class="overlay"></div>

                <?php if (Auth::isLogged()): ?>
                    <?php $usuario = Auth::usuario(); ?>
                    <h2 class="navbar-brand">
                        <a class="text-primary" href="<?= !empty($usuario) && isset($usuario['home']) ? url($usuario['home']) : '#' ?>" title="Di�rio Eletr�nico">
                            Di�rio Eletr�nico <small class="text-muted"><?= nomeAmbiente() ?></small>
                        </a>
                    </h2>
                <?php endif;?>

                <ul class='hamburger navbar-toggle' >
                    <li class='first'></li>
                    <li class='second'></li>
                    <li class='third'></li>
                </ul>
            </div>

            <div class="navbar-inverse side-collapse in">
                <nav role="navigation" class="navbar-collapse">
                    <ul class="nav navbar-nav list-group">
                        <li class="text-center">
                            <a class="text-center" href="#">
                                <img alt="Brand" src="<?= img("BrasaoRondonia50x50.png") ?>">
                            </a>
                        </li>
                        <li class="list-group-header">
                            <div class="divider"></div>
                        </li>

                        <!-- Header -->
                        <li class="list-group-item">
                            <div class="panel">
                                <?php if (Auth::isLogged()): ?>
                                    <div class="container">
                                        <p class="text-muted text-center">
                                            <?php $nomeUsuario = explode(' ', $_SESSION['usuario']['nome']);?>
                                            <em><?= $_SESSION['usuario']['cpf'];?></em> <?= $nomeUsuario[0];?><br>
                                            <strong><?= $_SESSION['usuario']['ambienteNome']; ?></strong>
                                        </p>
                                    </div>
                                <?php endif;?>
                            </div>
                        </li>

                        <li class="divider"></li>
                        <?php if (isset($_SESSION['usuario']) && $_SESSION['usuario']['home'] == Auth::INDEX_ADME): ?>
                            <?php if(isset($_SESSION['escola']['inep']) && !empty($_SESSION['escola']['inep'])): ?>

                                <li class="list-group-header" style="height: 50px">
                                    <?php $anos = Ano::getList($_SESSION['escola']['inep']) ?>
                                        <div class="col-xs-5">
                                            <form action="<?php url('seleciona_ano.php') ?>" class="form-horizontal">
                                                <select name="ano" class="form-control pull-left" onchange="this.form.submit()">
                                                    <?php foreach($anos as $ano): ?>
                                                        <option value="<?= $ano['ano'] ?>" <?= $ano["ano"] == $txtano ? " selected" : "" ?>><?= $ano['ano'] ?></option>
                                                    <?php endforeach; ?>
                                                </select>
                                            </form>
                                        </div>

                                        <div class="col-xs-7">
                                            <p class="text-muted text-center">
                                                <em><?= $_SESSION['escola']['inep'] ?></em> <br> <?= $_SESSION['escola']['descricao'] ?>
                                            </p>
                                        </div>
                                    <br>
                                </li>
                            <?php endif;?>
                        <?php endif;?>

                        <!-- Menus -->
                        <li class="list-group-item">
                            <div class="container">
                                <div class="menu-responsive panel-group" id="accordion" role="tablist" aria-multiselectable="true">
                                    <div class="panel">
                                        <div class="panel-heading" role="tab" id="headingOne">
                                            <h4 class="panel-title">
                                                <a class="collapsed" role="button" data-toggle="collapse" data-parent="#accordion" href="#vagas_menu" aria-expanded="false" aria-controls="vagas_menu">
                                                    <span class="sidebar-title h4">Ambientes</span>
                                                </a>
                                            </h4>
                                        </div>
                                        <div id="vagas_menu" class="panel-collapse collapse" role="tabpanel" aria-labelledby="vagas_menu">
                                            <div class="list-group list-group-sidebar-items">
                                                <?php foreach (Auth::usuario()['niveis'] as $key => $nivel): ?>
                                                    <a class="list-group-item" href="/trocar_ambiente.php?permissao=<?= $key ?>">
                                                        <?= $nivel['nome'] ?> <?= isset($nivel['departamento']) ? ' - ' . $nivel['departamento_nome'] : '' ?>
                                                    </a>
                                                <?php endforeach; ?>
                                            </div>
                                        </div>
                                    </div>


                                    <?php Menu::load(Auth::getAmbiente())->navResponsive() ?>

                                    <?php if ($_SESSION['usuario']['home'] != Auth::INDEX_URES): ?>
                                        <?php if (isset($_SESSION['escola']) && !empty($_SESSION['escola']) && $_SESSION['usuario']['home'] == Auth::INDEX_ADME): ?>
                                            <!-- Vagas/Matr�cula -->
                                            <div class="panel">
                                                <div class="panel-heading" role="tab" id="headingOne">
                                                    <h4 class="panel-title">
                                                        <a class="collapsed" role="button" data-toggle="collapse" data-parent="#accordion" href="#vagas_menu" aria-expanded="false" aria-controls="vagas_menu">
                                                            <span class="sidebar-title h4">Vagas/Matr�culas</span>
                                                        </a>
                                                    </h4>
                                                </div>
                                                <div id="vagas_menu" class="panel-collapse collapse" role="tabpanel" aria-labelledby="vagas_menu">
                                                    <div class="list-group list-group-sidebar-items">
                                                        <a class="list-group-item" href="<?php url('escola/chamadaescolar/form_pesquisa_aluno.php') ?>" title="Matr�cula Presencial">Matr�cula</a>
                                                        <a class="list-group-item" href="<?php url('escola/chamadaescolar/form_matricula_online.php') ?>">Matr�cula Online</a>
                                                        <a class="list-group-item" href="<?php url('escola/chamadaescolar/form_inclusao_saldo.php') ?>">Inclus�o de Vagas</a>
                                                        <a class="list-group-item" href="<?php url('escola/chamadaescolar/form_rel_vagaschamadaescolar.php') ?>">Consulta de Vagas</a>
                                                        <a class="list-group-item" href="<?php url('escola/chamadaescolar/rel_alunos.php') ?>">Relat�rio Anal�tico</a>
                                                        <a class="list-group-item" href="<?php url('escola/chamadaescolar/rel_sintetico.php') ?>">Relat�rio Sint�tico</a>
                                                    </div>
                                                </div>
                                            </div>
                                            <!-- Faq -->
                                            <div class="panel">
                                                <div class="panel-heading" role="tab" id="headingOne">
                                                    <h4 class="panel-title">
                                                        <a href="<?php url('escola/faq/faq.php') ?>" class="collapsed not-select">
                                                            <span class="sidebar-title h4">FAQ</span>
                                                        </a>
                                                    </h4>
                                                </div>
                                            </div>
                                        <?php endif; ?>
                                        <!-- Novidades -->
                                        <div class="panel">
                                            <div class="panel-heading" role="tab" id="headingOne">
                                                <h4 class="panel-title">
                                                    <a href="<?php url('novidades/visualisar.php') ?>" class="collapsed not-select">
                                                        <span class="sidebar-title h4">Novidades do di�rio</span>
                                                    </a>
                                                </h4>
                                            </div>
                                        </div>
                                    <?php endif; ?>
                                </div>
                            </div>
                        </li>

                        <?php if ($_SESSION['usuario']['home'] != Auth::INDEX_URES): ?>
                            <?php if (defined('MANUAL_URL')): ?>
                                <li class="list-group-item"><a href="<?= MANUAL_URL ?>" target="_blank">Manual</a></li>
                            <?php endif;?>
                            <li class="list-group-item"><a href="<?php url('sobre.php') ?>">Sobre</a></li>
                        <?php endif;?>
                        <li class="list-group-item">
                            <a href="<?php url('novidades/visualisar.php') ?>">
                                Novidades
                                <?php if ($totalNaoVisualisadas > 0): ?>
                                    <span class="badge badge-warning"><?= $totalNaoVisualisadas; ?></span>
                                <?php endif; ?>
                            </a>
                        </li>

                        <li class="list-group-item"><a href="<?php url('form_altera_senha.php') ?>">Alterar senha</a></li>
                        <li class="list-group-item">
                            <a href="<?php url('logout.php') ?>">
                                SAIR
                                <i class="fa fa-sign-out"></i>
                            </a>
                        </li>
                    </ul>
                    <br>
                    <br>
                </nav>
            </div>
        </div>

        <!--   Navbar  -->
        <?php require_once "_navbar.php"?>
    </nav>

    <div class="container nav-full">
        <?php Menu::load(Auth::getAmbiente())->nav() ?>
        <br>
    </div>

    <div class="visible-xs text-center">
        <img src="<?= asset('img/logo-brasao-rondonia.png') ?>" alt="">
    </div>
</header>

<section id="title">
    <div class="container">
        <p class="text-muted text-center data-extenso">
            <small><?php dataextenso(); ?></small>
        </p>

        <h2>
            <?php echo $title; ?>
            <?php if(isset($subtitle)):?>
                <br><small><?php echo $subtitle ?></small>
            <?php endif;?>

            <?php if(isset($btnNovo)): ?>
                <button type="button" onclick="$('#formNovo').slideToggle()" class="btn btn-sm btn-success">Adicionar Novo</button>
            <?php endif;?>
        </h2>

        <!-- Notifica��es e avisos -->
        <?php require_once "_avisos.php"?>
    </div>

</section>
