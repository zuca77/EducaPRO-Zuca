<div class="nav-full">
    <div class="bg-header-extent">
        <div class="bg-header"></div>
    </div>
    <div class="container">
        <div class="navbar-header">
            <?php if (Auth::isLogged()): ?>
                <?php $usuario = Auth::usuario(); ?>
                <a href="<?= !empty($usuario) && isset($usuario['home']) ? url($usuario['home']) : '#' ?>"
                   class="navbar-brand">
                                <span class="text-primary" title="Di�rio Eletr�nico">
                                Di�rio Eletr�nico
                                <small class="text-muted"><?= nomeAmbiente() ?></small>
                            </span>
                </a>
            <?php endif ?>
        </div>

        <div class="collapse navbar-collapse" id="bs-example-navbar-collapse-1">
            <?php if (isset($_SESSION['escola']) && !empty($_SESSION['escola'])): ?>
                <p class="navbar-text">
                    <small>
                        <b><?= $_SESSION['escola']['inep'] ?></b>
                        <?= $_SESSION['escola']['descricao'] ?>
                    </small>
                </p>
            <?php endif; ?>
            <ul class="nav navbar-nav navbar-right">
                <li class="<?= $iniciarPassoAPasso ? 'passo-a-passo' : '' ?> ambiente" data-step="1" data-intro="Este � o novo menu de permiss�es. Agora voc� pode mudar de ambiente sem precisar sair do sistema.">
                    <a href="#" class="dropdown-toggle" data-toggle="dropdown">
                        <?= Auth::usuario()['ambienteNome'] ?>
                        <b class="caret"></b></a>
                    <ul class="dropdown-menu multi-level">

                        <?php foreach (Auth::usuario()['niveis'] as $key => $nivel):?>
                            <li>
<!--                                Todos os ID's do nivel CRE s�o num�ricos -->
                                <?php if (is_numeric($nivel['abreviacao']) &&  !isset($nivel['departamento'])): ?>
                                    <a data-toggle="modal" data-id="<?= $nivel['abreviacao'] ?>" data-permissao="<?= $key ?>"  href="#modalAmbiente"><?= $nivel['nome'] ?></a>
                                <?php else: ?>
                                    <a name="nte" href="/trocar_ambiente.php?permissao=<?= $key ?>">
                                        <?= $nivel['nome']; ?> <?= isset($nivel['departamento']) ? ' - ' . $nivel['departamento_nome'] : '' ?>
                                    </a>
                                <?php endif; ?>
                            </li>
                        <?php endforeach; ?>

                    </ul>
                </li>
                <?php if (isset($_SESSION['usuario']) && $_SESSION['usuario']['home'] != Auth::INDEX_URES): ?>
                    <li>
                        <a href="<?php url('escola/faq/faq.php') ?>"><b>FAQ</b></a>
                    </li>
                <?php endif;?>

                <?php if (isset($_SESSION['escola']) && !empty($_SESSION['escola']) && $_SESSION['usuario']['home'] == Auth::INDEX_ADME): ?>
                    <li>
                        <a href="#" class="dropdown-toggle" data-toggle="dropdown">
                            <small>Vagas/Matr�culas</small>
                            <b class="caret"></b></a>
                        <ul class="dropdown-menu multi-level">
                            <li><a href="<?php url('escola/chamadaescolar/form_pesquisa_aluno.php') ?>"
                                   title="Matr�cula Presencial">Matr�cula</a></li>
                            <li><a href="<?php url('escola/chamadaescolar/form_matricula_online.php') ?>">Matr�cula
                                    Online</a></li>
                            <li class="divider"></li>
                            <li><a href="<?php url('escola/chamadaescolar/form_inclusao_saldo.php') ?>">Inclus�o de
                                    Vagas</a></li>
                            <li><a href="<?php url('escola/chamadaescolar/form_rel_vagaschamadaescolar.php') ?>">Consulta
                                    de Vagas</a></li>
                            <li class="divider"></li>
                            <li><a href="<?php url('escola/chamadaescolar/rel_alunos.php') ?>">Relat�rio Anal�tico</a>
                            </li>
                            <li><a href="<?php url('escola/chamadaescolar/rel_sintetico.php') ?>">Relat�rio
                                    Sint�tico</a></li>
                        </ul>
                    </li>

                    <?php $anos = Ano::getList($_SESSION['escola']['inep']) ?>
                    <li title="Alternar anos letivos" class="dropdown">
                        <?php if (isset($_SESSION['escola']['inep']) && !empty($_SESSION['escola']['inep'])): ?>
                            <a href="#" class="dropdown-toggle" data-toggle="dropdown" role="button"
                               aria-haspopup="true" aria-expanded="false">
                                <span class="text-primary"><?= $txtano; ?></span><span class="caret"></span>
                            </a>
                            <ul class="dropdown-menu">
                                <?php foreach ($anos as $ano): ?>
                                    <li>
                                        <a href="<?php url('seleciona_ano.php?ano=' . $ano['ano']) ?>"><?= $ano['ano'] ?></a>
                                    </li>
                                <?php endforeach; ?>
                            </ul>
                        <?php endif ?>
                    </li>
                <?php endif ?>

                <?php if (Auth::isLogged()): ?>
                    <li class="dropdown">
                        <a style="position: relative; min-width: 120px; text-align: right;" href="#"
                           class="dropdown-toggle" data-toggle="dropdown">
                            <?php $nomeUsuario = explode(' ', $_SESSION['usuario']['nome']);
                            echo $nomeUsuario[0];
                            ?>
                            <b class="caret"></b>
                        </a>

                        <ul class="dropdown-menu dropdown-menu-account">
                            <li class="active">
                                <div class="navbar-content">
                                    <span class="text-muted"><?= $_SESSION['usuario']['cpf']; ?></span>
                                    <span><?= $_SESSION['usuario']['nome'] ?></span>
                                    <p class="small">
                                        <?php if (isset($_SESSION['escola'])): ?>
                                            <span class="text-muted"
                                                  title="INEP"><?= $_SESSION['escola']['inep']; ?></span>
                                        <?php endif ?>
                                        <span title="N�vel"><?= $_SESSION['usuario']['ambienteNome']; ?></span>
                                    </p>
                                </div>
                                <div class="navbar-footer">
                                    <div class="navbar-footer-content">
                                        <div class="row">
                                            <div class="col-xs-6">
                                                <div class="btn-group">
                                                    <?php if ($_SESSION['usuario']['home'] != Auth::INDEX_URES): ?>
                                                        <?php if (defined('MANUAL_URL')): ?>
                                                            <a href="<?= MANUAL_URL ?>" target="_blank"
                                                               class="btn btn-default btn-sm">Manual</a>
                                                        <?php endif ?>
                                                        <a href="<?php url('sobre.php') ?>"
                                                           class="btn btn-default btn-sm">Sobre</a>
                                                    <?php endif ?>
                                                </div>
                                            </div>
                                            <div class="col-xs-6">
                                                <div class="btn-group">
                                                    <a href="<?php url('form_altera_senha.php') ?>"
                                                       class="btn btn-default btn-sm">Alterar senha</a>
                                                    <a href="<?php url('logout.php') ?>" class="btn btn-danger btn-sm">
                                                        SAIR
                                                        <i class="fa fa-sign-out"></i>
                                                    </a>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </li>
                        </ul>
                    </li>
                <?php endif; ?>

                <li class="dropdown">
                    <a data-step="2" data-intro="Para desativar este tutorial e ver mais detalhes sobre a novidade clique nas suas notifica��es" id="dropdown_notification" role="button" aria-expanded="false" data-toggle="dropdown"
                       data-target="#" href="#"
                       class="notification-icon <?= $totalNaoVisualisadas ? 'has-notification' : '' ?>"
                       title="Veja as novidades do Di�rio Eletr�nico">
                        <div class="notification-box">
                            <i class="fa fa-bell"><span
                                        class="badge-notification-icon"><?= $totalNaoVisualisadas ? $totalNaoVisualisadas : '' ?></span></i>
                        </div>
                    </a>

                    <ul class="dropdown-menu notifications" role="menu" aria-labelledby="dropdown_notification">
                        <li class="notification-heading">
                            <span class="h4">Novidades</span>
                        </li>
                        <li class="divider"></li>
                        <li class="notifications-wrapper">
                            <div class="list-group">
                                <?php foreach ($novidadesNotificacoes as $novidadeNotificacao): ?>
                                    <a href="<?= url("novidades/visualisar.php?id=" . $novidadeNotificacao["id"]) ?>"
                                       class="list-group-item notification-item
                                       <?= ($novidadeNotificacao["visualisada"] === null && $novidadeNotificacao["created_at"] >= "2017-05-22") ? ' active' : '' ?>">

                                        <?= $novidadeNotificacao["titulo"]; ?>
                                        <br>
                                        <span class="text-muted"><?= formataData($novidadeNotificacao["created_at"]); ?></span>
                                    </a>
                                <?php endforeach; ?>
                            </div>
                        </li>
                        <li class="divider"></li>
                        <li class="notification-footer">
                            <h4 class="menu-title">
                                <a href="<?= url("novidades/visualisar.php") ?>" class="btn-link">Ver todas</a>
                            </h4>
                        </li>
                    </ul>
                </li>
            </ul>
        </div>
    </div>
</div>
<?php require_once modal_cre(); ?>

