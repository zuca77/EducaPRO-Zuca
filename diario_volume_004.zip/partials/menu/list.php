<?php
return [
    "admescolar" => [
        [
            "label" => "Escola",
            "submenu" => [
                ["label" => "Dados da escola", "url" => "adme/escola/index.php"],
                ["label" => "Matriz curricular", "url" => "adme/escola/matriz.php"],
                ["label" => "Formas de recupera��o", "url" => "adme/escola/formas_recuperacao.php"],
                ["label" => "Abertura de ano letivo", "url" => "adme/escola/abre_ano.php"],
                ["label" => "Fechamento de ano letivo", "url" => "adme/escola/fecha_ano.php"],
            ],
        ], [
            "label" => "Estudante",
            "submenu" => [
                ["label" => "Procurar estudante", "url" => "escola/aluno/form_pesquisa_aluno_turma.php"],
                ["label" => "Matr�cula individual", "url" => "escola/aluno/form_pesquisa_aluno.php"],
                ["label" => "Abono de faltas", "url" => "escola/nota/form_consulta_abono_faltas.php"],
            ],
        ], [
            "label" => "Turma",
            "submenu" => [
                ["label" => "Todas as turmas", "url" => "escola/turma/form_inclusao_turma.php"],
                ["label" => "Espelho da turma", "url" => "escola/turmamanutencao/form_imprimi_turma_aluno.php"],
                ["label" => "Associar estudante", "url" => "escola/matricula/form_assoc_aluno_tuma.php"],
                ["label" => "Movimentar estudante", "url" => "escola/turmamanutencao/form_consulta_turmaaluno.php"],
                ["label" => "Turmas progress�o parcial / Condi��o especial", "url" => "escola/turmamanutencao/form_turma_aluno_progressao.php"],
                ["label" => "Turmas media��o tecnol�gica", "url" => "escola/turmamanutencao/form_turmas_mediacao_tecnologica.php"],
                ["label" => "Reabrir turma encerrada", "url" => "escola/turma/form_reabertura_turmas_encerradas.php"],
            ],
        ], [
            "label" => "Notas",
            "submenu" => [
                ["label" => "Lan�amento de notas", "url" => "escola/nota/form_nota.php"],
                ["label" => "Lan�amento de recupera��o", "url" => "escola/nota/form_recuperacao.php"],
            ],
        ], [
            "label" => "Componentes eliminados",
            "submenu" => [
                ["label" => "Avalia��o especial", "url" => "escola/nota/form_consulta_aluno_eliminacao.php"],
                ["label" => "ENEM&nbsp;/&nbsp;ENCCEJA", "url" => "escola/nota/form_consulta_aluno_eliminacao_enem.php"],
                ["label" => "Preenchimento de lacuna", "url" => "escola/nota/form_consulta_aluno_eliminacao_lacuna.php"],
                ["label" => "Avalia��es de fora de rede", "url" => "escola/nota/form_consulta_ava_fora_rede.php"],
            ],
        ], [
            "label" => "Servidores",
            "submenu" => [
                ["label" => "Editar dados", "url" => "escola/formealtera.php"],
                ["label" => "Recep��o de servidor", "url" => "escola/form_consulta_memo.php"],
                ["label" => "Devolu��o de professor", "url" => "escola/relatorios/professoresdev.php"],
                ["label" => "Devolu��o de administrativo", "url" => "escola/relatorios/administrativodev.php"],
                ["label" => "Lota��o de professor", "url" => "escola/relatorios/professoresenquadra.php"],
                ["label" => "Lota��o de administrativo", "url" => "escola/relatorios/administrativoenquadra.php"],
            ],
        ], [
            "label" => "Supervis�o",
            "submenu" => [
                ["label" => "Professor X Disciplina", "url" => "escola/supervisao/professor_disciplina.php"],
                ["label" => "Professor X Turma", "url" => "escola/supervisao/professor_turma.php"],
                ["label" => "Calend�rio letivo", "url" => "escola/calendario/calendario_letivo.php"],
                ["label" => "Previs�o dias di�rio", "url" => "escola/calendario/form_pesquisa_professor_dia_dairio.php"],
                ["label" => "Pr�via conte�do", "url" => "escola/calendario/previa_conteudo.php"],
                ["label" => "Libera��o de etapas", "url" => "escola/supervisao/form_liberacao_bim.php"],
                ["label" => "Libera��o de acesso", "url" => "escola/supervisao/busca_professor_senha.php"],
                ["label" => "Frequ�ncia escolar", "url" => "escola/calendario/form_pesquisa_professor_frequencia.php"],
                ["label" => "For�ar fechamento de etapa", "url" => "escola/turmamanutencao/form_forca_fechamento_etapas.php"],
            ],
        ], [
            "label" => "Relat�rios",
            "submenu" => [
                [
                    "group" => "Gerais",
                    "itens" => [
                        ["label" => "Boletim", "url" => "escola/nota/form_imprimi_turma_aluno.php"],
                        ["label" => "Ficha individual", "url" => "escola/nota/form_imprimi_fichaindividual.php"]
                    ]
                ], [
                    "group" => "Atas finais",
                    "itens" => [
                        ["label" => "ER | EMTI", "url" => "escola/nota/form_turma_atafina_ef.php"],
                        ["label" => "EJA", "url" => "escola/nota/form_turma_atafina_eja.php"],
                        ["label" => "Especial", "url" => "escola/nota/form_turma_atafina_especial.php"],
                        ["label" => "Media��o Tecnol�gica", "url" => "escola/nota/form_turma_atafina_mediacao_tecnologica.php"],
                    ]
                ], [
                    "group" => "Notas",
                    "itens" => [
                        ["label" => "Quadro de notas", "url" => "escola/nota/form_nota_detalhe_secretaria.php"],
                        ["label" => "Quadro demonstrativo", "url" => "escola/nota/form_quadrodemonstrativo.php"],
                    ]
                ], [
                    "group" => "Estudantes",
                    "itens" => [
                        ["label" => "Todos", "url" => "escola/aluno/rel_alunos.php"],
                        ["label" => "Por situa��o", "url" => "escola/aluno/rel_alunos_situacao.php"],
                        ["label" => "Bolsa Fam�lia", "url" => "escola/aluno/rel_alunos_bf.php"],
                        ["label" => "Transporte Escolar", "url" => "escola/aluno/rel_alunos_transpescolar.php"],
                    ]
                ], [
                    "group" => "Consolida��o",
                    "itens" => [
                        ["label" => "ER", "url" => "escola/nota/estatistica_refatoracao.php?modalidade=1"],
                        ["label" => "ER EMTI", "url" => "escola/nota/estatistica_refatoracao.php?modalidade=5"],
                        ["label" => "EJA", "url" => "escola/nota/estatistica_refatoracao.php?modalidade=2"],
                        ["label" => "Especial", "url" => "escola/nota/estatistica_refatoracao.php?modalidade=3"],
                        ["label" => "Media��o Tecnol�gica", "url" => "escola/nota/estatistica_refatoracao.php?modalidade=4"],
                    ]
                ],
            ],
        ],
    ],
    "admin" => [
        [
            "label" => "Usu�rio",
            "url" => "admin/formcadusuario.php"
        ], [
            "label" => "Escola",
            "submenu" => [
                ["label" => "Todas as escolas", "url" => "admin/formcadastroescola.php"],
                ["label" => "Extens�es", "url" => "escola/turma/extensoes.php"],
            ]
        ], [
            "label" => "Turmas",
            "url" => "admin/form_turmas.php"
        ], [
            "label" => "Estudantes",
            "submenu" => [
                ["label" => "Editar", "url" => "admin/form_editar_aluno.php"],
                ["label" => "Movimentar", "url" => "admin/form_movimentar_aluno.php"],
                ["label" => "Buscar Turma", "url" => "admin/form_turma_aluno.php"],
                ["label" => "Importar notas", "url" => "admin/importa_lancamentos_aluno_movimentado.php"],
            ]
        ], [
            "label" => "Chamada escolar",
            "url" => "admin/form_chamada_escolar.php"
        ], [
            "label" => "Informativos",
            "url" => "admin/informativos.php"
        ], [
            "label" => "FAQs",
            "url" => "admin/form_faq.php"
        ], [
            "label" => "Logger",
            "url" => "admin/formlogger.php"
        ], [
            "label" => "Portal do estudante",
            "url" => "admin/responsaveis.php"
        ]
    ],
    "consulta" => [
        [
            "label" => "Escola",
            "submenu" => [
                ["label" => "Todas as escolas", "url" => "consulta/escolas.php"],
                ["label" => "Extens�es", "url" => "consulta/extensoes.php"],
            ]
        ], [
            "label" => "Turmas",
            "url" => "consulta/turmas.php"
        ], [
            "label" => "Estudantes",
            "submenu" => [
                ["label" => "Buscar", "url" => "consulta/buscar_aluno.php"],
                ["label" => "Buscar estudante na turma", "url" => "consulta/form_turma_aluno.php"],
            ]
        ]
    ],
    "cre" => [
        [
            "label" => "Acompanhamento Escolar",
            "submenu" => [
                ["label" => "Chamada Escolar", "url" => "cre/form_chamada_escolar.php"],
                ["label" => "Utiliza��o do Sistema", "url" => "cre/utilizacao_sistema.php"],
                ["label" => "Pesquisar aluno", "url" => "escola/aluno/form_pesquisa_aluno_bf.php"]
            ]
        ], [
            "label" => "Alterar Dados do Servidor",
            "url" => "cre/formealtera.php",
        ], [
            "label" => "Movimenta��o de Servidor",
            "submenu" => [
                ["label" => "Recep��o de servidor", "url" => "cre/form_consulta_memo.php"],
                ["label" => "Inclus�o por CPF", "url" => "nam/form_busca_memo_cpflota.php"],
                ["label" => "Relota��o", "url" => "nam/form_mov_serv.php"],
            ]
        ], [
            "label" => "Servidores",
            "submenu" => [
                ["label" => "Professores", "url" => "cre/relatorios/professores.php"],
                ["label" => "Administrativo", "url" => "cre/relatorios/administrativo.php"],
                ["label" => "Relota��o", "url" => "cre/form_mov_serv.php"],
            ]
        ], [
            "label" => "Relat�rios",
            "submenu" => [
                ["label" => "An�lise de Ambiente Escolar", "url" => "nam/form_rel_lotacao.php"]
            ]
        ]
    ],
    "bolsafamilia" => [
        ["label" => "Pesquisar aluno", "url" => "escola/aluno/form_pesquisa_aluno_bf.php"]
    ],
    "dge" => [
        [
            "label" => "Relat�rio",
            "submenu"  => [
                ["label" => "Notas de alunos", "url" => "dge/relatorios/form_notas_alunos.php"]
            ]
        ], [
            "label" => "FAQs",
            "url" => "admin/form_faq.php"
        ]
    ],
    "escola" => [
        ["label" => "Registro Aula LIE", "url" => "formregaulas.php"],
        ["label" => "Registro de Capacita��o LIE", "url" => "formregformacao.php"],
        ["label" => "Registro de Assessoria", "url" => "formregassessoria.php"],
        ["label" => "Registro Extra Classe LIE", "url" => "formregextraclasse.php"],
        ["label" => "Registro Aula TELE SALA", "url" => "formregaulastvescola.php"],
        ["label" => "Gest�o Pedag�gica", "url" => "formpesquisaaulaescola.php"],
    ],
    "gti" => [
        ["label" => "Di�rio eletr�nico", "url" => "nam/form_consulta_escolar.php"],
        [
            "label" => "Di�rio",
            "submenu" => [
                ["label" => "Transfer�ncia", "url" => "escola/aluno/form_pesquisa_aluno_gti.php"],
                ["label" => "Dados da escola", "url" => "formpesqescolagti.php"],
                ["label" => "Movimenta��o | Libera��o", "url" => "formpesqescolagti_diario.php"]
            ]
        ]
    ],
    "lotacao" => [
        [
            "label" => "Alterar dados do servidor",
            "url" => "form_pesq_servidor_lota.php"
        ],
        [
            "label" => "Quandro de necessidade",
            "submenu" => [
                ["label" => "Professor", "url" => "nam/quadronecessidade/form_inclusao_saldo.php"],
                ["label" => "Administrativo", "url" => "nam/quadronecessidade/form_inclusao_saldo_tec.php"],
                ["label" => "Movimenta��o", "url" => "nam/quadronecessidade/form_pesq_quadrodevagas.php"],
            ]
        ], [
            "label" => "Lota��o",
            "url" => "nam/form_busca_memo_cpflota.php"
        ], [
            "label" => "Movimenta��o do servidor",
            "url" => "nam/form_mov_serv.php"
        ], [
            "label" => "Relat�rios",
            "submenu" => [
                ["label" => "Relat�rio Geral", "url" => "nam/formpesquisareclota.php"],
                ["label" => "Lota��o de Professores", "url" => "nam/formpesquisaprofessor.php"],
                ["label" => "Memorandos de Lota��o", "url" => "nam/form_memo_servidor.php"],
                ["label" => "An�lise de Amb Escolar", "url" => "nam/form_rel_lotacao.php"],
                ["label" => "Amb Escolar T�cnico", "url" => "nam/form_rel_lotacao_tecnico.php"],
                ["label" => "Hist�rico Lota��o", "url" => "nam/form_pesquisa_serv.php"],
            ]
        ]
    ],
    "nam" => [
        [
            "label" => "Servidor",
            "submenu" => [
                ["label" => "Inclus�o", "url" => "nam/form_incluir_servidor.php"],
                ["label" => "Altera��o", "url" => "form_pesq_servidor_nam.php"]
            ]
        ], [
            "label" => "Contrato",
            "submenu" => [
                ["label" => "Inclus�o", "url" => "nam/form_dados_contratos.php"],
                ["label" => "Altera��o", "url" => "nam/form_busca_contrato.php"]
            ]
        ], [
            "label" => "Memorando",
            "submenu" => [
                ["label" => "Inclus�o", "url" => "nam/form_memo_lotacao.php"],
                ["label" => "Pesquisa individual", "url" => "nam/form_busca_memo_cpf.php"]
            ]
        ], [
            "label" => "Relat�rio",
            "submenu" => [
                ["label" => "Relat�rio Geral", "url" => "nam/formpesquisarec.php"],
                ["label" => "An�lise de Amb Escolar", "url" => "nam/form_rel_lotacao.php"],
                ["label" => "Hist�rico Lota��o", "url" => "nam/form_pesquisa_serv.php"],
            ]
        ]
    ],
    "proaf" => [
        [
            "label" => "Relat�rios",
            "submenu" => [
                ["label" => "Registros por escola", "url" => "proaf/relatorios/form_data_registros_escola.php"]
            ]
        ]
    ],
    "professor" => [
        [
            "label" => "Lan�amento de notas",
            "submenu" => [
                ["label" => "Bimestral / Modular", "url" => "professor/nota.php"],
                ["label" => "Recupera��o", "url" => "professor/recuperacao.php"],
            ]
        ], [
            "label" => "Lan�amento de conte�do e frequ�ncia",
            "url" => "professor/frequencia_busca.php"
        ], [
            "label" => "Quadro de notas",
            "url" => "professor/quadro_notas.php"
        ], [
            "label" => "Relat�rios",
            "submenu" => [
                ["label" => "Canhotos", "url" => "professor/form_canhoto.php"],
                ["label" => "Conte�dos", "url" => "professor/form_conteudo.php"],
                ["label" => "Frequ�ncia", "url" => "professor/form_frequencia.php"],
            ]
        ]
    ],
    "ures" => [
        []
    ]
];