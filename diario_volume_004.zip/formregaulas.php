<?php
 session_start();
if (isset($_SESSION["login_usuario"]))
  {
     $login =  $_SESSION["login_usuario"];
     $nte   =  $_SESSION["nivel_usuario"];
	 $inep  =  $_SESSION["inep_usuario"] ;   
	 include ("funcoes.php");
     echo  saudacoes()."   ". "$login" ."  -  ". $nte."  ".dataextenso();
  }
 else
  {
     		 header("Location: login.php");
  }  	 

?>

<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
   <meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1" />
   <title>NTE-Porto Velho</title>
  
   <link rel="stylesheet" href="estilos.css" type="text/css">
  
<style>
a:visited {
	color: #FFFF00;
	text-decoration: none;
}
a:active {
	color: #00FF00;
	text-decoration: none;
}
body,td,th {
	color: #0000FF;
}
a:link {
	text-decoration: none;
}
a:hover {
	text-decoration: none;
}
.style5 {color: #0000FF}
-->
</style>


<script language="javascript" src="generic.js"></script>	

</head>
<body>
    <table>
      <tr>
        <td height="0"></td>
      </tr>
    </table>

  <body onLoad="data();">
  <div id="geral">
          <div id="topo">
           <img src= "public/img/LogoGovernoSite_small.jpg"/>
           <img src= "public/img/LayoutSGA_small.jpg"/>
         </div>

 <div id="corpo" class="fontecorpo">
	<table border=0 width="590" height="400" >
	<form name="formregistroaula" action="insere_regaula.php"  method="post">
   <tr>
    <td height="11"></td>
   </tr>
<br>
<br>
<br>
<br>
<?php
$id = $inep;
$sql = "select * from escola where inep = $id";
$resposta = mysql_query( $sql );
while ( $linha = mysql_fetch_array( $resposta )) 
   {
?>
   <tr>
    <td height="30"></td>
   </tr>

<tr><td>INEP </td><td><input  name="inep"  size="10" maxlength="10" type="text" readonly="true" value="<?php echo $linha["inep"];?>" onKeyPress="return Enum(event)"></td> </tr>
<tr><td>Descri��o</td><td><input  name="descricao" size="60" readonly="true" type="text" value="<?php echo $linha["descricao"];?>" onBlur=   "maiusculalteracadescola()"></td></tr>

	<tr> 
     <td>Endere�o</td>
	 <td>
 <input name="endereco" type="text" id="endereco" size="60" MAXLENGTH="60"  readonly="true" value="<?php echo $linha["endereco"];?>"    onBlur=   "maiusculalteracadescola()"> </td></tr>
      </td>
	</tr>

	<tr> 
     <td>Bairro</td><td>
       <input name="bairro" type="text" id="bairro" size="25" MAXLENGTH="25" readonly="true" value="<?php echo $linha["bairro"];?>" onBlur=   "maiusculalteracadescola()">
	  N
	   <input name="nr" type="text" id="nr" size="10" MAXLENGTH="4" readonly="true" value="<?php echo $linha["numero"];?>" onKeyPress="return Enum(event)" >
	   </td>	   
	</tr>

<?php
$codmuni=$linha["municipio"];
$sqlconulta        = "select codigo,descricao,nte from municipio where codigo = $codmuni";
$respconsulta      = mysql_query( $sqlconulta );
while ( $dado = mysql_fetch_array( $respconsulta )) 
  {
   $descricao = $dado["descricao"];
   $codigo    = $dado["codigo"];
   $nte       = $dado["nte"];
  }
}
?>
<tr><td>Munic�pio</td><td>
 <input  name="municodigo" size="8" type="text"  readonly="true" value="<?php echo "$codigo";?>">
 <input  name="municipio1" size="40" type="text" readonly="true" value="<?php echo "$descricao";?>">
 <input  name="nte"        size="3" type="text"  readonly="true" value="<?php echo "$nte";?>"></td>
</tr>
     <tr> 
            <td>Modalidade <img src= "imagem/check.gif"/></td><td>
			    <select name="nivel">
                <option value="">...Selecione o N�vel...</option>
                <option value="FR">FUNDAMENTAL REGULAR</option>
                <option value="MR">MEDIO REGULAR</option>
                <option value="FE">FUNDAMENTAL EJA</option>
                <option value="ME">MEDIO EJA</option>
                <option value="EI">EDUCACAO INDIGENA</option>
				<option value="EE">EDUCACAO ESPECIAL </option>
              </select> 
			</td>
          </tr>

     	  <tr> 
            <td>S�rie <img src= "imagem/check.gif"/></td>
			<td><select name="serie">
                <option value="">...Selecione a S�rie...</option>
                <option value="1">1 ANO</option>
                <option value="2">2 ANO</option>
                <option value="3">3 ANO</option>
                <option value="4">4 ANO</option>
                <option value="5">5 ANO</option>
                <option value="6">6 ANO</option>
                <option value="7">7 ANO</option>
                <option value="8">8 ANO</option>
                <option value="9">9 ANO</option>
              </select> 
			</td>
          </tr>

		  <tr> 
            <td>Turma <img src= "imagem/check.gif"/></td><td>
                <select name="turma">
                <option value="">...Selecione a Turma</option>
                <option value="A">A</option>
                <option value="B">B</option>
                <option value="C">C</option>
                <option value="D">D</option>
                <option value="E">E</option>
                <option value="F">F</option>
                <option value="G">G</option>
                <option value="H">H</option>
                <option value="I">I</option>
                <option value="J">J</option>
        		<option value="L">L</option>
        		<option value="K">K</option>
        		<option value="M">M</option>
        		<option value="N">N</option>
        		<option value="O">O</option>
        		<option value="P">P</option>
        		<option value="Q">Q</option>
        		<option value="R">R</option>
        		<option value="S">S</option>
        		<option value="T">T</option>
        		<option value="U">U</option>
        		<option value="V">V</option>
        		<option value="W">W</option>																																																								                <option value="X">X</option>																																																
        		<option value="Z">Z</option>																																																
                <option value="1">1</option>
                <option value="2">2</option>
                <option value="3">3</option>
                <option value="4">4</option>
                <option value="5">5</option>
                <option value="6">6</option>
                <option value="7">7</option>
                <option value="8">8</option>
                <option value="9">9</option>
                <option value="10">10</option>
        		<option value="11">11</option>
        		<option value="12">12</option>
        		<option value="13">13</option>
        		<option value="14">14</option>
        		<option value="15">15</option>
        		<option value="16">16</option>
        		<option value="17">17</option>
        		<option value="18">18</option>
        		<option value="19">19</option>
        		<option value="20">20</option>
        		<option value="21">21</option>
        		<option value="22">22</option>
        		<option value="23">23</option>																																																								                <option value="24">24</option>																																																
        		<option value="25">25</option>																																																
                <option value="26">26</option>
        		<option value="27">27</option>
        		<option value="28">28</option>
        		<option value="29">29</option>
        		<option value="30">30</option>
        		<option value="31">31</option>
        		<option value="32">32</option>
        		<option value="33">33</option>
        		<option value="34">34</option>
        		<option value="35">35</option>
        		<option value="36">36</option>
        		<option value="37">37</option>
        		<option value="38">38</option>
        		<option value="39">39</option>																																																								                <option value="40">40</option>																																																
        		<option value="41">41</option>																																																
        		<option value="42">42</option>																																													
        		<option value="43">43</option>																																													
              </select> 
			 </td>
          <tr>
          
  	  <tr> 
		    <td>Turno <img src= "imagem/check.gif"/></td><td>
              <select name="turno">
                <option value="">...Selecione o Turno..</option>
                <option value="M">MANHA</option>
                <option value="T">TARDE</option>
                <option value="N">NOITE</option>
              </select>
			 </td>
          </tr>

		  <tr> 
		    <td>Disciplina <img src= "imagem/check.gif"/></td><td>
              <select name="disciplina">
                <option value="">...Selecione a Disciplina..</option>
                <option value="PORTUGUES">PORTUGUES</option>
                <option value="MATEMATICA">MATEMATICA</option>
                <option value="HISTORIA">HISTORIA</option>
                <option value="GEOGRAFIA">GEOGRAFIA</option>
                <option value="INGLES">INGLES</option>
                <option value="ESPANHOL">ESPANHOL</option>				
                <option value="FILOSOFIA">FILOSOFIA</option>
                <option value="ARTES">ARTES</option>
                <option value="FISICA">FISICA</option>								
                <option value="QUIMICA">QUIMICA</option>												
                <option value="ED FISICA">ED FISICA</option>																
                <option value="ETICA CIDADANIA">ETICA CIDADANIA</option>																
                <option value="INFORMATICA">INFORMATICA</option>																
                <option value="BIOLOGIA">BIOLOGIA</option>																                
                <option value="SOCIOLOGIA">SOCIOLOGIA</option>																						
                <option value="CIENCIA">CIENCIA</option>																										
                <option value="OUTROS">OUTROS</option>																
              </select>
			 </td>
          </tr>

		  <tr> 
		    <td>Recurso Pedagogico <img src= "imagem/check.gif"/></td><td>

              <select name="recurso">
                <option value="">...Selecione Recurso..</option>
                <option value="SOFTWARE">SOFTWARE</option>
                <option value="INTERNET">INTERNET</option>
              </select>
			 </td>
          </tr>

		  <tr> 
		    <td>Tipo <img src= "imagem/check.gif"/></td><td>
			    <select name="tipo">
                <option value="">...Selecione Recurso..</option>
                <option value="E">EDUCATIVO</option>
                <option value="A">APLICATIVO</option>
              </select>
              Qual ?&nbsp;&nbsp;<input name="qual" type="text" id="qual" size="30" maxlength="40" onblur= "maiuscularegaula()" /></td>
          </tr>

     <tr> 
      <td>Descri��o <img src= "imagem/check.gif"/></td>
	  <td> 
       <input name="descrecurso" type="text" id="descrecurso" size="60" MAXLENGTH="140" onblur= "maiuscularegaula()" /></td>
     </tr>
     <tr> 
      <td>Conte�do <img src= "imagem/check.gif"/></td><td> 
      <input name="conteudo" type="text" id="conteudo" size="60" MAXLENGTH="100" onblur= "maiuscularegaula()" />
	 </td>
             </tr>   
   <tr> 	  
	  <td>Data<img src= "imagem/check.gif"/></td><td> 
        <input name= "dtabertura" type="text" id="dtabertura" size=15 maxlength=10 readonly="true"  align="right"onKeyPress="formatar(this, '##.##.####')">
		
<script>		
var data = new Date();
dia = data.getDate();
mes = data.getMonth()+1;
ano = data.getFullYear();
document.formregistroaula.dtabertura.value = (dia+ "."+mes + "." +ano);
</script></p>
	
		</td>
     </tr>
		  <tr> 
		    <td>Professor <img src= "imagem/check.gif"/></td><td><input name="professor" type="text" id="professor" size="40" MAXLENGTH="40" onBlur="maiuscularegaula()">
			</td>
     </tr>

		    <td>Obs.</td><td><input name="obs" type="text" id="obs" size="60" MAXLENGTH="60"  title="Relatar coment�rios de aulas que n�o foram registradas por falta de Internet." onBlur="maiuscularegaula()">
			</td>
     </tr>

   <td>Total de Alunos Aula <img src= "imagem/check.gif"/></td><td><input name="nalunos"  type="text" id="nalunos" size="3" MAXLENGTH="3"  title="Informa o n�mero de alunos que frequentou a aula." onKeyPress="return Enum(event)">
			</td>
     </tr>

      <input type=hidden name=tpaula id=tpaula value="NORMAL">

			<tr> 

             <td></td><td align="justify">
               
 <input name="submit"  type="submit"  value="Gravar" title="Grava Dados" onClick="javascript:return validaregaula();" >  
             </td>
      </tr>
   </table>
 </div>
	
	
    <div id="menu" class="fonte" align="left">
 	    <p>&nbsp; </p><br><br>
      <h3 align="center" class="style5" >Registro Aula</h3>
   	  <ul  class="menu_vertical">

      </ul>			
<tr>
<br>

<li><a href="/relatorios/relacompanhaaula.php?codigo=<?php echo $inep;?>"  title="Acessa Aula(s) Resgistrada(s) at� 30 Dias Anteriores." >Acompanhamento</a>
<li><a href="mnescola.php"     title="Retorna ao Menu Principal">Volta</a>


<script>		
var   data = new Date();
var dia = data.getDate();
var mes = data.getMonth()+1;
var ano = data.getFullYear();

document.formregistroaula.dtinicial.value = (dia+ "/"+mes + "/" +ano);
document.formregistroaula.dtfinal.value   = (dia+ "/"+mes + "/" +ano);
</script></p>

	
	
	
	</div>
</div>    
	 <div id="rodape" class="fonterodape">
     </div>   

</body>
</html>
