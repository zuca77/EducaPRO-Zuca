<?php
require_once __DIR__.'../../start.php';
$pdo = new Conexao;

Auth::whiteList(array('PROF'));

$title = "Lan�amento de Notas";
$subtitle = 'Liberado para turmas abertas';

if($txtano >=2017)
{
	$turmasDependencia = Turma::$turmasRetencaoParcial;
}
else {
	$turmasDependencia = Turma::$turmasDependencia;
}

$turmasMediacaoTecnologica = Turma::$turmasMediacaoTecnologica;

$cargaHorariaAvaliacao = GradeCurricular::CARGA_HORARIA_AVALICACAO;

$disciplinas = array();

$sql = "SELECT DISTINCT t.id, t.descricao
				FROM turma t
					JOIN turmaprofessor tp ON tp.id_turma = t.id
				WHERE t.inep = :inep
	        AND t.ano = :ano
	        AND tp.cpf = :usuario
	        AND ((t.fechado IS NULL) OR (t.fechado = 'N'))
				ORDER BY descricao";
$sth = $pdo->prepare($sql);
$sth->bindParam(':ano', $_SESSION['txtano']);
$sth->bindParam(':inep', $_SESSION['escola']['inep']);
$sth->bindParam(':usuario', $_SESSION['usuario']['cpf']);
$turmas = $sth->execute() ? $sth->fetchAll() : null;

if(isset($_GET['t']) && !empty($_GET['t'])) {
	$turma = Turma::get($_GET['t']);
	$turmaMediacaoTecnologica = in_array($turma['turmas'], $turmasMediacaoTecnologica);

	if (isset($turma)) {
		$disciplinas = Turma::getDisciplinasProfessor($inep, $turma['id'], $_SESSION['usuario']['cpf']);
		$turmaEja = Turma::modalidadeEja($turma['id']);
	}
}

if(isset($_GET['d']) && !empty($_GET['d'])) {
	$sql = "SELECT codigo as id, descricao FROM habilitacao WHERE codigo = :id;";
	$sth = $pdo->prepare($sql);
	$sth->bindParam(':id', $_GET['d']);
	$disciplina = $sth->execute() ? $sth->fetch() : null;
}

if(isset($disciplina) && isset($turma)) {
	$id_turma = $_GET['t'];
	$id_disciplina = $_GET['d'];

	if (in_array($turma['turmas'], $turmasDependencia) || $turmaMediacaoTecnologica) {

		$sql = "SELECT a.id AS id_aluno,ta.n_chamada AS chamada,ta.situacao,t.id,a.nome, sa.descricao AS situacaodesc
						FROM turma_aluno ta
							JOIN turma t ON t.id = ta.id_turma
							JOIN aluno a ON a.id = ta.id_aluno
							JOIN turma_dep_aluno_disciplina dp ON dp.id_turma = t.id AND dp.id_aluno = a.id
							JOIN tipo_mov_aluno sa ON sa.id = ta.situacao
						WHERE t.ano = :ano
							AND t.inep = :inep
							AND t.id = :id_turma
							AND dp.id_disciplina = :id_disciplina
						ORDER BY ta.n_chamada";
		$sth = $pdo->prepare($sql);
		$sth->bindParam(':id_disciplina', $id_disciplina);
	} else {
		$sql = "SELECT a.id AS id_aluno,ta.n_chamada AS chamada,ta.situacao,t.id,a.nome, sa.descricao AS situacaodesc
						FROM turma_aluno ta
							JOIN turma t ON t.id = ta.id_turma
							JOIN aluno a ON a.id = ta.id_aluno
							JOIN tipo_mov_aluno sa ON sa.id = ta.situacao
						WHERE t.ano = :ano
							AND t.inep = :inep
							AND t.id = :id_turma
						ORDER BY ta.n_chamada";
		$sth = $pdo->prepare($sql);
	}

	$sth->bindParam(':inep', $_SESSION['escola']['inep']);
	$sth->bindParam(':ano', $_SESSION['txtano']);
	$sth->bindParam(':id_turma', $id_turma);
	$alunos = $sth->execute() ? $sth->fetchAll() : array();
	$bloqueios = array(SituacaoAluno::REMANEJADO, SituacaoAluno::TRANSFERIDO);

	$id_disciplina_etapa = ($turmaMediacaoTecnologica) ? $_GET['d'] : null;
	$etapasLiberadas = Etapa::etapasLiberadas($inep, $txtano, $turma['modalidade'], $id_disciplina_etapa);

	$cargaDisciplina = GradeCurricular::cargaDisciplina($_GET['t'], $_GET['d']);
}

?><!DOCTYPE html>
<html>
	<head>
		<?php require_once page_head(); ?>
		<style>tr.row-nota input { width: 60px !important; }</style>
	</head>
	<body>
		<?php require_once page_header(); ?>

		<div class="container">
			<form class="well well-sm form-busca" method="get" action="/professor/nota.php">
				<div class="row">
					<div class="col-md-8">
						<div class="form-group">
							<label for="t">Turma</label>
							<select name="t" id="t" class="form-control chosen turma-select" required >
								<option value=""></option>
								<?php foreach ($turmas as $t): ?>
									<option value="<?php echo $t['id'] ?>" <?php echo (isset($_GET['t']) && $t['id']==$_GET['t']) ? 'selected' : '' ?>>
										<?php echo $t['descricao'] ?>
									</option>
								<?php endforeach ?>
							</select>
						</div>
					</div>
					<div class="col-md-4">
						<div class="form-group">
							<label for="d">Disciplina</label>
							<select name="d" id="d" class="form-control chosen disciplina-select">
								<option value=""></option>
								<?php foreach ($disciplinas as $d): ?>
									<option value="<?php echo $d['id'] ?>" <?php echo (isset($_GET['d']) && $d['id']==$_GET['d']) ? 'selected' : '' ?>>
										<?php echo $d['descricao'] ?>
									</option>
								<?php endforeach ?>
							</select>
						</div>
					</div>
				</div>

				<p id="finish">
					<input type="submit" class="btn btn-primary"  value="PESQUISAR">
					<button class="btn btn-default btn-back pull-right">Voltar</button>
				</p>
			</form>

			<?php if(isset($disciplina) && isset($turma)): ?>
			<form class="form-inline submit-wait" action="<?php url('escola/nota/altera_notas.php') ?>" method="post">
				<div class="table-responsive">
					<table class="table table-bordered table-condensed">
						<tr>
							<th width="10">Turma</th>
							<th colspan="2" class="text-primary"><?php echo $turma['descricao'] ?></th>
							<td width="10"><a href="<?php url('professor/nota.php') ?>" title="Deselecionar turma" class="btn btn-xs btn-default pull-right">x</a></td>
						</tr>
						<tr>
							<th width="10">Disciplina</th>
							<th class="text-danger"><?php echo $disciplina['descricao']; ?></th>
							<?php if (isset($cargaDisciplina)): ?>
								<th width="10" class="text-right" title="Carga hor�ria">C.H.</th>
								<td><b class="text-warning"><?php echo $cargaDisciplina ?></b></td>
							<?php endif ?>
						</tr>
					</table>
				</div>

				<input type="hidden" name="id_turma" value="<?php echo $turma['id']; ?>">
				<input type="hidden" name="id_disciplina" value="<?php echo $disciplina['id']; ?>">
				<input type="hidden" name="professor" value="<?php echo $_SESSION['usuario']['cpf']; ?>">
				<input type="hidden" name="form_prof" value="<?php echo true ?>">

				<div class="table-responsive">
					<table class="table table-bordered table-condensed table-hover table-striped">
						<thead>
							<tr>
								<th class="text-center" width="30">N�</th>
								<th>Nome do estudante</th>
								<?php if ($turmaMediacaoTecnologica): ?>
									<th width="120" class="text-center">Avalia��o I</th>
									<th width="120" class="text-center">Avalia��o II</th>
									<th width="120" class="text-center">Avalia��o III</th>
									<th width="130" class="text-center">Ava. Extra Classe</th>
								<?php else: ?>
									<th width="120" class="text-center">Nota 1� Bim</th>
									<th width="120" class="text-center">Nota 2� Bim</th>
									<?php if (!$turmaEja): ?>
									<th width="120" class="text-center">Nota 3� Bim</th>
									<th width="120" class="text-center">Nota 4� Bim</th>
									<?php endif ?>
								<?php endif ?>
								<th width="160">Situa&ccedil;&atilde;o</th>
								<th width="20"></th>
							</tr>
						</thead>
						<tbody>
							<?php foreach($alunos as $aluno):
								$id_aluno = $aluno['id_aluno'];
								$nota = Nota::get($id_turma, $id_disciplina, $id_aluno, null, false);
								$bloqueado = in_array($aluno["situacao"], $bloqueios);

								$disable = $bloqueado ? "disabled" : "";
							?>
							<tr class="row-nota">
								<td class="text-center">
									<input type="hidden" name="id_aluno[]" value="<?php echo $id_aluno; ?>" <?php echo $disable ?>>
									<?php echo $aluno["chamada"]; ?>
								</td>
								<td><?php echo $aluno["nome"]; ?></td>

								<td class="text-center">
								<?php if (in_array(Etapa::BIM1, $etapasLiberadas) || ($turmaMediacaoTecnologica && (in_array(Etapa::MODULAR, $etapasLiberadas) || in_array(Etapa::MODULAR_2_ANO, $etapasLiberadas)))): ?>
									<input type="text" name="<?php echo "nota1[{$id_aluno}]"; ?>" class="mask-nota form-control input-sm" maxlength="4" value="<?php echo $nota['nota1'] ?>" id="txtnota" onblur="validacampo(this, 0);" <?php echo $disable ?>>
								<?php else: ?>
									<input type="hidden" name="<?php echo "nota1[{$id_aluno}]"; ?>" value="<?php echo $nota['nota1'] ?>">
									<input type="text" class="mask-nota form-control input-sm" maxlength="4" value="<?php echo $nota['nota1'] ?>" id="txtnota" disabled title="Etapa Bloqueada">
								<?php endif ?>
								</td>

								<td class="text-center">
								<?php if (in_array(Etapa::BIM2, $etapasLiberadas) || ($turmaMediacaoTecnologica && (in_array(Etapa::MODULAR, $etapasLiberadas) || in_array(Etapa::MODULAR_2_ANO, $etapasLiberadas)))): ?>
									<input type="text" name="<?php echo "nota2[{$id_aluno}]"; ?>" class="mask-nota form-control input-sm" maxlength="4" value="<?php echo $nota['nota2'] ?>" id="txtnota" onblur="validacampo(this, 0);" <?php echo $disable ?>>
								<?php else: ?>
									<input type="hidden" name="<?php echo "nota2[{$id_aluno}]"; ?>" value="<?php echo $nota['nota2'] ?>">
									<input type="text" class="mask-nota form-control input-sm" maxlength="4" value="<?php echo $nota['nota2'] ?>" id="txtnota" disabled title="Etapa Bloqueada">
								<?php endif ?>
								</td>

								<?php if (!$turmaEja): ?>
								<td class="text-center">
								<?php if (in_array(Etapa::BIM3, $etapasLiberadas) || (($turmaMediacaoTecnologica && (in_array(Etapa::MODULAR, $etapasLiberadas) || in_array(Etapa::MODULAR_2_ANO, $etapasLiberadas))) && $cargaDisciplina > $cargaHorariaAvaliacao)): ?>
									<input type="text" name="<?php echo "nota3[{$id_aluno}]"; ?>" class="mask-nota form-control input-sm" maxlength="4" value="<?php echo $nota['nota3'] ?>" id="txtnota" onblur="validacampo(this, 0);" <?php echo $disable ?>>
								<?php else: ?>
									<input type="hidden" name="<?php echo "nota3[{$id_aluno}]"; ?>" value="<?php echo $nota['nota3'] ?>">
									<input type="text" class="mask-nota form-control input-sm" maxlength="4" value="<?php echo $nota['nota3'] ?>" id="txtnota" disabled title="Etapa Bloqueada">
								<?php endif ?>
								</td>

								<td class="text-center">
								<?php if (in_array(Etapa::BIM4, $etapasLiberadas) || ($turmaMediacaoTecnologica && (in_array(Etapa::MODULAR, $etapasLiberadas) || in_array(Etapa::MODULAR_2_ANO, $etapasLiberadas)))): ?>
									<input type="text" name="<?php echo "nota4[{$id_aluno}]"; ?>" class="mask-nota form-control input-sm" maxlength="4" value="<?php echo $nota['nota4'] ?>" id="txtnota" onblur="validacampo(this, 0);" <?php echo $disable ?>>
								<?php else: ?>
									<input type="hidden" name="<?php echo "nota4[{$id_aluno}]"; ?>" value="<?php echo $nota['nota4'] ?>">
									<input type="text" class="mask-nota form-control input-sm" maxlength="4" value="<?php echo $nota['nota4'] ?>" id="txtnota" disabled title="Etapa Bloqueada">
								<?php endif ?>
								</td>
								<?php endif ?>

								<td>
									<small><?php echo $aluno["situacaodesc"]; ?></small>
								</td>
								<td>
									<button type="button" class="btn btn-xs btn-default btn-notas-alteracao" title="Hist�rico"
											data-id="<?php echo encrypt_decrypt('encrypt', $nota['id']); ?>">
										<i class="fa fa-lg fa-history"></i>
									</button>
								</td>
							</tr>
							<?php endforeach; ?>
						</tbody>
						<tfoot>
							<tr>
								<th>Total</th>
								<td colspan="10"><?php echo sizeof($alunos); ?> estudantes</td>
							</tr>
						</tfoot>
					</table>
				</div>

				<div class="well well-sm">
					<button type="submit" class="btn btn-primary btn-submit-wait" onclick="return confirm('Confirma as altera��es?')">SALVAR NOTAS</button>
					<button class="btn btn-default btn-back pull-right">Voltar</button>
				</div>
			</form>
			<?php endif; ?>
		</div>

		<?php require '../partials/modalNotasAlteracoes.php' ?>

		<?php require_once page_footer(); ?>
		<script src="<?php echo js('modalNotasAlteracoes.js') ?>"></script>


        <script>
            $(function () {
                var $form = $(".form-busca");
                var $disciplina = $(".disciplina-select");

                $("#t").on("change", function () {
                    $disciplina.val(' ');
                    $form.submit()
                })
            })
        </script>
	</body>
</html>