<?php
	require_once '../start.php';
	$pdo = new Conexao;

	Auth::whiteList(array('PROF'));

	$title = 'Lan�ar frequ�ncia';

	$tfrequencia_aluno = tFrequenciaAluno($_SESSION['txtano']);
	$tfrequencia_cabeca = tFrequenciaCabeca($_SESSION['txtano']);

	$id_diadiario = isset($_GET['dd']) ? $_GET['dd'] : false;
	$id_etapa = isset($_GET['e']) ? $_GET['e'] : false;

	$sql = "SELECT dd.id, dd.data, dd.tpbloqueio, ba.descricao AS bloqueio_aula, t.id as id_turma, t.descricao as turma, h.descricao as disciplina, 
				t.modalidade, dd.cpf, tp.id as id_turmaprofessor,tp.cpf as id_professor, dd.id_disciplina,  ti.descricao AS tipo_aula, t.turmas as id_serie
			FROM dias_diario dd
			JOIN tipo_aula ti ON ti.id = dd.tipo_aula 
			JOIN bloqueia_aula ba ON dd.tpbloqueio = ba.id
			JOIN turmaprofessor tp
				ON tp.id_disciplina = dd.id_disciplina
				AND tp.id_turma = dd.id_turma
				AND tp.cpf = dd.cpf
				AND dd.inep = tp.inep
			INNER JOIN turma t on t.id = dd.id_turma
			INNER JOIN habilitacao h ON h.codigo = dd.id_disciplina
			WHERE dd.id = :id
				AND dd.cpf = :cpf
				AND dd.inep = :inep
				AND dd.ano = :ano;";

	$sth = $pdo->prepare($sql);	
	$sth->bindParam(':cpf', $_SESSION['usuario']['cpf']);
	$sth->bindParam(':id', $id_diadiario);
	$sth->bindParam(':ano', $_SESSION['txtano']);
	$sth->bindParam(':inep', $_SESSION['escola']['inep']);
	$diasDiario = $sth->execute() ? $sth->fetchAll() : null;

	if (!$diasDiario) {
		redirect('professor/frequencia_busca.php');
	}

	if($_SERVER["REQUEST_METHOD"] == "POST")  {
        $dia_diario = $diasDiario[0];

        $etapa = Etapa::getEtapaFromDate('Y-m-d', $dia_diario['data'], $dia_diario['modalidade'], $inep, date("Y"));

        if ($dia_diario["bloqueio_aula"] != 'LIBERADO') {
            Notification::error("Esta etapa est� fechada!");
            redirectBack();
        }

        $etapa = Etapa::getEtapaFromDate('Y-m-d', $dia_diario['data'], $dia_diario['modalidade'], $inep);

        $conteudo = isset($_POST['conteudo']) ? $_POST['conteudo'] : null;

		if (!$conteudo) {
			Notification::warning('Informe o conte�do.');
		} else {
			$now = new DateTime();
			$now = $now->format('Y-m-d');

			foreach ($_POST['conteudo'] as $id_diadiario => $conteudo) {
				try {
					if($dia_diario['tipo_aula'] != 'NORMAL'){
						$conteudo = $dia_diario['tipo_aula'].' - '.$conteudo;
					}

					$sql = "UPDATE dias_diario dd SET dd.registrado = 'S' WHERE dd.id = :id_diadiario;";
					$sth = $pdo->prepare($sql);
					$sth->bindParam(':id_diadiario', $id_diadiario);
					$sth->execute();

					$sql = "INSERT INTO {$tfrequencia_cabeca} (id_professor, id_turma, data, inep, assunto, id_disciplina, data_chamada, id_turma_prof, ano)
							VALUES (:id_professor, :id_turma, '{$now}', :inep, :conteudo, :id_disciplina, :data_chamada, :id_turmaprofessor, :ano);";
					$sth = $pdo->prepare($sql);
                    $sth->bindParam(':id_professor', $dia_diario['id_professor']);
                    $sth->bindParam(':id_turma', $dia_diario['id_turma']);
                    $sth->bindParam(':inep', $_SESSION['escola']['inep']);
                    $sth->bindParam(':conteudo', $conteudo);
                    $sth->bindParam(':id_disciplina', $dia_diario['id_disciplina']);
                    $sth->bindParam(':data_chamada', $dia_diario['data']);
                    $sth->bindParam(':id_turmaprofessor', $dia_diario['id_turmaprofessor']);
                    $sth->bindParam(':ano', $_SESSION['txtano']);
					$sth->execute();
					$id_frequenciacabeca = $pdo->lastInsertId();

					if($id_frequenciacabeca) {

						foreach ($_POST['freq'][$id_diadiario] as $id_aluno => $f) {
							$sql = "INSERT INTO {$tfrequencia_aluno} (professor, id_turma, id_disciplina, id_aluno,data, n_chamada, assunto, situacao, id_frequencia, data_chamada, inep, id_turma_prof, ano)
									VALUES (:id_professor, :id_turma, :id_disciplina, :id_aluno, '{$now}',
									(select n_chamada from turma_aluno where id_aluno = :id_aluno and id_turma = :id_turma and situacao = 1),
									:obs, :freq, :id_frequenciacabeca, :data_chamada, :inep, :id_turmaprofessor, :ano);";
							$sth = $pdo->prepare($sql);

							$obs = isset($_POST['obs'][$id_diadiario][$id_aluno]) ? $_POST['obs'][$id_diadiario][$id_aluno] : '';
                            $sth->bindParam(':id_professor', $dia_diario["id_professor"]);
                            $sth->bindParam(':id_turma', $dia_diario['id_turma']);
                            $sth->bindParam(':id_disciplina', $dia_diario['id_disciplina']);
                            $sth->bindParam(':id_aluno', $id_aluno);
                            $sth->bindParam(':obs', $obs);
                            $sth->bindParam(':freq', $f);
                            $sth->bindParam(':id_frequenciacabeca', $id_frequenciacabeca);
                            $sth->bindParam(':data_chamada', $dia_diario['data']);
                            $sth->bindParam(':id_turmaprofessor', $dia_diario["id_turmaprofessor"]);
                            $sth->bindParam(':inep', $_SESSION['escola']['inep']);
                            $sth->bindParam(':ano', $_SESSION['txtano']);
							$sth->execute();

							$existiaNotaAluno = Nota::exists($dia_diario['id_turma'], $dia_diario['id_disciplina'], $id_aluno);
							if(!$existiaNotaAluno)
							{
								if($f == 'P'){
									Frequencia::insertFaltaDiariamente($dia_diario['id_turma'], $dia_diario['id_disciplina'], $id_aluno, $dia_diario["id_professor"],$_SESSION['usuario']['cpf'], $id_etapa);
								}else {
									Frequencia::insertFaltaDiariamente($dia_diario['id_turma'], $dia_diario['id_disciplina'], $id_aluno, $dia_diario["id_professor"],$_SESSION['usuario']['cpf'], $id_etapa,true);
								}
							}
							else
							{
								if($f == 'F')
								{
									Frequencia::updateFaltaDiariamente($dia_diario['id_turma'], $dia_diario['id_disciplina'], $id_aluno, $dia_diario["id_professor"],$id_etapa);
								}
							}
						}
					}

				} catch (Exception $e) {
					Notification::error($e->getMessage());
				}
			}

			$dataFrequencia = formataData($dia_diario['data']);
			Notification::success("Frequ�ncia e conte�do de {$dataFrequencia} lan�ados com sucesso.");

			redirect("professor/frequencia_busca.php?t={$dia_diario['id_turma']}&d={$dia_diario['id_disciplina']}&e={$etapa['id']}");
		}
	}
	
	if (in_array($diasDiario[0]['id_serie'],Turma::$turmasRetencaoParcial)){
		$alunos = Aluno::getAlunosTurmaProgressao($_SESSION['escola']['inep'], $diasDiario[0]['id_turma'],$diasDiario[0]['id_disciplina']);
	} else {
		$alunos = Aluno::getAlunosTurma($_SESSION['escola']['inep'], $diasDiario[0]['id_turma']);
	}
	
	function alunos_matriculados($a) {
		return isset($a['situacao']) && in_array($a['situacao'], array(SituacaoAluno::MATRICULADO, SituacaoAluno::PROGRESSAO_PARCIAL));
	}

?><!DOCTYPE HTML>
<html>
	<head>
		<?php require_once page_head(); ?>
	</head>
	<body>
		<?php require_once page_header(); ?>
		<div class="container">

			<?php if (isset($diasDiario[0])): ?>
			<table class="table table-condensed table-bordered">
				<tr>
					<th width="20">Turma</th>
					<th class="text-primary"><?php echo $diasDiario[0]['turma'] ?></th>
				</tr>
				<tr>
					<th width="20">Disciplina</th>
					<th class="text-danger"><?php echo $diasDiario[0]['disciplina'] ?></th>
				</tr>
			</table>
			<?php endif ?>

			<div>
				<form method="POST" class="submit-wait">
					<input type="hidden" name="data_chamada" value="<?php echo $diasDiario[0]['data'] ?>">

					<?php
						foreach ($diasDiario as $key => $dia_diario):
						$id_diadiario = $dia_diario['id'];
						$dt = DateTime::createFromFormat('Y-m-d', $dia_diario['data']);
						$etapa = Etapa::getEtapaFromDate('Y-m-d', $dia_diario['data'], $dia_diario['modalidade'], $_SESSION['escola']['inep']); ?>

					<?php $isDisabled = ($dia_diario['tpbloqueio'] != 1) ? 'disabled' : ''; ?>

					<div class="panel panel-default">
						<div class="panel-heading">
							<span class="h4">
								Conte�do de
								<?php echo $dt->format('d/m/Y') ?> 
								<small class="text-muted">(<?php echo Calendario::$diasSemana[date_format($dt, 'N')] ?>)</small>
							</span>

							<?php if ($dia_diario['tpbloqueio'] != 1): ?>
								<span class="text-danger">
									(Aula bloqueada: <?php echo $dia_diario['bloqueio_aula'] ?>)
								</span>
							<?php endif ?>

							<span class="pull-right">
								<b>AULA <?php echo $dia_diario['tipo_aula']; ?></b>
							</span>

						</div>
						<div class="panel-body">
							<textarea autofocus <?php echo $isDisabled ?> required name="conteudo[<?php echo $id_diadiario ?>]" id="conteudo<?php echo $id_diadiario ?>" rows="3" class="form-control" placeholder="Digite o conte�do da aula aqui"></textarea>
							<button type="button" data-dd="<?php echo $id_diadiario ?>" data-tp="<?php echo $dia_diario['id_turmaprofessor'] ?>" data-etapa="<?php echo $etapa['id'] ?>" class="btn btn-sm btn-default btn-modal-conteudo">
								<i class="fa fa-search"></i> Pesquisar conte�do lan�ado
							</button>
						</div>

						<div class="table-responsive">
							<table class="table table-condensed table-striped table-bordered table-hover">
								<thead>
									<tr>
										<th width="10">N�</th>
										<th>Estudante</th>
										<th width="160">Situa��o</th>
										<th class="text-center" width="170">Frequ�ncia</th>
										<th>Observa��es</th>
									</tr>
								</thead>
								<tbody>
									<?php
										foreach ($alunos as $a):

											$situacao = SituacaoAluno::get($a['situacao']);
											$freq = "freq[{$id_diadiario}][{$a['id_aluno']}]";
											$freqp = "freqp[{$id_diadiario}][{$a['id_aluno']}]";
											$freqf = "freqf[{$id_diadiario}][{$a['id_aluno']}]";
											$obs = "obs[{$id_diadiario}][{$a['id_aluno']}]";

											$componenteEliminado = ComponenteEliminado::get($dia_diario['id_turma'], $dia_diario['id_disciplina'], $a['id_aluno']);
											$alunoDisabled = ($componenteEliminado || !alunos_matriculados($a)) ? 'disabled' : '';
										?>
										<tr >
											<td><?php echo $a['n_chamada'] ?></td>
											<td><?php echo $a['nome'] ?></td>
											<td><small><?php echo $situacao['descricao'] ?></small></td>
											<?php if ($alunoDisabled): ?>
											<td colspan="2">
												<?php if ($componenteEliminado): ?>
													<small class="text-primary">
														<i class="fa fa-info-circle"></i>
														Componente eliminado - <?php echo $componenteEliminado['tipo_avaliacao'] ?>
													</small>
												<?php endif ?>
											</td>
											<?php else: ?>
											<td>
												<div class="btn-group btn-group-xs">
													<label for="<?php echo $freqp ?>" class="btn btn-default">
														<input <?php echo $isDisabled ?> <?php echo $alunoDisabled ?> type="radio" id="<?php echo $freqp ?>" name="<?php echo $freq ?>" <?php echo (in_array($dia_diario['tipo_aula'],["RECUPERA��O","EXAME FINAL"])) ? '' :'checked' ?> value="P" autocomplete="off"> PRESEN�A 
													</label>
												 	<label for="<?php echo $freqf ?>" class="btn btn-default">
												    	<input <?php echo $isDisabled ?> <?php echo $alunoDisabled ?> type="radio" id="<?php echo $freqf ?>" name="<?php echo $freq ?>" value="F" autocomplete="off"> FALTA 
												  	</label>
												</div>
											</td>
											<td>
												<?php if (!empty($_POST['conteudo'])): ?>
													<textarea <?php echo $isDisabled ?> <?php echo $alunoDisabled ?> class="form-control" name="<?php echo $obs ?>" rows="2"></textarea>
												<?php else: ?>
													<button class="btn btn-primary btn-block btn-xs btn-toggle-ta">Adicionar observa��o</button>
													<textarea <?php echo $isDisabled ?> <?php echo $alunoDisabled ?> class="form-control" disabled style="display: none;" name="<?php echo $obs ?>" rows="2" placeholder="Adicionar observa��o"></textarea>
												<?php endif ?>
											</td>
											<?php endif ?>
										</tr>
									<?php endforeach ?>
								</tbody>
							</table>
						</div>
					</div>
					<?php endforeach ?>

					<div class="well well-sm">
						<button class="btn btn-primary btn-submit btn-submit-wait">SALVAR</button>
						<?php $urlBack = "professor/frequencia_busca.php?t={$dia_diario['id_turma']}&d={$dia_diario['id_disciplina']}&e={$etapa['id']}"; ?>
						<a class="btn btn-default pull-right" href="<?php url($urlBack) ?>">Voltar</a>
					</div>
				</form>
			</div>
		</div>

		<?php require '../partials/modalConteudoFrequencia.php' ?>

		<?php require_once page_footer(); ?>
		<script src="<?php echo js('modalConteudoFrequencia.js') ?>"></script>
	</body>
</html>