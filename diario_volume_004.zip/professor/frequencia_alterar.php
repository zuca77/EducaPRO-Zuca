<?php
require_once '../start.php';
$pdo = new Conexao;

$title = 'Alterar frequ�ncia';

Auth::whiteList(array('PROF'));

$id_diadiario = isset($_GET['dd']) ? $_GET['dd'] : false;
$tfrequencia_cabeca = tFrequenciaCabeca($_SESSION['txtano']);
$tfrequencia_aluno = tFrequenciaAluno($_SESSION['txtano']);

$sql = "SELECT dd.data, t.id as id_turma, t.modalidade, tp.cpf as id_professor, dd.id_disciplina, dd.inep, dd.id_disciplina
			FROM dias_diario dd
			JOIN tipo_aula ti ON ti.id = dd.tipo_aula 
			JOIN bloqueia_aula ba ON dd.tpbloqueio = ba.id
			JOIN turmaprofessor tp
				ON tp.id_disciplina = dd.id_disciplina
				AND tp.id_turma = dd.id_turma
				AND tp.cpf = dd.cpf
				AND dd.inep = tp.inep
			INNER JOIN turma t on t.id = dd.id_turma
			INNER JOIN habilitacao h ON h.codigo = dd.id_disciplina
			WHERE dd.id = :id
				AND dd.cpf = :cpf
				AND dd.inep = :inep
				AND dd.ano = :ano;";

$sth = $pdo->prepare($sql);
$sth->bindParam(':cpf', $_SESSION['usuario']['cpf']);
$sth->bindParam(':id', $id_diadiario);
$sth->bindParam(':ano', $_SESSION['txtano']);
$sth->bindParam(':inep', $_SESSION['escola']['inep']);
$dia_diario = $sth->execute() ? $sth->fetch() : null;


if (isset($_GET['excluir']) && !empty($_GET['excluir'])) {

    $sql = "SELECT situacao FROM {$tfrequencia_aluno}
			WHERE id = :id AND ano = :ano AND inep = :inep;";
    $sth = $pdo->prepare($sql);
    $sth->bindParam(':id', $_GET['excluir']);
    $sth->bindParam(':ano', $_SESSION['txtano']);
    $sth->bindParam(':inep', $_SESSION['escola']['inep']);
    $sth->execute();
    $situacao_frequencia = $sth->fetch();

    $sql = "DELETE FROM {$tfrequencia_aluno}
			WHERE id = :id AND ano = :ano AND inep = :inep;";
    $sth = $pdo->prepare($sql);
    $sth->bindParam(':id', $_GET['excluir']);
    $sth->bindParam(':ano', $_SESSION['txtano']);
    $sth->bindParam(':inep', $_SESSION['escola']['inep']);

    try {
        if ($sth->execute()) {
            Notification::success('Frequ�ncia de aluno exclu�da com sucesso.');
        } else {
            Notification::error('N�o foi poss�vel excluir frequ�ncia.');
        }

        if ($situacao_frequencia['situacao'] === 'F') {
            $etapa = Etapa::getEtapaFromDate('Y-m-d', $dia_diario['data'], $dia_diario['modalidade'], $dia_diario['inep']);

            Frequencia::updateFaltaDiariamente($dia_diario['id_turma'], $dia_diario['id_disciplina'], $_GET['id_aluno'], $dia_diario["id_professor"], $etapa['id'], true);
        }
    } catch (\Exception $e) {
        Notification::ex($e);
    }

    redirect('professor/frequencia_alterar.php?dd='.$_GET['dd'].'&e='.$_GET['e']);
}

if(isset($_GET['adicionarTodos']) && $_GET['adicionarTodos'] != 1) {
    $sql = "SELECT * FROM {$tfrequencia_cabeca} fc
			WHERE id = :id AND ano = :ano AND inep = :inep;";
    $sth = $pdo->prepare($sql);
    $sth->bindParam(':id', $_GET['adicionarTodos']);
    $sth->bindParam(':ano', $_SESSION['txtano']);
    $sth->bindParam(':inep', $_SESSION['escola']['inep']);
    $frequenciaCabeca = $sth->execute() ? $sth->fetch() : null;

    $sql = "SELECT ta.*
			FROM turma_aluno ta
			JOIN {$tfrequencia_cabeca} fc on fc.id_turma = ta.id_turma 
			WHERE fc.id = :id AND fc.ano = :ano AND fc.inep = :inep
			AND ta.situacao IN (1,8) 
			ORDER BY ta.n_chamada;";
    $sth = $pdo->prepare($sql);
    $sth->bindParam(':id', $_GET['adicionarTodos']);
    $sth->bindParam(':ano', $_SESSION['txtano']);
    $sth->bindParam(':inep', $_SESSION['escola']['inep']);
    $turmaAlunos = $sth->execute() ? $sth->fetchAll() : null;


    $sql = "INSERT INTO {$tfrequencia_aluno} (professor, id_turma, id_disciplina, id_aluno,data, n_chamada, situacao, id_frequencia, data_chamada, inep, id_turma_prof, ano) 
			VALUES ";

    foreach($turmaAlunos as $turmaAluno)
    {
        $sql .= " (:id_professor, :id_turma, :id_disciplina, {$turmaAluno['id_aluno']}, NOW(),{$turmaAluno['n_chamada']}, 1, :id_frequenciacabeca, :data_chamada, :inep, :id_turmaprofessor, :ano),";
    }
    $sql = substr($sql, 0, -1); //tira a virgula do ultimo value
    $sql .= ";";

    $sth = $pdo->prepare($sql);
    $sth->bindParam(':id_turma', $frequenciaCabeca['id_turma']);
    $sth->bindParam(':id_professor', $frequenciaCabeca["id_professor"]);
    $sth->bindParam(':id_disciplina', $frequenciaCabeca['id_disciplina']);
    $sth->bindParam(':data_chamada', $frequenciaCabeca['data_chamada']);
    $sth->bindParam(':id_frequenciacabeca', $frequenciaCabeca['id']);
    $sth->bindParam(':id_turmaprofessor', $frequenciaCabeca["id_turma_prof"]);
    $sth->bindParam(':ano', $_SESSION['txtano']);
    $sth->bindParam(':inep', $_SESSION['escola']['inep']);

    try {
        if ($sth->execute()) {
            Notification::success('Estudantes adicionados com sucesso.');
        } else {
            Notification::error('N�o foi poss�vel adicionar os estudantes.');
        }
    } catch (Exception $e) {
        Notification::ex($e);
    }
    redirect('professor/frequencia_alterar.php?dd='.$_GET['dd'].'&e='.$_GET['e']);

}

if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['adicionar']) && $_POST['adicionar'] == 1) {

    $sql = "SELECT * FROM {$tfrequencia_cabeca} fc
			WHERE id = :id AND ano = :ano AND inep = :inep;";
    $sth = $pdo->prepare($sql);
    $sth->bindParam(':id', $_POST["id_frequencia_cabeca"]);
    $sth->bindParam(':ano', $_SESSION['txtano']);
    $sth->bindParam(':inep', $_SESSION['escola']['inep']);
    $frequenciaCabeca = $sth->execute() ? $sth->fetch() : null;

    $sql = "INSERT INTO {$tfrequencia_aluno} (professor, id_turma, id_disciplina, id_aluno,data, n_chamada, assunto, situacao, id_frequencia, data_chamada, inep, id_turma_prof, ano)
			VALUES (:id_professor, :id_turma, :id_disciplina, :id_aluno, NOW(),(select n_chamada from turma_aluno where id_aluno = :id_aluno and id_turma = :id_turma and situacao = 1),
			:obs, :freq, :id_frequenciacabeca, :data_chamada, :inep, :id_turmaprofessor, :ano);";

    $sth = $pdo->prepare($sql);

    foreach ($_POST["alunos"] as $id_aluno => $aluno) {
        $sth->bindParam(':id_turma', $frequenciaCabeca['id_turma']);
        $sth->bindParam(':id_professor', $frequenciaCabeca["id_professor"]);
        $sth->bindParam(':id_disciplina', $frequenciaCabeca['id_disciplina']);
        $sth->bindParam(':data_chamada', $frequenciaCabeca['data_chamada']);
        $sth->bindParam(':id_frequenciacabeca', $frequenciaCabeca['id']);
        $sth->bindParam(':id_turmaprofessor', $frequenciaCabeca["id_turma_prof"]);
        $sth->bindParam(':obs', $aluno["observacao"]);
        $sth->bindParam(':freq', $aluno["frequencia"]);
        $sth->bindParam(':id_aluno', $id_aluno);
        $sth->bindParam(':ano', $_SESSION['txtano']);
        $sth->bindParam(':inep', $_SESSION['escola']['inep']);

        try {
            $success = $sth->execute();

            if ($aluno['frequencia'] === 'F') {
                $etapa = Etapa::getEtapaFromDate('Y-m-d', $frequenciaCabeca['data_chamada'], $dia_diario['modalidade'], $dia_diario['inep']);

                Frequencia::updateFaltaDiariamente($frequenciaCabeca['id_turma'], $frequenciaCabeca['id_disciplina'], $id_aluno, $frequenciaCabeca["id_professor"], $etapa['id'], true);
            }
        } catch (Exception $e) {
            Notification::ex($e);
        }
    }

    if ($success) {
        Notification::success('Estudantes adicionados com sucesso.');
    } else {
        Notification::error('N�o foi poss�vel adicionar um ou mais estudantes.');
    }

    redirect('professor/frequencia_alterar.php?dd='.$_GET['dd']);
}

$sql = "SELECT dd.id, dd.data, dd.tpbloqueio, ba.descricao AS bloqueio_aula, t.id as id_turma, t.descricao as turma, h.descricao as disciplina, 
				t.modalidade, dd.cpf, tp.id as id_turmaprofessor,tp.cpf as id_professor, dd.id_disciplina,  ti.descricao AS tipo_aula, t.turmas as id_serie,
				fc.assunto as conteudo, fc.id as id_frequencia_cabeca

			FROM dias_diario dd
			JOIN tipo_aula ti ON ti.id = dd.tipo_aula 
			JOIN bloqueia_aula ba ON dd.tpbloqueio = ba.id
			JOIN turmaprofessor tp
				ON tp.id_disciplina = dd.id_disciplina
				AND tp.id_turma = dd.id_turma
				AND tp.cpf = dd.cpf
				AND dd.inep = tp.inep
			INNER JOIN turma t on t.id = dd.id_turma
			INNER JOIN habilitacao h ON h.codigo = dd.id_disciplina
			JOIN {$tfrequencia_cabeca} fc ON fc.id_turma = t.id
				AND fc.id_professor = tp.cpf
				AND fc.id_disciplina = h.codigo
				AND fc.data_chamada = dd.data
			WHERE dd.id = :id
				AND dd.cpf = :cpf
				AND dd.inep = :inep
				AND dd.ano = :ano;";

$sth = $pdo->prepare($sql);
$sth->bindParam(':cpf', $_SESSION['usuario']['cpf']);
$sth->bindParam(':id', $id_diadiario);
$sth->bindParam(':ano', $_SESSION['txtano']);
$sth->bindParam(':inep', $_SESSION['escola']['inep']);
$diasDiario = $sth->execute() ? $sth->fetchAll() : null;

if (!$diasDiario) {
    Logger::error('Frequ�ncia n�o encontrada', 'N�o encontrada Frequ�ncia ID '.$_GET['dd'].' para alterar. INEP '.$_SESSION['escola']['inep']);
    redirect('professor/frequencia_busca.php');
}

if($_SERVER["REQUEST_METHOD"] == "POST")  {
    $now = new DateTime();
    $now = $now->format('Y-m-d');

    if ($diasDiario[0]["bloqueio_aula"] != 'LIBERADO') {
        Notification::error("A etapa est� bloqueada!");
        redirectBack();
    }

    $etapa = Etapa::getEtapaFromDate('Y-m-d', $diasDiario[0]['data'], $diasDiario[0]['modalidade'], $inep);

    if (!isset($_POST['conteudo'])) {
        Notification::warning('Informe o conte�do.');
    } else {
        foreach ($_POST['conteudo'] as $id_frequencia_cabeca => $conteudo) {
            $sql = "UPDATE {$tfrequencia_cabeca}
					SET assunto = :conteudo
					WHERE id = :id;";
            $sth = $pdo->prepare($sql);
            $sth->bindParam(':id', $id_frequencia_cabeca);
            $sth->bindParam(':conteudo', $conteudo);
            $sth->execute();
        }

        $sql = "UPDATE {$tfrequencia_aluno} fa
				SET fa.situacao = :freq, fa.assunto = :obs
				WHERE fa.id_aluno = :id_aluno
					AND fa.id_frequencia = :id_frequencia_cabeca;";
        $sth = $pdo->prepare($sql);

        foreach ($_POST['freq'] as $id_frequencia_cabeca => $frequencias) {
            foreach ($frequencias as $id_aluno => $freq) {
                $obs = isset($_POST['obs'][$id_frequencia_cabeca][$id_aluno]) ? $_POST['obs'][$id_frequencia_cabeca][$id_aluno] : '';
                $sth->bindParam(':obs', $obs);
                $sth->bindParam(':freq', $freq);
                $sth->bindParam(':id_aluno', $id_aluno);
                $sth->bindParam(':id_frequencia_cabeca', $id_frequencia_cabeca);
                $sth->execute();
            }
        }
    }

    executar_async(url("professor/atualiza_frequencia_aluno.php?dd={$id_diadiario}", true));

    Notification::success('Frequ�ncia alterada com sucesso.');

    redirect("professor/frequencia.php?dd={$id_diadiario}");
}

?><!DOCTYPE HTML>
<html>
<head>
    <?php require_once page_head(); ?>
</head>
<body>
<?php require_once page_header(); ?>
<div class="container">

    <?php if (isset($diasDiario[0])): ?>
        <table class="table table-condensed table-bordered">
            <tr>
                <th width="20">Turma</th>
                <th class="text-primary"><?php echo $diasDiario[0]['turma'] ?></th>
            </tr>
            <tr>
                <th width="20">Disciplina</th>
                <th class="text-danger"><?php echo $diasDiario[0]['disciplina'] ?></th>
            </tr>
        </table>

    <?php endif ?>

    <?php
    foreach ($diasDiario as $dia_diario):
        $dt = DateTime::createFromFormat('Y-m-d', $dia_diario['data']);
        $etapa = Etapa::getEtapaFromDate('Y-m-d', $dia_diario['data'], $dia_diario['modalidade'], $_SESSION['escola']['inep']);
        $id_frequencia_cabeca = $dia_diario['id_frequencia_cabeca'];
        $alunosSemFrequencia = Frequencia::alunosSemFrequencia($dia_diario['id_frequencia_cabeca'], $_SESSION['txtano']);
        ?>

        <?php if (sizeof($alunosSemFrequencia) > 0): ?>
        <div class="modal fade" id="modal_<?= $dia_diario['id_frequencia_cabeca'] ?>" tabindex="-1" role="dialog" data-backdrop="static">
            <div class="modal-dialog modal-lg" role="document">
                <div class="modal-content">
                    <div class="modal-header">
                        <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
                        <h3 class="modal-title" style="border:none">Adicionar estudantes na frequ�ncia</h3>
                    </div>
                    <div class="modal-body">
                        <form method="POST">
                            <input type="hidden" name="adicionar" value="1">
                            <input type="hidden" name="id_frequencia_cabeca" value="<?= $id_frequencia_cabeca ?>">
                            <table class="table table-bordered table-condensed table-striped table-hover adiciona-alunos">
                                <thead>
                                    <tr>
                                        <th colspan="2">Aluno</th>
                                        <th>Frequ�ncia</th>
                                        <th>Observa��o</th>
                                        <th></th>
                                    </tr>
                                </thead>
                                <tbody>
                                <?php foreach ($alunosSemFrequencia as $aluno): ?>
                                    <tr>
                                        <td width="20"><?= $aluno['n_chamada'] ?> </td>
                                        <td><?= $aluno['nome'] ?> <small>(<?= $aluno['situacao'] ?>)</small></td>
                                        <td width="130">
                                            <input type="hidden" name="alunos[<?= $aluno["id"]?>]">
                                            <div class="form-group">
                                                <select name="alunos[<?= $aluno["id"]?>][frequencia]" id="frequencia" class="form-control">
                                                    <option value="P">PRESEN�A</option>
                                                    <option value="F">FALTA</option>
                                                </select>
                                            </div>
                                        </td>
                                        <td width="200">
                                            <button class="btn btn-primary btn-block btn-xs btn-toggle-ta">Adicionar observa��o</button>
                                            <textarea class="form-control" disabled style="display: none;" name="alunos[<?= $aluno["id"]?>][observacao]" rows="2" placeholder="Adicionar observa��o"></textarea>
                                        </td>
                                        <td>
                                            <button type="button" class="btn btn-danger btn-xs btn-remove-aluno">
                                                <i class="fa fa-trash-o fa-lg"></i>
                                            </button>
                                        </td>
                                    </tr>
                                <?php endforeach; ?>
                                </tbody>
                            </table>
                            <div>
                                <button type="submit" class="btn btn-success btn-offset">ADICIONAR</button>
                                <button type="button" class="btn btn-default btn-offset pull-right" data-dismiss="modal">Cancelar</button>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    <?php endif ?>

        <form method="POST">
            <div class="panel panel-default">
                <div class="panel-heading">
						<span class="h3">
							Conte�do de
                            <?php echo $dt->format('d/m/Y') ?>
                            <small class="text-muted">(<?php echo Calendario::$diasSemana[date_format($dt, 'N')] ?>)</small>
						</span>

                    <?php
                    $frequencia_aluno = Frequencia::frequenciaAlunos($dia_diario['id_frequencia_cabeca'], $tfrequencia_aluno);
                    if(sizeof($frequencia_aluno) == 0): ?>
                        <a class="btn btn-primary btn-sm pull-right"  href="?adicionarTodos=<?php echo $id_frequencia_cabeca ?>">
                            <i class="fa fa-plus"></i>
                            ADICIONAR TODOS MATRICULADOS
                        </a>
                    <?php endif?>

                    <?php if (sizeof($alunosSemFrequencia) > 0): ?>
                        <button type="button" class="btn btn-sm btn-success pull-right" data-toggle="modal" data-target="#modal_<?php echo $id_frequencia_cabeca ?>">
                            <i class="fa fa-plus"></i>
                            ADICIONAR ESTUDANTE
                        </button>
                    <?php endif ?>

                </div>
                <div class="panel-body">
                    <textarea name="conteudo[<?php echo $id_frequencia_cabeca ?>]" id="conteudo" rows="3" class="form-control"><?php echo $dia_diario['conteudo']; ?></textarea>
                </div>
                <div class="table-responsive">
                    <table id="table_<?php echo $id_frequencia_cabeca ?>" class="table table-hover table-condensed table-striped table-bordered">
                        <thead>
                        <tr>
                            <th class="text-center">N�</th>
                            <th>Estudante</th>
                            <th width="10">Situa��o</th>
                            <th width="200" class="text-center">Frequ�ncia</th>
                            <th>Observa��es</th>
                            <th width="10"></th>
                        </tr>
                        </thead>
                        <tbody>
                        <?php
                        foreach ($frequencia_aluno as $fa):
                            $situacao = SituacaoAluno::get($fa['situacao']);
                            $freq = "freq[{$id_frequencia_cabeca}][{$fa['id_aluno']}]";
                            $freqp = "freqp[{$id_frequencia_cabeca}][{$fa['id_aluno']}]";
                            $freqf = "freqf[{$id_frequencia_cabeca}][{$fa['id_aluno']}]";
                            $obs = "obs[{$id_frequencia_cabeca}][{$fa['id_aluno']}]";
                            ?>
                            <tr>
                                <td width="10" class="text-center"><?php echo $fa['n_chamada'] ?></td>
                                <td><?php echo $fa['nome'] ?></td>
                                <td><small><?php echo $situacao['descricao'] ?></small></td>
                                <td>
                                    <div class="btn-group btn-group-xs">
                                        <label for="<?php echo $freqp ?>" class="btn btn-default <?php echo $fa['frequencia'] != 'F' ? 'active' : '' ?>">
                                            <input type="radio" name="<?php echo $freq ?>" id="<?php echo $freqp ?>" value="P" <?php checked($fa['frequencia'] != 'F') ?> autocomplete="off"> PRESEN�A
                                        </label>
                                        <label for="<?php echo $freqf ?>" class="btn btn-default <?php echo $fa['frequencia'] == 'F' ? 'active' : '' ?>">
                                            <input type="radio" name="<?php echo $freq ?>" id="<?php echo $freqf ?>" value="F" <?php checked($fa['frequencia'] == 'F') ?> autocomplete="off"> FALTA
                                        </label>
                                    </div>
                                </td>
                                <td>
                                    <?php if (!empty($fa['observacao'])): ?>
                                        <textarea class="form-control"  name="<?php echo $obs ?>" rows="2"><?php echo $fa['observacao'] ?></textarea>
                                    <?php else: ?>
                                        <button class="btn btn-primary btn-block btn-xs btn-toggle-ta">Adicionar observa��o</button>
                                        <textarea class="form-control" disabled style="display: none;" name="<?php echo $obs ?>" rows="2" placeholder="Adicionar observa��o"></textarea>
                                    <?php endif ?>
                                </td>
                                <td>
                                    <a href="?excluir=<?php echo $fa['id'] ?>&dd=<?php echo $id_diadiario ?>&id_aluno=<?= $fa['id_aluno'] ?>&e=<?= $_GET['e']?>" class="btn btn-danger btn-xs"
                                       title="Excluir frequ�ncia de estudante" onclick="return confirm('Confirma excluir esse registro de frequ�ncia do estudante?')">
                                        <i class="fa fa-trash-o fa-lg"></i>
                                    </a>
                                </td>
                            </tr>
                        <?php endforeach ?>
                        </tbody>
                    </table>
                </div>
                <div class="panel-footer">
                    <button class="btn btn-primary btn-submit btn-submit-wait">SALVAR ALTERA��ES</button>
                    <a class="btn btn-default pull-right" href="<?php echo url("professor/frequencia_busca.php?t={$dia_diario['id_turma']}&d={$dia_diario['id_disciplina']}&e={$etapa['id']}") ?>">Voltar</a>
                </div>
            </div>
        </form>
        <hr>
    <?php endforeach ?>

</div>
<?php require_once page_footer(); ?>
<script>
    $(function() {
        $('.btn-toggle-ta').on('click', function(e) {
            e.preventDefault();
            $(this).hide();
            $(this).parent().find('textarea').removeAttr('disabled').fadeIn(function() { $(this).focus(); });
        });

        $(".btn-remove-aluno").on("click", function () {
            $(this).closest('tr').remove();
        });

    });
</script>
</body>
</html>