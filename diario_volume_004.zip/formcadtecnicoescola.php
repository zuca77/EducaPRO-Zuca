<?
session_start();
if (isset($_SESSION["login_usuario"]))
  {
     $login =  $_SESSION["login_usuario"];
     $nte   =  $_SESSION["nivel_usuario"];
	 $inep  =  $_SESSION["inep_usuario"] ;   
	 include ("funcoes.php");
     echo  saudacoes()."   ". "$login" ."  -  ". $nte."  ".dataextenso();
     echo  "$inep";
   }
 else
  {
      header("Location: login.php");
  }  	 

?>

<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1" />
<title>NTE-Porto Velho</title>
  
  <link rel="stylesheet" href="estilos.css" type="text/css">
  
<style>
a:visited {
	color: #FFFF00;
	text-decoration: none;
}
a:active {
	color: #00FF00;
	text-decoration: none;
}
body,td,th {
	color: #0000FF;
}
a:link {
	text-decoration: none;
}
a:hover {
	text-decoration: none;
}
.style5 {color: #0000FF}
-->
</style>


  <script language="javascript" src="generic.js"></script>	

</head>

<body>
	
    <table>
      <tr>
        <td height="0"></td>
      </tr>
    </table>



  <div id="geral">
          <div id="topo">
	          <img src= "public/img/LogoGovernoSite_small.jpg"/>
       	   <img src= "public/img/LayoutSGA_small.jpg"/>         </div>

 <div id="corpo" class="fontecorpo">
<table border=0 width="590" height="230" >
	<form name="formtecnico" action = "insere_tecnicoescola.php" method="post">
	
	
	  <tr>
         <td height="40"></td>
      </tr>
<br><br><br>
<?
$id = $inep;
$sql = "select * from escola where inep = $id";
$resposta = mysql_query( $sql );
while ( $linha = mysql_fetch_array( $resposta )) 
   {
?>
  
<tr><td>INEP </td><td><input  name="inep"  size="10" maxlength="10" type="text" readonly="true" value="<?echo $linha["INEP"];?>" onKeyPress="return Enum(event)"> 
Descri��o&nbsp<input  name="descricao" size="50" readonly="true" type="text" value="<?echo $linha["DESCRICAO"];?>" onBlur=   "maiusculalteracadescola()"></td></tr>
<?
 }
?>


	<tr> 
     <td>CPF*</td><td>
              <input name="cpf" type="text" id="cpf" size="15" MAXLENGTH="11" onBlur="return valida_cpf(cpf.value)">
			  Matricula* <input name="matricula" type="text" id="matricula" size="12" MAXLENGTH="12" onKeyPress="return Enum(event)">
      </td>
	</tr>
    

	<tr> 
     <td>RG*</td><td>
          <input name="rg" type="text"    size="20" MAXLENGTH="20" onBlur=   "maiusculatecnico() ">
          Org�o Exp.*  <input name="orgaoexp"      type="text"  size="10" MAXLENGTH="10" onBlur=   "maiusculatecnico() ">
		  Data Emiss�o* <input name="dtemissaorg"  id="dtemissaorg"   type="text"  size="10" MAXLENGTH="10" OnKeyUp="mascaraData(dtemissaorg.value)">
		 <input name="dtemissaorg1"    type="hidden"  size="10" MAXLENGTH="10" >


      </td>
	</tr>
	
	<tr> 
     <td>Nome*</td><td>
            <input name="nome" type="text" id="nome" size="60" MAXLENGTH="60" onBlur=   "maiusculatecnico() ">
      </td>
	</tr>

	<tr> 
     <td>Endere�o*</td><td>
       <input name="endereco" type="text" id="endereco" size="40" MAXLENGTH="40" onBlur=   "maiusculatecnico()">
      </td>
	</tr>

	<tr> 
     <td>Bairro*</td><td>
       <input name="bairro" type="text" id="bairro" size="25" MAXLENGTH="25" onBlur=   "maiusculatecnico() ">


       Nr.* <input name="nr" type="text" id="nr" size="5" MAXLENGTH="5" onKeyPress="return Enum(event)">
      </td>
	</tr>

    <tr> 
     <td>Munic�pio*</td><td>
       <?=lista_municipio();?> 
      CEP* 
	    <input name="cep" type="text" id="cep" size="8" MAXLENGTH="8" onKeyPress="return Enum(event)">
	 </td>
	</tr>

	<tr> 
     <td>Fone Setor*</td>
      <td> 
	     <input name="fonesetor" type="text" id="fonsetor" size="15" MAXLENGTH="15" >
	     Fone Res*
	     <input name="foneres"  type="text"  id="foneres" size="15" MAXLENGTH="15">
	     Celular*
	     <input name="celular"  type="text"  id="celular" size="15" MAXLENGTH="15">

	  </td>
	</tr>

    <tr> 
     <td>Email*</td><td>
       <input name="email" type="text" id="email" size="60" MAXLENGTH="60" onBlur=   "maiusculacadescola() ">
      </td>
	</tr>


	<tr> 
     <td>Escolariade*</td><td>
          <select name="escolaridade">
              <option value="">...Selecione Tipo...</option>
              <option value="MEDIO COMPLETOC">M�DIO COMPLETO</option>			  
              <option value="SUPERIOR INCOMPLETO">SUPERIOR INCOMPLETO</option>			  			  
              <option value="SUPERIOR COMPLETO">SUPERIOR COMPLETO</option>			  			  			  
              <option value="TECNICO">T�CNICO</option>			  			  			  
              <option value="POS-GRADUADO">P�S-GRADUADO</option>			  			  			  			  
              <option value="MESTRADO">MESTRADO</option>			  			  			  			  			  
			  <option value="DOUTORADO">DOUTORADO</option>			  			  			  			  			  
          </select>
      </td>
	</tr>

	<tr> 
     <td>Habilita��o*</td><td>
          <select name="habilitacao">
              <option value="">...Selecione Tipo...</option>
              <option value="MATEMATICA">MATEM�TICA</option>
              <option value="FISICA">F�SICA</option>
              <option value="GEOGRAFIA">GEOGRAFIA</option>
              <option value="HISTORIA">HIST�RIA</option>			  
              <option value="PORTUGUES">PORTUGU�S</option>			  			  
              <option value="INFORMATICA">INFORM�TICA</option>			  			  			  
              <option value="LITERATURA">LITERATURA</option>			  			  			  			  
              <option value="ARTES">ARTES</option>
              <option value="ECONOMIA">CI�NCIAS ECONOMICAS</option>			  
			  <option value="TECNICO">TECNICO</option>
			  <option value="PEDAGOGIA">PEDAGOGIA</option>
			  <option value="OUTROS">OUTROS</option>
          </select>
      </td>
	</tr>





	<tr> 
     <td>Nascimento</td><td>
              Dia*
			  <select name="dia">
              <option value="">...Selecione Dia...</option>
              <option value="1">01</option>			  
              <option value="2">02</option>			  			  
              <option value="3">03</option>			  			  			  
              <option value="4">04</option>			  			  			  
              <option value="5">05</option>			  			  			  			  
              <option value="6">06</option>			  			  			  			  			  
			  <option value="7">07</option>			  			  			  			  			  
              <option value="8">08</option>
              <option value="9">09</option>			  
              <option value="10">10</option>			  			  
              <option value="11">11</option>			  			  			  
              <option value="12">12</option>			  			  			  
              <option value="13">13</option>			  			  			  			  
              <option value="14">14</option>			  			  			  			  			  
			  <option value="15">15</option>			  			  			  			  			  
              <option value="16">16</option>			  
              <option value="17">17</option>			  			  
              <option value="18">18</option>			  			  			  
              <option value="19">19</option>			  			  			  
              <option value="20">20</option>			  			  			  			  
              <option value="21">21</option>			  			  			  			  			  
			  <option value="22">22</option>			  			  			  			  			  
              <option value="23">23</option>
              <option value="24">24</option>			  
              <option value="25">25</option>			  			  
              <option value="26">26</option>			  			  			  
              <option value="27">27</option>			  			  			  
              <option value="28">28</option>			  			  			  			  
              <option value="29">29</option>			  			  			  			  			  
			  <option value="30">30</option>			  			  			  			  			  
              <option value="31">31</option>
          </select>
	   
	   
	   
	   M�s*    
	   
              <select name="mes">
              <option value="">...Selecione M�s...</option>
              <option value="1">01</option>			  
              <option value="2">02</option>			  			  
              <option value="3">03</option>			  			  			  
              <option value="4">04</option>			  			  			  
              <option value="5">05</option>			  			  			  			  
              <option value="6">06</option>			  			  			  			  			  
			  <option value="7">07</option>			  			  			  			  			  
              <option value="8">08</option>
              <option value="9">09</option>			  
              <option value="10">10</option>			  			  
              <option value="11">11</option>			  			  			  
              <option value="12">12</option>			  			  			  
          </select>

     </td>
	</tr>
	<tr> 
     <td>Banco</td>
	<td> 
       <input name="banco" id ="banco" type="text" size="3" MAXLENGTH="3" onKeyPress="return Enum(event)">
       Ag�ncia
	      <input name= "agencia" id="agencia" type="text" size="5" MAXLENGTH="5" >
       Conta 
	       <input name="cc" id = "cc" type="text"  size="15" MAXLENGTH="15" >
   	  </td>
 </tr>


	<tr> 
     <td>T�tulo Eleitor</td><td>
            <input name="titulo" id="titulo" type="text" size="20" MAXLENGTH="20" onKeyPress="return Enum(event)">
     Zona
            <input name="zona" id="zona" type="text"  size="5" MAXLENGTH="5" onKeyPress="return Enum(event)">
     Sess�o
            <input name="sessao" id="sessao" type="text" size="5" MAXLENGTH="5" onKeyPress="return Enum(event)">
			
      </td>
</tr>

	<tr> 
     <td>PIS/PASEP</td><td>
       <input name="pis"   id="pis" type="text"  size="20"  MAXLENGTH="20" onKeyPress="return Enum(event)">
      </td>
	</tr>

	<tr> 
     <td>Fun��o*</td><td>
          <select name="funcao">
              <option value="">...Selecione Fun��o...</option>
              <option value="COORDENADOR LIE">COORDENADOR LIE</option>			  
			  <option value="DIRETOR">DIRETOR</option>
			  <option value="SUPERVISOR">SUPERVISOR</option>
          </select>
      </td>
	</tr>


   <tr><td></td>
   <td><left>
 <input name="submit"  type="submit"  value="Gravar" onClick="javascript:return validatecnico();" >  
 <input name="reset"   type="reset"   value="Limpar" onClick="javascript:return validacampo();" >  
    </td>
  </tr>
             <tr>
               <td height="2"></td>
             </tr>
 
     </form>     
 </table>

</div>
	<br><br><br>
	
    <div id="menu" class="fonte" align="left">
   	    <p>&nbsp; </p>
	    <h3 align="center" class="style5" >Escola</h3>
	    <h3 align="center" class="style5" >Cadastro</h3>
	    <h3 align="center" class="style5" >Pessoal</h3>
   	  <ul  class="menu_vertical">
		 <li><a href="mnescola.php"   title="Retorna ao Menu">Volta</a>
      </ul>			
	</div>
</div>    
    
	
	 <div id="rodape" class="fonterodape">
	         Endere�o : Rua General Os�rio, 81 Centro.<br>
	         CEP: 76801-086 - Porto Velho (RO) <br>
			 Fone:(69)3216-5325-5306
     </div>   

</body>
</html>
