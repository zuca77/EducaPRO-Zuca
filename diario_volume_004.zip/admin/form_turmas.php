<?php
require_once '../start.php';
$pdo = new Conexao;

$title = 'Turmas';

$sql = "SELECT e.inep, CONCAT(e.inep, ' ', e.descricao, ' (', m.descricao, ')') AS descricao
				FROM escola e
					JOIN municipio m ON e.municipio = m.codigo
				ORDER BY m.descricao, e.descricao";
$escolas = $pdo->query($sql)->fetchAll();

$sql = "SELECT ano FROM ano_letivo ORDER BY ano DESC";
$anosLetivos = $pdo->query($sql)->fetchAll();

if (isset($_POST['action']) && $_POST['action'] == 'excluir' && isset($_POST['id'])) {
	if ($_POST['id'] !== $_POST['id_turma']) {
		$error = "O ID de confirma��o da turma � diferente do ID da turma que deseja excluir. Preste aten��o.<br>";
		$error.= "ID Turma: <b>{$_POST['id']}</b> - ID Confirma��o: <b>{$_POST['id_turma']}</b>.";
		Notification::error($error);
		redirectBack();
	}

	if ($_POST['inep'] !== $_POST['inep_turma']) {
		$error = "O INEP de confirma��o da turma � diferente do INEP da turma que deseja excluir. Preste aten��o.<br>";
		$error.= "INEP Turma: <b>{$_POST['inep']}</b> - INEP Confirma��o: <b>{$_POST['inep_turma']}</b>.";
		Notification::error($error);
		redirectBack();
	}

	if ($_POST['cpf'] != $_SESSION['usuario']['cpf']) {
		Notification::error('O CPF de confirma��o � diferente do usu�rio logado. Preste aten��o.');
		redirectBack();
	}

	$sql = "CALL exclui_turma(:id_turma, :inep);";
	$sth = $pdo->prepare($sql);
	$sth->bindParam(':id_turma', $_POST['id_turma'], PDO::PARAM_INT);
	$sth->bindParam(':inep', $_POST['inep_turma'], PDO::PARAM_STR);

	try {
		if ($sth->execute()) {
			Notification::success('Exclu�do turma e todos os dados associados com sucesso.');

			$msg = "Exclu�do turma ID {$_POST['id_turma']}, INEP {$_POST['inep_turma']} e todos os dados com sucesso. Usu�rio {$_POST['cpf']}!";
			Logger::success('Exclu�do turma', $msg);

			redirect('admin/form_turmas.php');
		} else {
			Notification::error('N�o foi poss�vel excluir turma.');
			$msg = "N�o foi poss�vel excluir turma ID {$_POST['id_turma']}, INEP {$_POST['inep_turma']}";
			Logger::error('Erro Excluir Turma', '');
		}
	} catch (Exception $e) {
		Notification::ex($e);
		Logger::exception('Exception Excluir Turma', $e . " Usu�rio {$_POST['cpf']}!");
	}

	redirectBack();
}

if (isset($_GET['inep']) && !empty($_GET['inep'])) {
	$escola = Escola::get($_GET['inep']);

	$sql = "SELECT id, descricao, inep, ano, fechado
					FROM turma
					WHERE inep = :inep AND ano = :ano;";
	$sth = $pdo->prepare($sql);
	$sth->bindParam(':inep', $_GET['inep']);
	$sth->bindParam(':ano', $_GET['ano']);
	$turmas = $sth->execute() ? $sth->fetchAll() : null;
}

if (isset($_GET['id'])) {
	$sql = "SELECT id, descricao, inep, ano FROM turma
					WHERE id = :id AND inep = :inep";
	$sth = $pdo->prepare($sql);
	$sth->bindParam(':id', $_GET['id']);
	$sth->bindParam(':inep', $_GET['inep']);
	$turma = $sth->execute() ? $sth->fetch() : null;

	if (!$turma) {
		redirect('admin/form_turmas.php');
	}

	$turma['escola'] = Escola::get($turma['inep']);

//	Total de Professores
	$sql = "SELECT count(usuario) as total FROM turmaprofessor WHERE id_turma = {$turma['id']}";
	$sth = $pdo->prepare($sql);
	$sth->execute();

	$total_professores = $sth->fetch()['total'];

//	Total de Alunos
    $sql = "SELECT count(id) as total FROM turma_aluno WHERE id_turma = {$turma['id']}";
    $sth = $pdo->prepare($sql);
    $sth->execute();

    $total_alunos = $sth->fetch()['total'];

//  Total Notas lan�adas
    $sql = "SELECT count(id) as total FROM nota_aluno WHERE id_turma = {$turma['id']}";
    $sth = $pdo->prepare($sql);
    $sth->execute();

    $total_notas = $sth->fetch()['total'];

//  Total de Frequ�ncias lan�adas
    $tabela_frequencia = tFrequenciaAluno($_GET['ano']);
    $sql = "SELECT count(id) as total FROM {$tabela_frequencia} WHERE id_turma = {$turma['id']}";
    $sth = $pdo->prepare($sql);
    $sth->execute();

    $total_frequencias = $sth->fetch()['total'];

}

?><!DOCTYPE HTML>
<html>
<head>
	<?php require_once page_head(); ?>
</head>
<body>
	<?php require_once page_header(); ?>

		<div class="container">
			<form class="well well-sm" method="GET">
				<div class="row">
					<div class="col-md-10">
						<div class="form-group">
							<label for="inep">Escola</label>
							<select name="inep" id="inep" class="form-control chosen" onchange="this.form.submit()">
								<option value=""></option>
								<?php foreach ($escolas as $escola): ?>
								<option value="<?php echo $escola['inep'] ?>" <?php selected(isset($_GET['inep']) && $_GET['inep'] == $escola['inep']) ?>><?php echo $escola['descricao'] ?></option>
								<?php endforeach ?>
							</select>
						</div>
					</div>
					<div class="col-md-2">
						<div class="form-group">
							<label for="ano">Ano letivo</label>
							<select name="ano" id="ano" class="form-control chosen" onchange="this.form.submit()">
								<?php foreach ($anosLetivos as $aaa): ?>
								<option value="<?php echo $aaa['ano'] ?>" <?php selected(isset($_GET['ano']) && $_GET['ano'] == $aaa['ano']) ?>><?php echo $aaa['ano'] ?></option>
								<?php endforeach ?>
							</select>
						</div>
					</div>
				</div>
			</form>

			<?php if (isset($turma) && isset($_GET['action']) && $_GET['action'] == 'excluir'): ?>
			<form method="POST" class="submit-wait">
				<input type="hidden" name="action" value="excluir">
				<input type="hidden" name="inep" value="<?php echo $turma['inep'] ?>">
				<fieldset>
					<legend>Excluir turma</legend>

					<div class="row">
						<div class="col-md-2">
							<div class="form-group">
								<label>ID Turma</label>
								<input name="id" value="<?php echo $turma['id'] ?>" class="form-control" readonly>
							</div>
						</div>
						<div class="col-md-8">
							<div class="form-group">
								<label>Descri��o</label>
								<input class="form-control" value="<?php echo $turma['descricao'] ?>" readonly>
							</div>
						</div>
						<div class="col-md-2">
							<div class="form-group">
								<label>Ano Letivo</label>
								<input value="<?php echo $turma['ano'] ?>" class="form-control" readonly>
							</div>
						</div>
					</div>

					<div class="form-group">
						<label>Escola</label>
						<input value="<?php echo $turma['escola']['inep'].' '.$turma['escola']['descricao'] ?>" class="form-control" readonly>
					</div>

                    <div class="row">
                        <div class="col-md-3">
                            <div class="panel panel-default">
                                <div class="panel-heading text-center">
                                    <span class="h4 text-muted">Total de professores</span>
                                </div>

                                <div class="panel-body text-center">
                                    <span class="h1 text-muted"><?= $total_professores ?></span>
                                </div>
                            </div>
                        </div>

                        <div class="col-md-3">
                            <div class="panel panel-default">
                                <div class="panel-heading text-center">
                                    <span class="h4 text-muted">Alunos na turma</span>
                                </div>

                                <div class="panel-body text-center">
                                    <span class="h1 text-muted"><?= $total_alunos ?></span>
                                </div>
                            </div>
                        </div>

                        <div class="col-md-3">
                            <div class="panel panel-default">
                                <div class="panel-heading text-center">
                                    <span class="h4 text-muted">Notas lan�adas</span>
                                </div>

                                <div class="panel-body text-center">
                                    <span class="h1 text-muted"><?= $total_notas ?></span>
                                </div>
                            </div>
                        </div>

                        <div class="col-md-3">
                            <div class="panel panel-default">
                                <div class="panel-heading text-center">
                                    <span class="h4 text-muted">Frequ�ncias lan�adas</span>
                                </div>

                                <div class="panel-body text-center">
                                    <span class="h1 text-muted"><?= $total_frequencias ?></span>
                                </div>
                            </div>
                        </div>
                    </div>

					<fieldset class="well well-sm">
						<legend>Confirma��o da exclus�o</legend>

						<p>
							Digite novamente o INEP, ID da turma e o seu CPF para confirmar.
						</p>

						<div class="row">
							<div class="col-md-2">
								<div class="form-group">
									<label>INEP</label>
									<input autocomplete="off" name="inep_turma" maxlength="8" class="form-control" placeholder="Digite o INEP" required>
								</div>
							</div>

							<div class="col-md-2">
								<div class="form-group">
									<label>ID Turma</label>
									<input autocomplete="off" name="id_turma" maxlength="10" class="form-control" placeholder="Digite o ID da turma" required>
								</div>
							</div>

							<div class="col-md-2">
								<div class="form-group">
									<label>CPF do Usu�rio</label>
									<input autocomplete="off" name="cpf" value="" class="form-control mask-cpf" placeholder="Digite o seu CPF" required>
								</div>
							</div>

							<div class="col-md-6">
							<div class="alert alert-danger">
								<h4>ATEN��O!</h4>
								Muito cuidado ao executar essa opera��o. <b>Todos os dados associado � turma ser�o exclu�dos.</b>
								Todos os alunos matr�culados na turma, abono de faltas, professores associados, lan�amentos de notas e presen�as,
								previs�o de aulas e v�rios outros registros. N�o ser� poss�vel restaurar os dados ap�s a exclus�o.
							</div>
							</div>
						</div>
					</fieldset>

					<div class="well well-sm">
						<button type="submit" class="btn btn-danger btn-lg btn-submit-wait" onclick="return confirm('Confirma excluir turma?')">
							EXCLUIR TURMA
						</button>

						<button type="button" class="btn btn-back btn-default pull-right">Voltar</button>
					</div>
				</fieldset>
			</form>

			<?php elseif (isset($turmas)): ?>
				<table class="table table-bordered table-condensed table-striped">
					<thead>
						<tr>
							<th width="80">ID Turma</th>
							<th>Turma</th>
							<th width="80">Situa��o</th>
							<th width="80"></th>
						</tr>
					</thead>
					<tbody>
					<?php foreach ($turmas as $tu): ?>
						<tr>
							<td>
								<?php echo $tu['id'] ?>
							</td>
							<td>
								<?php echo $tu['descricao'] ?>
							</td>
							<td>
								<span class="text-<?php echo $tu['fechado'] == 'S' ? 'danger' : 'success' ?>">
									<?php echo $tu['fechado'] == 'S' ? 'FECHADA' : 'ABERTA' ?>
								</span>
							</td>
							<td>
								<a href="<?php url("admin/form_turmas.php?action=excluir&id={$tu['id']}&inep={$tu['inep']}&ano={$tu['ano']}") ?>" class="btn btn-xs btn-danger pull-right">
									EXCLUIR
								</a>
							</td>
						</tr>
					<?php endforeach ?>
					</tbody>
				</table>
			<div class="list-group">
			</div>
			<?php endif ?>

		</div>
	<?php require_once page_footer(); ?>
</body>
</html>