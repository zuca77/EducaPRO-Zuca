<?php
require_once '../start.php';
$pdo = new Conexao;

$title = 'Editar escola';

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
  $sql = "UPDATE escola
          SET descricao=:descricao, municipio=:municipio, tipo=:tipo, endereco=:logradouro, numero=:numero, bairro=:bairro, fone=:fone,
          	diretor=:diretor,vicediretor=:vicediretor,secretario=:secretario,latitude=:latitude,longitude=:longitude, tipo_rede_ensino=:tipo_rede_ensino
          WHERE inep=:inep;";
  $sth = $pdo->prepare($sql);
  $sth->bindParam(':inep', $_POST['inep']);
  $sth->bindParam(':descricao', $_POST['descricao']);
  $sth->bindParam(':municipio', $_POST['municipio']);
  $sth->bindParam(':tipo', $_POST['tipo']);
  $sth->bindParam(':logradouro', $_POST['logradouro']);
  $sth->bindParam(':numero', $_POST['numero']);
  $sth->bindParam(':bairro', $_POST['bairro']);
  $sth->bindParam(':fone', $_POST['fone']);
  $sth->bindParam(':diretor', $_POST['diretor']);
  $sth->bindParam(':vicediretor', $_POST['vicediretor']);
  $sth->bindParam(':secretario', $_POST['secretario']);
  $sth->bindParam(':latitude', $_POST['latitude']);
  $sth->bindParam(':longitude', $_POST['longitude']);
  $sth->bindParam(':tipo_rede_ensino', $_POST['tipo_rede_ensino']);

  try {
    if ($sth->execute()) {
    	$msg = "Escola {$_POST['inep']} {$_POST['descricao']} atualizada com sucesso.";
    	Logger::success('Escola atualizada', $msg);
      Notification::success($msg);
    } else {
      Notification::error('N�o foi poss�vel salvar altera��es.');
    }
  } catch (Exception $e) {
    Notification::ex($e);
  }
  redirectBack();
}

$municipios = Municipio::getAll();

$sql = "SELECT * FROM rede_ensino;";
$query = $pdo->query($sql);
$query->execute();
$tiposRedeEnsino = $query->fetchAll();

if (isset($_GET['inep']) && !empty($_GET['inep'])) {
  $escola = Escola::get($_GET['inep']);
}

?><!DOCTYPE HTML>
<html>
	<head>
		<?php require_once page_head(); ?>
	</head>
	<body>
		<?php require_once page_header(); ?>
		<div class="container">
			<form id="formEscola" class="submit-wait" method="POST">
          <input type="hidden" name="codigo" value="<?php echo isset($escola) ? $escola['codigo'] : null ?>">
          <div class="row">
            <div class="col-md-2">
              <div class="form-group">
                <label for="inep">INEP</label>
                <input type="text" id="inep" name="inep" maxlength="11" value="<?php echo isset($escola) ? $escola['inep'] : null ?>" class="form-control text-uppercase" <?php echo isset($escola) ? 'readonly' : '' ?> required>
              </div>
            </div>
            <div class="col-md-3">
              <div class="form-group">
                <label for="descricao">Nome da escola</label>
                <input type="text" id="descricao" name="descricao" value="<?php echo isset($escola) ? $escola['descricao'] : null ?>" class="form-control text-uppercase" required>
              </div>
            </div>
            <div class="col-md-3">
              <div class="form-group">
                <label for="municipio">Munic�pio</label>
                <select name="municipio" id="municipio" class="form-control chosen" required>
                  <option value=""></option>
                  <?php foreach ($municipios as $mu) : ?>
                  <option value="<?php echo $mu['id'] ?>" <?php echo (isset($escola) && $mu['id']==$escola['cod_municipio']) ? 'selected' : '' ?>><?php echo $mu['descricao'] ?></option>
                  <?php endforeach ?>
                </select>
              </div>
            </div>
            <div class="col-md-2">
              <div class="form-group">
                <div class="form-group">
                  <label for="tipo">Zona</label>
                  <select name="tipo" id="tipo" class="form-control" required>
                    <option value=""></option>
                    <option value="URBANA" <?php echo isset($escola) && $escola['zona']=='URBANA' ? 'selected' : '' ?>>URBANA</option>
                    <option value="RURAL" <?php echo isset($escola) && $escola['zona']=='RURAL' ? 'selected' : '' ?>>RURAL</option>
                  </select>
                </div>
              </div>
            </div>
            <div class="col-md-2">
              <div class="form-group">
                <div class="form-group">
                  <label for="tipo_rede_ensino">Rede de ensino</label>
                  <select name="tipo_rede_ensino" id="tipo_rede_ensino" class="form-control" required>
                    <option value=""></option>
                    <?php
                        foreach ($tiposRedeEnsino as $rede_ensino):
                            echo "<option value='{$rede_ensino['id']}'";
                            echo (isset($escola) && $escola['tipo_rede_ensino'] == $rede_ensino['id']) ? ' selected' : '';
                            echo ">{$rede_ensino['descricao']}</option>";
                        endforeach;
                    ?>
                  </select>
                </div>
              </div>
            </div>
          </div>
          <div class="row">
            <div class="col-md-5">
              <div class="form-group">
                <div class="form-group">
                  <label for="logradouro">Logradouro</label>
                  <input type="text" id="logradouro" name="logradouro" value="<?php echo isset($escola) ? $escola['endereco'] : null ?>" class="form-control text-uppercase" required>
                </div>
              </div>
            </div>
            <div class="col-md-2">
              <div class="form-group">
                <div class="form-group">
                  <label for="numero">N�mero</label>
                  <input type="text" id="numero" name="numero" value="<?php echo isset($escola) ? $escola['numero'] : null ?>" class="form-control text-uppercase" required>
                </div>
              </div>
            </div>
            <div class="col-md-3">
              <div class="form-group">
                <div class="form-group">
                  <label for="bairro">Bairro</label>
                  <input type="text" id="bairro" name="bairro" value="<?php echo isset($escola) ? $escola['bairro'] : null ?>" class="form-control text-uppercase" required>
                </div>
              </div>
            </div>
            <div class="col-md-2">
              <div class="form-group">
                <div class="form-group">
                  <label for="fone">Telefone</label>
                  <input type="text" id="fone" name="fone" value="<?php echo isset($escola) ? $escola['fone'] : null ?>" class="form-control mask-telefone" required>
                </div>
              </div>
            </div>
          </div>
          <div class="row">
            <div class="col-md-4">
              <div class="form-group">
                <div class="form-group">
                  <label for="diretor">Diretor(a)</label>
                  <input type="text" id="diretor" name="diretor" value="<?php echo isset($escola) ? $escola['diretor'] : null ?>" class="form-control text-uppercase">
                </div>
              </div>
            </div>
            <div class="col-md-4">
              <div class="form-group">
                <div class="form-group">
                  <label for="vicediretor">Vice-diretor(a)</label>
                  <input type="text" id="vicediretor" name="vicediretor" value="<?php echo isset($escola) ? $escola['vicediretor'] : null ?>" class="form-control text-uppercase">
                </div>
              </div>
            </div>
            <div class="col-md-4">
              <div class="form-group">
                <div class="form-group">
                  <label for="secretario">Secret�rio(a)</label>
                  <input type="text" id="secretario" name="secretario" value="<?php echo isset($escola) ? $escola['secretario'] : null ?>" class="form-control text-uppercase">
                </div>
              </div>
            </div>
          </div>

          <div class="gllpLatlonPicker">
          	<div class="row">
          		<div class="col-md-2">
          			<div class="form-group">
									<label for="latitude">Latitude</label>
									<input type="text" class="form-control gllpLatitude" name="latitude" id="latitude" value="<?php echo isset($escola['latitude']) ? $escola['latitude'] : '' ?>">
          			</div>
          		</div>
          		<div class="col-md-2">
          			<div class="form-group">
          				<label for="longitude">Longitude</label>
									<input type="text" class="form-control gllpLongitude" name="longitude" id="longitude" value="<?php echo isset($escola['longitude']) ? $escola['longitude'] : '' ?>">
          			</div>
          		</div>
          		<div class="col-md-8">
          			<div class="form-group">
          				<label for="q">Procurar endere�o</label>
									<div class="input-group">
										<?php $endereco = "{$escola['endereco']}, {$escola['numero']}, {$escola['bairro']}, {$escola['municipio']}"; ?>
										<input id="q" type="text" class="gllpSearchField form-control" placeholder="Digite o endere�o para procurar" value="<?php echo $endereco ?>">
										<div class="input-group-btn">
											<button type="button" class="gllpSearchButton btn btn-default">PROCURAR</button>
										</div>
									</div>
          			</div>
          		</div>
          	</div>
						<div class="gllpMap well well-sm" style="height: 500px; width:100%">Google Maps</div>
						<br>
						<input type="hidden" class="gllpLatitude" value="<?php echo isset($escola['latitude']) ? $escola['latitude'] : '-10' ?>">
						<input type="hidden" class="gllpLongitude" value="<?php echo isset($escola['longitude']) ? $escola['longitude'] : '-63' ?>">
						<input type="hidden" class="gllpZoom" value="<?php echo isset($escola['latitude']) && $escola['longitude'] ? 15 : 7 ?>">
					</div>

          <div class="well well-sm">
            <a href="<?php url("admin/formcadastroescola.php") ?>" class="btn btn-default ">Voltar</a>
	          <button type="submit" class="btn btn-primary btn-submit-wait pull-right">SALVAR ALTERA��ES</button>
          </div>
        </form>
		</div>
        <script src="http://maps.googleapis.com/maps/api/js?key=AIzaSyDQoKEPOecap3ae6K2KEZLmaF10Kn25bLQ"></script>
        <?php require_once page_footer(); ?>
	</body>
</html>