<?php
require_once '../start.php';

Auth::whiteList('ADM');

$title = 'Editar Usu�rio';
$pdo = new Conexao;

$niveis = Auth::niveisAcesso();
$usuarioEdit = Usuario::getById($_GET['id']);
if(!$usuarioEdit) {
	redirect('admin/formcadusuario.php');
}

$sql = "SELECT id, lotado FROM lotacao WHERE cpf = :cpf;";
$sth = $pdo->prepare($sql);
$sth->bindParam(':cpf', $usuarioEdit['cpf']);
$lotacoes = $sth->execute() ? $sth->fetchAll() : null;

$sql = "SELECT inep FROM escola ORDER BY inep";
$escolas = $pdo->query($sql)->fetchAll();

?><!DOCTYPE html>
<html>
	<head>
		<?php require_once page_head(); ?>
	</head>
	<body>
		<?php require_once page_header(); ?>

		<div class="container">

			<form action="altera_usuario.php" method="post" class="submit-wait">
				<fieldset class="well well-sm">
					<legend>
						Dados do Usu�rio

						<small class="text-right text-muted pull-right">
							Cadastrado em <?php echo date('d/m/Y H:i:s', strtotime($usuarioEdit["created_at"])); ?>
							<br>
							Atualizado em <?php echo date('d/m/Y H:i:s', strtotime($usuarioEdit["updated_at"])); ?>
						</small>
					</legend>

					<div class="row">
						<div class="col-md-2">
							<div class="form-group">
								<label for="cpf">CPF</label>
								<input readonly name="cpf" class="form-control" type="text" value="<?php echo $usuarioEdit['cpf'] ?>">
							</div>
						</div>
						<div class="col-md-8">
							<div class="form-group">
								<label for="nome">Nome</label>
								<input name="nome" maxlength="120" type="text" class="form-control" value="<?php echo $usuarioEdit["nome"]; ?>">
							</div>
						</div>
						<div class="col-md-2">
							<div class="form-group">
								<label for="ativo">Ativo</label>
								<select name="ativo" id="ativo" class="form-control">
									<option value="S" <?php echo isset($usuarioEdit['ativo']) && $usuarioEdit['ativo']=='S' ? 'selected' : '' ?>>SIM</option>
									<option value="N" <?php echo isset($usuarioEdit['ativo']) && $usuarioEdit['ativo']=='N' ? 'selected' : '' ?>>N�O</option>
								</select>
							</div>
						</div>
					</div>
				</fieldset>

				<fieldset>
					<legend>Lota��es do Usu�rio</legend>

					<table class="table table-bordered table-condensed table-striped">
						<tr>
						 	<th width="60">Matr�cula</th>
						 	<th>INEP / Ger�ncia</th>
						 	<th>Escola / Departamento</th>
						 	<th width="100" class="text-center">Lotado em</th>
						 	<th width="80" class="text-center">Sa�da em</th>
							<th width="30" class="text-center" title="Carga Hor�ria">C.H.</th>
							<th width="30" class="text-center" title="Qtda Aulas">Aulas</th>
						</tr>
						<?php foreach($lotacoes as $lota):
							if ($lota['lotado'] == '2') {
						 		$sql = "SELECT l.id ,l.cpf,l.matricula,l.lotado,l.gerencia,l.departamento,l.qtdaaula ,l.inep,l.dtlotacao,l.chlotacao,e.descricao,l.dtsaida,l.dtren,l.dtescola,l.dtren,l.dtescola
			 									FROM lotacao l
			 										LEFT JOIN escola e ON l.inep = e.inep
			 									WHERE l.id = :id;";
						  } else {
						  	$sql = "SELECT l.id,l.cpf,l.matricula,l.chlotacao,l.dtlotacao,l.dtsaida,l.qtdaaula,l.dtren,l.dtescola,g.sigla,g.descricao,d.descricao AS descricaod
			  								FROM lotacao l
			  									LEFT JOIN gerencia g ON l.gerencia = g.codigo
			  									LEFT JOIN departamento d ON d.gerencia = l.gerencia
			  								WHERE l.id = :id;";
						 	}
		 					$sth = $pdo->prepare($sql);
		 					$sth->bindParam(':id', $lota['id']);
		 					$registro = $sth->execute() ? $sth->fetch() : null;
						?>
						<tr>
				   	  <td><small><?php echo $registro['matricula'];?></small></td>
							<?php if ($lota['lotado'] == '2') { ?>
				      <td><small><?php echo $registro['inep'];?></small></td>
				      <td><small><?php echo $registro['descricao'];?></small></td>
				      <?php } else { ?>
				      <td><small><?php echo $registro['sigla'];?></small></td>
				      <td><small><?php echo $registro['descricaod'];?></small></td>
							<?php } ?>
				      <td class="text-center"><?php echo formataData($registro['dtlotacao']) ?></td>
				      <td class="text-center"><?php echo formataData($registro['dtsaida']) ?></td>
				      <td class="text-center"><?php echo empty($registro['chlotacao']) ? '-' : $registro['chlotacao'];?></td>
				      <td class="text-center"><?php echo empty($registro['qtdaaula']) ?  '-' : $registro['qtdaaula'];?></td>
					  </tr>
						<?php endforeach ?>
					</table>
				</fieldset>

				<fieldset>
					<legend>Acessos do usu�rio</legend>

					<div class="row">
						<div class="col-md-6">
							<fieldset class="well well-sm">
								<legend>Permiss�o 1</legend>
								<div class="row">
									<div class="col-md-8">
										<div class="form-group">
											<label for="nivel">Ambiente</label>
											<select class="form-control chosen-deselect" name="nivel" id="nivel">
												<option value=""></option>
												<?php foreach($niveis as $nivel): ?>
													<option value="<?php echo $nivel['abreviacao']; ?>" <?php echo (($nivel['abreviacao'] == $usuarioEdit['nivel'])? " selected" : "") ?>>
														<?php echo $nivel['nome'] ?>
													</option>
												<?php endforeach ?>
											</select>
										</div>
									</div>
									<div class="col-md-4">
										<div class="form-group">
											<label for="dpto">INEP</label>
											<select class="form-control chosen-deselect" name="dpto" id="dpto">
												<option value=""></option>
												<?php foreach($escolas as $escola): ?>
													<option value="<?php echo $escola['inep']; ?>" <?php selected($usuarioEdit['dpto'] == $escola['inep']) ?> >
														<?php echo $escola['inep'] ?>
													</option>
												<?php endforeach ?>
											</select>
										</div>
									</div>
								</div>
							</fieldset>
						</div>

						<div class="col-md-6">
							<fieldset class="well well-sm">
								<legend>Permiss�o 2</legend>
								<div class="row">
									<div class="col-md-8">
										<div class="form-group">
											<label for="nivel2">Ambiente</label>
											<select class="form-control chosen-deselect" name="nivel2" id="nivel2">
												<option value=""></option>
												<?php foreach($niveis as $nivel): ?>
													<option value="<?php echo $nivel['abreviacao']; ?>" <?php echo (($nivel['abreviacao'] == $usuarioEdit['nivel2'])? " selected" : "") ?>>
														<?php echo $nivel['nome'] ?>
													</option>
												<?php endforeach ?>
											</select>
										</div>
									</div>
									<div class="col-md-4">
										<div class="form-group">
											<label for="dpto2">INEP</label>
											<select class="form-control chosen-deselect" name="dpto2" id="dpto2">
												<option value=""></option>
												<?php foreach($escolas as $escola): ?>
													<option value="<?php echo $escola['inep']; ?>" <?php selected($usuarioEdit['dpto2'] == $escola['inep']) ?> >
														<?php echo $escola['inep'] ?>
													</option>
												<?php endforeach ?>
											</select>
										</div>
									</div>
								</div>
							</fieldset>
						</div>
					</div>

					<div class="row">
						<div class="col-md-6">
							<fieldset class="well well-sm">
								<legend>Permiss�o 3</legend>
								<div class="row">
									<div class="col-md-8">
										<div class="form-group">
											<label for="nivel3">Ambiente</label>
											<select class="form-control chosen-deselect" name="nivel3" id="nivel3">
												<option value=""></option>
												<?php foreach($niveis as $nivel): ?>
													<option value="<?php echo $nivel['abreviacao']; ?>" <?php echo (($nivel['abreviacao'] == $usuarioEdit['nivel3'])? " selected" : "") ?>>
														<?php echo $nivel['nome'] ?>
													</option>
												<?php endforeach ?>
											</select>
										</div>
									</div>
									<div class="col-md-4">
										<div class="form-group">
											<label for="dpto3">INEP</label>
											<select class="form-control chosen-deselect" name="dpto3" id="dpto3">
												<option value=""></option>
												<?php foreach($escolas as $escola): ?>
													<option value="<?php echo $escola['inep']; ?>" <?php selected($usuarioEdit['dpto3'] == $escola['inep']) ?> >
														<?php echo $escola['inep'] ?>
													</option>
												<?php endforeach ?>
											</select>
										</div>
									</div>
								</div>
							</fieldset>
						</div>

						<div class="col-md-6">
							<fieldset class="well well-sm">
								<legend>Permiss�o 4</legend>
								<div class="row">
									<div class="col-md-8">
										<div class="form-group">
											<label for="nivel4">Ambiente</label>
											<select class="form-control chosen-deselect" name="nivel4" id="nivel4">
												<option value=""></option>
												<?php foreach($niveis as $nivel): ?>
													<option value="<?php echo $nivel['abreviacao']; ?>" <?php echo (($nivel['abreviacao'] == $usuarioEdit['nivel4'])? " selected" : "") ?>>
														<?php echo $nivel['nome'] ?>
													</option>
												<?php endforeach ?>
											</select>
										</div>
									</div>
									<div class="col-md-4">
										<div class="form-group">
											<label for="dpto4">INEP</label>
											<select class="form-control chosen-deselect" name="dpto4" id="dpto4">
												<option value=""></option>
												<?php foreach($escolas as $escola): ?>
													<option value="<?php echo $escola['inep']; ?>" <?php selected($usuarioEdit['dpto4'] == $escola['inep']) ?> >
														<?php echo $escola['inep'] ?>
													</option>
												<?php endforeach ?>
											</select>
										</div>
									</div>
								</div>
							</fieldset>
						</div>

						<div class="col-md-6">
							<fieldset class="well well-sm">
								<legend>Permiss�o 5</legend>
								<div class="row">
									<div class="col-md-8">
										<div class="form-group">
											<label for="nivel5">Ambiente</label>
											<select class="form-control chosen-deselect" name="nivel5" id="nivel5">
												<option value=""></option>
												<?php foreach($niveis as $nivel): ?>
													<option value="<?php echo $nivel['abreviacao']; ?>" <?php echo (($nivel['abreviacao'] == $usuarioEdit['nivel5'])? " selected" : "") ?>>
														<?php echo $nivel['nome'] ?>
													</option>
												<?php endforeach ?>
											</select>
										</div>
									</div>
									<div class="col-md-4">
										<div class="form-group">
											<label for="dpto5">INEP</label>
											<select class="form-control chosen-deselect" name="dpto5" id="dpto5">
												<option value=""></option>
												<?php foreach($escolas as $escola): ?>
													<option value="<?php echo $escola['inep']; ?>" <?php selected($usuarioEdit['dpto5'] == $escola['inep']) ?> >
														<?php echo $escola['inep'] ?>
													</option>
												<?php endforeach ?>
											</select>
										</div>
									</div>
								</div>
							</fieldset>
						</div>

						<div class="col-md-6">
							<fieldset class="well well-sm">
								<legend>Permiss�o 6</legend>
								<div class="row">
									<div class="col-md-8">
										<div class="form-group">
											<label for="nivel6">Ambiente</label>
											<select class="form-control chosen-deselect" name="nivel6" id="nivel6">
												<option value=""></option>
												<?php foreach($niveis as $nivel): ?>
													<option value="<?php echo $nivel['abreviacao']; ?>" <?php echo (($nivel['abreviacao'] == $usuarioEdit['nivel6'])? " selected" : "") ?>>
														<?php echo $nivel['nome'] ?>
													</option>
												<?php endforeach ?>
											</select>
										</div>
									</div>
									<div class="col-md-4">
										<div class="form-group">
											<label for="dpto6">INEP</label>
											<select class="form-control chosen-deselect" name="dpto6" id="dpto6">
												<option value=""></option>
												<?php foreach($escolas as $escola): ?>
													<option value="<?php echo $escola['inep']; ?>" <?php selected($usuarioEdit['dpto6'] == $escola['inep']) ?> >
														<?php echo $escola['inep'] ?>
													</option>
												<?php endforeach ?>
											</select>
										</div>
									</div>
								</div>
							</fieldset>
						</div>
					</div>
				</fieldset>

				<div class="row">
					<div class="col-md-8">
						<fieldset class="well well-sm">
							<legend>Senha</legend>

							<div class="row">
								<div class="col-md-4">
									<div class="checkbox">
										<br>
										<label>
											<input name="alterasenha" type="checkbox" id="alterasenha" value="1">
											Alterar senha?
										</label>
									</div>
								</div>
								<div id="resetar" style="display:none">
									<div class="col-md-4">
										<div class="form-group">
											<label for="senha">Senha</label>
											<input  name="senha" class="form-control" placeholder="Nova senha" type="password" value="">
										</div>
									</div>
									<div class="col-md-4">
										<div class="form-group">
											<label for="senhaconf">Confirma��o de Senha</label>
											<input type="password" id="senhaconf" class="form-control" placeholder="Confirma��o da senha" name="senhaconf">
										</div>
									</div>
								</div>
							</div>
						</fieldset>
					</div>
					<div class="col-md-4">
						<fieldset class="well well-sm">
							<p>
								Clique no bot�o para resetar a senha do usu�rio para a padr�o <b><?php echo Usuario::DEFAULT_PASSWORD ?></b>.
							</p>
							<p>
								Ap�s autenticar, o usu�rio ser� solicitado a alterar a senha.
							</p>
							<a href="<?php url("reseta_senha_usuario.php?cpf={$usuarioEdit['cpf']}") ?>" onclick="return confirm('Confirma resetar senha de usu�rio?')"
								class="btn btn-block btn-danger">RESETAR SENHA PARA PADR�O</a>
						</fieldset>
					</div>
				</div>

				<div class="well well-sm">
					<button type="submit" class="btn btn-primary btn-submit-wait">SALVAR ALTERA��ES</button>
					<a class="btn btn-default pull-right" href="formcadusuario.php">Voltar</a>
				</div>
			</form>
		</div>

		<?php require_once page_footer(); ?>
<!--		<script language="javascript" src="../generic.js"></script>-->
		<script type="text/javascript">
			$(document).ready(function () {
				$('#alterasenha').change(function(e) {
					var check = $(this);
					if (check.is(':checked')) {
						$('#resetar').show();
					} else {
						$('#resetar').hide();
					}
				});
			});
		</script>
	</body>
</html>