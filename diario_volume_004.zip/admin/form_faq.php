<?php
require_once '../start.php';
$pdo = new Conexao;

$niveis = array("ADM","DGE");
Auth::whiteList($niveis);

$title = 'FAQs';
$subtitle = 'Perguntas e Respostas Frequentes';

$faqs = Faq::getAll();
$temas = Faq::temas();

if ($_SERVER['REQUEST_METHOD'] == 'POST') {

  $conteudo = htmlspecialchars($_POST['conteudo'], ENT_IGNORE, 'ISO-8859-1');

  if (empty($conteudo)) {
    Notification::error('O conte�do est� vazio.');
    redirectBack();
  }

  if (isset($_POST['id'])) {
    $sql = "UPDATE faqs
            SET titulo=:titulo, conteudo=:conteudo,status=:status, updated_by=:usuario, updated_at=NOW()
            WHERE id = :id;";
    $sth = $pdo->prepare($sql);
    $sth->bindParam(':id', $_POST['id']);
    $sth->bindParam(':status', $_POST['status']);
    $sth->bindParam(':titulo', $_POST['titulo']);
    $sth->bindParam(':conteudo', $conteudo);
    $sth->bindParam(':usuario', $_SESSION['usuario']['cpf']);
  } else {

    $sql = "INSERT INTO faqs (titulo, conteudo, created_by, updated_by, status, created_at, updated_at)
            VALUES (:titulo, :conteudo, :usuario, :usuario, 1, NOW(), NOW());";
    $sth = $pdo->prepare($sql);
    $sth->bindParam(':titulo', $_POST['titulo']);
    $sth->bindParam(':conteudo', $conteudo);
    $sth->bindParam(':usuario', $_SESSION['usuario']['cpf']);
  }

  try {
    if ($sth->execute()) {
      Notification::success('Publica��o salva com sucesso.');

      $sql = "SELECT id FROM faqs WHERE titulo = :titulo AND conteudo = :conteudo;";
      $sth = $pdo->prepare($sql);
      $sth->bindParam(':titulo', $_POST['titulo']);
      $sth->bindParam(':conteudo', $conteudo);
      $criado = $sth->execute() ? $sth->fetch() : null;

      //ve se ja tem tema para o faq e deleta para inserir novos
      $sql = "DELETE FROM faq_tema WHERE id_faq = :id_faq;";
      $sth = $pdo->prepare($sql);
      $sth->bindParam(':id_faq', $criado['id']);
      $sth->execute();

      $inserirTemas = $_POST['tema'];
      foreach ($inserirTemas as $inserirTema) {
        $sql = "INSERT INTO faq_tema (id_faq,id_tema)
                VALUES (:id_faq, :id_tema);";
        $sth = $pdo->prepare($sql);
        $sth->bindParam(':id_faq', $criado['id']);
        $sth->bindParam(':id_tema',$inserirTema);
        $sth->execute();
      };

    } else {
      Notification::error('N�o foi poss�vel salvar publica��o.');
    }
  } catch (Exception $e) {
    Notification::ex($e);
  }

  redirect('admin/form_faq.php');
}

if (isset($_GET['editar']) && !empty($_GET['editar'])) {
  $sql = "SELECT f.*, CONCAT(uc.cpf, ' ', uc.nome) AS created_by_usuario, CONCAT(uu.cpf, ' ', uu.nome) AS updated_by_usuario
          FROM faqs f
            JOIN usuario uc ON uc.cpf = f.created_by
            JOIN usuario uu ON uu.cpf = f.updated_by
          WHERE f.id = :id;";
  $sth = $pdo->prepare($sql);
  $sth->bindParam(':id', $_GET['editar']);
  $faq = $sth->execute() ? $sth->fetch() : null;
}

?><!DOCTYPE HTML>
<html>
  <head>
    <?php require_once page_head(); ?>
    <link rel="stylesheet" type="text/css" href="<?php echo js('summernote/summernote.css') ?>">
  </head>
  <body>
  <?php require_once page_header(); ?>
  <div class="container">

    <p class="well well-sm">
      <a class="btn btn-success" href="?novo=1"><i class="fa fa-plus"></i> Adicionar FAQ</a>
      <button type="button" class="btn btn-default btn-back pull-right">Voltar</button>
    </p>

    <?php if (isset($_GET['novo']) && $_GET['novo']): ?>
    <div class="row">
        <form method="POST" class="submit-wait">
          <fieldset>
            <div class="col-md-12">
            <legend>Adicionar FAQ</legend>
            </div>
            <div class="col-md-8">
              <div class="form-group">
                <label for="titulo">T�tulo</label>
                <input id="titulo" type="text" class="form-control input" name="titulo" required>
              </div>
            </div>
            <div class="col-md-4">
              <div class="form-group">
                <label for="tema">Tem�tica</label>
                  <select name="tema[]" id="tema[]" multiple class="form-control chosen">
                    <option value=""></option>
                    <?php foreach ($temas as $tema): ?>
                    <option value="<?php echo $tema['id'] ?>"><?php echo $tema['descricao'] ?></option>
                    <?php endforeach ?>
                  </select>
              </div>
            </div>
            <div class="col-md-12">
              <div class="form-group">
                <textarea name="conteudo" class="editor">
                </textarea>
              </div>
            </div>
          </fieldset>
          <div class="col-md-12">
            <div class="well well-sm">
              <button type="submit" class="btn btn-primary btn-submit-wait">SALVAR</button>
            </div>
          </div>
        </form>
      </div>
    </div>
    <?php elseif (isset($_GET['editar']) && isset($faq)): ?>
      <form method="POST" class="submit-wait">
        <input type="hidden" name="id" value="<?php echo $faq['id']; ?>">
        <fieldset>
        <div class="row">
          <div class="col-md-12">
            <legend>Editar publica��o</legend>
            </div>
            <div class="col-md-8">
              <div class="form-group">
                <label for="titulo">T�tulo</label>
                <input id="titulo" type="text" class="form-control input" name="titulo" value="<?php echo $faq['titulo']; ?>" required>
              </div>
            </div>
            <div class="col-md-4">
              <div class="form-group">
                <label for="tema">Tem�tica</label>
                  <select name="tema[]" id="tema[]" multiple class="form-control chosen">
                    <option value=""></option>
                    <?php foreach ($temas as $tema): ?>
                    <option value="<?php echo $tema['id'] ?>"><?php echo $tema['descricao'] ?></option>
                    <?php endforeach ?>
                  </select>
              </div>
            </div>
            <div class="col-md-12">
              <div class="form-group">
                <textarea class="editor" name="conteudo"><?php echo $faq['conteudo']; ?></textarea>
              </div>
            </div>
          </div>
          <div class="row">
            <div class="col-md-2">
              <div class="form-group">
                <label for="status">Situa��o</label>
                <select name="status" id="status" class="form-control">
                  <option value="3" <?php selected($faq['status'] == 3) ?>>DESATIVADO</option>
                  <option value="2" <?php selected($faq['status'] == 2) ?>>PUBLICADO</option>
                  <option value="1" <?php selected($faq['status'] == 1) ?>>RASCUNHO</option>
                </select>
              </div>
            </div>
            <div class="col-md-2">
              <div class="form-group">
                <label for="created_at">Criado em</label>
                <input id="created_at" type="text" name="created_at" class="form-control" value="<?php echo formataDataHora($faq['created_at']); ?>" readonly>
              </div>
            </div>
            <div class="col-md-2">
              <div class="form-group">
                <label for="updated_at">Modificado em</label>
                <input id="updated_at" type="text" name="updated_at" class="form-control" value="<?php echo formataDataHora($faq['updated_at']); ?>" readonly>
              </div>
            </div>
            <div class="col-md-3">
              <div class="form-group">
                <label for="created_by_usuario">Criado por</label>
                <input id="created_by_usuario" type="text" name="created_by_usuario" class="form-control" value="<?php echo $faq['created_by_usuario']; ?>" readonly>
              </div>
            </div>
            <div class="col-md-3">
              <div class="form-group">
                <label for="updated_by_usuario">Modificado por</label>
                <input id="updated_by_usuario" type="text" name="updated_by_usuario" class="form-control" value="<?php echo $faq['updated_by_usuario']; ?>" readonly>
              </div>
            </div>
          </div>
        </fieldset>

        <div class="well well-sm">
          <button type="submit" value="0" class="btn btn-primary btn-submit-wait">SALVAR</button>
        </div>
      </form>
    <?php else: ?>
      <?php if (sizeof($faqs) == 0): ?>
      <div class="alert alert-info">
        Nenhuma FAQ para exibir. Adicione uma agora!
      </div>
      <?php endif ?>
      <table class="table table">
        <thead>
          <tr>
            <th width="10">#</th>
            <th>T�tulo</th>
            <th width="200">Tem�tica</th>
            <th width="130">Criado em</th>
            <th width="130">Modificado em</th>
            <th width="100">Situa��o</th>
            <th width="10"></th>
          </tr>
        </thead>
        <tbody>
        <?php foreach ($faqs as $nov): ?>
          <tr>
            <td><?php echo $nov['id']; ?></td>
            <td>
              <a href="#" onclick="$('#preview_<?php echo $nov['id']; ?>').toggle()" >
                <?php echo $nov['titulo'] ?>
              </a>

              <div style="display: none;" id="preview_<?php echo $nov['id']; ?>" class="well well-sm">
                <?php echo htmlspecialchars_decode($nov['conteudo']); ?>
              </div>
            </td>
            <td><?php $temasDesteFaq = Faq::temasFaq($nov['id']); 
                  foreach ($temasDesteFaq as $tf)
                    {
                      echo " <span class='badge'>".$tf['descricao']."</span>";
                    }; ?></td>
            <td><?php echo formataDataHora($nov['created_at']) ?></td>
            <td><?php echo formataDataHora($nov['updated_at']) ?></td>
            <td>
              <b class="text-<?php if($nov['status']=='1'){ 
                                    echo 'warning'; }
                                  else if($nov['status']=='2'){ 
                                    echo 'success'; } 
                                  else { 
                                    echo 'danger'; } ?>">
                <?php if($nov['status']=='1'){ 
                        echo 'RASCUNHO'; }
                      else if($nov['status']=='2'){ 
                        echo 'PUBLICADO'; } 
                      else { 
                        echo 'DESATIVADO'; }  ?>
              </b>
            </td>
            <td>
              <a href="?editar=<?php echo $nov['id']; ?>" class="btn btn-primary btn-xs">EDITAR</a>
            </td>
          </tr>
        <?php endforeach ?>
        </tbody>
    </table>
    <?php endif ?>
  </div>
  <?php require_once page_footer(); ?>
  <script type="text/javascript" src="<?php echo js('summernote/summernote.min.js') ?>"></script>
  <script type="text/javascript" src="<?php echo js('summernote/lang/summernote-pt-BR.min.js') ?>"></script>
  <script type="text/javascript">
    $(function() {
      $('.editor').summernote({ height: 220, lang: 'pt-BR' });
    });
  </script>
 	</body>
</html>
