<?php
require_once '../start.php';
$pdo = new Conexao;

Auth::whiteList('ADM');

$title = 'Escolas';

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
  $sql = "INSERT INTO escola (inep, descricao, municipio, tipo, endereco, numero, bairro, fone, diretor, vicediretor, secretario)
          VALUES (:inep, UPPER(:descricao), :municipio, :tipo, UPPER(:logradouro), :numero, UPPER(:bairro), :fone, UPPER(:diretor), UPPER(:vicediretor), UPPER(:secretario));";
  $sth = $pdo->prepare($sql);
  $sth->bindParam(':inep', $_POST['inep']);
  $sth->bindParam(':descricao', $_POST['descricao']);
  $sth->bindParam(':municipio', $_POST['municipio']);
  $sth->bindParam(':tipo', $_POST['tipo']);
  $sth->bindParam(':logradouro', $_POST['logradouro']);
  $sth->bindParam(':numero', $_POST['numero']);
  $sth->bindParam(':bairro', $_POST['bairro']);
  $sth->bindParam(':fone', $_POST['fone']);
  $sth->bindParam(':diretor', $_POST['diretor']);
  $sth->bindParam(':vicediretor', $_POST['vicediretor']);
  $sth->bindParam(':secretario', $_POST['secretario']);

  try {
    if ($sth->execute()) {
      $msg = "Escola {$_POST['inep']} {$_POST['descricao']} adicionada com sucesso.";
      Logger::success('Escola adicionada', $msg);
      Notification::success($msg);
    } else {
      Notification::error('N�o foi poss�vel salvar altera��es.');
    }
  } catch (Exception $e) {
    Notification::ex($e);
  }
  redirectBack();
}

$sql = "SELECT e.inep, e.descricao, r.descricao AS cre, m.descricao AS municipio, UPPER(e.tipo) AS zona, e.fone, re.descricao AS rede_ensino
        FROM escola e
          LEFT JOIN municipio m ON e.municipio = m.codigo
          LEFT JOIN rede_ensino re ON e.tipo_rede_ensino = re.id
          LEFT JOIN ren r ON r.codigo = m.ren ";
if (isset($_GET['q']) && !empty($_GET['q'])) {
  $sql .= " WHERE e.inep LIKE :query
            OR e.descricao LIKE :query
            OR m.descricao LIKE :query
            OR r.descricao LIKE :query ";
}
$sql .= " ORDER BY m.descricao ASC, m.descricao ASC";
$sth = $pdo->prepare($sql);
if (isset($_GET['q']) && !empty($_GET['q'])) {
  $query = '%'.$_GET['q'].'%';
  $sth->bindParam(':query', $query);
}
$escolas = $sth->execute() ? $sth->fetchAll() : array();

$municipios = Municipio::getAll();

if (isset($_GET['inep']) && !empty($_GET['inep'])) {
  $escola = Escola::get($_GET['inep']);
}

?><!DOCTYPE HTML>
<html>
  <head>
    <?php require_once page_head(); ?>
  </head>
  <body>
    <?php require_once page_header(); ?>
    <div class="container">
      <fieldset class="well well-sm">
        <legend>
          Adicionar escola

          <?php if(!isset($escola)): ?>
          <button type="button" onclick="$('#formEscola').slideToggle()" class="btn btn-xs btn-success"><i class="fa fa-plus fa-lg"></i></button>
          <?php endif ?>
        </legend>

        <form id="formEscola" method="POST" style="<?= isset($escola) ? '' : 'display:none' ?>">
          <input type="hidden" name="codigo" value="<?= isset($escola) ? $escola['codigo'] : null ?>">
          <div class="row">
            <div class="col-md-2">
              <div class="form-group">
                <label for="inep">INEP</label>
                <input type="text" id="inep" name="inep" maxlength="11" value="<?= isset($escola) ? $escola['inep'] : null ?>" class="form-control text-uppercase" <?= isset($escola) ? 'readonly' : '' ?> required>
              </div>
            </div>
            <div class="col-md-5">
              <div class="form-group">
                <label for="descricao">Nome da escola</label>
                <input type="text" id="descricao" name="descricao" value="<?= isset($escola) ? $escola['descricao'] : null ?>" class="form-control text-uppercase" required>
              </div>
            </div>
            <div class="col-md-3">
              <div class="form-group">
                <label for="municipio">Munic�pio</label>
                <select name="municipio" id="municipio" class="form-control" required>
                  <option value=""></option>
                  <?php foreach ($municipios as $mu) : ?>
                  <option value="<?= $mu['id'] ?>" <?= (isset($escola) && $mu['id']==$escola['cod_municipio']) ? 'selected' : '' ?>><?= $mu['descricao'] ?></option>
                  <?php endforeach ?>
                </select>
              </div>
            </div>
            <div class="col-md-2">
              <div class="form-group">
                <div class="form-group">
                  <label for="tipo">Zona</label>
                  <select name="tipo" id="tipo" class="form-control" required>
                    <option value=""></option>
                    <option value="URBANA" <?= isset($escola) && $escola['zona']=='URBANA' ? 'selected' : '' ?>>URBANA</option>
                    <option value="RURAL" <?= isset($escola) && $escola['zona']=='RURAL' ? 'selected' : '' ?>>RURAL</option>
                  </select>
                </div>
              </div>
            </div>
          </div>
          <div class="row">
            <div class="col-md-5">
              <div class="form-group">
                <div class="form-group">
                  <label for="logradouro">Logradouro</label>
                  <input type="text" id="logradouro" name="logradouro" value="<?= isset($escola) ? $escola['endereco'] : null ?>" class="form-control text-uppercase" required>
                </div>
              </div>
            </div>
            <div class="col-md-2">
              <div class="form-group">
                <div class="form-group">
                  <label for="numero">N�mero</label>
                  <input type="text" id="numero" name="numero" value="<?= isset($escola) ? $escola['numero'] : null ?>" class="form-control text-uppercase" required>
                </div>
              </div>
            </div>
            <div class="col-md-3">
              <div class="form-group">
                <div class="form-group">
                  <label for="bairro">Bairro</label>
                  <input type="text" id="bairro" name="bairro" value="<?= isset($escola) ? $escola['bairro'] : null ?>" class="form-control text-uppercase" required>
                </div>
              </div>
            </div>
            <div class="col-md-2">
              <div class="form-group">
                <div class="form-group">
                  <label for="fone">Telefone</label>
                  <input type="text" id="fone" name="fone" value="<?= isset($escola) ? $escola['fone'] : null ?>" class="form-control" required>
                </div>
              </div>
            </div>
          </div>
          <div class="row">
            <div class="col-md-4">
              <div class="form-group">
                <div class="form-group">
                  <label for="diretor">Diretor(a)</label>
                  <input type="text" id="diretor" name="diretor" value="<?= isset($escola) ? $escola['diretor'] : null ?>" class="form-control text-uppercase">
                </div>
              </div>
            </div>
            <div class="col-md-4">
              <div class="form-group">
                <div class="form-group">
                  <label for="vicediretor">Vice-diretor(a)</label>
                  <input type="text" id="vicediretor" name="vicediretor" value="<?= isset($escola) ? $escola['vicediretor'] : null ?>" class="form-control text-uppercase">
                </div>
              </div>
            </div>
            <div class="col-md-4">
              <div class="form-group">
                <div class="form-group">
                  <label for="secretario">Secret�rio(a)</label>
                  <input type="text" id="secretario" name="secretario" value="<?= isset($escola) ? $escola['secretario'] : null ?>" class="form-control text-uppercase">
                </div>
              </div>
            </div>
          </div>

          <button type="submit" class="btn btn-primary">ADICIONAR ESCOLA</button>
          <a href="<?php url("formcadastroescola.php") ?>" class="btn btn-default pull-right">Voltar</a>
        </form>
      </fieldset>
      <hr>

      <form class="" method="get">
        <div class="form-group">
          <div class="input-group">
            <label for="q" class="input-group-addon">
              <i class="fa fa-search fa-lg"></i>
            </label>
            <input type="search" name="q" id="q" class="form-control" placeholder="Procure por INEP, nome da escola ou munic�pio" autofocus value="<?= isset($_GET['q']) ? $_GET['q'] : '' ?>">
            <div class="input-group-btn">
              <button type="submit" class="btn btn-primary">PROCURAR</button>
            </div>
          </div>
        </div>
      </form>

      <table class="table table-bordered table-condensed table-striped table-hover">
        <thead>
          <tr>
            <th width="20">INEP</th>
            <th>Nome da Escola</th>
            <th width="110">Telefone</th>
            <th>CRE</th>
            <th>Munic�pio</th>
            <th>Zona</th>
            <th>Rede&nbsp;de&nbsp;ensino</th>
            <th width="170"></th>
          </tr>
        </thead>
        <tbody>
          <?php foreach ($escolas as $esc): ?>
          <tr>
            <td><?= $esc['inep'] ?></td>
            <td><?= $esc['descricao'] ?></td>
            <td><?= $esc['fone'] ?></td>
            <td><small><?= $esc['cre'] ?></small></td>
            <td><small><?= $esc['municipio'] ?></small></td>
            <td><?= $esc['zona'] ?></td>
            <td><?= $esc['rede_ensino'] ?></td>
            <td>
              <a class="btn btn-xs btn-primary" href="<?php url("admin/form_edita_escola.php?inep={$esc['inep']}") ?>">EDITAR</a>
              <a class="btn btn-xs btn-default" href="<?php url("admin/form_edita_anos.php?inep={$esc['inep']}") ?>">ANOS</a>
              <a class="btn btn-xs btn-default" title="Acessar ambiente da escola" href="<?php url("trocar_ambiente.php?permissao=LOT&inep={$esc['inep']}") ?>">ADME</a>
            </td>
          </tr>
          <?php endforeach ?>
        </tbody>
        <tfoot>
          <tr>
            <td></td>
            <th class="text-right">Total</th>
            <td colspan="5"><?= sizeof($escolas) ?> escolas</td>
          </tr>
        </tfoot>
      </table>
    </div>
    <?php require_once page_footer(); ?>
  </body>
</html>