<?php
require_once '../../start.php';
$pdo = new Conexao();
Auth::whiteList('DGE');

$title = 'Notas dos estudantes';


$escolas = Escola::getList();

$inepEscola = isset($_GET['e']) ? $_GET['e'] : null;
$anoLetivo = isset($_GET['a']) ? $_GET['a'] : null;
$idTurma = isset($_GET['t']) ? $_GET['t'] : null;
$idDisciplina = isset($_GET['d']) ? $_GET['d'] : null;

$anosLetivos = [];
$turmas = [];
$disciplinas = [];

if ($inepEscola) {
    $escola = Escola::get($inepEscola);
    $anosLetivos = Ano::getList($inepEscola);
}

if ($inepEscola && $anosLetivos) {
    $turmas = Turma::lista($inepEscola, $anoLetivo);
}

if ($idTurma) {
    $turma = Turma::get($idTurma, $inepEscola);
    if (!$turma) {
        redirect("dge/relatorios/form_notas_alunos.php?e={$inepEscola}&a={$anoLetivo}");
    }

    $tipo_recuperacao = TipoRecuperacao::get($inepEscola, $anoLetivo, $turma['modalidade']);
    $disciplinas = GradeCurricular::get($inepEscola, $anoLetivo, $turma['modalidade'], $turma['turmas']);
}

if (isset($turma) && $idDisciplina) {
    $disciplina = Disciplina::get($idDisciplina);

    $turmaEja = Turma::modalidadeEja($turma);
    $turmaMediacaoTecnologica = Turma::modalidadeMediacaoTecnologia($turma);
    $tipoRecuperacao = Escola::tipoRecuperacao($inepEscola, $anoLetivo, $turma['modalidade']);
    $adereExameFinal = Escola::adereExameFinal($inepEscola, $anoLetivo, $turma['modalidade']);
    $alunos = Aluno::getAlunosTurma($inepEscola, $idTurma);

    $situacoesAlunos = SituacaoAluno::getAllx();
}

?><!DOCTYPE HTML>
<html>
<head>
    <?php require_once page_head(); ?>
</head>
<body>
<?php require_once page_header(); ?>
<div class="container">
    <form method="GET" action="" class="well well-sm submit-wait hidden-print">

        <div class="row">
            <div class="col-md-10">
                <div class="form-group">
                    <label for="inep">Escola</label>
                    <select name="e" id="e" class="form-control chosen" onchange="this.form.submit()" required>
                        <option value=""></option>
                        <?php foreach ($escolas as $esc): ?>
                            <option value="<?php echo $esc['inep'] ?>" <?php selected($inepEscola && $esc['inep'] == $inepEscola) ?>>
                                <?php echo $esc['descricao'] ?>
                            </option>
                        <?php endforeach ?>
                    </select>
                </div>
            </div>
            <div class="col-md-2">
                <div class="form-group">
                    <label for="ano">Ano letivo</label>
                    <select name="a" id="a" class="form-control chosen" onchange="this.form.submit()">
                        <option value=""></option>
                        <?php foreach ($anosLetivos as $anno): ?>
                            <option value="<?php echo $anno['ano'] ?>" <?php selected($anoLetivo && $anno['ano'] == $anoLetivo) ?>>
                                <?php echo $anno['ano'] ?>
                            </option>
                        <?php endforeach ?>
                    </select>
                </div>
            </div>
        </div>

        <div class="row">
            <div class="col-md-8">
                <div class="form-group">
                    <label for="t">Turma</label>
                    <select name="t" id="t" class="form-control chosen" onchange="this.form.submit()" required>
                        <option value=""></option>
                        <?php foreach ($turmas as $tu): ?>
                            <option value="<?php echo $tu['id'] ?>" <?php selected(isset($idTurma) && $tu['id'] == $idTurma) ?>>
                                <?php echo $tu['descricao'] ?>
                                <?php echo $tu['fechado']=='S' ? '(FECHADA)' : '(ABERTA)'; ?>
                            </option>
                        <?php endforeach ?>
                    </select>
                </div>
            </div>
            <div class="col-md-4">
                <div class="form-group">
                    <label for="d">Disciplina</label>
                    <select name="d" id="d" class="form-control chosen" onchange="this.form.submit()" required>
                        <option value=""></option>
                        <?php foreach ($disciplinas as $disc): ?>
                            <option value="<?php echo $disc['id_disciplina'] ?>" <?php selected($idDisciplina && $disc['id_disciplina'] == $idDisciplina) ?>>
                                <?php echo $disc['descricao'] ?>
                            </option>
                        <?php endforeach ?>
                    </select>
                </div>
            </div>
        </div>
    </form>

    <hr class="hidden-print">

    <?php if (isset($turma) && isset($disciplina)): ?>
        <table class="table table-bordered table-condensed">
            <tr>
                <th width="20">Escola</th>
                <td>
                    <b class="text-success">
                        <?php echo $escola['inep']; ?>
                        <?php echo $escola['descricao']; ?>
                    </b>
                </td>
                <th width="20">Munic�pio</th>
                <td>
                    <b class="text-success">
                        <?php echo $escola['municipio']; ?>
                    </b>
                </td>
            </tr>
            <tr>
                <th width="20">Turma</th>
                <th class="text-primary"><?php echo $turma['descricao'] ?></th>
                <th width="20">Disciplina</th>
                <th class="text-danger"><?php echo $disciplina['descricao'] ?></th>
            </tr>
            <tr>
                <th width="20">Recupera��o</th>
                <th colspan="3" class="text-info"><?php echo $tipo_recuperacao['descricao'] ?></th>
            </tr>
        </table>

        <div class="text-center text-danger">
            Notas do bimestres inferiores a 6 est�o destacadas.
        </div>

        <table id="notas" class="table table-bordered table-condensed table-striped">
            <thead>
            <?php if ($turmaMediacaoTecnologica): ?>
                <tr>
                    <td colspan="2"></td>
                    <th colspan="4" class="text-center">Avalia��o</th>
                    <th colspan="4" class="text-center">Recupera��o</th>
                    <th colspan="4"></th>
                </tr>
            <?php endif ?>

            <tr>
                <th width="10">N�</th>
                <th>Estudante</th>
                <th>Situa��o</th>
                <?php if ($turmaMediacaoTecnologica): ?>
                    <th class="text-center">I</th>
                    <th class="text-center">II</th>
                    <th class="text-center">III</th>
                    <th>Extra Classe</th>
                    <?php echo Nota::thRecuperacao($turmaEja, $tipoRecuperacao, $adereExameFinal); ?>
                    <th>N.F.</th>
                <?php else: ?>
                    <th>1�B</th>
                    <th>2�B</th>
                    <?php if(!$turmaEja): ?>
                        <th>3�B</th>
                        <th>4�B</th>
                    <?php endif; ?>
                    <th>Soma</th>
                    <?php echo Nota::thRecuperacao($turmaEja, $tipoRecuperacao, $adereExameFinal); ?>
                    <th>M.A.</th>
                <?php endif ?>
                <th>Faltas</th>
                <th>C.H.</th>
                <th>M.F.</th>
            </tr>
            </thead>
            <tbody>
            <?php $totalAlunosNotasVermelhas = 0;
                    foreach ($alunos as $key => $aluno):
                    $nota = Nota::get($turma['id'], $disciplina['id'], $aluno['id_aluno'], $aluno['situacao'], false, false);
                    $notaVermelha = Nota::verificaNotaVermelha($nota, $turmaEja);
                    if ($notaVermelha) $totalAlunosNotasVermelhas++; ?>
                <tr>
                    <td><?php echo $aluno['n_chamada'] ?></td>
                    <td class="<?php echo $notaVermelha ? 'danger' : ''; ?>"><?php echo $aluno['nome'] ?></td>
                    <td><?php echo $situacoesAlunos[$aluno['situacao']]; ?></td>
                    <?php if ($turmaMediacaoTecnologica): ?>
                        <td  class="<?php echo $nota['nota1'] != '' && $nota['nota1'] < 6 ? 'danger' : 'success'; ?>"><?php echo Nota::format($nota, 'nota1') ?></td>
                        <td class="<?php echo $nota['nota2'] != '' && $nota['nota2'] < 6 ? 'danger' : 'success'; ?>"><?php echo Nota::format($nota, 'nota2') ?></td>
                        <td class="<?php echo $nota['nota3'] != '' && $nota['nota3'] < 6 ? 'danger' : 'success'; ?>"><?php echo Nota::format($nota, 'nota3') ?></td>
                        <td class="<?php echo $nota['nota4'] != '' && $nota['nota4'] < 6 ? 'danger' : 'success'; ?>"><?php echo Nota::format($nota, 'nota4') ?></td>
                        <?php echo Nota::tdRecuperacao($turmaEja, $tipoRecuperacao, $adereExameFinal, $nota); ?>
                    <?php else: ?>
                        <td class="<?php echo $nota['nota1'] != '' && $nota['nota1'] < 6 ? 'danger' : 'success'; ?>"><?php echo Nota::format($nota, 'nota1') ?></td class="<?php echo $nota['nota1'] != '' && $nota['nota1'] < 6 ? 'danger' : 'success'; ?>">
                        <td class="<?php echo $nota['nota2'] != '' && $nota['nota2'] < 6 ? 'danger' : 'success'; ?>"><?php echo Nota::format($nota, 'nota2') ?></td>
                        <?php if(!$turmaEja): ?>
                            <td class="<?php echo $nota['nota3'] != '' && $nota['nota3'] < 6 ? 'danger' : 'success'; ?>"><?php echo Nota::format($nota, 'nota3') ?></td>
                            <td class="<?php echo $nota['nota4'] != '' && $nota['nota4'] < 6 ? 'danger' : 'success'; ?>"><?php echo Nota::format($nota, 'nota4') ?></td>
                        <?php endif; ?>
                        <td><?php echo Nota::format($nota, 'soma') ?></td>
                        <?php echo Nota::tdRecuperacao($turmaEja, $tipoRecuperacao, $adereExameFinal, $nota); ?>
                    <?php endif ?>

                    <td><?php echo Nota::format($nota, 'ma') ?></td>
                    <td><?php echo Nota::format($nota, 'faltas') ?></td>
                    <td><?php echo Nota::format($nota, 'ch') ?></td>
                    <td><?php echo Nota::format($nota, 'mf') ?></td>
                </tr>
            <?php endforeach; ?>
            </tbody>
        </table>

        <table class="table table-bordered table-condensed table-striped">
            <tr>
                <th class="text-center">Total de estudantes</th>
                <th class="text-center">Estudantes com nota menor que 6</th>
                <th class="text-center">Estudantes com nota maior que 6</th>
            </tr>
            <tr>
                <td class="text-center"><?php echo sizeof($alunos); ?></td>
                <td class="text-center"><?php echo $totalAlunosNotasVermelhas; ?></td>
                <td class="text-center"><?php echo sizeof($alunos) - $totalAlunosNotasVermelhas; ?></td>
            </tr>
        </table>

        <?php require_once '../../partials/relatorios/footer_print.php' ?>

    <?php endif ?>
</div>
<?php require_once page_footer(); ?>
</body>
</html>