function DataHora(){var agora=new Date();var horas=agora.getHours();var minutos=agora.getMinutes();var horaAtual=""+((horas>12)?horas-12:horas);horaAtual+=((minutos<10)?":0":":")+minutos;horaAtual+=(horas>=12)?" PM":" AM";timerRunning=true;dataAtual=new Date();diaAtual=dataAtual.getDay();mesAtual=dataAtual.getMonth();diaDaSemanaAtual=dataAtual.getDate();diaDaSemana=diaDaSemanaAtual;anoAtual=dataAtual.getFullYear();ano=anoAtual;switch(diaAtual){case 0:dia="Domingo, ";break;case 1:dia="Segunda, ";break;case 2:dia="Terça, ";break;case 3:dia="Quarta, ";break;case 4:dia="Quinta, ";break;case 5:dia="Sexta, ";break;case 6:dia="Sábado, ";break;}switch(mesAtual){case 0:mes=" de Janeiro de ";break;case 1:mes=" de Fevereiro de ";break;case 2:mes=" de Março, ";break;case 3:mes=" de Abril de ";break;case 4:mes=" de Maio de ";break;case 5:mes=" de Junho de ";break;case 6:mes=" de Julho de ";break;case 7:mes=" de Agosto de ";break;case 8:mes=" de Setembro de ";break;case 9:mes=" de Outubro de ";break;case 10:mes=" de Novembro de ";break;case 11:mes=" de Dezembro de ";break;}document.write(dia+diaDaSemana+mes+ano+" - "+horaAtual);}

// loadCidades('estado_natal', 'cidade_natal', 'RO', '48850');

function loadCidades(id_estado, id_cidade, estado_selected, cidade_selected)
{	
	if(estado_selected != '0')
	{
		selectOption(id_estado, estado_selected);
		$("#"+id_cidade).html("<option value='0'>Carregando cidades...</option>");
		$.post('ajax/loadCidades.php', { uf: estado_selected, selected: cidade_selected }, function(resposta) {
			$('#'+id_cidade).html(resposta);
		});						
	}
	else
	{
		$("#"+id_cidade).html('<option>:: Selecione o Estado ::</option>');
	}
}

function getCidades(idEstado, idCidade)
{
	if(idEstado.value != '0')
	{
		$("#"+idCidade).html('<option value="0">Carregando cidades...</option>');
		$.post('ajax/loadCidades.php', { uf: idEstado.value }, function(resposta) {
			$('#'+idCidade).html(resposta);
		});
	}
	else
	{
		$("#"+idCidade).html('<option value="0">:: Selecione o Estado ::</option>');
	}
}

function tipo_buscar(tipo)
{
	$('#inputString').val('');
	
	switch(tipo)
	{
		case 'numero_cartao':
			$('#inputString').unmask()
							.attr('maxlength', '9')
							.attr('onkeyup', 'somente_numero(this);');
			break;
		
		case 'cpf':
			$('#inputString').unmask()
							.mask('999.999.999-99')
							.attr('maxlength', '14')
							.attr('onkeyup', '');
			break;
			
		case 'cliente':
		default:
			$('#inputString').unmask()
							.attr('maxlength', '100')
							.attr('onkeyup', '');
			break;
	}
	$('#inputString').focus();
}

// dá foco ao elemento indicado em 'id_alvo'
// exemplo: <input onkeyup="autofocus(this, 10, 'cpf');" />
function autofocus(origem, tamanho, id_alvo)
{
	var valor_origem = $('input[name='+origem.name+']').val();
	if(valor_origem == null)
	{
		valor_origem = $('#'+origem).val();
	}
	
	if(valor_origem.length == tamanho)
		$('input[name='+id_alvo+']').focus();
	else
		return false;
}


function loadSelect(page, id_select, value_selected, msg)
{	
	var msg_carregando = msg==null ? 'Carregando....' : msg;
	
	$('#'+id_select).html('<option value="0">'+msg_carregando+'</option>');
	$.post(page, { selected: value_selected }, function(resposta) {
		$('#'+id_select).html(resposta);
	});
}

/*** ANTIGO selectOption() {}
function OLDselectOption(selectName, value)
{
	mySelect = document.getElementById(selectName);
	if(mySelect != null)
	{
		for(i=0; i<mySelect.length; i++)
		{
			if(value != null)
				if(mySelect.options[i].value == value)
				{				
					mySelect.options[i].selected = true;
					$('#'+selectName).trigger('change');
				}
		}
	} else {
		alert('Select "'+selectName+'" não encontrado.');
	}
} */

function selectOption(nameSelect, value)
{
	$('select[name='+nameSelect+'] option[value='+value+']').attr('selected','selected');
}

function selectRadio(nameRadio, value)
{
	if(value != '0' && value != 0)
		$('input[name='+nameRadio+'][value='+value+']').get(0).checked = true;
}

function selectCheckbox(nameCheck, value)
{
	if(value != '0' && value != 0)
		$('input[name='+nameCheck+'][value='+value+']').get(0).checked = true;
}

function marcar_todos(botao, grupo)
{
	if($('#' + botao).is(':checked'))
	{
		$('.' + grupo).attr('checked', 'checked');
	}
	else
	{
		$('.' + grupo).attr('checked', '');
	}
}

function lookup(inputString) {
	if(inputString.length == 0) {
		// Hide the suggestion box.
		$('#suggestions').hide();
	} else {
		if(inputString.length > 3)
		{
			$.post("autocomplete_cliente.php",  {queryString: ""+inputString+"" }, function(data){
				if(data.length >0) {
					$('#suggestions').show();
					$('#autoSuggestionsList').html(data);
				}
			});
		}
	}
} // lookup

function fill(nome_cliente, id_cliente)
{
	$('#inputString').val(nome_cliente);
	$('#id_cliente').val(id_cliente);
	setTimeout("$('#suggestions').hide();", 200);
}

function abrir_janela(valor, tipoBusca)
{
	
	// valor = valor q usuario digita para efetuar a busca
	
	// tipoBusca = tipo de busca (cpf,n_cartao e nome) 
	
	$.modal('<iframe src="cliente-detalhe.php?valor='+valor+'&tipoBusca='+tipoBusca+'" width="100%" height="600" scrolling="No" frameborder="0"></iframe>');
}


function calcularCompra(valorCompra, saldo)
{ 	
	if (valorCompra > saldo)
	{			
		alert('Valor de compra acima do Saldo!');
		$('#valorMax').val();
		$('#confirmar').attr("disabled",'disabled');  
	}
	else
	{
		var resuldado =  saldo - valorCompra;
		$('#valorMax').fadeIn(2500);
		$('#valorMax').html('<b> Saldo Após a Compra ----------------------- R$'+resuldado+'<b>');
		$('#confirmar').attr("disabled",''); 
	}
}

function buscarCep(cep)
{
	if(cep.length == 9)
	{
		$('#loadingCep').css({display:''}); // Mostra loading...
		$.ajax({
			type: 'POST',
			dataType: 'xml',
			url: 'buscar_cep.php',
			data: 'cep='+cep,
			success: function(dataset){
				$('#loadingCep').css({display:'none'}); // esconder loading...
				$(document).css({cursor:''});
				$(dataset).find('webservicecep').each(function(){
					switch($(this).find('resultado').text())
					{
						case '1': break;
						case '-1': alert('CEP não encontrado.'); break;
						case '-2': alert('Formato de CEP inválido.'); break;
						case '-3': alert('Limite de buscas por minuto excedido. Tente novamente em breve.'); break;
						case '-4': alert('IP banido. Contate o administrador.'); break;
						default: alert('Erro ao conectar-se tente novamente.'); break;

					}//end switch resultado
					
					if($(this).find('resultado').text()==1)
					{
						$("#uf").attr({ value: $(this).find('uf').text() });
						$("#cidade").attr({ value: $(this).find('cidade').text() });
						$("#bairro").attr({ value: $(this).find('bairro').text() });						
						$("#endereco").attr({ value: $(this).find('tipo_logradouro').text()+" "+$(this).find('logradouro').text() });
					}//end resultado true
				});//end each webservicecep
			}//end success
		});//end ajax
	}//end if cep
}

function verificarUsuario(_usuario)
{
	$('#loading').show();	
	$.post('verificarUsuario.php', { usuario: _usuario }, Dados);
	
	function Dados(resposta)
	{
		$('#response').html(resposta);
		$('#loading').hide();									
	}
}

// Navegação das abas
function navegarAbas(numeroAba)
{
	$('#abas').tabs('option', 'selected', numeroAba);
	return false;
}

function mostrarEstrelas(limiteId, estrelasId)
{
	var limite = $('#'+limiteId).val();
	var img = $('#'+estrelasId);
	var estrelas = new Array('50', '100', '150', '200');
	
	if(limite == estrelas[0])
	{
		img.attr('class', 'perfil2');
	}
	else if(limite == estrelas[1])
	{
		img.attr('class', 'perfil3');
	}
	else if(limite == estrelas[2])
	{
		img.attr('class', 'perfil4');
	}
	else if(limite >= estrelas[3])
	{
		img.attr('class', 'perfil5');
	}
}

function calcularLimite(ocupacaoId, rendaId, limiteId, estrelasId)
{
	var ocup   = $('#'+ocupacaoId).val();
	var renda  = $('#'+rendaId).val();
	var limite = $('#'+limiteId);
	var img    = $('#'+estrelasId);

	var estrelas = new Array('50', '100', '150', '200');
	var salario = 465;

	if(ocup == 0)
	{
		alert('Selecione a ocupação do cliente');
		return false;
	}
	
	if(renda == null)
	{
		renda = 0;
	}
	
	switch(ocup)
	{
		case '1': // Estudante
			limite.val(estrelas[0]);
			img.attr('class', 'perfil2');
			break;
			
		case '2': // Dona de casa
			limite.val(estrelas[1]);
			img.attr('class', 'perfil3');
			break;
			
		case '3': // Autônomo
			if(renda <= salario)
			{
				limite.val(estrelas[0]);
				img.attr('class', 'perfil2');
				break;
			}
			else if(renda > 3 * salario)
			{
				limite.val(estrelas[3]);
				img.attr('class', 'perfil5');
				break;
			}
			else
			{
				limite.val(estrelas[1]);
				img.attr('class', 'perfil3');
				break;
			}
		
		case '4': // profissional liberal
			if(renda <= (3 * salario))
			{
				limite.val(estrelas[2]);
				img.attr('class', 'perfil4');
				break;
			}
			else
			{
				limite.val(estrelas[3]);
				img.attr('class', 'perfil5');
				break;
			}
			
		case '5': // empresário
			if(renda <= (3 * salario))
			{
				limite.val(estrelas[1]);
				img.attr('class', 'perfil3');
				break;
			}
			else
			{
				limite.val(estrelas[2]);
				img.attr('class', 'perfil4');
				break;
			}
				
		case '6': // empregado
			if(renda <= salario)
			{
				limite.val(estrelas[1]);
				img.attr('class', 'perfil3');
				break;
			}
			else if(renda > (3 *salario))
			{
				limite.val(estrelas[3]);
				img.attr('class', 'perfil5');
				break;
			}
			else
			{
				limite.val(estrelas[2]); 
				img.attr('class', 'perfil4');
				break;
			}
		
		case '7': // servidor público
			if(renda <= (3 * salario))
			{
				limite.val(estrelas[2]);
				img.attr('class', 'perfil4');
				break;
			}
			else
			{
				limite.val(estrelas[3]); 
				img.attr('class', 'perfil5');
				break;
			}
				
		case '8': // Universitário
			limite.val(estrelas[1]); 
			img.attr('class', 'perfil3');
			break;
		
		case '9': // Aposentado
			if(renda <= salario)
			{
				limite.val(estrelas[0]); 
				img.attr('class', 'perfil2');
				break;
			}
			else if(renda > (3 * salario))
			{
				limite.val(estrelas[2]); 
				img.attr('class', 'perfil4');
				break;
			}
			else
			{
				limite.val(estrelas[1]); 
				img.attr('class', 'perfil3');
				break;
			}
		default:
			limite.val(0); 
			img.attr('class', '');
			break;
	}

}

function calculajuros()
{
	var parcela  = $("#valor_parcela").val().replace(',', '.');
	var juros    = $("#valor_juros").val().replace(',', '.');	
	
	var nparcela = new Number(parcela);
	var njuros   = new Number(juros);

	var num      = new Number(nparcela + njuros);
		
	
	$("#valor_pagar").html('R$ ' + num.toFixed(2));
	
	$("#valor_pago").val(num.toFixed(2));
}

function marcar_todos(botao, grupo)
	{
		if($('#' + botao).is(':checked'))
		{
			$('.' + grupo).attr('checked', 'checked');
		}
		else
		{
			$('.' + grupo).attr('checked', '');
		}
	}	
