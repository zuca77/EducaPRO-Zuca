<?
session_start();
$login =$_SESSION["login_usuario"];

include ("conexao_mysql.php");




$inep        = $_POST['inep'];
$fone        = $_POST['fone'];
$nalunos     = $_POST['nalunos'];
$siteblog    = $_POST['siteblog'];
$merf        = $_POST['merf'];
$merm        = $_POST['merm'];
$meef        = $_POST['meef'];
$meem        = $_POST['meem'];
$ndocentes   = $_POST['ndocentes'];
$nsala= $_POST['nsala'];
$ntmanha= $_POST['ntmanha'];
$nttarde= $_POST['nttarde'];
$ntnoite= $_POST['ntnoite'];
$nlies= $_POST['nlies'];
$ntelessala= $_POST['ntelessala'];
$emailescola= $_POST['emailescola'];
$nomediretor= $_POST['nomediretor'];
$fonediretor= $_POST['fonediretor'];
$vicediretor= $_POST['vicediretor'];
$fonevice= $_POST['fonevice'];



$liescoord1= $_POST['liescoord1'];
$liescoord1m= $_POST['liescoord1m'];
$liescoord1t= $_POST['liescoord1t'];
$liescoord1n= $_POST['liescoord1n'];
$liescoord2= $_POST['liescoord2'];
$liescoord2m= $_POST['liescoord2m'];
$liescoord2t= $_POST['liescoord2t'];
$liescoord2n= $_POST['liescoord2n'];

$liescoord3= $_POST['liescoord3'];
$liescoord3m= $_POST['liescoord3m'];
$liescoord3t= $_POST['liescoord3t'];
$liescoord3n= $_POST['liescoord3n'];



$tvecoord1= $_POST['tvecoord1'];
$tvecoord1m= $_POST['tvecoord1m'];
$tvecoord1t= $_POST['tvecoord1t'];
$tvecoord1n= $_POST['tvecoord1n'];
$tvecoord2= $_POST['tvecoord2'];
$tvecoord2m= $_POST['tvecoord2m'];
$tvecoord2t= $_POST['tvecoord2t'];
$tvecoord2n= $_POST['tvecoord2n'];
$tvecoord3= $_POST['tvecoord3'];
$tvecoord3m= $_POST['tvecoord3m'];
$tvecoord3t= $_POST['tvecoord3t'];
$tvecoord3n= $_POST['tvecoord3n'];
$proinfo= $_POST['proinfo1'];
$tonomundo= $_POST['tonomundo1'];
$alvorada= $_POST['alvorada1'];
$despertar= $_POST['despertar1'];
$promed= $_POST['promed1'];
$proinesp= $_POST['proinesp1'];
$prooutros= $_POST['prooutros'];
$salaliem2= $_POST['salaliem2'];
$qtdaarlie= $_POST['qtdaarlie'];
$qtdacentrallie= $_POST['qtdacentrallie'];
$codifisicalie= $_POST['codifisicalie'];
$salatvm2= $_POST['salatvm2'];
$qtdaartv= $_POST['qtdaartv'];

$qtdacentraltv= $_POST['qtdacentraltv'];

$codifisicatv= $_POST['codifisicatv'];
$Computadorlie= $_POST['Computadorlie'];
$armariolie= $_POST['armariolie'];
$cadeiralie= $_POST['cadeiralie'];
$bancadalie= $_POST['bancadalie'];
$mesalie= $_POST['mesalie'];
$impressoralie= $_POST['impressoralie'];
$qdinterativolie= $_POST['qdinterativolie'];
$notebooklie= $_POST['notebooklie'];
$nobreaklie= $_POST['nobreaklie'];
$ledvdlie= $_POST['ledvdlie'];
$pratileiralie= $_POST['pratileiralie'];
$computadortv= $_POST['computadortv'];
$armariotv= $_POST['armariotv'];
$cadeiratv= $_POST['cadeiratv'];
$mesatv= $_POST['mesatv'];
$tvana= $_POST['tvana'];
$maqfototv= $_POST['maqfototv'];
$qdrinterativotv= $_POST['qdrinterativotv'];
$receotortv= $_POST['receotortv'];
$tvassina= $_POST['tvassina'];
$apsomtv= $_POST['apsomtv'];
$cxsomtv= $_POST['cxsomtv'];
$bandalarga= $_POST['bandalarga'];
$gesac= $_POST['gesac'];
$oitomundo= $_POST['oitomundo'];
$seduc= $_POST['seduc'];
$discada= $_POST['discada'];
$ncicuito= $_POST['ncicuito'];
$introducao40= $_POST['introducao40'];
$tic100= $_POST['tic100'];
$projetos40= $_POST['projetos40'];
$alunointegrado= $_POST['alunointegrado'];
$uca= $_POST['uca'];













$sql="select * from diagnostico where inep= $inep";
$resultado=mysql_query($sql) or die (mysql_error());
$linhas=mysql_num_rows($resultado);


if ($linhas<=0)
{
$sql = "insert into diagnostico (inep,fone,nalunos,siteblog,merf,merm,meef,meem,ndocentes,nsala,ntmanha,nttarde,ntnoite,nlies,ntelessala,emailescola,nomediretor,fonediretor,vicediretor,fonevice,liescoord1,liescoord1m,liescoord1t,liescoord1n,liescoord2,liescoord2m,liescoord2t,liescoord2n,liescoord3,liescoord3m,liescoord3t,liescoord3n,tvecoord1,tvecoord1m,tvecoord1t,tvecoord1n,tvecoord2,tvecoord2m,tvecoord2t,tvecoord2n,tvecoord3,tvecoord3m,tvecoord3t,tvecoord3n,proinfo,tonomundo,alvorada,despertar,promed,proinesp,prooutros,salaliem2,qtdaarlie,qtdacentrallie,codifisicalie,salatvm2,qtdaartv,qtdacentraltv,codifisicatv,Computadorlie,armariolie,cadeiralie,bancadalie,mesalie,impressoralie,qdinterativolie,notebooklie,nobreaklie,ledvdlie,pratileiralie,computadortv,armariotv,cadeiratv,mesatv,tvana,maqfototv,qdrinterativotv,receotortv,tvassina,apsomtv,cxsomtv,bandalarga,gesac,oitomundo,seduc,discada,ncicuito,introducao40,tic100,projetos40,alunointegrado,uca) values('$inep','$fone','$nalunos','$siteblog','$merf','$merm','$meef','$meem','$ndocentes','$nsala','$ntmanha','$nttarde','$ntnoite','$nlies','$ntelessala','$emailescola','$nomediretor','$fonediretor','$vicediretor','$fonevice','$liescoord1','$liescoord1m','$liescoord1t','$liescoord1n','$liescoord2','$liescoord2m','$liescoord2t','$liescoord2n','$liescoord2','$liescoord3m','$liescoord3t','$liescoord3n','$tvecoord1','$tvecoord1m','$tvecoord1t','$tvecoord1n','$tvecoord2','$tvecoord2m','$tvecoord2t','$tvecoord2n','$tvecoord3','$tvecoord3m','$tvecoord3t','$tvecoord3n','$proinfo','$tonomundo','$alvorada','$despertar','$promed','$proinesp','$prooutros','$salaliem2','$qtdaarlie','$qtdacentrallie','$codifisicalie','$salatvm2','$qtdaartv','$qtdacentraltv','$codifisicatv','$Computadorlie','$armariolie','$cadeiralie','$bancadalie','$mesalie','$impressoralie','$qdinterativolie','$notebooklie','$nobreaklie','$ledvdlie','$pratileiralie','$computadortv','$armariotv','$cadeiratv','$mesatv','$tvana','$maqfototv','$qdrinterativotv','$receotortv','$tvassina','$apsomtv','$cxsomtv','$bandalarga','$gesac','$oitomundo','$seduc','$discada','$ncicuito','$introducao40','$tic100','$projetos40','$alunointegrado','$uca')";
$qry = mysql_query($sql);
mysql_close($conexao);

echo "<html><head><title>Resposta !!!</title></head>";
echo "<body background=\"background_mensagens.jpg\" style=\"background-attachment:fixed; background-repeat:no-repeat\">";
echo "<br><br><br>";
echo "<center><img src=\"faleconosco/atencao.gif\" alt=\"\"><p><font color=\"#ff6600\" face=\"Verdana\" size=\"4\">Registro Gravado Com Sucesso. Obrigado !!!! <b></b></font></center>";
echo "<br><br><center><a href=\"mnnte.php\"><img src=\"faleconosco/button_voltar2_.gif\" alt=\"Voltar\" border=\"0\" /></a></center>";
echo "</body></html>";
} 
else
{
echo "<html><head><title>Resposta !!!</title></head>";
echo "<body background=\"background_mensagens.jpg\" style=\"background-attachment:fixed; background-repeat:no-repeat\">";
echo "<br><br><br>";
echo "<center><img src=\"faleconosco/atencao.gif\" alt=\"\"><p><font color=\"#ff6600\" face=\"Verdana\" size=\"4\">Diagnostico j� Registrado. Para alterar utiliza a op��o alterar !!!! <b></b></font></center>";
echo "<br><br><center><a href=\"mnnte.php\"><img src=\"faleconosco/button_voltar2_.gif\" alt=\"Voltar\" border=\"0\" /></a></center>";
echo "</body></html>";
}













/*$sql = "insert into diagnostico (inep,fone,nalunos,siteblog,merf,merm,meef,meem,ndocentes,nsala,ntmanha,nttarde,ntnoite,nlies,ntelessala,emailescola,nomediretor,fonediretor,vicediretor,fonevice,liescoord1,liescoord1m,liescoord1t,liescoord1n,liescoord2,liescoord2m,liescoord2t,liescoord2n,liescoord3,liescoord3m,liescoord3t,liescoord3n,tvecoord1,tvecoord1m,tvecoord1t,tvecoord1n,tvecoord2,tvecoord2m,tvecoord2t,tvecoord2n,tvecoord3,tvecoord3m,tvecoord3t,tvecoord3n,proinfo,tonomundo,alvorada,despertar,promed,proinesp,prooutros,salaliem2,qtdaarlie,qtdacentrallie,codifisicalie,salatvm2,qtdaartv,qtdacentraltv,codifisicatv,Computadorlie,armariolie,cadeiralie,bancadalie,mesalie,impressoralie,qdinterativolie,notebooklie,nobreaklie,ledvdlie,pratileiralie,computadortv,armariotv,cadeiratv,mesatv,tvana,maqfototv,qdrinterativotv,receotortv,tvassina,apsomtv,cxsomtv,bandalarga,gesac,oitomundo,seduc,discada,ncicuito,introducao40,tic100,projetos40,alunointegrado,uca) values('$inep','$fone','$nalunos','$siteblog','$merf','$merm','$meef','$meem','$ndocentes','$nsala','$ntmanha','$nttarde','$ntnoite','$nlies','$ntelessala','$emailescola','$nomediretor','$fonediretor','$vicediretor','$fonevice','$liescoord1','$liescoord1m','$liescoord1t','$liescoord1n','$liescoord2','$liescoord2m','$liescoord2t','$liescoord2n','$liescoord2','$liescoord3m','$liescoord3t','$liescoord3n','$tvecoord1','$tvecoord1m','$tvecoord1t','$tvecoord1n','$tvecoord2','$tvecoord2m','$tvecoord2t','$tvecoord2n','$tvecoord3','$tvecoord3m','$tvecoord3t','$tvecoord3n','$proinfo','$tonomundo','$alvorada','$despertar','$promed','$proinesp','$prooutros','$salaliem2','$qtdaarlie','$qtdacentrallie','$codifisicalie','$salatvm2','$qtdaartv','$qtdacentraltv','$codifisicatv','$Computadorlie','$armariolie','$cadeiralie','$bancadalie','$mesalie','$impressoralie','$qdinterativolie','$notebooklie','$nobreaklie','$ledvdlie','$pratileiralie','$computadortv','$armariotv','$cadeiratv','$mesatv','$tvana','$maqfototv','$qdrinterativotv','$receotortv','$tvassina','$apsomtv','$cxsomtv','$bandalarga','$gesac','$oitomundo','$seduc','$discada','$ncicuito','$introducao40','$tic100','$projetos40','$alunointegrado','$uca')";
$qry = mysql_query($sql);
mysql_close($conexao);



//header("Location: formcadagenda.php");










/*
$liescoord1= $_POST['liescoord1'];
$liescoord1m= $_POST['liescoord1m'];
$liescoord1t= $_POST['liescoord1t'];
$liescoord1n= $_POST['liescoord1n'];
$liescoord2= $_POST['liescoord2'];
$liescoord2m= $_POST['liescoord2m'];
$liescoord2t= $_POST['liescoord2t'];
$liescoord2n= $_POST['liescoord2n'];
$liescoord3= $_POST['liescoord3'];
$liescoord3m= $_POST['liescoord3m'];
$liescoord3t= $_POST['liescoord3t'];
$liescoord3n= $_POST['liescoord3n'];
$tvecoord1= $_POST['tvecoord1'];
$tvecoord1m= $_POST['tvecoord1m'];
$tvecoord1t= $_POST['tvecoord1t'];
$tvecoord1n= $_POST['tvecoord1n'];
$tvecoord2= $_POST['tvecoord2'];
$tvecoord2m= $_POST['tvecoord2m'];
$tvecoord2t= $_POST['tvecoord2t'];
$tvecoord2n= $_POST['tvecoord2n'];
$tvecoord3= $_POST['tvecoord3'];
$tvecoord3m= $_POST['tvecoord3m'];
$tvecoord3t= $_POST['tvecoord3t'];
$tvecoord3n= $_POST['tvecoord3n'];
$proinfo= $_POST['proinfo1'];
$tonomundo= $_POST['tonomundo1'];
$alvorada= $_POST['alvorada1'];
$despertar= $_POST['despertar1'];
$promed= $_POST['promed1'];
$proinesp= $_POST['proinesp1'];
$prooutros= $_POST['prooutros'];
$salaliem2= $_POST['salaliem2'];
$qtdaarlie= $_POST['qtdaarlie'];
$qtdacentrallie= $_POST['qtdacentrallie'];
$codifisicalie= $_POST['codifisicalie'];
$salatvm2= $_POST['salatvm2'];
$qtdaartv= $_POST['qtdaartv'];
$qtdacentraltv= $_POST['qtdacentraltv'];
$codifisicatv= $_POST['codifisicatv'];
$Computadorlie= $_POST['Computadorlie'];
$armariolie= $_POST['armariolie'];
$cadeiralie= $_POST['cadeiralie'];
$bancadalie= $_POST['bancadalie'];
$mesalie= $_POST['mesalie'];
$impressoralie= $_POST['impressoralie'];
$qdinterativolie= $_POST['qdinterativolie'];
$notebooklie= $_POST['notebooklie'];
$nobreaklie= $_POST['nobreaklie'];
$ledvdlie= $_POST['ledvdlie'];
$pratileiralie= $_POST['pratileiralie'];
$computadortv= $_POST['computadortv'];
$armariotv= $_POST['armariotv'];
$cadeiratv= $_POST['cadeiratv'];
$mesatv= $_POST['mesatv'];
$tvana= $_POST['tvana'];
$maqfototv= $_POST['maqfototv'];
$qdrinterativotv= $_POST['qdrinterativotv'];
$receotortv= $_POST['receotortv'];
$tvassina= $_POST['tvassina'];
$apsomtv= $_POST['apsomtv'];
$cxsomtv= $_POST['cxsomtv'];
$bandalarga= $_POST['bandalarga'];
$gesac= $_POST['gesac'];
$oitomundo= $_POST['oitomundo'];
$seduc= $_POST['seduc'];
$discada= $_POST['discada'];
$ncicuito= $_POST['ncicuito'];
$introducao40= $_POST['introducao40'];
$tic100= $_POST['tic100'];
$projetos40= $_POST['projetos40'];
$alunointegrado= $_POST['alunointegrado'];
$uca= $_POST['uca'];


//$sql = "insert into escola (inep,fone,nprofessores,nalunos,siteblog,merf,merm,meef,meem,ndocentes,nsala,ntmanha,nttarde,ntnoite,nlies,ntelessala,emailescola,nomediretor,fonediretor,vicediretor,fonevice,liescoord1,liescoord1m,liescoord1t,liescoord1n,liescoord2,liescoord2m,liescoordt,liescoord2n,liescoord3,liescoord3m,liescoord3t,liescoord3n,tvecoord1,tvecoord1m,tvecoord1t,tvecoord1n,tvecord2,tvecoord2m,tvecoord2t,tvecoord2n,tvecoord3,tvecoord3m,tvecoord3t,tvecoord3n,proinfo,tonomundo,alvorada,despertar,promed,proinesp,prooutros,salaliem2,qtdaarlie,qtdacentrallie,codifisicalie,salatvm2,qtdaartv,qtacentraltv,codifisicatv,Computadorlie,armariolie,cadeiralie,bancadalie,mesalie,impressoralie,qdinterativolie,noebooklie,nobreaklie,ledvdlie,pratileiralie,computadortv,armariotv,cadeiratv,mesatv,tvana,maqfototv,qdrinteraivotv,receotortv,tvassina,apsomtv,cxsomtv,bandalarga,gesac,oitomundo,seduc,discada,ncicuito,introducao40,tic100,projetos40,alunointegrado,uca) values 
//('$inep','$fone','$nprofessores','$nalunos','$siteblog','$merf','$merm','$meef','$meem','$ndocentes','$nsala','$ntmanha','$nttarde','$ntnoite','$nlies','$ntelessala','$emailescola','$nomediretor','$fonediretor','$vicediretor','$fonevice','$liescoord1','$liescoord1m','$liescoord1t','$liescoord1n','$liescoord2','$liescoord2m','$liescoordt','$liescoord2n','$liescoord3','$liescoord3m','$liescoord3t','$liescoord3n','$tvecoord1','$tvecoord1m','$tvecoord1t','$tvecoord1n','$tvecord2','$tvecoord2m','$tvecoord2t','$tvecoord2n','$tvecoord3','$tvecoord3m','$tvecoord3t','$tvecoord3n','$proinfo','$tonomundo','$alvorada','$despertar','$promed','$proinesp','$prooutros','$salaliem2','$qtdaarlie','$qtdacentrallie','$codifisicalie','$salatvm2','$qtdaartv','$qtacentraltv','$codifisicatv','$Computadorlie','$armariolie','$cadeiralie','$bancadalie','$mesalie','$impressoralie','$qdinterativolie','$noebooklie','$nobreaklie','$ledvdlie','$pratileiralie','$computadortv','$armariotv','$cadeiratv','$mesatv','$tvana','$maqfototv','$qdrinteraivotv','$receotortv','$tvassina','$apsomtv','$cxsomtv','$bandalarga','$gesac','$oitomundo,'$seduc','$discada','$ncicuito','$introducao40','$tic100','$projetos40','$alunointegrado','$uca')
*/



?>




