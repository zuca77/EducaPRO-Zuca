<?php

class Frequencia {

	public static function get($id_turma, $id_aluno, $totalFaltas, $faltas_de_opcionais = 0) {
		$frequencia['faltas'] = $totalFaltas;
		$frequencia['abono'] = self::getAbonoFaltas($id_turma, $id_aluno);
		$frequencia['total'] = self::getTotal($totalFaltas, $frequencia['abono']);
		$frequencia['total_final'] = self::getTotalFinal($frequencia['total'], $faltas_de_opcionais);
		return $frequencia;
	}

    private static function getTotalFinal($total, $faltas_de_opcionais)
    {
        $total = $total - $faltas_de_opcionais;

        return $total < 0 ? 0 : $total;
	}

    private static function getTotal($totalFaltas, $abono)
    {
        $total = $totalFaltas - $abono;

        return $total < 0 ? 0 : $total;
	}

	private static function getAbonoFaltas($id_turma, $id_aluno) {
		$pdo = new Conexao;
		$query = "SELECT IF(SUM(falta) IS NULL, 0, SUM(falta)) as abono
					FROM abono_faltas
					WHERE id_aluno = :id_aluno
					AND id_turma = :id_turma
					AND cancelado = 'N'";
		$sth = $pdo->prepare($query);
		$sth->bindParam(':id_aluno', $id_aluno);
		$sth->bindParam(':id_turma', $id_turma);
		$sth->execute();
		return $sth->fetchColumn();
	}

	public static function frequenciaAlunos($id_frequencia_cabeca, $tfrequencia_aluno) {
		$pdo = new Conexao;
		$sql = "SELECT fa.id, a.nome, ta.n_chamada, fa.id_aluno, fa.assunto as observacao, fa.situacao as frequencia, ta.situacao
						FROM aluno a
							LEFT JOIN {$tfrequencia_aluno} fa ON a.id = fa.id_aluno
							LEFT JOIN turma_aluno ta ON ta.id_aluno = a.id AND ta.id_turma = fa.id_turma
						WHERE fa.id_frequencia = :id_frequencia_cabeca
						ORDER BY ta.n_chamada;";
		$sth = $pdo->prepare($sql);
		$sth->bindParam(':id_frequencia_cabeca', $id_frequencia_cabeca);

		return $sth->execute() ? $sth->fetchAll() : array();
	}

	public static function alunosSemFrequencia($id_frequencia_cabeca, $ano) {
	    $tfrequencia_aluno = tFrequenciaAluno($ano);
        $tfrequencia_cabeca = tFrequenciaCabeca($ano);

		$pdo = new Conexao;

		$sql = "SELECT a.id, a.nome, ta.n_chamada, s.descricao AS situacao
                FROM aluno a
                    JOIN turma_aluno ta ON ta.id_aluno = a.id
                    JOIN tipo_mov_aluno s ON s.id = ta.situacao
                LEFT JOIN {$tfrequencia_cabeca} fc ON fc.id_turma = ta.id_turma
                WHERE ta.id_aluno NOT IN (
                    SELECT faa.id_aluno FROM {$tfrequencia_aluno} faa
                    WHERE faa.id_frequencia = :id_frequencia_cabeca)
                AND fc.id = :id_frequencia_cabeca
                GROUP BY a.id, a.nome
                ORDER BY ta.n_chamada;";
		$sth = $pdo->prepare($sql);
		$sth->bindParam(':id_frequencia_cabeca', $id_frequencia_cabeca);

		return $sth->execute() ? $sth->fetchAll() : null;
	}

	public static function totalFaltas($aluno, $turmaProfessor, $diasFrequencia, $tfrequencia_aluno) {
		$pdo = new Conexao;

		$datas = '';
		foreach($diasFrequencia as $diaFreq) {
			$datas.= "'{$diaFreq['data']}',";
		}
		$datas = rtrim($datas,',');

		if (empty($datas)) {
			return '-';
		}

		$sql = "SELECT COUNT(fa.id)
						FROM {$tfrequencia_aluno} fa
							JOIN turma_aluno ta ON fa.id_turma = ta.id_turma AND fa.id_aluno = ta.id_aluno
						WHERE fa.situacao = 'F'
						AND fa.id_aluno = :id_aluno
						AND fa.id_turma = :id_turma
						AND fa.id_disciplina = :id_disciplina
						AND ta.n_chamada = :n_chamada
						AND fa.data_chamada IN ({$datas})";

		$sth = $pdo->prepare($sql);
		$sth->bindParam(':id_aluno', $aluno['id']);
		$sth->bindParam(':n_chamada', $aluno['n_chamada']);
		$sth->bindParam(':id_turma', $turmaProfessor['id_turma']);
		$sth->bindParam(':id_disciplina', $turmaProfessor['id_disciplina']);

		return $sth->execute() ? $sth->fetchColumn() : '-';
	}

	public static function copiaFrequenciaAluno($idTurmaAnterior, $idTurmaNova, $idAluno, $novoInep, $txtano) {
    	$pdo = new Conexao;
    	$tabela = $txtano<=2014 ? 'frequencia_aluno' : 'frequencia_aluno'.$txtano;
		$query = "INSERT INTO {$tabela} (professor, id_turma, id_disciplina, id_aluno, data, n_chamada,
					assunto, situacao, id_frequencia, data_chamada, inep, id_turma_prof, ano)
			  	SELECT f.professor, :idTurmaNova, f.id_disciplina, f.id_aluno, f.data, f.n_chamada,
					f.assunto, f.situacao, f.id_frequencia, f.data_chamada, :inep, f.id_turma_prof, f.ano
				FROM {$tabela} f
				LEFT JOIN {$tabela} f2
					ON f2.id_aluno = f.id_aluno
					AND f2.id_turma = f.id_turma
					AND f2.id_disciplina = f.id_disciplina
					AND f2.data = f.data
					AND f2.n_chamada = f.n_chamada
					AND f2.id_turma_prof = f.id_turma_prof
					AND f2.id_frequencia = f.id_frequencia
				WHERE f.id_turma = :idTurmaAnterior
				AND f.id_aluno = :idAluno
				AND f2.id IS NULL";
		$sth = $pdo->prepare($query);
		$sth->bindParam(':idTurmaNova', $idTurmaNova);
		$sth->bindParam(':inep', $novoInep);
		$sth->bindParam(':idTurmaAnterior', $idTurmaAnterior);
		$sth->bindParam(':idAluno', $idAluno);

		return $sth->execute();
	}

	public static function copiaAbonoFaltaAluno($idTurmaAnterior, $idTurmaNova, $idAluno, $novoInep) {
    	$pdo = new Conexao;
		$query = "INSERT INTO abono_faltas (inep,id_aluno,ano,obs,falta,usuario,data,dt_movimento,cancelado,id_turma)
			  	SELECT :inep, f.id_aluno, f.ano, f.obs, f.falta, f.usuario, f.data, f.dt_movimento, f.cancelado, :idTurmaNova
				FROM abono_faltas f
				lEFT JOIN abono_faltas f2
					ON f2.id_aluno = f.id_aluno
					AND f2.ano = f.ano
					AND f2.data = f.data
					AND f2.dt_movimento = f.dt_movimento
					AND f2.usuario = f.usuario
					AND f2.id_turma = f.id_turma
					AND f2.id_aluno = f.id_aluno
				WHERE f.id_turma = :idTurmaAnterior
				AND f.id_aluno = :idAluno
				AND f2.id IS NULL
				AND f.cancelado != 'N'";
		$sth = $pdo->prepare($query);
		$sth->bindParam(':idTurmaNova', $idTurmaNova);
		$sth->bindParam(':inep', $novoInep);
		$sth->bindParam(':idTurmaAnterior', $idTurmaAnterior);
		$sth->bindParam(':idAluno', $idAluno);
		return $sth->execute();
	}

	public static function insertFaltaDiariamente($id_turma, $id_disciplina, $id_aluno, $professor, $cpf,$id_etapa, $faltou = false, $valor = null)
	{
 		$pdo = new Conexao;
		$now = date('Y-m-d');
       	$turma = Turma::get($id_turma);
		if(Auth::verificaAmbiente('PROF'))
		{
			
	   		$query = "SELECT id FROM turmaprofessor WHERE id_disciplina = :id_disciplina AND id_turma = :id_turma AND cpf = :professor";
	   		$sth = $pdo->prepare($query);
            $sth->bindParam('id_disciplina', $id_disciplina);
            $sth->bindParam('id_turma', $id_turma);
	   		$sth->bindParam('professor', $professor);
	   		$id_turmaprofessor = $sth->execute() ? $sth->fetchColumn() : null;

            switch ($id_etapa) {
                case 1:
                    $queryFalta = "t_falta1";
                    break;
                case 2:
                    $queryFalta = "t_falta2";
                    break;
                case 3:
                    $queryFalta = "t_falta3";
                    break;
                case 4:
                    $queryFalta = "t_falta4";
                    break;
                case 5:
                    $queryFalta = "t_falta_rec1";
                    break;
                case 6:
                    $queryFalta = "t_falta_rec2";
                    break;
                case 7:
                    $queryFalta = "t_falta_rec3";
                    break;
                case 8:
                    $queryFalta = "t_falta_rec4";
                    break;
                default:
                    $queryFalta = "t_falta1";
                    break;
            }
			
			$query = "INSERT INTO nota_aluno (id_turma, id_disciplina, id_professor, inep, ano, id_aluno, data, usuario, id_turmaprofessor, {$queryFalta}) 
			            VALUES (:id_turma, :id_disciplina, :id_professor, :inep, :ano, :id_aluno, :now, :usuario, :id_turmaprofessor , :falta );";
			
 			$sth = $pdo->prepare($query);

			$sth->bindParam(':id_turma', $id_turma, PDO::PARAM_INT);
			$sth->bindParam(':id_disciplina', $id_disciplina, PDO::PARAM_INT);
 			$sth->bindParam(':id_professor', $professor);
 			$sth->bindParam(':inep', $turma['inep']);
 			$sth->bindParam(':ano', $turma['ano']);
			$sth->bindParam(':id_aluno', $id_aluno, PDO::PARAM_INT);
 			$sth->bindParam(':now', $now);
 			$sth->bindParam(':usuario', $cpf);
 			$sth->bindParam(':id_turmaprofessor', $id_turmaprofessor);
 			if (!$valor) {
                if($faltou == true) {
                    $valor = 1;
                } else {
                    $valor = 0;
                }
            }
 			$sth->bindParam(':falta',$valor);
			
			if (!$sth->execute()) {
				throw new Exception('['.$pdo->errorCode().'] - '.$pdo->errorInfo());
			}
        }
	}

	public static function updateFaltaDiariamente($id_turma, $id_disciplina, $id_aluno, $professor,$id_etapa, $excluido = false, $valor = null)
	{
 		$pdo = new Conexao;
 		$turma = Turma::get($id_turma);
		if(Auth::verificaAmbiente('PROF') || Auth::verificaAmbiente('ADME'))
		{
			switch ($id_etapa) {
                case Etapa::BIM1:
                    $queryFalta = "t_falta1";
                    break;
                case Etapa::BIM2:
                    $queryFalta = "t_falta2";
                    break;
                case Etapa::BIM3:
                    $queryFalta = "t_falta3";
                    break;
                case Etapa::BIM4:
                    $queryFalta = "t_falta4";
                    break;
                case Etapa::REC1:
                case Etapa::REC_SEMESTRAL_EJA: //REC 1� SEMESTRE ER / 1� e 2� SEMESTRE EJA
                case Etapa::REC_ANUAL: //RECUPERACAO ANUAL ER
                    $queryFalta = "t_falta_rec1";
                    break;
                case Etapa::REC_SEMESTRE_2:
                case Etapa::REC2:
                    $queryFalta = "t_falta_rec2";
                    break;
                case Etapa::REC3:
                    $queryFalta = "t_falta_rec3";
                    break;
                case Etapa::REC4:
                    $queryFalta = "t_falta_rec4";
                    break;
                default:
                    $queryFalta = "t_falta1";
                    break;
            }

	   		if (!is_null($valor)) {
			    $valorNovo = $valor;
            } else {
                $query = "SELECT {$queryFalta} FROM nota_aluno 
	   				  WHERE id_disciplina = :id_disciplina AND id_turma = :id_turma AND id_professor = :professor
	   				  AND ano = :ano AND inep = :inep AND id_aluno = :id_aluno";

                $sth = $pdo->prepare($query);
                $sth->bindParam('id_turma', $id_turma,PDO::PARAM_INT);
                $sth->bindParam('id_disciplina', $id_disciplina);
                $sth->bindParam('professor', $professor);
                $sth->bindParam(':inep', $turma['inep']);
                $sth->bindParam(':ano', $turma['ano']);
                $sth->bindParam(':id_aluno', $id_aluno, PDO::PARAM_INT);
                $valor = $sth->execute() ? $sth->fetch() : null;

                if ($excluido) {
                    $valorNovo = ($valor[$queryFalta] == 0) ? 1 : $valor[$queryFalta] - 1;
                } else {
                    $valorNovo = $valor[$queryFalta] + 1;
                }
            }

            $query = "UPDATE nota_aluno SET ".$queryFalta." = :falta
 						WHERE id_turma = :id_turma
						AND id_disciplina = :id_disciplina
						AND id_aluno = :id_aluno;";
 					
 			$sth = $pdo->prepare($query);

			$sth->bindParam(':id_turma', $id_turma, PDO::PARAM_INT);
			$sth->bindParam(':id_aluno', $id_aluno, PDO::PARAM_INT);
			$sth->bindParam(':id_disciplina', $id_disciplina, PDO::PARAM_INT);
			$sth->bindParam(':falta',$valorNovo);

			if (!$sth->execute()) {
				throw new Exception('['.$pdo->errorCode().'] - '.$pdo->errorInfo());
			}
        }
	}

    /**
     * Busca a frequ�ncia da disciplina Pedagogia
     * @param $id_aluno
     * @param $id_turma
     * @return array
     */
    public static function getFaltasSeriesIniciais($id_aluno, $id_turma)
    {
        $pdo = new Conexao();
        $query = "SELECT n.t_falta1, n.t_falta2, n.t_falta3, n.t_falta4,
                          n.t_falta_rec1,n.t_falta_rec2,n.t_falta_rec3,n.t_falta_rec4
                        FROM nota_aluno n
                        INNER JOIN turma t
                            ON t.id = n.id_turma
                        WHERE n.id_aluno = :id_aluno
                            AND n.id_turma = :id_turma
                            AND n.id_disciplina = 28";

        $sth = $pdo->prepare($query);
        $sth->bindParam(':id_turma', $id_turma);
        $sth->bindParam(':id_aluno', $id_aluno);
        $sth->execute();

        return $sth->fetch();
	}
}