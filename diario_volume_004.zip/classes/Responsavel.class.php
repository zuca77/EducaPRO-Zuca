<?php
/**
* Responsavel
*/
class Responsavel
{
    public static function preCadastro($nome, $email)
    {
        if (!isset($nome) || empty($nome)) return ["type" => "error", "message" => 'Informe o nome!'];
        if (!checkEmailValido($email)) return ["type" => "error", "message" => 'Informe um email v�lido!'];

        $nome = ucwords(strtolower(utf8_decode(trim($nome))));
        $email = strtolower(utf8_decode(trim($email)));
        $token = self::generateToken();
        $validade = self::getValidade();

        try {
            $pdo = new Conexao;
            $sql = "INSERT INTO pre_cadastro_responsaveis (nome, email, token, validade)
                    VALUES (:nome, :email, :token, :validade);";

            $sth = $pdo->prepare($sql);
            $sth->bindParam(':validade', $validade);
            $sth->bindParam(':nome', $nome);
            $sth->bindParam(':email', $email);
            $sth->bindParam(':token', $token);
            $sth->execute();

            $id = $pdo->lastInsertId();

            if (self::enviarEmailConfirmacao($id, $nome, $email, $token)) {
                return [
                    "type" => "success",
                    "message" => "<b>Aguarde! Enviaremos um email para voc�!</b>"
                ];
            } else {
                return [
                    "type" => "error",
                    "message" => "N�o conseguimos enviar o email de confirma��o! Por favor, verifique se seu email est� correto!"
                ];
            }

        } catch (Exception $e) {
            Logger::error("Portal do Estudante - Pre-cadastro", $e->getMessage());
        }

        return [
            "type" => "error",
            "message" => "Houve um erro! Por favor, verifique se suas informa��es est�o corretas!"
        ];
    }

    private static function parseTokenIdPreCadastro($token)
    {
        return explode('.', $token);
    }

    public static function validarPreCadastro($tokenId)
    {
        $tokenParsed = self::parseTokenIdPreCadastro($tokenId);
        $url_pre_cadastro = url("portal/pre_cadastro.php", true);
        $msg_token_invalido = [
            "type" => "error",
            "message" => "Token inv�lido! Provavelmente voc� demorou para confirmar o email que enviamos. Cadastre-se novamente <a href='" . $url_pre_cadastro . "''>aqui</a>"
        ];

        if (!isset($tokenParsed[0]) || !isset($tokenParsed[1]))
            return $msg_token_invalido;

        $pre_cadastro = static::getPrecadastro($tokenParsed[1]);

        if (!$pre_cadastro)
            return ["type" => "error", "message" => "N�o encontramos o seu pr�-cadastro! Por favor cadastre-se novamente!"];

        if (!self::validateToken($tokenParsed[0], $pre_cadastro))
            return $msg_token_invalido;

        return [
            "type" => "success",
            "pre_cadastro_id" => $pre_cadastro["id"],
            "message" => "Email confirmado com sucesso! Nos d� mais algumas informa��es e finalize seu cadastro!"
        ];
    }

    private static function validateToken($token, $pre_cadastro)
    {
        $is_equal = ((string) $token === (string) $pre_cadastro["token"]);
        $is_valid = date("Y-m-d H:m:i") <= $pre_cadastro["validade"];

        return $is_valid && $is_equal;
    }

    private static function getPrecadastro($id)
    {
        $pdo = new Conexao;
        $sql = "SELECT * FROM pre_cadastro_responsaveis WHERE id = :id;";

        $sth = $pdo->prepare($sql);
        $sth->bindParam(':id', $id);
        $sth->execute();

        return $sth->fetch();
    }

    private static function getValidade()
    {
        $date_now = new DateTime();
        $date_now->modify("+30 day");

        return $date_now->format("Y-m-d H:m:i");
    }

    private static function generateToken()
    {
        $token = openssl_random_pseudo_bytes(28);
        return bin2hex($token);
    }

    private static function validarResponsavel($responsavel)
    {
        if (!isset($responsavel['cpf']) || empty($responsavel['cpf']))
            return ["type" => "error", "message" => "Informe o CPF!"];
        if (!validarCPF($responsavel['cpf']))
            return ["type" => "error", "message" => "Informe um CPF v�lido!"];
        if (!isset($responsavel['telefone']) || empty($responsavel['telefone']))
            return ["type" => "error", "message" => "Informe o telefone!"];
        if (!isset($responsavel['senha']) || empty($responsavel['senha']))
            return ["type" => "error", "message" => "Informe a senha!"];
        if (isset($responsavel['confirma_senha'])) {
            if (isset($responsavel['senha']) && isset($responsavel['confirma_senha']) && $responsavel['confirma_senha'] != $responsavel['senha'])
                return ["type" => "error", "message" => "A senha e a confirma��o s�o diferentes!"];
        }
    }

	public static function cadastrar($responsavel) {
		$pdo = new Conexao;

        try {
            $pre_cadastro = self::getPrecadastro($responsavel["pre_cadastro_id"]);

            $responsavel["nome"] = $pre_cadastro["nome"];
            $responsavel["email"] = $pre_cadastro["email"];

            self::validarResponsavel($responsavel);
            $sql = "SELECT COUNT(cpf) FROM responsaveis WHERE cpf = :cpf;";
            $sth = $pdo->prepare($sql);
            $sth->bindParam(':cpf', $responsavel['cpf']);
            $countCpf = $sth->execute() ? $sth->fetchColumn() : 0;
            if ($countCpf) {
                return ["type" => "error", "message" => "J� existe usu�rio com o CPF <b>{$responsavel["cpf"]}</b>"];
            }


            $sql = "SELECT COUNT(email) FROM responsaveis WHERE email = :email;";
            $sth = $pdo->prepare($sql);
            $sth->bindParam(':email', $responsavel['email']);
            $countEmail = $sth->execute() ? $sth->fetchColumn() : 0;
            if ($countEmail) {
                return ["type" => "error", "message" => "J� existe usu�rio com o email <b>{$responsavel["email"]}</b>"];
            }

            $sql = "INSERT INTO responsaveis (cpf, nome, email, telefone, senha, created_at, updated_at, confirmado, confirmacao_token)
                    VALUES (:cpf, :nome, :email, :telefone, SHA2(:senha, 256), NOW(), NOW(), 1, :token);";
            $sth = $pdo->prepare($sql);
            $sth->bindParam(':cpf', $responsavel['cpf']);
            $sth->bindParam(':nome', $responsavel['nome']);
            $sth->bindParam(':email', $responsavel['email']);
            $sth->bindParam(':telefone', $responsavel['telefone']);
            $sth->bindParam(':senha', $responsavel['senha']);
            $sth->bindParam(':token', $pre_cadastro["token"]);
            $sth->execute();

            return ["type" => "success", "message" => "Cadastro finalizado com sucesso!"];
        } catch (Exception $e) {
            Logger::error("Portal do Estudante - Pre-cadastro", $e->getMessage());

            return ["type" => "error", "message" => "Houve um erro! Verifique seus dados!"];
        }
	}

    public static function enviarEmailConfirmacao($precadastro_id, $nome, $email, $token) {
        $destinatario = array($email, $nome);
        $urlConfirmacao = BASE_URL . "/portal/confirmacao.php?token={$token}.{$precadastro_id}&email={$email}";


        $assunto = 'Confirma��o de email';
        $mensagem = <<<EOF
            <html><head><style>section { width: 500px; margin: 0 auto; }h1{margin-bottom:30px;}a{text-decoration: none;}footer { border-top: 1px solid #999; font-size: 80%; margin-top:20px; padding: 10px 0; }
            .btn {
                display: inline-block;text-align: center;white-space: nowrap;vertical-align: middle;touch-action: manipulation;padding: 9px 14px;font-size: 14px;line-height: 1.3;border-radius: 2px; color: #fff;text-shadow: 0 1px rgba(0,0,0,.1);
                background-image: linear-gradient(to bottom,#4d90fe 0,#4787ed 100%);background-repeat: repeat-x;border: 1px solid #3079ed; cursor: default;box-shadow: none;background-color: #337ab7;
            }
            </style></head>
            <body><section>
            <h1><a href="http://diario.seduc.ro.gov.br/portal/login.php"><img src="http://diario.seduc.ro.gov.br/public/img/logo-brasao-rondonia.png" alt=""><br>Portal do Estudante</h1></a>
            <p>Este email foi usado no cadastro do Portal do Estudante do Governo de Rond�nia.</p>
            <p>Se voc� n�o se cadastrou, ignorar este email.</p>
            <p>
                <a class="btn" href="{$urlConfirmacao}" target="_blank">Clique aqui para continuar seu cadastro!</a>
            </p>
            <hr>
            <footer>Coordenadoria de Tecnologia da Informa��o e Comunica��o<br>Ger�ncia de Sistema de Informa��o</footer>
            </section>
            </div></body></html>
EOF;
        return Email::enviar($destinatario, $assunto, $mensagem, 'Portal do Estudante');
    }

	public static function esqueceuSenha($cpf) {
		$pdo = new Conexao;
		$sql = "SELECT nome,email FROM responsaveis WHERE cpf = :cpf;";
		$sth = $pdo->prepare($sql);
		$sth->bindParam(':cpf', $cpf);
		$responsavel = $sth->execute() ? $sth->fetch() : null;

		if (!$responsavel) {
			return array('error' => "N�o foi encontrado usu�rio com o CPF {$cpf}.");
		}

		$novaSenha = self::generateRandomString(6);
		$sql = "UPDATE responsaveis
                SET senha = SHA2(:novaSenha, 256), updated_at = NOW()
                WHERE cpf = :cpf;";
		$sth = $pdo->prepare($sql);
		$sth->bindParam(':cpf', $cpf);
		$sth->bindParam(':novaSenha', $novaSenha);

		if ($sth->execute() && $sth->rowCount()) {
			$destinatario = array($responsavel['email'], $responsavel['nome']);
			$assunto = 'Esqueceu a senha';

			$mensagem = <<<EOF
            <html>
            <head>
                <style>
                    section { width: 500px; margin: 0 auto; }h1{margin-bottom:30px;}a{text-decoration: none;}footer { border-top: 1px solid #999; font-size: 80%; margin-top:20px; padding: 10px 0; }
                    .btn {display: inline-block;text-align: center;white-space: nowrap;vertical-align: middle;touch-action: manipulation;padding: 9px 14px;font-size: 14px;line-height: 1.3;border-radius: 2px; color: #fff;text-shadow: 0 1px rgba(0,0,0,.1);background-image: linear-gradient(to bottom,#4d90fe 0,#4787ed 100%);background-repeat: repeat-x;border: 1px solid #3079ed; cursor: default;box-shadow: none;background-color: #337ab7;}
                </style>
            </head>
            <body><section>
            <h1><a href="http://diario.seduc.ro.gov.br/portal/login.php"><img src="http://diario.seduc.ro.gov.br/img/logo-brasao-rondonia.png" alt=""><br>Portal do Estudante</h1></a>
            <p>Foi solicitado ao CPF associado a este email a gera��o de uma nova senha.</p>
            <p>A nova senha para acessar o portal do estudate: <b>{$novaSenha}</b></p>
            <a class="btn" href="http://diario.seduc.ro.gov.br/portal/login.php">Fazer login no Portal do Estudante</a><br>
            <hr>
           <footer>Coordenadoria de Tecnologia da Informa��o e Comunica��o<br>Ger�ncia de Sistema de Informa��o</footer>
            </section>
            </div></body></html>
EOF;

			$emailEscondido = obfuscateEmail($responsavel['email']);

			if (Email::enviar($destinatario, $assunto, $mensagem, 'Portal do Estudante')) {
				return array('success' => "Enviamos a nova senha para o email {$emailEscondido}.");
			}
		}

		return array('error' => 'N�o foi poss�vel enviar o email.');
	}

	public static function get($cpf, $senha) {
		$pdo = new Conexao;
		$sql = "SELECT id, cpf, nome, telefone, email, confirmado, confirmacao_token
                FROM responsaveis
      			WHERE cpf = :cpf
      			  AND SHA2(:senha, 256) = senha";

		$sth = $pdo->prepare($sql);
		$sth->bindParam(':cpf', $cpf);

		if (!is_null($senha)) {
            $sth->bindParam(':senha', $senha);
        }
		return $sth->execute() ? $sth->fetch() : null;
	}

	public static function getCPF($cpf) {
        $pdo = new Conexao;
        $sql = "SELECT id, cpf, nome, telefone, email, confirmado, confirmacao_token
                FROM responsaveis
      			WHERE cpf = :cpf;";
        $sth = $pdo->prepare($sql);
        $sth->bindParam(':cpf', $cpf);

        return $sth->execute() ? $sth->fetch() : null;
    }

    public static function select($query)
    {
        $query = "%" . str_replace(' ', '%', trim($query)) . "%";
        $pdo = new Conexao;
        $sql = "SELECT id, cpf, nome, telefone, email, confirmado, created_at, updated_at
                    FROM responsaveis
                        WHERE nome LIKE :query
                            OR cpf LIKE :query
                        ORDER BY id ASC";

        $sth = $pdo->prepare($sql);
        $sth->bindParam(':query', $query);
        $sth->execute();

        return $sth->fetchAll();
    }

    public static function getByEmailToken($email, $token) {
        $pdo = new Conexao;
        $sql = "SELECT cpf, nome, telefone, email, confirmado, confirmacao_token
                FROM responsaveis
      			WHERE email = :email
        			AND confirmacao_token = :token;";
        $sth = $pdo->prepare($sql);
        $sth->bindParam(':email', $email);
        $sth->bindParam(':token', $token);

        return $sth->execute() ? $sth->fetch() : null;
    }

	public static function alunos($cpf, $ano) {
		$pdo = new Conexao;
		$sql = "SELECT a.id, a.dt_nascimento, t.id AS id_turma, ta.n_chamada, a.nome, t.descricao AS turma, e.descricao AS escola, s.descricao AS situacao
                FROM turma_aluno ta
                    JOIN aluno a ON a.id = ta.id_aluno
                JOIN turma t ON t.id = ta.id_turma AND t.ano = :ano
                JOIN escola e ON t.inep = e.inep
                JOIN tipo_mov_aluno s ON ta.situacao = s.id
                WHERE :cpf IN (a.cpf, a.cpfresp, a.cpf_mae, a.cpf_aluno);";
		$sth = $pdo->prepare($sql);
		$sth->bindParam(':cpf', $cpf);
		$sth->bindParam(':ano', $ano);

		return $sth->execute() ? $sth->fetchAll() : array();
	}

	public static function generateRandomString($length = 6) {
        $characters = '123456789abcdefghijklmnpqrstuvwxyz';
        $charactersLength = strlen($characters);
        $randomString = '';
        for ($i = 0; $i < $length; $i++) {
          $randomString .= $characters[rand(0, $charactersLength - 1)];
        }

        return $randomString;
	}

    public static function update($id, $cpf, $nome, $email)
    {
        $pdo = new Conexao;
        $nome = ucwords(strtolower(utf8_decode(trim($nome))));
        $email = strtolower(trim($email));
        $cpf = trim($cpf);

        $sql = "SELECT COUNT(cpf) FROM responsaveis 
                          WHERE cpf = :cpf
                              AND id <> :id";
        $sth = $pdo->prepare($sql);
        $sth->bindParam(':id', $id);
        $sth->bindParam(':cpf', $cpf);
        $countCpf = $sth->execute() ? $sth->fetchColumn() : 0;

        if ($countCpf > 0) {
            throw new Exception("J� existe usu�rio com o CPF <strong>$cpf</strong>.");
        }

        $sql = "SELECT COUNT(email) FROM responsaveis 
                          WHERE email = :email
                              AND id <> :id;";
        $sth = $pdo->prepare($sql);
        $sth->bindParam(':id', $id);
        $sth->bindParam(':email', $email);
        $countEmail = $sth->execute() ? $sth->fetchColumn() : 0;

        if ($countEmail > 0) {
            throw new Exception("J� existe usu�rio com o email <strong>$email</strong>.");
        }

        $sql = "UPDATE responsaveis 
                    SET cpf=:cpf, nome=:nome, email=:email, updated_at=NOW() 
                    WHERE id=:id";
        $query = $pdo->prepare($sql);

        $query->bindParam(":id", $id);
        $query->bindParam(":nome", $nome);
        $query->bindParam(":cpf", $cpf);
        $query->bindParam(":email", $email);

        return $query->execute();
    }
}