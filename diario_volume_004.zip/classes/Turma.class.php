<?php

class Turma
{
    public static $turmasDependencia = array(75, 76, 77, 78, 79, 100, 101, 114, 115, 137, 138);
	public static $turmasRetencaoParcial = array(139, 140, 141, 142,143,144,145,146,147,148,149,150,151,152, 156,157,158,159,160,161,162);
    public static $turmasModular = array(13, 14, 15, 28, 29, 30, 93, 94, 95);
    public static $turmasMediacaoTecnologica = array(116, 117, 118);
    public static $turmasEnsinoMedioCampo = array(93, 94, 95);

    public static function get($id_turma, $inep = null)
    {
		$pdo = new Conexao;

        $inep = isset($_SESSION['escola']['inep']) ? $_SESSION['escola']['inep'] : $inep;

		$query = "SELECT id, modalidade, turmas, t_vagas, inep, usuario, data,
                        motivo, turno, descricao, tipomov, sala, ano, semestre,
                        tipo_eja, fechado, dtfecha, obs, ata, id_grade,
                        ano_fechado, dtfecha_turma
					FROM turma t
					WHERE t.id = :id_turma
                    AND t.inep = :inep";

		$sth = $pdo->prepare($query);
        $sth->bindParam(':id_turma', $id_turma);
        $sth->bindParam(':inep', $inep);

        return $sth->execute() ? $sth->fetch() : null;
    }

    public static function lista($inep, $ano)
    {
        $pdo = new Conexao;
        $sql = "SELECT t.id, t.modalidade, t.turmas, t.t_vagas, t.inep, t.usuario, t.data, t.motivo, t.turno, t.descricao, t.tipomov,
                    t.sala, t.ano, t.semestre,t.tipo_eja, t.fechado, t.dtfecha, t.obs, t.ata, t.id_grade,t.ano_fechado, t.dtfecha_turma
                FROM turma t
                WHERE t.inep = :inep
                    AND t.ano = :ano
                ORDER BY t.fechado ASC, t.descricao";

        $sth = $pdo->prepare($sql);
        $sth->bindParam(':inep', $inep);
        $sth->bindParam(':ano', $ano);

        return $sth->execute() ? $sth->fetchAll() : null;
    }

    public static function getTurmaProfessor($id_turmaprofessor)
    {
        $pdo = new Conexao;
        $query = "SELECT tp.id, t.id as id_turma, t.modalidade, t.turmas, t.t_vagas, t.inep, t.usuario, t.data,
                        t.motivo, t.turno, t.descricao, t.tipomov, t.sala, t.ano, t.semestre,
                        t.tipo_eja, t.fechado, t.dtfecha, t.obs, t.ata, t.id_grade,
                        t.ano_fechado, t.dtfecha_turma, tp.id_disciplina, h.descricao as disciplina, s.nome as professor
                    FROM turma t
                    INNER JOIN turmaprofessor tp ON tp.id_turma = t.id
                    INNER JOIN servidorrec s ON s.cpf = tp.cpf
                    INNER JOIN habilitacao h ON h.codigo = tp.id_disciplina
                    WHERE tp.id = :id_turmaprofessor
                    ORDER BY t.descricao, h.descricao";

        $sth = $pdo->prepare($query);
        $sth->bindParam(':id_turmaprofessor', $id_turmaprofessor);
        return $sth->execute() ? $sth->fetch() : null;
    }

    public static function getTurmasProfessor($inep, $ano, $cpf)
    {
        $pdo = new Conexao;
        $query = "SELECT DISTINCT tp.id, t.id as id_turma, t.modalidade, t.turmas, t.t_vagas, t.inep, t.usuario, t.data,
                                t.motivo, t.turno, t.descricao, t.tipomov, t.sala, t.ano, t.semestre,
                                t.tipo_eja, t.fechado, t.dtfecha, t.obs, t.ata, t.id_grade,
                                t.ano_fechado, t.dtfecha_turma, tp.id_disciplina, h.descricao as disciplina, s.nome as professor
                    FROM turma t
                    INNER JOIN turmaprofessor tp ON tp.id_turma = t.id
                    INNER JOIN servidorrec s ON s.cpf = tp.cpf
                    INNER JOIN habilitacao h ON h.codigo = tp.id_disciplina
                    WHERE t.inep = :inep
                    AND tp.cpf = :cpf
                    AND t.ano = :ano
                    GROUP BY t.id";

        $sth = $pdo->prepare($query);
        $sth->bindParam(':inep', $inep);
        $sth->bindParam(':cpf', $cpf);
        $sth->bindParam(':ano', $ano);

        return $sth->execute() ? $sth->fetchAll() : null;
    }

    public static function listaTurmasProfessores($inep, $ano, $id_turma = null)
    {
        $pdo = new Conexao;
        $query = "SELECT DISTINCT tp.id, t.id as id_turma, tp.cpf, t.modalidade, t.turmas, t.t_vagas, t.inep, t.usuario, t.data,
                                t.motivo, t.turno, t.descricao, t.tipomov, t.sala, t.ano, t.semestre,
                                t.tipo_eja, t.fechado, t.dtfecha, t.obs, t.ata, t.id_grade,
                                t.ano_fechado, t.dtfecha_turma, tp.id_disciplina, h.descricao as disciplina,
                                s.nome as professor, s.cpf as id_professor, h.codigo as id_disciplina
                    FROM turma t
                    INNER JOIN turmaprofessor tp ON tp.id_turma = t.id
                    INNER JOIN servidorrec s ON s.cpf = tp.cpf
                    INNER JOIN habilitacao h ON h.codigo = tp.id_disciplina
                    WHERE t.inep = :inep AND t.ano = :ano "
                    .($id_turma != null ? ' AND t.id = :id_turma ' : '').
                    " ORDER BY s.nome, t.descricao, h.descricao";

        $sth = $pdo->prepare($query);
        $sth->bindParam(':inep', $inep);
        $sth->bindParam(':ano', $ano);
        if ($id_turma != null) {
            $sth->bindParam(':id_turma', $id_turma);
        }

        return $sth->execute() ? $sth->fetchAll() : null;
    }

    public static function modalidadeEja($turma) {
    	if (is_numeric($turma)) {
    		$turma = self::get($turma);

    		return self::modalidadeEja($turma);
    	}

    	if (isset($turma['modalidade'])) {
    		return $turma['modalidade'] == Modalidade::EJA;
    	}

    	return false;
    }

    public static function modalidadeMediacaoTecnologia($turma) {
        if (is_numeric($turma)) {
            $turma = self::get($turma);

            return self::modalidadeMediacaoTecnologia($turma);
        }

        if (isset($turma['turmas'])) {
            return in_array($turma['turmas'], self::$turmasMediacaoTecnologica);
        }

        return false;
    }

    public static function getAulaDada($id_turma, $id_disciplina) {
        $pdo = new Conexao;
        $query = "SELECT count(id)
                    FROM dias_diario
                    WHERE id_turma = :id_turma
                    AND id_disciplina = :id_disciplina
                    AND registrado = 'S'
                    AND tipo_aula IN (1, 2)
                    AND tpbloqueio = 1;";

        $sth = $pdo->prepare($query);
        $sth->bindParam(':id_turma', $id_turma);
        $sth->bindParam(':id_disciplina', $id_disciplina);
        $sth->execute();

        return $sth->fetchColumn();
    }

    public static function getDisciplinasGrade($inep, $id_turma) {
        $pdo = new Conexao;
        $query = "SELECT h.codigo as id, h.descricao
                    FROM turma t
                    INNER JOIN grade_curricular g
                      ON g.id_serie = t.id_grade
                      AND g.ano = t.ano
                      AND g.id_modalidade = t.modalidade
                      AND g.inep = t.inep
                    INNER JOIN habilitacao h
                      ON h.codigo = g.id_disciplina
                    WHERE t.inep = :inep
                      AND t.id = :id_turma
                    ORDER BY h.impressao";
        $sth = $pdo->prepare($query);
        $sth->bindParam('inep', $inep);
        $sth->bindParam('id_turma', $id_turma);

        return $sth->execute() ? $sth->fetchAll() : null;
    }

    public static function getDisciplinasGradeProfessor($inep, $id_turma, $id_professor) {
        $pdo = new Conexao;
        $query = "SELECT h.codigo as id, h.descricao
                    FROM turma t
                    INNER JOIN grade_curricular g
                      ON g.id_serie = t.id_grade
                      AND g.ano = t.ano
                      AND g.id_modalidade = t.modalidade
                      AND g.inep = t.inep
                    INNER JOIN habilitacao h
                      ON h.codigo = g.id_disciplina
                    INNER JOIN turmaprofessor tp
                      ON tp.id_turma = t.id
                      AND tp.id_disciplina = g.id_disciplina
                      AND tp.inep = t.inep
                    WHERE t.inep = :inep
                      AND t.id = :id_turma
                      AND tp.cpf = :id_professor
                    ORDER BY h.impressao";
        $sth = $pdo->prepare($query);
        $sth->bindParam(':inep', $inep);
        $sth->bindParam(':id_turma', $id_turma);
        $sth->bindParam(':id_professor', $id_professor);

        return $sth->execute() ? $sth->fetchAll() : null;
    }

    public static function getDisciplinasProfessor($inep, $id_turma, $cpf)
    {
        $pdo = new Conexao;
        $sql = "SELECT h.codigo as id, h.descricao
                FROM turmaprofessor tp
                    JOIN turma t ON tp.id_turma = t.id
                    JOIN habilitacao h ON tp.id_disciplina = h.codigo
                WHERE t.inep = :inep
                    AND t.id = :id_turma
                    AND tp.cpf = :cpf
                ORDER BY h.impressao";
        $sth = $pdo->prepare($sql);
        $sth->bindParam(':inep', $inep);
        $sth->bindParam(':id_turma', $id_turma);
        $sth->bindParam(':cpf', $cpf);

        return $sth->execute() ? $sth->fetchAll() : null;
    }

    public static function getDisciplinasDependencia($id_turma, $id_aluno) {
        $pdo = new Conexao;
        $query = "SELECT group_concat(t.id_disciplina) as ids
                    FROM turma_dep_aluno_disciplina t
                    WHERE t.id_aluno = :id_aluno
                      AND t.id_turma = :id_turma";
        $sth = $pdo->prepare($query);
        $sth->bindParam(':id_turma', $id_turma);
        $sth->bindParam(':id_aluno', $id_aluno);

        $discs = array();
        if ($sth->execute()) {
            $discs = $sth->fetchColumn();
            $discs = explode(',', $discs);
        }

        return $discs;
    }

    public static function copiaLancamentosTurma($idTurmaAluno)
    {
        $pdo = new Conexao;
        $sqlTurmaAluno = "SELECT ta.*, t.id_grade, t.modalidade
                        FROM turma_aluno ta
                        INNER JOIN turma t ON ta.id_turma = t.id
                        WHERE ta.id = :idTurmaAluno";
        $sth = $pdo->prepare($sqlTurmaAluno);
        $sth->bindParam('idTurmaAluno', $idTurmaAluno);
        $turmaAluno = $sth->execute() ? $sth->fetch() : null;


        $idTurma = $turmaAluno["id_turma"];
        $ano = $turmaAluno['ano'];
        $inep = $turmaAluno['inep'];
        $idAluno = $turmaAluno["id_aluno"];
        $idGrade = $turmaAluno["id_grade"];
        $modalidade = $turmaAluno["modalidade"];

        $sql = "SELECT t.id
                FROM turma_aluno ta
                    JOIN turma t ON t.id = ta.id_turma
                WHERE t.ano = :ano
                    AND t.id_grade = :idGrade
                    AND t.modalidade = :modalidade
                    AND ta.id_aluno = :idAluno
                    AND (ta.situacao IN (2, 3))
                ORDER BY ta.dt_movimento DESC;";
        $sth = $pdo->prepare($sql);
        $sth->bindParam('ano', $ano);
        $sth->bindParam('idGrade', $idGrade);
        $sth->bindParam('modalidade', $modalidade);
        $sth->bindParam('idAluno', $idAluno);

        $idTurmaAnterior = $sth->execute() ? $sth->fetchColumn() : false;

        if ($idTurmaAnterior) {
            $copiouNotas = Nota::copiaNotasAluno($idTurmaAnterior, $idTurma, $idAluno, $inep);
            $copiouFreq = Frequencia::copiaFrequenciaAluno($idTurmaAnterior, $idTurma, $idAluno, $inep, $ano);
            $copiouAbono = Frequencia::copiaAbonoFaltaAluno($idTurmaAnterior, $idTurma, $idAluno, $inep);

            return $copiouNotas && $copiouAbono && $copiouFreq;
        }

        return false;
    }

    public static function checaAssociacaoProfessor($inep, $ano, $id_turma, $id_disciplina, $id_professor)
    {
        $pdo = new Conexao;
        $q = "SELECT COUNT(tp.id) as count
                FROM turma t
                INNER JOIN turmaprofessor tp ON tp.id_turma = t.id
                AND tp.cpf = :id_professor
                AND tp.id_disciplina = :id_disciplina
                AND t.id = :id_turma
                AND tp.ano = :ano
                AND tp.inep = :inep";
        $sth = $pdo->prepare($q);
        $sth->bindParam(':inep', $inep);
        $sth->bindParam(':ano', $ano);
        $sth->bindParam(':id_turma', $id_turma);
        $sth->bindParam(':id_professor', $id_professor);
        $sth->bindParam(':id_disciplina', $id_disciplina);
        $sth->execute();

        return $sth->fetchColumn() > 0;
    }

    public static function associarProfessor($inep, $ano, $usuario, $id_turma, $id_disciplina, $id_professor)
    {
        $pdo = new Conexao;
        if (!self::checaAssociacaoProfessor($inep, $ano, $id_turma, $id_disciplina, $id_professor)) {
            $q = "INSERT INTO turmaprofessor (cpf, id_turma, ano, inep, data, usuario, id_disciplina)
                    VALUES(:id_professor, :id_turma, :ano, :inep, :data, :usuario, :id_disciplina)";
            $sth = $pdo->prepare($q);
            $sth->bindParam(":inep", $inep);
            $sth->bindParam(":ano", $ano);
            $sth->bindParam(":usuario", $usuario);
            $sth->bindParam(":id_turma", $id_turma);
            $sth->bindParam(":id_disciplina", $id_disciplina);
            $sth->bindParam(":id_professor", $id_professor);
            $data = date('Y.m.d');
            $sth->bindParam(":data", $data);

            return $sth->execute();
        }

        return false;
    }

    public static function desvincularProfessor($inep, $ano, $id_turma, $id_disciplina, $id_professor)
    {
        $pdo = new Conexao;
        $q = "SELECT count(dd.id)
              FROM dias_diario dd
              WHERE dd.id_turmaprofessor = (
                SELECT t.id
                FROM turmaprofessor t
                WHERE t.id_turma = :id_turma
                AND t.cpf = :id_professor
                AND t.id_disciplina = :id_disciplina
              )";

        $sth = $pdo->prepare($q);
        $sth->bindParam(':id_turma', $id_turma);
        $sth->bindParam(':id_disciplina', $id_disciplina);
        $sth->bindParam(':id_professor', $id_professor);
        $aulas = $sth->execute() ? $sth->fetchColumn() : null;

        if($aulas > 0)
        {
            return false;
        }
        
        $q = "DELETE FROM turmaprofessor
            WHERE inep = :inep AND ano = :ano AND id_turma = :id_turma AND id_disciplina = :id_disciplina AND cpf = :id_professor";
        $sth = $pdo->prepare($q);
        $sth->bindParam(':inep', $inep);
        $sth->bindParam(':ano', $ano);
        $sth->bindParam(':id_turma', $id_turma);
        $sth->bindParam(':id_disciplina', $id_disciplina);
        $sth->bindParam(':id_professor', $id_professor);

        return $sth->execute();
    }



}