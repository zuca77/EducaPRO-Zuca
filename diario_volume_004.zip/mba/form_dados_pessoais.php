<?php

session_start();
if (isset($_SESSION["login_usuario"]))
  {
     $login =  $_SESSION["login_usuario"];
     $nte   =  $_SESSION["nivel_usuario"];
     include ("../funcoes.php");
     echo  saudacoes()."   ". "$login" ."  -  ". $nte."  ".dataextenso();
  }
 else
  {
     		 header("Location: ../login.php");
  }  	 















if(file_exists("conexao_mysql.php")) 
{
        require "conexao_mysql.php";
        mysql_query("SET NAMES 'utf8'");

             
} else 
{
        echo "Conexão nao foi encontrado";
        exit;
}
?>

<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01//EN"
	"http://www.w3.org/TR/html4/strict.dtd"><head>

	<meta http-equiv="Content-type" content="text/html; charset=utf-8" />
	<title>SEDUC-RO</title>
	
	
	
	<link rel="stylesheet" href="style/forms.css" type="text/css" />
	<link rel="stylesheet" href="estilo.css" type="text/css" />
	<link rel="stylesheet" href="style/menu.css" type="text/css" />
	<link href="tablecloth/tablecloth.css" rel="stylesheet" type="text/css" media="screen" />


	
	<script type="text/javascript" src="tablecloth/tablecloth.js"></script>
	<script src="lib/jquery-1.4.2.js" type="text/javascript"></script>
	<script src="lib/validate.js" type="text/javascript"></script>
	<script src="lib/forms.js" type="text/javascript"></script>
	<script src="generic1.js" type="text/javascript"></script>
    <script src="lib/jquery.maskedinput-1.1.1.js" type="text/javascript"></script>



 	<link type="text/css" href="jquery-ui-1.8.18.custom/css/ui-lightness/jquery-ui-1.8.18.custom.css" rel="stylesheet" />
<!--	Versao nao trabalha com validade <script type="text/javascript" src="jquery-ui-1.8.18.custom/js/jquery-1.7.1.min.js"></script>-->
	<script type="text/javascript" src="jquery-ui-1.8.18.custom/js/jquery-ui-1.8.18.custom.min.js"></script>


<script>


	$(function() {
		$( "#txtdtnascimento" ).datepicker({
			changeMonth: true,
			changeYear: true
		});
	});

$(function() {
        $("#txtdtnascimento").datepicker();
        $('#txtdtnascimento').datepicker('option', 'dateFormat', 'dd/mm/yy');
});



	$(function() {
		$( "#txtDataEmissao" ).datepicker({
			changeMonth: true,
			changeYear: true
		});
	});


$(function() {
        $("#txtDataEmissao").datepicker();
        $('#txtDataEmissao').datepicker('option', 'dateFormat', 'dd/mm/yy');
});

	$(function() {
		$( "#txttdtte" ).datepicker({
			changeMonth: true,
			changeYear: true
		});
	});


$(function() {
        $("#txttdtte").datepicker();
        $('#txttdtte').datepicker('option', 'dateFormat', 'dd/mm/yy');
});



</script>

</head>
<body>
	<div id="warpper">
		<div id="header">
		    <img src= "img/seduc_topo.jpg"/>

		</div>
    <div id="container">
      <div id="menu">
        <ul>
          <li>
             <center>
			 </center>
          </li>
       </ul>
      </div>
			<div id="content">

				<form  name="form" class="form" action="insere_dados_pessoais.php" method="POST">
				 <div id="tema"> 
					   <p><center>Dados Pessoais</center></p>
				  </div>

					<p>
						<label for="txtCPF">CPF<img src= "img/check.gif"/></label>
						<input type="text" name="cpf" style="width:110px" value="" maxlength="11" id="cpf" />

  				    <label for="txtPisPasep">PIS/PASEP:</label>
					 <input type="text" name="pis"  id="pis" style="width:110px"  maxlength="25" value=""/>

					</p>
					<p>

						<label for="txtRG">RG<img src= "img/check.gif"/></label>
						<input type="text" name="txtRG" style="width:110px" maxlength="20" value="" id="txtRG" />
						
						<label for="txtOrgaoExp" >Orgão Exp<img src= "img/check.gif"/></label>
						<input type="text" name="txtOrgaoExp" value="" style="width:70px" maxlength="10" id="txtOrgaoExp" />
						
						<label for="txtDataEmissao">Data Emissão<img src= "img/check.gif"/></label>
						<input type="text" name="txtDataEmissao" value="" style="width:70px" id="txtDataEmissao" />
					</p>
					




					<p>

						<label for="lblte">Título Eleitor<img src= "img/check.gif"/></label>
						<input type="text" name="txtte" style="width:110px" value="" maxlength="20" id="txtte" />
						
						<label for="lblzona" >Zona<img src= "img/check.gif"/></label>
						<input type="text" name="txtzona" value="" style="width:70px" id="txtzona" maxlength="10" />
						
						<label for="lblsecao">Seção<img src= "img/check.gif"/></label>
						<input type="text" name="txtsecao" value="" style="width:70px"  maxlength="5" id="txtsecao" />
						
						<label for="lbldtemissaote">Data Emissão<img src= "img/check.gif"/></label>
						<input type="text" name="txttdtte" value="" style="width:70px" id="txttdtte" />

					</p>
					



					<p>
						<label for="txtNome">Nome<img src= "img/check.gif"/></label>
						<input type="text" name="txtNome" style="width:565px" maxlength="60" value="" id="txtNome" />
					</p>

					<p>
						<label for="selectsexo">Estado Civil<img src= "img/check.gif"/></label>
 			               <select id="selectcivil" name="selectcivil" style="width:150px">
              		          <option value="CASADO">CASADO</option>
            		          <option value="SOLTEIRO">SOLTEIRO</option>
              		          <option value="VIUVO">VIUVO</option>
            		          <option value="DESQUITADO">DESQUITADO</option>
              		          <option value="DIVORCIADO">DIVORCIADO</option>
            		          <option value="OUTROS">OUTROS</option>


    		               </select>
						<label for="lbldtnascimento">Data Nascimento<img src= "img/check.gif"/></label>
						<input type="text" name="txtdtnascimento" value="" style="width:70px" id="txtdtnascimento" />

 	    		        
						<label for="selectsexo">Sexo<img src= "img/check.gif"/></label>
 			               <select id="selectsexo" name="selectsexo"  style="width:140px">
              		          <option value="M">Masculino</option>
            		          <option value="F">Feminino</option>
    		               </select>


					</p>


					<p>
						<label for="lblconjuge">Conjuge</label>
						<input type="text" name="txtconjuge" style="width:565px" maxlength="60" value="" id="txtconjuge" />
					</p>

					<p>
						<label for="lblmae">Nome Mãe<img src= "img/check.gif"/></label>
						<input type="text" name="txtmae" style="width:565px" maxlength="60" value="" id="txtmae" />
					</p>
					<p>
						<label for="lblpai">Nome Pai<img src= "img/check.gif"/></label>
						<input type="text" name="txtpai" style="width:565px" maxlength="60" value="" id="txtpai" />
					</p>


					<p>


						<label for="lblEndereco">Endereço<img src= "img/check.gif"/></label>
						<input type="text" name="txtEndereco" style="width:298px" value=""  maxlength="60" size="60" id="txtEndereco" />
					</p>
						<p>
						<label for="lblEndereco">Complemento</label>
				<input type="text" name="txtcomplemento" style="width:565px" value=""  maxlength="40" size="60" id="txtcomplemento" />
					</p>

					<p>
						<label for="lblBairro">Bairro<img src= "img/check.gif"/></label>
						<input type="text" name="txtBairro" value="" id="txtBairro" maxlength ="40"/>
						<label for="lblBairro">Nr<img src= "img/check.gif"/></label>
						<input type="text" name="txtnr" style="width:60px" value="" maxlength="5" id="txtnr" />
			            <label for="txtCEP">CEP<img src= "img/check.gif"/></label>
            			<input id="txtcep" name="txtcep" maxlength="8" type="text" style="width:90px" />
					</p>
					<p>
						<label for="txtFoneS">Telefone Trabalho</label>
						<input type="text" name="txtFoneSetor" style="width:110px" maxlength="20" value="" id="txtFoneSetor" />
						<label for="txtFoneRes">Telefone Residencial<img src= "img/check.gif"/></label>
						<input type="text" name="txtFoneRes" style="width:110px" maxlength="20" value="" id="txtFoneRes" />
						<label for="txtCelular12">Telefone Celular<img src= "img/check.gif"/></label>
						<input type="text" name="txtCelular" style="width:110px" maxlength="20" value="" id="txtCelular" />
					</p>
					<p>
						<label for="txtEmail">E-mail</label>
						<input type="text" name="txtEmail" style="width:565px" maxlength="80" value="" id="txtEmail" />
					</p>


					<p>
	 
					<label for="cod_estados">Naturalidade - Estado:</label>
						<select name="cod_estado" id="cod_estado">
						<option value=""></option>
					<?php
							$sql = "SELECT cod_estados, sigla
									FROM estados
									ORDER BY sigla";
				     		$res = mysql_query( $sql );
							while ( $row = mysql_fetch_assoc( $res ) ) {
							echo '<option value="'.$row['cod_estados'].'">'.$row['sigla'].'</option>';
						}
	
					?>
					</select>
          		<label for="cod_cidades">Cidade:</label>
         		<span class="carregando">Aguarde, carregando...</span>
		          <select name="cod_cidades" id="cod_cidades">
			           <option value="">-- Escolha um estado --</option>
            	 </select>

<!--		<script src="http://www.google.com/jsapi"></script>
-->
		<script type="text/javascript">
		  //google.load('jquery', '1.3');
		</script>		

		<script type="text/javascript"> 
		$(function(){
			$('#cod_estado').change(function(){
	 
 				if( $(this).val() ) {
					$('#cod_cidades').hide();
					$('.carregando').show();
					$.getJSON('cidades.ajax.php?search=',{cod_estado: $(this).val(), ajax: 'true'}, function(j){
						var options = '<option value=""></option>';	
						for (var i = 0; i < j.length; i++) {
							options += '<option value="' + j[i].cod_cidades + '">' + j[i].nome + '</option>';

						}	
						$('#cod_cidades').html(options).show();
						$('.carregando').hide();
					});
				} else {
					$('#cod_cidades').html('<option value="">– Escolha um estado –</option>');

				}
			});
		});

		</script>

		</p>




					<p>
	 
					<label for="lblinstrucao">Grau de Instrução</label>
						<select name="txtinstrucao" id="txtinstrucao">
						<option value="">Selecione Grau de Instrução</option>
					<?php
							$sql = "SELECT codigo, descricao
									FROM grauinstrucao
									ORDER BY descricao";
				     		$res = mysql_query( $sql );
							while ( $row = mysql_fetch_assoc( $res ) ) {
							echo '<option value="'.$row['codigo'].'">'.$row['descricao'].'</option>';
						}
	
					?>
					</select>

					</p>



					<p>
	 
					<label for="lblhabilitacao">Habilitação</label>
						<select name="txthabilitacao" id="txthabilitacao">
						<option value="">Selecione Habilitação</option>
					<?php
							$sql = "SELECT codigo, descricao
									FROM habilitacao
									ORDER BY descricao";
				     		$res = mysql_query( $sql );
							while ( $row = mysql_fetch_assoc( $res ) ) {
							echo '<option value="'.$row['codigo'].'">'.$row['descricao'].'</option>';
						}
	
					?>
					</select>

					</p>


					  <p>
						  <label for="txtBanco">Banco:</label>
						  <input type="text" name="txtBanco" value="" maxlength="3" style="width:50px" id="txtBanco" />
						  <label for="txtAgencia" >Agência:</label>
						  <input type="text" name="txtAgencia" value="" maxlength="20" style="width:60px" id="txtAgencia" />
						  <label for="txtConta">Conta:</label>
						  <input type="text" name="txtConta" value="" maxlength="20" style="width:100px" id="txtConta" />
					  </p>


					<p id="finish">
            <input type="button" value=" Voltar " onclick="history.go(-1);">
            <input type="submit" value="Gravar" />
            <input type="reset" value="limpar" />
					</p>
				</form>
			</div>
		</div>
		<div id="footer">
			<p>Todos direitos reservados GTI-SEDUC-RO</p>
		</div>
	</div>
</body>

