<? 
session_start();

if (isset($_SESSION["login_usuario"]))
  {
    $login =  $_SESSION["login_usuario"];
     $nte   =  $_SESSION["nivel_usuario"];
     include ("../../conexao_mysql.php");
     include ("../../funcoes.php");
     echo  saudacoes()."   ". "$login" ."  -  ".$nte."  ".dataextenso();


  }
 else
  {
    header("Location: login.php");
  }  	 

$cpf              = $_SESSION["cpf_usuario"];     
$inep             = $_POST['tecnico'];
$lotacaoprof      = $_POST['lotacaoprof'];
$opcao            = $_POST['opcao'];
$txtgerencia      = $_POST['txtgerencia'];
$txtdpto          = $_POST['txtdpto'];

$txtcod_cargo     = $_POST['txtcod_cargo'];
$cod_funcao0      = $_POST['cod_funcao0'];
$txthabilitacao   = $_POST['txthabilitacao'];

$lotacaoserv     = $_POST['lotacaoserv'];
$tppresquisa     = $_POST['tppresquisa'];
$tppresquisaadm  = $_POST['tppresquisaadm'];

$pesqnomemat     = $_POST['pesqnomemat'];
$pesqnomematadm     = $_POST['pesqnomematadm'];


if ($opcao=="1")
{
if ($lotacaoprof=="1")
{
$sql = "SELECT l.inep,e.descricao,s.cpf,s.nome,s.endereco,s.bairro,l.chlotacao,m.descricao as descricaom,cg.descricao as descricaocg,f.descricao as descricaof FROM lotacao 
l,escola e,servidorrec s,municipio m,contrato c,cargo cg,funcao f WHERE l.lotado = '2' and l.inep <> '' and  l.inep = e.inep and l.cpf =s.cpf and e.municipio = m.codigo and c.cpf =l.cpf and c.cpf = s.cpf  and c.cargo > 1 and cg.cod_cargo = c.cargo and f.cod_funcao = c.funcao and l.inep='$inep' order by l.inep"; 


$re = mysql_query("select count(l.inep) as total FROM lotacao 
l,escola e,servidorrec s,municipio m,contrato c,cargo cg,funcao f WHERE l.lotado = '2' and l.inep <> '' and  l.inep = e.inep and l.cpf =s.cpf and e.municipio = m.codigo and c.cpf =l.cpf and c.cpf = s.cpf  and c.cargo > 1 and cg.cod_cargo = c.cargo and f.cod_funcao = c.funcao and   l.inep='$inep'");
$total = mysql_result($re, 0, "total");

}
else if ($lotacaoprof=="2")
{
$sql = "SELECT l.inep,e.descricao as descricaoe,s.cpf,s.nome,s.endereco,s.bairro,l.chlotacao,l.areaatuacao,h.descricao as descricaoh,m.descricao as descricaom,c.matricula,cg.descricao as descricaocg,f.descricao as descricaof FROM lotacao l,escola e,servidorrec s,habilitacao h,municipio m,contrato c,cargo cg,funcao f WHERE l.lotado ='2' and l.inep <> '' and l.inep = e.inep and l.cpf =s.cpf and l.areaatuacao = h.codigo and e.municipio = m.codigo and c.cpf = l.cpf and c.cpf =s.cpf  and cg.cod_cargo = c.cargo and f.cod_funcao = c.funcao and l.inep='$inep' and cg.cod_cargo in(1,2) order by s.nome"; 


$re = mysql_query("select count(l.inep) as total FROM lotacao l,escola e,servidorrec s,habilitacao h,municipio m,contrato c,cargo cg,funcao f WHERE l.lotado ='2' and l.inep <> '' and l.inep = e.inep and l.cpf =s.cpf and l.areaatuacao = h.codigo and e.municipio = m.codigo and c.cpf = l.cpf and c.cpf =s.cpf and cg.cod_cargo = c.cargo and f.cod_funcao = c.funcao  and l.inep='$inep' and cg.cod_cargo in(1,2)");
$total = mysql_result($re, 0, "total");

}
else if ($lotacaoprof=="3")
{
$sql = "SELECT l.inep,e.descricao as descricaoe,s.cpf,s.nome,s.endereco,s.bairro,l.chlotacao,l.areaatuacao,h.descricao as descricaoh,m.descricao as descricaom,c.matricula,cg.descricao as descricaocg,f.descricao as descricaof FROM lotacao l,escola e,servidorrec s,habilitacao h,municipio m,contrato c,cargo cg,funcao f WHERE l.lotado ='2' and l.inep <> '' and l.inep = e.inep and l.cpf =s.cpf and l.areaatuacao = h.codigo and e.municipio = m.codigo and c.cpf = l.cpf and c.cpf =s.cpf  and cg.cod_cargo = c.cargo and f.cod_funcao = c.funcao and cg.cod_cargo in(1,2) order by s.nome"; 


$re = mysql_query("select count(l.inep) as total FROM lotacao l,escola e,servidorrec s,habilitacao h,municipio m,contrato c,cargo cg,funcao f WHERE l.lotado ='2' and l.inep <> '' and l.inep = e.inep and l.cpf =s.cpf and l.areaatuacao = h.codigo and e.municipio = m.codigo and c.cpf = l.cpf and c.cpf =s.cpf and cg.cod_cargo = c.cargo and f.cod_funcao = c.funcao  and cg.cod_cargo in(1,2)");
$total = mysql_result($re, 0, "total");

}
else if ($lotacaoprof=="4")
{
$sql = "SELECT l.inep,e.descricao,s.cpf,s.nome,s.endereco,s.bairro,l.chlotacao,m.descricao as descricaom,cg.descricao as descricaocg,f.descricao as descricaof FROM lotacao l,escola e,servidorrec s,municipio m,contrato c,cargo cg,funcao f WHERE l.lotado = '2' and l.inep <> '' and  l.inep = e.inep and l.cpf =s.cpf and e.municipio = m.codigo and c.cpf =l.cpf and c.cpf = s.cpf  and c.cargo > 1 and cg.cod_cargo = c.cargo and f.cod_funcao = c.funcao  order by l.inep"; 


$re = mysql_query("select count(l.inep) as total FROM lotacao 
l,escola e,servidorrec s,municipio m,contrato c,cargo cg,funcao f WHERE l.lotado = '2' and l.inep <> '' and  l.inep = e.inep and l.cpf =s.cpf and e.municipio = m.codigo and c.cpf =l.cpf and c.cpf = s.cpf  and c.cargo > 1 and cg.cod_cargo = c.cargo and f.cod_funcao = c.funcao ");
$total = mysql_result($re, 0, "total");

}
else if ($lotacaoprof=="5")
{
$sql = "SELECT l.inep,e.descricao, count( l.inep ) as total FROM lotacao l, escola e, servidorrec s, habilitacao h, municipio m, contrato c, cargo cg, funcao f WHERE l.lotado = '2' AND l.inep <> ''AND l.inep = e.inep AND l.cpf = s.cpf AND l.areaatuacao = h.codigo AND e.municipio = m.codigo AND c.cpf = l.cpf AND c.cpf = s.cpf AND cg.cod_cargo = c.cargo AND f.cod_funcao = c.funcao AND cg.cod_cargo IN ( 1, 2 ) GROUP BY l.inep"; 



$re = mysql_query("select count(l.inep) as total FROM lotacao 
l,escola e,servidorrec s,municipio m,contrato c,cargo cg,funcao f WHERE l.lotado = '2' and l.inep <> '' and  l.inep = e.inep and l.cpf =s.cpf and e.municipio = m.codigo and c.cpf =l.cpf and c.cpf = s.cpf  and c.cargo > 1 and cg.cod_cargo = c.cargo and f.cod_funcao = c.funcao ");
$total = mysql_result($re, 0, "total");
  }


else if ($lotacaoprof=="7")
{
$sql = "SELECT l.inep,e.descricao as descricaoe,s.cpf,s.nome,s.endereco,s.bairro,l.chlotacao,l.areaatuacao,h.descricao as descricaoh,m.descricao as descricaom,c.matricula,cg.descricao as descricaocg,f.descricao as descricaof, m.descricao as descricaom FROM lotacao l,escola e,servidorrec s,habilitacao h,municipio m,contrato c,cargo cg,funcao f WHERE l.lotado ='2' and l.inep <> '' and l.inep = e.inep and l.cpf =s.cpf and l.areaatuacao = h.codigo and e.municipio = m.codigo and c.cpf = l.cpf and c.cpf =s.cpf  and cg.cod_cargo = c.cargo and f.cod_funcao = c.funcao and cg.cod_cargo in(1,2) order by m.descricao"; 


$re = mysql_query("select count(l.inep) as total FROM lotacao l,escola e,servidorrec s,habilitacao h,municipio m,contrato c,cargo cg,funcao f WHERE l.lotado ='2' and l.inep <> '' and l.inep = e.inep and l.cpf =s.cpf and l.areaatuacao = h.codigo and e.municipio = m.codigo and c.cpf = l.cpf and c.cpf =s.cpf and cg.cod_cargo = c.cargo and f.cod_funcao = c.funcao  and cg.cod_cargo in(1,2)");
$total = mysql_result($re, 0, "total");

}
if ($lotacaoprof=="8")
{
$sql = "SELECT l.inep,e.descricao,s.cpf,s.nome,s.endereco,s.bairro,l.chlotacao,m.descricao as descricaom,cg.descricao as descricaocg,f.descricao as descricaof FROM lotacao 
l,escola e,servidorrec s,municipio m,contrato c,cargo cg,funcao f WHERE l.lotado = '2' and l.inep <> '' and  l.inep = e.inep and l.cpf =s.cpf and e.municipio = m.codigo and c.cpf =l.cpf and c.cpf = s.cpf  and c.cargo > 1 and cg.cod_cargo = c.cargo and f.cod_funcao = c.funcao  order by s.nome"; 


$re = mysql_query("select count(l.inep) as total FROM lotacao 
l,escola e,servidorrec s,municipio m,contrato c,cargo cg,funcao f WHERE l.lotado = '2' and l.inep <> '' and  l.inep = e.inep and l.cpf =s.cpf and e.municipio = m.codigo and c.cpf =l.cpf and c.cpf = s.cpf  and c.cargo > 1 and cg.cod_cargo = c.cargo and f.cod_funcao = c.funcao ");
$total = mysql_result($re, 0, "total");

}




}

else if ($opcao=="2")  /* Servidores Administrativo*/
{

if (trim($txtdpto)=='')
 {  

   $sql = "SELECT distinct l.cpf,s.nome,s.endereco,s.bairro,g.descricao,cg.descricao as descricaocg,f.descricao as descricaof,d.descricao as descricaod FROM lotacao   l,servidorrec s,gerencia g,cargo cg,funcao f,contrato c,departamento d WHERE l.lotado ='1' and l.cpf =s.cpf and l.gerencia = g.codigo and l.gerencia =  '$txtgerencia' and  l.gerencia <> '' AND cg.cod_cargo = c.cargo AND f.cod_funcao = c.funcao and c.cpf =l.cpf and c.cpf = s.cpf and d.codigo_dpto=l.departamento and d.gerencia = l.gerencia  and l.dtsaida is null order by s.nome" ; 
   $re = mysql_query("SELECT  COUNT(DISTINCT l.cpf) as total FROM lotacao   l,servidorrec s,gerencia g,cargo cg,funcao f,contrato c,departamento d WHERE l.lotado ='1' and l.cpf =s.cpf and l.gerencia = g.codigo and l.gerencia =  '$txtgerencia' and  l.gerencia <> '' AND cg.cod_cargo = c.cargo AND f.cod_funcao = c.funcao and c.cpf =l.cpf and c.cpf = s.cpf and d.codigo_dpto=l.departamento and d.gerencia = l.gerencia and l.dtsaida is null ");
$total = mysql_result($re, 0, "total");
  }
else
{
 $sql = "SELECT distinct l.cpf,s.nome,s.endereco,s.bairro,g.descricao,cg.descricao as descricaocg,f.descricao as descricaof,d.descricao as descricaod FROM lotacao   l,servidorrec s,gerencia g,cargo cg,funcao f,contrato c,departamento d WHERE l.lotado ='1' and l.cpf =s.cpf and l.gerencia = g.codigo and l.gerencia =  '$txtgerencia' and  l.gerencia <> '' AND cg.cod_cargo = c.cargo AND f.cod_funcao = c.funcao and  c.cpf =l.cpf and c.cpf = s.cpf and  l.departamento='$txtdpto' and d.codigo_dpto=l.departamento and d.gerencia = l.gerencia and l.dtsaida is null order by s.nome" ; 

  $re = mysql_query("SELECT COUNT(DISTINCT l.cpf) as total FROM  lotacao   l,servidorrec s,gerencia g,cargo cg,funcao f,contrato c,departamento d WHERE l.lotado ='1' and l.cpf =s.cpf and l.gerencia = g.codigo and l.gerencia =  '$txtgerencia' and  l.gerencia <> '' AND cg.cod_cargo = c.cargo AND f.cod_funcao = c.funcao and  c.cpf =l.cpf and c.cpf = s.cpf and  l.departamento='$txtdpto' and d.codigo_dpto=l.departamento and d.gerencia = l.gerencia and l.dtsaida is null");
$total = mysql_result($re, 0, "total");
  }
}
else if ($opcao=="3")  /* Servidores Administrativo*/
{
if ($lotacaoserv=='1')
{

  if ((trim($cod_funcao0)=='')&&(trim($txthabilitacao)==''))
   {  
   $sql = "SELECT distinct l.cpf,s.nome,s.endereco,s.bairro,g.descricao as descricaog,f.descricao as descricaof FROM lotacao l,servidorrec s,gerencia g,contrato c,funcao f WHERE l.lotado ='1' and l.cpf =s.cpf and l.gerencia = g.codigo and s.cpf = c.cpf and c.funcao = f.cod_funcao and c.cargo='$txtcod_cargo'"; 

  $re = mysql_query("SELECT  COUNT(DISTINCT l.cpf) as total FROM lotacao l,servidorrec s,gerencia g,contrato c,funcao f WHERE l.lotado ='1   ' and l.cpf =s.cpf and l.gerencia = g.codigo and s.cpf = c.cpf and c.funcao = f.cod_funcao and c.cargo='$txtcod_cargo'");
   $total = mysql_result($re, 0, "total");
    }

 else if (trim($txthabilitacao)=='')
     {  
   $sql = "SELECT distinct l.cpf,s.nome,s.endereco,s.bairro,g.descricao as descricaog,f.descricao as descricaof FROM lotacao l,servidorrec s,gerencia g,contrato c,funcao f WHERE l.lotado ='1' and l.cpf =s.cpf and l.gerencia = g.codigo and s.cpf = c.cpf and c.funcao = f.cod_funcao and c.cargo='$txtcod_cargo' and c.funcao='$cod_funcao0'"; 

  $re = mysql_query("SELECT  COUNT(DISTINCT l.cpf) as total FROM lotacao l,servidorrec s,gerencia g,contrato c,funcao f WHERE l.lotado ='1   ' and l.cpf =s.cpf and l.gerencia = g.codigo and s.cpf = c.cpf and c.funcao = f.cod_funcao and c.cargo='$txtcod_cargo' and c.funcao='$cod_funcao0'");
   $total = mysql_result($re, 0, "total");
     }

 else 
     {  
echo "passoi asdf adm"; 
echo "$txtcod_cargo aaa $cod_funcao0 aaa $txthabilitacao";

   $sql = "SELECT distinct l.cpf,s.nome,s.endereco,s.bairro,g.descricao as descricaog,f.descricao as descricaof FROM lotacao l,servidorrec s,gerencia g,contrato c,funcao f,habilitacao h WHERE l.lotado ='1' and l.cpf =s.cpf and l.gerencia = g.codigo and s.cpf = c.cpf and c.funcao = f.cod_funcao and c.cargo='$txtcod_cargo' and c.funcao='$cod_funcao0' and l.areaatuacao='$txthabilitacao'"; 

  $re = mysql_query("SELECT  COUNT(DISTINCT l.cpf) as total FROM lotacao l,servidorrec s,gerencia g,contrato c,funcao f,habilitacao h WHERE l.lotado ='1   ' and l.cpf =s.cpf and l.gerencia = g.codigo and s.cpf = c.cpf and c.funcao = f.cod_funcao and c.cargo='$txtcod_cargo' and c.funcao='$cod_funcao0' and l.areaatuacao='$txthabilitacao'");
   $total = mysql_result($re, 0, "total");
     }

 }

else // ESCOLA
 {

  if ((trim($cod_funcao0)=='')&&(trim($txthabilitacao)==''))
   {  

   $sql = "SELECT distinct l.cpf,s.nome,s.endereco,s.bairro,e.descricao as descricaog,f.descricao as descricaof FROM lotacao l,servidorrec s,escola e,contrato c,funcao f WHERE l.lotado ='2' and l.cpf =s.cpf and e.inep = l.inep and s.cpf = c.cpf and c.funcao =   f.cod_funcao and c.cargo='$txtcod_cargo'"; 

  $re = mysql_query("SELECT  COUNT(DISTINCT l.cpf) as total FROM lotacao l,servidorrec s,escola e,contrato c,funcao f WHERE l.lotado ='2   ' and l.cpf =s.cpf and e.inep = l.inep  and s.cpf = c.cpf and c.funcao = f.cod_funcao and c.cargo='$txtcod_cargo'");
   $total = mysql_result($re, 0, "total");
    }

 else if ((trim($cod_funcao0)=='')&&(trim($txthabilitacao)==''))
   {  

   $sql = "SELECT distinct l.cpf,s.nome,s.endereco,s.bairro,e.descricao as descricaog,f.descricao as descricaof FROM lotacao l,servidorrec s,escola e,contrato c,funcao f WHERE l.lotado ='2' and l.cpf =s.cpf and e.inep = l.inep and s.cpf = c.cpf and c.funcao =   f.cod_funcao and c.cargo='$txtcod_cargo' and c.funcao='$cod_funcao0' "; 

  $re = mysql_query("SELECT  COUNT(DISTINCT l.cpf) as total FROM lotacao l,servidorrec s,escola e,contrato c,funcao f WHERE l.lotado ='2   ' and l.cpf =s.cpf and e.inep = l.inep  and s.cpf = c.cpf and c.funcao = f.cod_funcao and c.cargo='$txtcod_cargo' and c.funcao='$cod_funcao0'");
   $total = mysql_result($re, 0, "total");
    }
 else 
   {  

   $sql = "SELECT distinct l.cpf,s.nome,s.endereco,s.bairro,e.descricao as descricaog,f.descricao as descricaof FROM lotacao l,servidorrec s,escola e,contrato c,funcao f WHERE l.lotado ='2' and l.cpf =s.cpf and e.inep = l.inep and s.cpf = c.cpf and c.funcao =   f.cod_funcao and c.cargo='$txtcod_cargo' and c.funcao='$cod_funcao0' and l.areaatuacao='$txthabilitacao'"; 

  $re = mysql_query("SELECT  COUNT(DISTINCT l.cpf) as total FROM lotacao l,servidorrec s,escola e,contrato c,funcao f WHERE l.lotado ='2   ' and l.cpf =s.cpf and e.inep = l.inep  and s.cpf = c.cpf and c.funcao = f.cod_funcao and c.cargo='$txtcod_cargo' and c.funcao='$cod_funcao0' and l.areaatuacao='$txthabilitacao'");
   $total = mysql_result($re, 0, "total");
    }
 }


}





if ($opcao=="4")  /* Pesquisa por nome e matricula*/
{
     
if ($tppresquisa=='1')
{

$sql = "SELECT l.inep,e.descricao as descricaoe,s.cpf,s.nome,s.endereco,s.bairro,l.chlotacao,l.areaatuacao,h.descricao as  descricaoh,m.descricao as descricaom,c.matricula,cg.descricao as descricaocg,f.descricao as descricaof FROM lotacao l,escola e,servidorrec s,habilitacao h,municipio m,contrato c,cargo cg,funcao f WHERE l.lotado ='2' and l.inep <> '' and l.inep = e.inep and l.cpf =s.cpf and l.areaatuacao = h.codigo and e.municipio = m.codigo and c.cpf = l.cpf and c.cpf =s.cpf  and cg.cod_cargo = c.cargo and f.cod_funcao = c.funcao and cg.cod_cargo in(1,2) and c.matricula ='$pesqnomemat' order by s.nome"; 


$re = mysql_query("select count(l.inep) as total FROM lotacao l,escola e,servidorrec s,habilitacao h,municipio m,contrato c,cargo cg,funcao f WHERE l.lotado ='2' and l.inep <> '' and l.inep = e.inep and l.cpf =s.cpf and l.areaatuacao = h.codigo and e.municipio = m.codigo and c.cpf = l.cpf and c.cpf =s.cpf and cg.cod_cargo = c.cargo and f.cod_funcao = c.funcao  and cg.cod_cargo in(1,2) and c.matricula ='$pesqnomemat' ");
$total = mysql_result($re, 0, "total");
  }

else if ($tppresquisa=='2')
{
 $sql = "SELECT l.inep,e.descricao as descricaoe,s.cpf,s.nome,s.endereco,s.bairro,l.chlotacao,l.areaatuacao,h.descricao as  descricaoh,m.descricao as descricaom,c.matricula,cg.descricao as descricaocg,f.descricao as descricaof FROM lotacao l,escola e,servidorrec s,habilitacao h,municipio m,contrato c,cargo cg,funcao f WHERE l.lotado ='2' and l.inep <> '' and l.inep = e.inep and l.cpf =s.cpf and l.areaatuacao = h.codigo and e.municipio = m.codigo and c.cpf = l.cpf and c.cpf =s.cpf  and cg.cod_cargo = c.cargo and f.cod_funcao = c.funcao and cg.cod_cargo in(1,2) and s.nome like '$pesqnomemat%' order by s.nome"; 
  $re = mysql_query("select count(l.inep) as total FROM lotacao l,escola e,servidorrec s,habilitacao h,municipio m,contrato c,cargo cg,funcao f WHERE l.lotado ='2' and l.inep <> '' and l.inep = e.inep and l.cpf =s.cpf and l.areaatuacao = h.codigo and e.municipio = m.codigo and c.cpf = l.cpf and c.cpf =s.cpf and cg.cod_cargo = c.cargo and f.cod_funcao = c.funcao  and cg.cod_cargo in(1,2) and s.nome like '$pesqnomemat%' ");
  $total = mysql_result($re, 0, "total");
}


else if ($tppresquisa=='3')
{
$sql = "SELECT l.inep,e.descricao as descricaoe,s.cpf,s.nome,s.endereco,s.bairro,l.chlotacao,l.areaatuacao,h.descricao as  descricaoh,m.descricao as descricaom,c.matricula,cg.descricao as descricaocg,f.descricao as descricaof FROM lotacao l,escola e,servidorrec s,habilitacao h,municipio m,contrato c,cargo cg,funcao f WHERE l.lotado ='2' and l.inep <> '' and l.inep = e.inep and l.cpf =s.cpf and l.areaatuacao = h.codigo and e.municipio = m.codigo and c.cpf = l.cpf and c.cpf =s.cpf  and cg.cod_cargo = c.cargo and f.cod_funcao = c.funcao and cg.cod_cargo in(1,2) and c.cpf ='$pesqnomemat' order by s.nome";

$re = mysql_query("select count(l.inep) as total FROM lotacao l,escola e,servidorrec s,habilitacao h,municipio m,contrato c,cargo cg,funcao f WHERE l.lotado ='2' and l.inep <> '' and l.inep = e.inep and l.cpf =s.cpf and l.areaatuacao = h.codigo and e.municipio = m.codigo and c.cpf = l.cpf and c.cpf =s.cpf and cg.cod_cargo = c.cargo and f.cod_funcao = c.funcao  and cg.cod_cargo in(1,2) and c.cpf ='$pesqnomemat' ");
$total = mysql_result($re, 0, "total");
  }

}





if ($opcao=="5")  /* Pesquisa por nome e matricula*/
{

if ($tppresquisaadm=='1')
{

$sql = "SELECT distinct l.cpf,s.nome,s.endereco,s.bairro,g.descricao,cg.descricao as descricaocg,f.descricao as descricaof,d.descricao as descricaod FROM lotacao   l,servidorrec s,gerencia g,cargo cg,funcao f,contrato c,departamento d WHERE l.lotado ='1' and l.cpf =s.cpf and l.gerencia = g.codigo  and  l.gerencia <> '' AND cg.cod_cargo = c.cargo AND f.cod_funcao = c.funcao and  c.cpf =l.cpf and c.cpf = s.cpf and  l.matricula='$pesqnomematadm' and d.codigo_dpto=l.departamento and d.gerencia = l.gerencia order by s.nome" ;


$re = mysql_query("SELECT COUNT(DISTINCT l.cpf) as total FROM lotacao   l,servidorrec s,gerencia g,cargo cg,funcao f,contrato c,departamento d WHERE l.lotado ='1' and l.cpf =s.cpf and l.gerencia = g.codigo  and  l.gerencia <> '' AND cg.cod_cargo = c.cargo AND f.cod_funcao = c.funcao and  c.cpf =l.cpf and c.cpf = s.cpf and  l.matricula='$pesqnomematadm' and d.codigo_dpto=l.departamento and d.gerencia = l.gerencia order by s.nome");
$total = mysql_result($re, 0, "total");
  }

else if ($tppresquisaadm=='2')
{
$sql = "SELECT distinct l.cpf,s.nome,s.endereco,s.bairro,g.descricao,cg.descricao as descricaocg,f.descricao as descricaof,d.descricao as descricaod FROM lotacao   l,servidorrec s,gerencia g,cargo cg,funcao f,contrato c,departamento d WHERE l.lotado ='1' and l.cpf =s.cpf and l.gerencia = g.codigo  and  l.gerencia <> '' AND cg.cod_cargo = c.cargo AND f.cod_funcao = c.funcao and  c.cpf =l.cpf and c.cpf = s.cpf and  s.nome like '$pesqnomematadm%' and d.codigo_dpto=l.departamento and d.gerencia = l.gerencia order by s.nome" ;


$re = mysql_query("select COUNT(DISTINCT l.cpf) as total FROM lotacao   l,servidorrec s,gerencia g,cargo cg,funcao f,contrato c,departamento d WHERE l.lotado ='1' and l.cpf =s.cpf and l.gerencia = g.codigo  and  l.gerencia <> '' AND cg.cod_cargo = c.cargo AND f.cod_funcao = c.funcao and  c.cpf =l.cpf and c.cpf = s.cpf and  s.nome like '$pesqnomematadm%' and d.codigo_dpto=l.departamento and d.gerencia = l.gerencia order by s.nome") ;
$total = mysql_result($re, 0, "total");
  }


else if ($tppresquisaadm=='3')
{

$sql = "SELECT distinct l.cpf,s.nome,s.endereco,s.bairro,g.descricao,cg.descricao as descricaocg,f.descricao as descricaof,d.descricao as descricaod FROM lotacao   l,servidorrec s,gerencia g,cargo cg,funcao f,contrato c,departamento d WHERE l.lotado ='1' and l.cpf =s.cpf and l.gerencia = g.codigo  and  l.gerencia <> '' AND cg.cod_cargo = c.cargo AND f.cod_funcao = c.funcao and  c.cpf =l.cpf and c.cpf = s.cpf and  l.cpf='$pesqnomematadm' and d.codigo_dpto=l.departamento and d.gerencia = l.gerencia order by s.nome" ;

$re = mysql_query("select COUNT(DISTINCT l.cpf) as total FROM lotacao   l,servidorrec s,gerencia g,cargo cg,funcao f,contrato c,departamento d WHERE l.lotado ='1' and l.cpf =s.cpf and l.gerencia = g.codigo  and  l.gerencia <> '' AND cg.cod_cargo = c.cargo AND f.cod_funcao = c.funcao and  c.cpf =l.cpf and c.cpf = s.cpf and  l.cpf='$pesqnomematadm' and d.codigo_dpto=l.departamento and d.gerencia = l.gerencia order by s.nome") ;
$total = mysql_result($re, 0, "total");
  }
}







$resposta = mysql_query( $sql ) or die(mysql_error());

$dia = date('d');
$mes = date('m');
$ano = date('Y');
 
$data =$dia.".".$mes.".".$ano;

if ($total==0) 
  { 
	echo "<html><head><title>Resposta !!!</title></head>";
	echo "<body background=\"background_mensagens.jpg\" style=\"background-attachment:fixed; background-repeat:no-repeat\">";
	echo "<br><br><br>";
	echo "<center><img src=\"faleconosco/atencao.gif\" alt=\"\"><p><font color=\"#ff6600\" face=\"Verdana\" size=\"4\">Banco Sem Informa��o!!!! <b></b></font></center>";
	echo "<br><br><center><a href=\"../formpesquisarec.php\"><img src=\"faleconosco/button_voltar2_.gif\" alt=\"Voltar\" border=\"0\" /></a></center>";
    echo "</body></html>";
   }
else
{

?><head>
<script language="javascript">
function DoPrinting() {
    if (!window.print) {
        alert("Netscape, Internet Explorer 4.0 ou superior!")
        return
    }
    window.print();
}
</script>
</head>




<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1" />
<title>:: Acompanhamento Recadastramento ::</title>
<style type="text/css">
<!--
.style1 {
	font-size: large;
	font-weight: bold;
}
.style2 {
	font-size: x-large;
	font-weight: bold;
}
.style3 {
	font-size: large;
	font-family: Verdana, Arial, Helvetica, sans-serif;
}
.style5 {font-family: Verdana, Arial, Helvetica, sans-serif}
.style6 {font-size: xx-large; font-weight: bold; font-family: Verdana, Arial, Helvetica, sans-serif; }
.style7 {font-size: x-large; font-weight: bold; font-family: Verdana, Arial, Helvetica, sans-serif; }
.style8 {font-size: large; font-weight: bold; font-family: Verdana, Arial, Helvetica, sans-serif; }
-->
</style>
</head>

<body>
<div align="left">


  <table width="100" border="1" cellpadding="0" cellspacing="0" bordercolor="#000000">
    <tr>
      <td colspan="9" rowspan="4"><table width="1000" border="0" cellpadding="0" cellspacing="0">
          <tr>
            <td width="120" class="style5"><div align="center"><img src="../img/logo_brazil.jpg" width="113" height="118" /></div></td>
            <td width="706" class="style5"><p align="center" class="style2">GOVERNO DO ESTADO DE ROND�NIA<br>
			SECRETARIA DE ESTADO DA EDUCA��O<br>
			GERENCIA RECURSOS HUMANOS</p>
              <p align="center" class="style2">N�CLEO DE APOIO AOS MUNIC�PIOS</p></td>
          </tr>
      </table></td>
      <td width="131" height="36" bgcolor="#CCCCCC"><div align="center" class="style3">Data </div></td>
    </tr>
    <tr>
      <td height="46"><div align="center" class="style3"><span class="style5"></span><span class="style5"><? echo $data ?></span></div></td>
    </tr>
    <tr>
      <td height="47" bgcolor="#CCCCCC"><div align="center" class="style3">GTI</div></td>
    </tr>
    <tr>
      <td height="38" class="style3"><div align="center"><? echo $nte ?></div></td>
    </tr>

<?
if ($opcao=="1")
{
 if ($lotacaoprof=="1")
 {
?>
    <tr>
      <td height="68" colspan="10" bgcolor="#999999"><div align="center" class="style7">Relat�rio de Servidores T�c Administrativo Por Escola<?echo $id?></div></td><br>
    </tr>
<?
}
else if($lotacaoprof=="2")
{
?>
    <tr>
      <td height="68" colspan="10" bgcolor="#999999"><div align="center" class="style7">Relat�rio de Servidores Professores Por Escola<?echo $id?></div></td><br>
    </tr>
<?
}
else if($lotacaoprof=="3")
{
?>

    <tr>
      <td height="68" colspan="10" bgcolor="#999999"><div align="center" class="style7">Relat�rio Anal�tico Professores <?echo $id?></div></td><br>
    </tr>

<?
}
else if($lotacaoprof=="4")
{
?>
    <tr>
      <td height="68" colspan="10" bgcolor="#999999"><div align="center" class="style7">Relat�rio Anal�tico T�cnico Administrativo <br>
<?echo $id?></div></td><br>
    </tr>

<?
}
else if($lotacaoprof=="5")
{
?>

    <tr>
      <td height="68" colspan="10" bgcolor="#999999"><div align="center" class="style7">Relat�rio Sint�tico de Professores  Por Escola <br>
<?echo $id?></div></td><br>
    </tr>

<?
}
else if($lotacaoprof=="6")
{
?>


    <tr>
      <td height="68" colspan="10" bgcolor="#999999"><div align="center" class="style7">Relat�rio Sint�tico de T�cnico Administrativo <br>
<?echo $id?></div></td><br>
    </tr>



<?
  }
?>



<?
if (($opcao=="1") || ($opcao=="2") ||($opcao=="4") ||($opcao=="5"))
{
 if ($lotacaoprof!="5")
{
?>

<tr>

 <td><font size="2"><b>CPF</b></td>
 <td><font size="2"><b>NOME</b></td>
 <td><font size="2"><b>INEP</b></td>
 <td><font size="2"><b>ESCOLA</b></td>
 <td><font size="2"><b>CH</b></td>
 <td><font size="2"><b>HABILITA�AO</b></td>
 <td><font size="2"><b>MATRICULA</b></td>
 <td><font size="2"><b>CARGO</b></td>
 <td><font size="2"><b>FUNCAO</b></td>
 <td><font size="2"><b>MUNICIPIO</b></td>
</tr>

<?
 }
else if ($lotacaoprof!="5") 
{
?>

<tr>
 <td><font size="2"><b>INEP</b></td>
 <td><font size="2"><b>Descricao</b></td>
 <td><font size="2"><b>Total de Servidores</b></td>
</tr>
<?
 }
}
else //if ($opcao=="1")
{

?>

<tr>
 <td><font size="2"><b>ALTERA</b></td>
 <td><font size="2"><b>CPF</b></td>
 <td><font size="2"><b>NOME</b></td>
 <td><font size="2"><b>GERENCIA</b></td>
 <td><font size="2"><b>DEPARTAMENTO</b></td>
 <td><font size="2"><b>CARGO</b></td>
 <td><font size="2"><b>FUNCAO</b></td>
</tr>
<?
 }
}

if ($opcao=="3")
{
?>
<tr>
  <td><font size="2"><b>CPF</b></td>
 <td><font size="2"><b>NOME</b></td>
 <td><font size="2"><b>LOTA��O</b></td>
 <td><font size="2"><b>FUNCAO</b></td>
</tr>
<?
}

while ($dado = mysql_fetch_array($resposta)) 
{
    $dtabertura    = date("d/m/Y",strtotime($dado["DTABERTURA"]));


if (($opcao=="1")  ||($opcao=="4"))
{
if ($lotacaoprof!="5")
  {
?>
<!-- colocando os dados em uma tabela -->
<tr>
	  <td><font size="2"><?echo  trim($dado["cpf"]);?></td>
      <td><font size="2"><?echo  trim($dado["nome"]);?></td> 	  
	  <td><font size="2"><?echo  trim($dado["inep"]);?></td>
 	  <td><font size="2"><?echo  trim($dado["descricaoe"]);?></td>
  	  <td><font size="2"><?echo  trim($dado["chlotacao"]);?></td>
	  <td align="center"><font size="2" ><?echo trim($dado["descricaoh"]);?></td>	  
 	  <td align="center"><font size="2" ><?echo trim($dado["matricula"]);?></td>	  
 	  <td align="center"><font size="2" ><?echo trim($dado["descricaocg"]);?></td>	  
 	  <td align="center"><font size="2" ><?echo $dado["descricaof"];?></td>	  
 	  <td align="center"><font size="2" ><?echo $dado["descricaom"];?></td>	  

</tr>
<?
  }
 else
  {
?> 
<tr>
	  <td><font size="2"><?echo  trim($dado["inep"]);?></td>
 	  <td><font size="2"><?echo  trim($dado["descricao"]);?></td>
 	  <td align="center"><font size="2" ><?echo $dado["total"];?></td>	  
</tr>
 
<?
   }
}
else
{
 if ($opcao=="3")
  {
?>
<tr>
   <td><font size="2"><?echo  trim($dado["cpf"]);?></td>
   <td><font size="2"><?echo  trim($dado["nome"]);?></td> 	  
   <td align="center"><font size="2" ><?echo trim($dado["descricaog"]);?></td>	  
   <td align="center"><font size="2" ><?echo $dado["descricaof"];?></td>	  
   <td align="center"><font size="2" ><?echo trim($dado["descricaod"]);?></td>	  	  


</tr>
<?
  }
else
  {
?>
<tr>
 <td align="center"><font size="2"><a href="../../busca_dados_recconsulta.php?cpf=<?echo $dado["cpf"];?>"><img src="../img/nota_fiscal.png" title="Permite Alterar Dados"></a>
	  <td><font size="2"><?echo  trim($dado["cpf"]);?></td>
      <td><font size="2"><?echo  trim($dado["nome"]);?></td> 	  
 	  <td align="center"><font size="2" ><?echo trim($dado["descricao"]);?></td>	  
 	  <td align="center"><font size="2" ><?echo trim($dado["descricaod"]);?></td>	  	  
 	  <td align="center"><font size="2" ><?echo trim($dado["descricaocg"]);?></td>	  
 	  <td align="center"><font size="2" ><?echo $dado["descricaof"];?></td>	  
</tr>
<?
   } 
} 

}

 }//while;


?>

</table>
  <script>
   cor_tabela("tabzebra");
 </script>

</div>
</div>
<?
if ($total>0)
{
?>


    </tr>
    <tr>
      <td height="47" bgcolor="#CCCCCC"><div align="center" class="style3">Total de Servidores <?echo $total;?></div></td>
    </tr>
    <tr>
<tr>

<td align="center">

<form>
  <input type="button"  value="Imprimir a p�gina"   onClick="DoPrinting()" />
</form>
</td>
</tr>
<?
}
?>

</body>
</html>
