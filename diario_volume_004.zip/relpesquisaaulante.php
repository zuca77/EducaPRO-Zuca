<? 
session_start();

if (isset($_SESSION["login_usuario"]))
  {
     $login =  $_SESSION["login_usuario"];
     $nte   =  $_SESSION["nivel_usuario"];
     $cpf    =  $_SESSION["cpf_usuario"];  
	 include ("../conexao_mysql.php");
     include ("../funcoes.php");
     echo  saudacoes()."   ". "$login" ."  -  ".$nte."  ".dataextenso();
  }
 else
  {
   	 header("Location: login.php");
  }  	 




$turno       = $_POST['turno'];
$disciplina  = $_POST['disciplina'];
$dtinicial   = $_POST['dtinicial'];
$dtfinal     = $_POST['dtfinal'];
$opcao       = $_POST['opcao'];
$dtinicial1  = $_POST['dtinicial'];
$dtfinal1    = $_POST['dtfinal'];
$tecnico     = $_POST['tecnico'];
$municipio   = $_POST['municipio'];

//-----------------------------------------------------

	 $data  = explode('/', $dtinicial);
	 $dtinicial = $data[2].'.'.$data[1].'.'.$data[0];

	 $data  = explode('/', $dtfinal);
	 $dtfinal = $data[2].'.'.$data[1].'.'.$data[0];



$sql = "select r.CODIGO,r.MUNICIPIO,r.NIVEL,r.TURNO,r.PROFESSOR,r.DISCIPLINA,r.DTAULA,e.DESCRICAO,r.TPAULA,m.DESCRICAO as MDESCRICAO from regaula r,escola e,municipio m where r.inep= e.inep and e.municipio=m.codigo and r.nte= '$nte' and r.dtaula >= '$dtinicial' and r.dtaula <= '$dtfinal' " ; 



if ($opcao=='1')
{
$re = mysql_query("select count(*) as total from regaula where  dtaula >= '$dtinicial' and  dtaula <= '$dtfinal' and nte = '$nte' and tpaula <> 'TVESCOLA'" );


}
else if ($opcao=='2')
{
   if ($turno=="TODOS")
     { 
	   $re = mysql_query("select count(*) as total from regaula where dtaula >= '$dtinicial' and dtaula <= '$dtfinal' and  nte = '$nte' and  inep ='$tecnico' and tpaula <> 'TVESCOLA'");
	}
    else 
      {
       $re = mysql_query("select count(*) as total from regaula where dtaula >= '$dtinicial' and dtaula <= '$dtfinal' and  nte = '$nte' and     turno = '$turno' and inep = '$tecnico' and tpaula <> 'TVESCOLA' and nte= '$nte'");
	 }
 }

else if ($opcao=='3')
{

$re = mysql_query("select count(*) as total from chamado where municipio = '$tecnico' and dtabertura >= '$dtinicial' and dtabertura <= '$dtfinal' and nte = '$nte' and municipio ='$municipio' and nte= '$nte'");
}

else if ($opcao=='4')
{
$re = mysql_query("select count(distinct(inep)) as total FROM regaula where  dtaula >= '$dtinicial' and dtaula <= '$dtfinal' and nte= '$nte'" );

}


else if ($opcao=='5')
{
   if ($turno=="TODOS")
     { 
	   $re = mysql_query("select count(*) as total from regaula where dtaula >= '$dtinicial' and dtaula <= '$dtfinal' and  nte = '$nte' and  professor ='$tecnico' and tpaula <> 'TVESCOLA'");
	}
    else 
      {
       $re = mysql_query("select count(*) as total from regaula where dtaula >= '$dtinicial' and dtaula <= '$dtfinal' and  nte = '$nte' and     turno = '$turno' and inep = '$tecnico' and tpaula <> 'TVESCOLA' and nte= '$nte'");
	 }
 }



$total = mysql_result($re, 0, "total");

if ($total==0) 
  { 
	echo "<html><head><title>Resposta !!!</title></head>";
	echo "<body background=\"background_mensagens.jpg\" style=\"background-attachment:fixed; background-repeat:no-repeat\">";
	echo "<br><br><br>";
	echo "<center><img src=\"faleconosco/atencao.gif\" alt=\"\"><p><font color=\"#ff6600\" face=\"Verdana\" size=\"4\">Banco Sem Informa��o!!!! <b></b></font></center>";
	echo "<br><br><center><a href=\"/formpesquisaaulante.php\"><img src=\"faleconosco/button_voltar2_.gif\" alt=\"Voltar\" border=\"0\" /></a></center>";
    echo "</body></html>";
   }


if ($opcao=='1')
 {
$sql = mysql_query("select r.CODIGO,r.MUNICIPIO,r.NIVEL,r.TURNO,r.NALUNOS,r.PROFESSOR,r.DISCIPLINA,r.DTAULA,r.TPAULA,e.DESCRICAO as EDESCRICAO,m.DESCRICAO as MDESCRICAO from regaula r,escola e,municipio m where r.inep= e.inep and e.municipio=m.codigo and r.nte= '$nte' and r.dtaula >= '$dtinicial' and r.dtaula <= '$dtfinal' and r.tpaula <> 'TVESCOLA' and r.nte= '$nte'"); 
$conta = mysql_num_rows($sql);
 }

else if ($opcao=='2')
 {
if ($turno=="TODOS") {
$sql = mysql_query("select r.CODIGO,r.MUNICIPIO,r.NIVEL,r.TURNO,r.PROFESSOR,r.DISCIPLINA,r.DTAULA,r.NALUNOS,r.TPAULA,e.DESCRICAO,e.DESCRICAO as EDESCRICAO,m.DESCRICAO as MDESCRICAO from regaula r,escola e,municipio m where r.inep= e.inep and e.municipio=m.codigo and r.dtaula >= '$dtinicial' and r.dtaula <= '$dtfinal' and  r.inep = '$tecnico' and r.tpaula <> 'TVESCOLA' and r.nte= '$nte'"); 
$conta = mysql_num_rows($sql);
   }
else 
   {
$sql = mysql_query("select r.CODIGO,r.MUNICIPIO,r.NIVEL,r.TURNO,r.PROFESSOR,r.DISCIPLINA,r.DTAULA,r.NALUNOS,r.TPAULA,e.DESCRICAO,e.DESCRICAO as EDESCRICAO,m.DESCRICAO as MDESCRICAO from regaula r,escola e,municipio m where r.inep= e.inep and e.municipio=m.codigo and r.dtaula >= '$dtinicial' and r.dtaula <= '$dtfinal' and  r.inep = '$tecnico' and r.tpaula <> 'TVESCOLA' and turno ='$turno' and r.nte= '$nte'"); 
$conta = mysql_num_rows($sql);
   }
 }
 
else if ($opcao=='3')
{
$sql = mysql_query("select r.CODIGO,r.MUNICIPIO,r.NIVEL,r.TURNO,r.PROFESSOR,r.DISCIPLINA,r.DTAULA,r.NALUNOS,r.TPAULA,e.DESCRICAO,e.DESCRICAO as EDESCRICAO,m.DESCRICAO as MDESCRICAO from regaula r,escola e,municipio m where r.inep= e.inep and e.municipio=m.codigo and e.municipio='$municipio' and r.dtaula >= '$dtinicial' and r.dtaula <= '$dtfinal' and  r.tpaula  <> 'TVESCOLA' and r.nte= '$nte'"); 
$conta = mysql_num_rows($sql);
}
else if ($opcao=='4')
{
$sql = mysql_query("select r.INEP,e.DESCRICAO,count(r.INEP) as TAULAS,m.DESCRICAO as MDESCRICAO from regaula r,escola e,municipio m where e.inep=r.inep  and e.municipio=m.codigo and (r.dtaula >= '$dtinicial' and r.dtaula <= '$dtfinal') and  r.tpaula  <> 'TVESCOLA' and r.nte= '$nte'  group by inep"); 
$conta = mysql_num_rows($sql);
}

else if ($opcao=='5')
 {
$sql = mysql_query("select  r.CODIGO,r.MUNICIPIO,r.NIVEL,r.TURNO,r.PROFESSOR,r.DISCIPLINA,r.DTAULA,r.NALUNOS,r.TPAULA,e.DESCRICAO,e.DESCRICAO as EDESCRICAO,m.DESCRICAO as MDESCRICAO from regaula r,escola e,municipio m where r.inep= e.inep and e.municipio=m.codigo and r.dtaula >= '$dtinicial' and r.dtaula <= '$dtfinal' and  r.PROFESSOR = '$tecnico' and r.tpaula <> 'TVESCOLA' and r.nte= '$nte'"); 
$conta = mysql_num_rows($sql);
 }




?><head>
<script language="javascript">
function DoPrinting() {
    if (!window.print) {
        alert("Netscape, Internet Explorer 4.0 ou superior!")
        return
    }
    window.print();
}
</script>
</head>


<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1" />
<title>:: Registro de Aula ::</title>
<style type="text/css">
<!--
.style1 {
	font-size: large;
	font-weight: bold;
}
.style2 {
	font-size: x-large;
	font-weight: bold;
}
.style3 {
	font-size: large;
	font-family: Verdana, Arial, Helvetica, sans-serif;
}
.style5 {font-family: Verdana, Arial, Helvetica, sans-serif}
.style6 {font-size: xx-large; font-weight: bold; font-family: Verdana, Arial, Helvetica, sans-serif; }
.style7 {font-size: x-large; font-weight: bold; font-family: Verdana, Arial, Helvetica, sans-serif; }
.style8 {font-size: large; font-weight: bold; font-family: Verdana, Arial, Helvetica, sans-serif; }
-->
</style>
</head>

<body>
<div align="left">


  <table width="988" border="1" cellpadding="0" cellspacing="0" bordercolor="#000000">
    <tr>
      <td colspan="8" rowspan="4"><table width="100%" border="0" cellpadding="0" cellspacing="0">
          <tr>
            <td width="120" class="style5"><div align="center"><img src="../img/logo_brazil.jpg" width="113" height="118" /></div></td>
            <td width="706" class="style5"><p align="center" class="style2">GOVERNO DO ESTADO DE ROND�NIA<br>
			SECRETARIA DE ESTADO DA EDUCA��O<br>
			GERENCIA DE PROJETOS ESPECIAIS</p>
              <p align="center" class="style2">PROGRAMA DE TECNOLOGIA EDUCACIONAL/RO  </p></td>
          </tr>
      </table></td>
      <td width="131" height="36" bgcolor="#CCCCCC"><div align="center" class="style3">Data </div></td>
    </tr>
    <tr>
      <td height="46"><div align="center" class="style3"><span class="style5"></span><span class="style5"><? echo $data ?></span></div></td>
    </tr>
    <tr>
      <td height="47" bgcolor="#CCCCCC"><div align="center" class="style3">NTE</div></td>
    </tr>
    <tr>
      <td height="38" class="style3"><div align="center"><? echo $nte ?></div></td>
    </tr>
    <tr>
      <td height="68" colspan="9" bgcolor="#999999"><div align="center" class="style7">Relat�rio Acompanhamento <?echo $dtinicial1?>
	  <?echo $dtfinal1?></div></td><br>
    </tr>

    <tr>
      <td height="49" colspan="9"><div align="left" class="style7"><span class="style8"><?echo $inep?><?echo $escola?><br>
        <?echo $municipio?><br>
    		
		</div></td>
    </tr>
    <tr>
      <td height="44" colspan="9"><div align="center" class="style7">
        <div align="center"></div>
      </div></td>
    </tr>

<? if ($opcao!='4') {   ?>
<tr>
 <td><font size="2"><b>Escola</b></td>
 <td><font size="2"><b>Municipio</b></td>
 <td><font size="2"><b>Disciplina</b></td>
 <td><font size="2"><b>N�vel</b></td>
 <td><font size="2"><b>Turno</b></td>
 <td><font size="2"><b>Professor</b></td>
 <td><font size="2"><b>Data</b></td>
 <td><font size="2"><b>Total</b></td>
 <td><font size="2"><b>Tipo Aula</b></td>
</tr>

<?
  }
else
 {
?>
 <tr>
 <td><font size="2"><b>Inep</b></td>
 <td><font size="2"><b>Escola</b></td>
 <td><font size="2"><b>Municipio</b></td>
 <td><font size="2"><b>Total de Aulas</b></td>
</tr>
<?
 }

while ($dado = mysql_fetch_array($sql)) 
  {
   $dtabertura    = date("d/m/Y",strtotime($dado["DTAULA"]));

if ($opcao!='4')
  {
?>
<!-- colocando os dados em uma tabela -->
<tr>
 	  <td><font size="2"><?echo  $dado["EDESCRICAO"];?></td>
 	  <td><font size="2"><?echo  $dado["MDESCRICAO"];?></td>
 	  <td><font size="2"><?echo  $dado["DISCIPLINA"];?></td>
	  <td align="center"><font size="2" ><?echo $dado["NIVEL"];?></td>
  	  <td align="center"><font size="2" ><?echo $dado["TURNO"];?></td>	  
      <td align="left"><font size="2" ><?echo $dado["PROFESSOR"];?></td>	  
	  <td align="center"><font size="2" ><?echo $dtabertura;?></td>	  
	  <td align="right"><font size="2" ><?echo $dado["NALUNOS"];?></td>	  
 	  <td align="left"><font size="2" ><?echo $dado["TPAULA"];?></td>	  
</tr>
<?
 }
 else
  {
?> 	  
<tr>	
	  <td><font size="2"><?echo  $dado["INEP"];?></td>
  	  <td><font size="2"><?echo  $dado["DESCRICAO"];?></td>
 	  <td><font size="2"><?echo  $dado["MDESCRICAO"];?></td>
	  <td align="right"><font size="2" ><?echo $dado["TAULAS"];?></td>	  
</tr>	  
<? 
     } 
 }
?>

</table>
  <script>
   cor_tabela("tabzebra");
 </script>

</div>
</div>

    </tr>
    <tr>
      <td height="47" bgcolor="#CCCCCC"><div align="center" class="style3">Total Aula(S) <?echo $total;?></div></td>
    </tr>
 
    <tr>
<tr>
<td align="center">
<form>
  <input type="button"  value="Imprimir a p�gina"   onClick="DoPrinting()" />
</form>
</td>
</tr>
</body>
</html>
