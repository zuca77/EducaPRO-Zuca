<?

include ("conexao_mysql.php");


$cpf	            = $_POST['cpf'];
$pis	            = $_POST['pis'];
$txtBairro          = $_POST['txtBairro'];

$txtDataEmissao     = $_POST['txtDataEmissao'];	
$txtEmail	        = $_POST['txtEmail'];	
$txtEndereco        = $_POST['txtEndereco'];


$txtFoneRes	        = $_POST['txtFoneRes'];
$txtFoneSetor       = $_POST['txtFoneSetor'];
$txtCelular         = $_POST['txtCelular'];	
$txtcontato         = $_POST['txtcontato'];


$txtNome            = $_POST['txtNome'];
$txtOrgaoExp        = $_POST['txtOrgaoExp'];
$txtRG              = $_POST['txtRG'];


$txtcep	            = $_POST['txtcep'];
$txtdtnascimento	= $_POST['txtdtnascimento'];
$txthabilitacao	    = $_POST['txthabilitacao'];
$txtinstrucao       = $_POST['txtinstrucao1'];
$txtmae             = $_POST['txtmae'];
$txtnr	            = $_POST['txtnr'];
$txtpai             = $_POST['txtpai'];
$txtsecao           = $_POST['txtsecao'];
$txtnr	            = $_POST['txtnr'];


$txtsecao           = $_POST['txtsecao'];
$txttdtte	        = $_POST['txttdtte'];
$txtte              = $_POST['txtte'];
$txtzona            = $_POST['txtzona'];


$selectsexo	        = $_POST['selectsexo'];
$txtdtnascimento	= $_POST['txtdtnascimento'];
$txtmae             = $_POST['txtmae'];
$txtnr	            = $_POST['txtnr'];
$txtpai             = $_POST['txtpai'];

$selectcivil        = $_POST['selectcivil'];

$cod_estado         = $_POST['cod_estado1'];
$cod_cidades        = $_POST['cod_cidades1'];


$txtconjuge          = $_POST['txtconjuge'];
$anoaposentadoria    = $_POST['anoaposentadoria1'];
$txtcomplemento      = $_POST['txtcomplemento'];

$tpservidor          =  $_POST['tpservidor'];
$selectqtdacontrato  =  $_POST['selectqtdacontrato'];

$txtnr               =  $_POST['txtnr'];
$txtBanco            =  $_POST['txtBanco'];
$txtAgencia          =  $_POST['txtAgencia'];
$txtConta            =  $_POST['txtConta'];



//         fonecontato       = '$txtcontato'





/*data*/
$diarg = substr($txtDataEmissao, 0,2);
$anorg = substr($txtDataEmissao, -4);
$mesrg = substr($txtDataEmissao, -7,2);
$txtDataEmissao=$anorg.".".$mesrg.".".$diarg;






$diarg1 = substr($txttdtte, 0,2);
$anorg1 = substr($txttdtte, -4);
$mesrg1 = substr($txttdtte, -7,2);
$txttdtte=$anorg1.".".$mesrg1.".".$diarg1;

$diarg = substr($txtdtnascimento, 0,2);
$anorg = substr($txtdtnascimento, -4);
$mesrg = substr($txtdtnascimento, -7,2);
$txtdtnascimento=$anorg.".".$mesrg.".".$diarg;






//echo "$dtemissaorg";
$dia = date('d');
$mes = date('m');
$ano = date('Y');
 
$data =$dia.".".$mes.".".$ano;



$sql="select * from servidorrec where cpf= '$cpf'";
$resultado=mysql_query($sql) or die (mysql_error());
$linhas=mysql_num_rows($resultado);
if ($linhas > 0)
{




$sql = "update servidorrec set 
		 pis         	='$pis',
		 rg           	='$txtRG',
		 orgaoexp     	='$txtOrgaoExp',
		 dtemissaorg  	='$txtDataEmissao',
		 cep			='$txtcep',
		 te				='$txtte',
		 zona			='$txtzona',
		 secao			='$txtsecao',

		 dtemissaote	='$txttdtte',
		
		 nome			='$txtNome',
		 estcivil		='$selectcivil',
		 dtnascimento	='$txtdtnascimento',
         sexo 			='$selectsexo',
		 conjuge		='$txtconjuge',
		 mae			='$txtmae',
		 pai			='$txtpai',


		 endereco		='$txtEndereco',
		 bairro			='$txtBairro',
		 fonesetor		='$txtFoneSetor',
		 email			='$txtEmail',
		 estado			='$cod_estado',
		 cidade			='$cod_cidades',

         celular            ='$txtCelular', 
		 grauinstrucao   	='$txtinstrucao',
		 preaposentadoria   ='$anoaposentadoria',
		 complemento	    ='$txtcomplemento',

		 ncontrato			='$selectqtdacontrato',
		 banco				='$txtBanco',
		 agencia			='$txtAgencia',
		 cc					='$txtConta',
		 numero				='$txtnr',
	     foneresidencial   = '$txtFoneRes'


         where cpf = '$cpf'";
         $qry = mysql_query($sql);


//+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++


         $sqlcontrato = " delete from contrato  where cpf=$cpf";
         $qrycontrato = mysql_query($sqlcontrato);

         $sqlcontrato = " delete from lotacao  where cpf=$cpf";
         $qrycontrato = mysql_query($sqlcontrato);


//Gravacao na base de contrato1
//**************************************************************
$txtMatricula1         = $_POST['txtMatricula1'];
$txtcod_cargo          = $_POST['txtcod_cargo'];
$cod_funcao0           = $_POST['cod_funcao0'];
$selectcontrato1       = $_POST['selectcontrato1'];
$txtdtadmissao1        = $_POST['txtdtadmissao1'];
$selectch1             = $_POST['selectch1'];
$txtdecreto1           = $_POST['txtdecreto1'];
$txtdtdecreto1         = $_POST['txtdtdecreto1'];
$txtdiario1            =  $_POST['txtdiario1'];
$txtdtdiario1          = $_POST['txtdtdiario1'];
$selectlotacao1        = $_POST['selectlotacao1'];
$txtcargo_comisionado  = $_POST['txtcargo_comisionado'];
$selectlicenca         = $_POST['selectlicenca'];
$selectcadm1           = $_POST['selectcadm1'];
$txtdpto              = $_POST['$txtdpto'];
$txthabilitacao	      = $_POST['txthabilitacao'];

$diarg = substr($txtdtadmissao1, 0,2);
$anorg = substr($txtdtadmissao1, -4);
$mesrg = substr($txtdtadmissao1, -7,2);
$txtdtadmissao1=$anorg.".".$mesrg.".".$diarg;



$diarg = substr($txtdtdecreto1, 0,2);
$anorg = substr($txtdtdecreto1, -4);
$mesrg = substr($txtdtdecreto1, -7,2);
$txtdtdecreto1=$anorg.".".$mesrg.".".$diarg;


$diarg = substr($txtdtdiario1, 0,2);
$anorg = substr($txtdtdiario1, -4);
$mesrg = substr($txtdtdiario1, -7,2);
$txtdtdiario1=$anorg.".".$mesrg.".".$diarg;


$sqlcontrato = "insert into contrato(cpf,matricula,cargo,funcao,regime,dtadmissao,chcontrato,decreto,dtdecreto,dof,dtdof,lotado,cds,licenca,orgaocedido,dpto,habilitacao) values ('$cpf','$txtMatricula1','$txtcod_cargo','$cod_funcao0','$selectcontrato1','$txtdtadmissao1','$selectch1','$txtdecreto1','$txtdtdecreto1','$txtdiario1','$txtdtdiario1','$selectlotacao1','$txtcargo_comisionado','$selectlicenca','$selectcadm1','$txtdpto','$txthabilitacao')";
$qrycontrato = mysql_query($sqlcontrato);


//***************************************************************
//Gravacao na base de contrato2
//**************************************************************

$txtMatricula2         = $_POST['txtMatricula2'];
$txtcod_cargo1         = $_POST['txtcod_cargo1'];
$cod_funcao1           = $_POST['cod_funcao1'];
$selectcontrato2       = $_POST['selectcontrato2'];
$txtdtadmissao2        = $_POST['txtdtadmissao2'];
$selectch2             = $_POST['selectch2'];
$txtdecreto2           = $_POST['txtdecreto2'];
$txtdtdecreto2         = $_POST['txtdtdecreto2'];
$txtdiario2            = $_POST['txtdiario2'];
$txtdtdiario2          = $_POST['txtdtdiario2'];
$selectlotacao2        = $_POST['selectlotacao2'];
$txtcargo_comisionado2 = $_POST['txtcargo_comisionado2'];
$selectlicenca         = $_POST['selectlicenca2'];
$selectcadm2           = $_POST['selectcadm2'];
$txtgerencia2          = $_POST['txtgerencia2'];
$selectcadm2           = $_POST['selectcadm2'];
$txtdpto1              = $_POST['txtdpto1'];

$diarg = substr($txtdtadmissao2, 0,2);
$anorg = substr($txtdtadmissao2, -4);
$mesrg = substr($txtdtadmissao2, -7,2);
$txtdtadmissao2=$anorg.".".$mesrg.".".$diarg;

$diarg = substr($txtdtdecreto2, 0,2);
$anorg = substr($txtdtdecreto2, -4);
$mesrg = substr($txtdtdecreto2, -7,2);
$txtdtdecreto2=$anorg.".".$mesrg.".".$diarg;

$diarg = substr($txtdtdiario2, 0,2);
$anorg = substr($txtdtdiario2, -4);
$mesrg = substr($txtdtdiario2, -7,2);
$txtdtdiario2=$anorg.".".$mesrg.".".$diarg;

$sqlcontrato = "insert into contrato(cpf,matricula,cargo,funcao,regime,dtadmissao,chcontrato,decreto,dtdecreto,dof,dtdof,lotado,cds,licenca,orgaocedido,dpto) values ('$cpf','$txtMatricula2','$txtcod_cargo1','$cod_funcao1','$selectcontrato2','$txtdtadmissao2','$selectch2','$txtdecreto2','$txtdtdecreto2','$txtdiario2','$txtdtdiario2','$selectlotacao2','$txtcargo_comisionado2','$selectlicenca2','$selectcadm2','$txtdpto1')";
$qrycontrato = mysql_query($sqlcontrato);

/******************Lotacao  ************************************/
//**************Lota��o*********************************************
//Lota��o dos Servidors  contrato - 1 
//*****************************************************************

$selectlotacao1 = $_POST['selectlotacao1'];
$selectch1lota = $_POST['selectch1lota'];
$txtdtlota11 = $_POST['txtdtlota11'];
$txtinep1 = $_POST['txtinep1']; 
$txtqdtaaulas1 = $_POST['txtqdtaaulas1']; 
$txtMatricula1 = $_POST['txtMatricula1']; 
$txtgerencia = $_POST['txtgerencia']; 
$txtdpto = $_POST['txtdpto']; 
$txtautacao1 = $_POST['txtautacao1']; 


$diarg = substr($txtdtlota11, 0,2);
$anorg = substr($txtdtlota11, -4);
$mesrg = substr($txtdtlota11, -7,2);
$txtdtlota11=$anorg.".".$mesrg.".".$diarg;

$sqllotacao1 = "insert into lotacao(cpf,matricula,lotado,gerencia,departamento,inep,dtlotacao,qtdaaula,areaatuacao,chlotacao) values ('$cpf','$txtMatricula1','$selectlotacao1','$txtgerencia','$txtdpto','$txtinep1','$txtdtlota11','$txtqdtaaulas1','$txtautacao1','$selectch1lota')";
$qrylotacao1 = mysql_query($sqllotacao1);



$selectch2lota   = $_POST['selectch2lota'];
$txtdtlota12     = $_POST['txtdtlota12'];
$txtinep2        = $_POST['txtinep2']; 
$txtqdtaaulas2   = $_POST['txtqdtaaulas2']; 
$txtautacao2     = $_POST['txtautacao2']; 


$diarg = substr($txtdtlota12, 0,2);
$anorg = substr($txtdtlota12, -4);
$mesrg = substr($txtdtlota12, -7,2);
$txtdtlota12=$anorg.".".$mesrg.".".$diarg;


$sqllotacao1 = "insert into lotacao(cpf,matricula,lotado,gerencia,departamento,inep,dtlotacao,qtdaaula,areaatuacao,chlotacao) values ('$cpf','$txtMatricula1','$selectlotacao1','$txtgerencia','$txtdpto','$txtinep2','$txtdtlota12','$txtqdtaaulas2','$txtautacao2','$selectch2lota')";

$qrylotacao1 = mysql_query($sqllotacao1);

//Lota��o dos Servidors  escola 3

$selectch3lota   = $_POST['selectch3lota'];
$txtdtlota13     = $_POST['txtdtlota13'];
$txtinep3        = $_POST['txtinep3']; 
$txtqdtaaulas3   = $_POST['txtqdtaaulas3']; 
$txtautacao3     = $_POST['txtautacao3']; 


$diarg = substr($txtdtlota13, 0,2);
$anorg = substr($txtdtlota13, -4);
$mesrg = substr($txtdtlota13, -7,2);
$txtdtlota13=$anorg.".".$mesrg.".".$diarg;


$sqllotacao1 = "insert into lotacao(cpf,matricula,lotado,gerencia,departamento,inep,dtlotacao,qtdaaula,areaatuacao,chlotacao) values ('$cpf','$txtMatricula1','$selectlotacao1','$txtgerencia','$txtdpto','$txtinep3','$txtdtlota13','$txtqdtaaulas3','$txtautacao3','$selectch3lota')";
$qrylotacao1 = mysql_query($sqllotacao1);

//Lota��o dos Servidors  escola 4

$selectch4lota   = $_POST['selectch4lota'];
$txtdtlota14     = $_POST['txtdtlota14'];
$txtinep4        = $_POST['txtinep4']; 
$txtqdtaaulas4   = $_POST['txtqdtaaulas4']; 
$txtautacao4     = $_POST['txtautacao4']; 


$diarg = substr($txtdtlota14, 0,2);
$anorg = substr($txtdtlota14, -4);
$mesrg = substr($txtdtlota14, -7,2);
$txtdtlota14=$anorg.".".$mesrg.".".$diarg;


$sqllotacao1 = "insert into lotacao(cpf,matricula,lotado,gerencia,departamento,inep,dtlotacao,qtdaaula,areaatuacao,chlotacao) values ('$cpf','$txtMatricula1','$selectlotacao1','$txtgerencia','$txtdpto','$txtinep4','$txtdtlota14','$txtqdtaaulas4','$txtautacao4','$selectch4lota')";
$qrylotacao1 = mysql_query($sqllotacao1);





//Lota��o dos Servidors  escola 5

$selectch5lota   = $_POST['selectch5lota'];
$txtdtlota15     = $_POST['txtdtlota15'];
$txtinep5        = $_POST['txtinep5']; 
$txtqdtaaulas5   = $_POST['txtqdtaaulas5']; 
$txtautacao5     = $_POST['txtautacao5']; 


$diarg = substr($txtdtlota15, 0,2);
$anorg = substr($txtdtlota15, -4);
$mesrg = substr($txtdtlota15, -7,2);
$txtdtlota15=$anorg.".".$mesrg.".".$diarg;


$sqllotacao1 = "insert into lotacao(cpf,matricula,lotado,gerencia,departamento,inep,dtlotacao,qtdaaula,areaatuacao,chlotacao) values ('$cpf','$txtMatricula1','$selectlotacao1','$txtgerencia','$txtdpto','$txtinep5','$txtdtlota15','$txtqdtaaulas5','$txtautacao5','$selectch5lota')";
$qrylotacao1 = mysql_query($sqllotacao1);

//**************Lota��o*********************************************
//          Fim Lotacao contrato 1 
//*****************************************************************

//**************Lota��o*********************************************
//          Lotacao contrato  2
//*****************************************************************
 

$txtdpto1		    = $_POST['txtdpto1'];  
$txtgerencia1		= $_POST['txtgerencia1']; 
$txtMatricula2      = $_POST['txtMatricula2']; 
$txtinep21          = $_POST['txtinep21']; 
$txtqdtaaulas21     = $_POST['txtqdtaaulas21'];
$selectchcontrato21 = $_POST['selectchcontrato21']; 
$txtautacao21       = $_POST['txtautacao21']; 
$selectlotacao2     = $_POST['selectlotacao2']; 
$txtdtlotacontr21   = $_POST['txtdtlotacontr21']; 


$diarg = substr($txtdtlotacontr21, 0,2);
$anorg = substr($txtdtlotacontr21, -4);
$mesrg = substr($txtdtlotacontr21, -7,2);
$txtdtlotacontr21=$anorg.".".$mesrg.".".$diarg;



$sqllotacao21 = "insert into lotacao(cpf,matricula,lotado,gerencia,departamento,inep,dtlotacao,qtdaaula,areaatuacao,chlotacao) values ('$cpf','$txtMatricula2','$selectlotacao2','$txtgerencia1','$txtdpto1','$txtinep21','$txtdtlotacontr21','$txtqdtaaulas21','$txtautacao21','$selectchcontrato21')";
$qrylotacao21 = mysql_query($sqllotacao21);



//escola2 contrato2


$selectchcontrato22     = $_POST['selectchcontrato22'];
$txtdtlotacontr22       = $_POST['txtdtlotacontr22'];
$txtinep22              = $_POST['txtinep22']; 
$txtqdtaaulas22         = $_POST['txtqdtaaulas22']; 
$txtautacao22           = $_POST['txtautacao22']; 


$diarg = substr($txtdtlotacontr22, 0,2);
$anorg = substr($txtdtlotacontr22, -4);
$mesrg = substr($txtdtlotacontr22, -7,2);
$txtdtlotacontr22=$anorg.".".$mesrg.".".$diarg;


$sqllotacao1 = "insert into lotacao(cpf,matricula,lotado,gerencia,departamento,inep,dtlotacao,qtdaaula,areaatuacao,chlotacao) values ('$cpf','$txtMatricula2','$selectlotacao1','$txtgerencia','$txtdpto','$txtinep22','$txtdtlotacontr22','$txtqdtaaulas22','$txtautacao22','$selectchcontrato22')";

$qrylotacao1 = mysql_query($sqllotacao1);

//Lota��o dos Servidors  escola 3

$selectchcontrato23     = $_POST['selectchcontrato23'];
$txtdtlotacontr23       = $_POST['txtdtlotacontr23'];
$txtinep23              = $_POST['txtinep23']; 
$txtqdtaaulas23         = $_POST['txtqdtaaulas23']; 
$txtautacao23           = $_POST['txtautacao23']; 


$diarg = substr($txtdtlotacontr23, 0,2);
$anorg = substr($txtdtlotacontr23, -4);
$mesrg = substr($txtdtlotacontr23, -7,2);
$txtdtlotacontr23=$anorg.".".$mesrg.".".$diarg;


$sqllotacao1 = "insert into lotacao(cpf,matricula,lotado,gerencia,departamento,inep,dtlotacao,qtdaaula,areaatuacao,chlotacao) values ('$cpf','$txtMatricula2','$selectlotacao1','$txtgerencia','$txtdpto','$txtinep23','$txtdtlotacontr23','$txtqdtaaulas23','$txtautacao23','$selectchcontrato23')";
$qrylotacao1 = mysql_query($sqllotacao1);

//Lota��o dos Servidors  escola 4

$selectchcontrato24     = $_POST['selectchcontrato24'];
$txtdtlotacontr24       = $_POST['txtdtlotacontr24'];
$txtinep24              = $_POST['txtinep24']; 
$txtqdtaaulas24         = $_POST['txtqdtaaulas24']; 
$txtautacao24           = $_POST['txtautacao24']; 


$diarg = substr($txtdtlotacontr24, 0,2);
$anorg = substr($txtdtlotacontr24, -4);
$mesrg = substr($txtdtlotacontr24, -7,2);
$txtdtlotacontr24=$anorg.".".$mesrg.".".$diarg;


$sqllotacao1 = "insert into lotacao(cpf,matricula,lotado,gerencia,departamento,inep,dtlotacao,qtdaaula,areaatuacao,chlotacao) values ('$cpf','$txtMatricula2','$selectlotacao1','$txtgerencia','$txtdpto','$txtinep24','$txtdtlotacontr24','$txtqdtaaulas23','$txtautacao24','$selectchcontrato24')";
$qrylotacao1 = mysql_query($sqllotacao1);





//Lota��o dos Servidors  escola 5

$selectchcontrato25     = $_POST['selectchcontrato25'];
$txtdtlotacontr25       = $_POST['txtdtlotacontr25'];
$txtinep25              = $_POST['txtinep25']; 
$txtqdtaaulas25         = $_POST['txtqdtaaulas25']; 
$txtautacao25           = $_POST['txtautacao25']; 


$diarg = substr($txtdtlotacontr25, 0,2);
$anorg = substr($txtdtlotacontr25, -4);
$mesrg = substr($txtdtlotacontr25, -7,2);
$txtdtlotacontr25=$anorg.".".$mesrg.".".$diarg;


$sqllotacao1 = "insert into lotacao(cpf,matricula,lotado,gerencia,departamento,inep,dtlotacao,qtdaaula,areaatuacao,chlotacao) values ('$cpf','$txtMatricula2','$selectlotacao1','$txtgerencia','$txtdpto','$txtinep25','$txtdtlotacontr25','$txtqdtaaulas25','$txtautacao25','$selectchcontrato25')";
$qrylotacao1 = mysql_query($sqllotacao1);

//**************Lota��o*********************************************
//         FIM  Lotacao contrato  2
//*****************************************************************
















mysql_close($conexao);

}
?>


<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<script language="javascript">
function DoPrinting() {
    if (!window.print) {
        alert("Netscape, Internet Explorer 4.0 ou superior!")
        return
    }
    window.print();
}
</script>

<head>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1" />
<title>:: Recadastramento Secret�ria de Educa��o do Estado de Rond�nia::</title>
<style type="text/css">
<!--
.style1 {
	font-size: large;
	font-weight: bold;
}
.style2 {
	font-size: x-large;
	font-weight: bold;
}
.style3 {
	font-size: large;
	font-family: Verdana, Arial, Helvetica, sans-serif;
}
.style5 {font-family: Verdana, Arial, Helvetica, sans-serif}
.style6 {font-size: xx-large; font-weight: bold; font-family: Verdana, Arial, Helvetica, sans-serif; }
.style7 {font-size: x-large; font-weight: bold; font-family: Verdana, Arial, Helvetica, sans-serif; }
.style8 {font-size: large; font-weight: bold; font-family: Verdana, Arial, Helvetica, sans-serif; }
-->
</style>
</head>

<body>
<div align="left">
  <table width="988" border="1" cellpadding="0" cellspacing="0" bordercolor="#000000">
    <tr>
      <td colspan="7" rowspan="4"><table width="100%" border="0" cellpadding="0" cellspacing="0">
          <tr>
            <td width="120" class="style5"><div align="center"><img src="../img/logo_brazil.jpg" width="113" height="118" /></div></td>
            <td width="706" class="style5"><p align="center" class="style2">GOVERNO DO ESTADO DE ROND�NIA<br>
			SECRETARIA DE ESTADO DA EDUCA��O<br>
			GERENCIA DE TECNOLIGIA DE INFORMA��O</p>
              <p align="center" class="style2">PROGRAMA DE TECNOLOGIA EDUCACIONAL/RO</p></td>
          </tr>
      </table></td>
      <td width="131" height="36" bgcolor="#CCCCCC"><div align="center" class="style3">CADASTRO</div></td>
    </tr>
    <tr>
      <td height="46"><div align="center" class="style3"><span class="style5"></span><span class="style5"><? echo $data ?></span></div></td>
    </tr>
    <tr>
      <td height="47" bgcolor="#CCCCCC"><div align="center" class="style3">GTI-NTE</div></td>
    </tr>
    <tr>
      <td height="38" class="style3"><div align="center"><? GTI-NTE ?></div></td>
    </tr>
    <tr>
      <td height="68" colspan="8" bgcolor="#999999"><div align="center" class="style7">Recadastramento dos Servidores da Educa��o<br/> Parab�ns Seus Dados Foram Alterados Com Sucesso</div></td><br/>

    </tr>

    <tr>
      <td height="49" colspan="8"><div align="left" class="style7"><span class="style8"><br />

		CPF:         <?echo  $cpf?><br>
	    Nome:        <?echo  $txtNome?><br>
		</div></td>
    </tr>


    <tr>
	</tr>
</div>

<tr>
<td align="center">
<form>
 <input type="button"  value="Imprimir a p�gina"   onClick="DoPrinting()" />

<center><img src=\"faleconosco/atencao.gif\"> <b></b></font></center>
<br><br><center><a href=\"index.php\"><img src=\"faleconosco/button_voltar2_.gif"/></a></center>
</form>
</td>
</tr>
</body>
</html>

<?
/*} 

else
{
echo "<html><head><title>Resposta !!!</title></head>";
echo "<body background=\"background_mensagens.jpg\" style=\"background-attachment:fixed; background-repeat:no-repeat\">";
echo "<br><br><br>";
echo "<center><img src=\"faleconosco/atencao.gif\" alt=\"\"><p><font color=\"#ff6600\" face=\"Verdana\" size=\"4\">Servidor seu recadastramento j� efetuado.!!!! <b></b></font></center>";
echo "<br><br><center><a href=\"index.php\"><img src=\"faleconosco/button_voltar2_.gif\" alt=\"Voltar\" border=\"0\" /></a></center>";
echo "</body></html>";

}

*/
?>























