<?php
require_once '../start.php';
$pdo = new Conexao;

$title = 'Inclus�o de servidor';

$sql = "SELECT codigo, descricao FROM grauinstrucao ORDER BY descricao";
$grauInstrucoes = $pdo->query($sql)->fetchAll();

$sql = "SELECT cod_estados, CONCAT(sigla, ' - ', nome) AS descricao FROM estados ORDER BY sigla";
$estados = $pdo->query($sql)->fetchAll();

$sql = "SELECT codigo, descricao FROM municipio;";
$municipios = $pdo->query($sql)->fetchAll();



?><!DOCTYPE HTML>
<html>
	<head>
		<?php require_once page_head(); ?>
	</head>
	<body>
		<?php require_once page_header(); ?>
		<div class="container">
			<form action="incluir_servidor.php" class="submit-wait" method="POST">

				<fieldset class="well well-sm">
					<legend>Dados pessoais</legend>

					<div class="row">
						<div class="col-md-2">
							<div class="form-group">
								<label for="cpf">CPF</label>
								<input type="text" id="cpf" name="cpf" class="form-control mask-cpf" autofocus placeholder="CPF" maxlength="11" required>
							</div>
						</div>
						<div class="col-md-8">
							<div class="form-group">
								<label for="nome">Nome completo</label> <small class="text-muted">(Sem abrevia��es)</small>
								<input type="text" id="nome" name="nome" class="form-control text-uppercase" placeholder="Nome completo" required>
							</div>
						</div>
						<div class="col-md-2">
							<div class="form-group">
								<label for="dtnascimento">Data de Nascimento</label>
								<input type="text" id="dtnascimento" name="dtnascimento" class="form-control mask-data" placeholder="Data de Nascimento" required>
							</div>
						</div>
					</div>

					<div class="row">
						<div class="col-md-2">
							<div class="form-group">
								<label for="sexo">Sexo</label>
								<select name="sexo" id="sexo" class="form-control" required>
									<option value=""></option>
    		         				<option value="F">FEMININO</option>
									<option value="M">MASCULINO</option>
								</select>
							</div>
						</div>
						<div class="col-md-2">
							<div class="form-group">
								<label for="estcivil">Estado Civil</label>
								<select id="estcivil" name="estcivil" class="form-control" required>
									  <option value=""></option>
				    		          <option value="CASADO">CASADO</option>
				    		          <option value="SOLTEIRO">SOLTEIRO</option>
				    		          <option value="VIUVO">VIUVO</option>
				    		          <option value="DESQUITADO">DESQUITADO</option>
				    		          <option value="DIVORCIADO">DIVORCIADO</option>
				    		          <option value="OUTROS">OUTROS</option>
				               	</select>
							</div>
						</div>
						<div class="col-md-2">
							<div class="form-group">
								<label for="pis">PIS / PASEP</label>
								<input type="text" id="pis" name="pis" class="form-control text-uppercase" placeholder="PIS / PASEP">
							</div>
						</div>
						<div class="col-md-2">
							<div class="form-group">
								<label for="rg">RG</label>
								<input type="text" id="rg" name="rg" class="form-control text-uppercase" placeholder="RG" required>
							</div>
						</div>
						<div class="col-md-2">
							<div class="form-group">
								<label for="orgaoexp">RG Emissor</label>
								<input type="text" id="orgaoexp" name="orgaoexp" class="form-control text-uppercase" placeholder="RG Emissor" required>
							</div>
						</div>
						<div class="col-md-2">
							<div class="form-group">
								<label for="dtemissaorg">RG Data Emiss�o</label>
								<input type="text" id="dtemissaorg" name="dtemissaorg" class="form-control mask-data" placeholder="RG Data Emiss�o" required>
							</div>
						</div>
					</div>

					<div class="row">
						<div class="col-md-2">
							<div class="form-group">
								<label for="te">T�tulo Eleitor</label>
								<input type="text" id="te" name="te" class="form-control text-uppercase" placeholder="T�tulo Eleitor" required>
							</div>
						</div>
						<div class="col-md-2">
							<div class="form-group">
								<label for="zona">Zona</label>
								<input type="text" id="zona" name="zona" class="form-control text-uppercase" placeholder="Zona" required>
							</div>
						</div>
						<div class="col-md-2">
							<div class="form-group">
								<label for="secao">Se��o</label>
								<input type="text" id="secao" name="secao" class="form-control text-uppercase" placeholder="Se��o" required>
							</div>
						</div>
						<div class="col-md-2">
							<div class="form-group">
								<label for="dtemissaote">Data de Emiss�o</label>
								<input type="text" id="dtemissaote" name="dtemissaote" class="form-control mask-data" placeholder="Data de Emiss�o" required>
							</div>
						</div>
						<div class="col-md-4">
							<div class="form-group">
								<label for="grauinstrucao">Grau de Instru��o</label>
								<select name="grauinstrucao" id="grauinstrucao" class="form-control chosen" required>
									<option value=""></option>
									<?php foreach ($grauInstrucoes as $grau): ?>
    		         				 <option value="<?php echo $grau['codigo'] ?>"><?php echo $grau['descricao'] ?></option>
									<?php endforeach ?>
								</select>
							</div>
						</div>
					</div>

					<div class="row">
						<div class="col-md-6">
							<div class="form-group">
								<label for="mae">Nome da m�e</label>
								<input type="text" id="mae" name="mae" class="form-control text-uppercase" placeholder="Nome da m�e" required>
							</div>
						</div>
						<div class="col-md-6">
							<div class="form-group">
								<label for="pai">Nome do pai</label>
								<input type="text" id="pai" name="pai" class="form-control text-uppercase" placeholder="Nome do pai">
							</div>
						</div>
					</div>

					<div class="row">
						<div class="col-md-5">
							<div class="form-group">
								<label for="conjuge">Nome do c�njuge</label>
								<input type="text" id="conjuge" name="conjuge" class="form-control text-uppercase" placeholder="Nome do c�njuge">
							</div>
						</div>
						<div class="col-md-3">
							<div class="form-group">
								<label for="estado">Estado Natural</label>
								<select name="estado" id="estado" class="form-control chosen-deselect">
									<option value=""></option>
									<?php foreach ($estados as $estado): ?>
    		         				<option value="<?php echo $estado['cod_estados'] ?>"><?php echo $estado['descricao'] ?></option>
									<?php endforeach ?>
								</select>
							</div>
						</div>
						<div class="col-md-4">
							<div class="form-group">
								<label for="cidade">Cidade Natural</label>
								<select name="cidade" id="cidade" class="form-control chosen-deselect">
									<option value=""></option>
								</select>
							</div>
						</div>
					</div>
				</fieldset>

				<fieldset class="well well-sm">
					<legend>Endere�o e contato</legend>

					<div class="row">
						<div class="col-md-6">
							<div class="form-group">
								<label for="endereco">Logradouro</label>
								<input type="text" class="form-control text-uppercase" name="endereco" id="endereco" placeholder="Logradouro" required>
							</div>
						</div>
						<div class="col-md-2">
							<div class="form-group">
								<label for="numero">N�mero</label>
								<input type="text" class="form-control" name="numero" id="numero" maxlength="10" required placeholder="N�mero">
							</div>
						</div>
						<div class="col-md-4">
							<div class="form-group">
								<label for="bairro">Bairro</label>
								<input type="text" class="form-control text-uppercase" name="bairro" id="bairro" required placeholder="Bairro">
							</div>
						</div>
					</div>

					<div class="row">
						<div class="col-md-2">
							<div class="form-group">
								<label for="cep">CEP</label>
	        			<input id="cep" name="cep" type="text" class="form-control" maxlength="8" required placeholder="CEP">
							</div>
						</div>
						<div class="col-md-4">
							<div class="form-group">
								<label for="complemento">Complemento</label>
								<input type="text" class="form-control text-uppercase" name="complemento" placeholder="Complemento" id="complemento">
							</div>
						</div>
						<div class="col-md-6">
							<div class="form-group">
								<label for="municipio">Munic�pio</label>
						  	<select name="municipio" id="municipio" class="form-control chosen" required>
								  <option value="">Selecione o munic�pio</option>
								  <?php foreach($municipios as $municipio): ?>
			            <option value="<?php echo $municipio['codigo']?>"><?php echo $municipio['descricao'];?><?php endforeach ?>
						   	</select>
							</div>
						</div>
					</div>

					<div class="row">
						<div class="col-md-2">
							<div class="form-group">
								<label for="fonesetor">Telefone Comercial</label>
								<input type="text" class="form-control mask-telefone" name="fonesetor" placeholder="Telefone Comercial" id="fonesetor"  maxlength="20">
							</div>
						</div>
						<div class="col-md-2">
							<div class="form-group">
								<label for="foneresidencial">Telefone Residencial</label>
								<input type="text" class="form-control mask-telefone" name="foneresidencial" placeholder="Telefone Residencial" id="foneresidencial" maxlength="20"/>
							</div>
						</div>
						<div class="col-md-2">
							<div class="form-group">
								<label for="celular">Telefone Celular</label>
								<input type="text" class="form-control mask-telefone" name="celular" placeholder="Telefone Celular" id="celular" maxlength="20"/>
							</div>
						</div>
						<div class="col-md-2">
							<div class="form-group">
								<label for="fonecontato">Telefone Contato</label>
								<input type="text" class="form-control mask-telefone" name="fonecontato" placeholder="Telefone Contato" id="fonecontato" maxlength="25" required>
							</div>
						</div>
						<div class="col-md-4">
							<div class="form-group">
								<label for="email">E-mail</label>
								<input type="email" class="form-control" name="email" placeholder="Email" id="email" maxlength="80" required>
							</div>
						</div>
					</div>
				</fieldset>

				<div class="row">
					<div class="col-md-6">
						<fieldset class="well well-sm">
							<legend>Dados banc�rios</legend>

							<div class="row">
								<div class="col-md-4">
									<div class="form-group">
									  <label for="banco">Banco</label>
									  <input type="text" class="form-control" name="banco" id="banco" maxlength="3">
									</div>
								</div>
								<div class="col-md-4">
									<div class="form-group">
									  <label for="agencia">Ag�ncia</label>
									  <input type="text" class="form-control" name="agencia" id="agencia" maxlength="10">
									</div>
								</div>
								<div class="col-md-4">
									<div class="form-group">
									  <label for="cc">Conta</label>
									  <input type="text" class="form-control" name="cc" id="cc" maxlength="20">
									</div>
								</div>
							</div>
						</fieldset>
					</div>
					<div class="col-md-6">
						<div class="form-group">
							<label for="observacao">Observa��es</label>
							<textarea name="observacao" id="observacao" class="form-control" rows="5"></textarea>
						</div>
					</div>
				</div>

				<div class="well well-sm">
					<button type="submit" class="btn btn-primary btn-submit-wait">SALVAR</button>
					<button type="button" class="btn btn-default btn-back pull-right">Voltar</button>
				</div>
			</form>
		</div>
		<?php require_once page_footer(); ?>

        <script>
		$(function() {
			$('#estado').on('change', function() {
				var estado = $(this).val();
				$.get('cidades.ajax.php', { cod_estado: estado })
					.success(function(cidades) {
						var options = '<option value=""></option>';
						for (key in cidades) {
							options += '<option value="' + cidades[key].cod_cidades + '">' + cidades[key].nome + '</option>';
						}
						$('#cidade').html(options).trigger('chosen:updated');
					})
					.error(function() {
						$('#cidade').html('<option value=""></option>').trigger('chosen:updated');
					});
			})
		});
		</script>
	</body>
</html>