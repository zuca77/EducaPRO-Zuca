<? 
session_start();

if (isset($_SESSION["login_usuario"]))
  {
     $login =  $_SESSION["login_usuario"];
     $nte   =  $_SESSION["nivel_usuario"];
     $inep      =  $_SESSION["inep_usuario"] ;
     $cpf              = $_SESSION["cpf_usuario"];   
  include ("../../conexao_mysql.php");
     include ("../../funcoes.php");
     echo  saudacoes()."   ". "$login" ."  -  ".$nte."  ".dataextenso()." ".$inep;
  }
 else
  {
    header("Location: ../../login.php");
  }  	 
     

     

if($_SERVER["REQUEST_METHOD"] == "POST")
{
  $selectturno        = $_POST['selectturno']; 
  $inep               = $_POST['cod_escola'];  
  $txtautacao1        = $_POST['txtautacao1'];  
  $selectexecercio   = $_POST['selectexecercio'];  
}




if ($inep=='')
  { 
	echo "<html><head><title>Resposta !!!</title></head>";
	echo "<body background=\"background_mensagens.jpg\" style=\"background-attachment:fixed; background-repeat:no-repeat\">";
	echo "<br><br><br>";
	echo "<center><img src=\"faleconosco/atencao.gif\" alt=\"\"><p><font color=\"#ff6600\" face=\"Verdana\" size=\"4\">Defina uma Escola de Acesso!! <b></b></font></center>";
	echo "<br><br><center><a href=\"../form_rel_lotacao.php\"><img src=\"faleconosco/button_voltar2_.gif\" alt=\"Voltar\" border=\"0\" /></a></center>";
    echo "</body></html>";
    exit;
   }


if (($selectexecercio== "") && ($selectturno=='') && ($txtautacao1==''))
{
	echo "<html><head><title>Resposta !!!</title></head>";
	echo "<body background=\"background_mensagens.jpg\" style=\"background-attachment:fixed; background-repeat:no-repeat\">";
	echo "<br><br><br>";
	echo "<center><img src=\"faleconosco/atencao.gif\" alt=\"\"><p><font color=\"#ff6600\" face=\"Verdana\" size=\"4\">Defina uma das op��es!! <b></b></font></center>";
	echo "<br><br><center><a href=\"../form_rel_lotacao.php\"><img src=\"faleconosco/button_voltar2_.gif\" alt=\"Voltar\" border=\"0\" /></a></center>";
    echo "</body></html>";
    exit;
   }





/*******************************Escola************************************/

$sqlgerencia = "select e.descricao as descricaoesc,m.descricao as descricaomuni from escola e , municipio m  where inep ='$inep' and e.municipio = m.codigo";
$resultadoger=mysql_query($sqlgerencia) or die (mysql_error());
$linhas   =mysql_num_rows($resultadoger);
if($linhas>0)
{
   while($pegar=mysql_fetch_array($resultadoger))
	{

    	$descescola    =$pegar["descricaoesc"];
    	$descmunici    =$pegar["descricaomuni"];

    }
 }




/* Servidores Adm Escola

$sql = "SELECT l.inep,e.descricao,s.cpf,s.nome,s.endereco,s.bairro,l.chlotacao,m.descricao as descricaom,cg.descricao as descricaocg,f.descricao as descricaof FROM lotacao
l,escola e,servidorrec s,municipio m,contrato c,cargo cg,funcao f WHERE l.lotado = '2' and l.inep <> '' and  l.inep = e.inep and l.cpf =s.cpf and e.municipio = m.codigo and c.cpf =l.cpf and c.cpf = s.cpf  and c.cargo > 1 and cg.cod_cargo = c.cargo and f.cod_funcao = c.funcao and l.inep='$inep' order by l.inep";


$re = mysql_query("select count(l.inep) as total FROM lotacao
l,escola e,servidorrec s,municipio m,contrato c,cargo cg,funcao f WHERE l.lotado = '2' and l.inep <> '' and  l.inep = e.inep and l.cpf =s.cpf and e.municipio = m.codigo and c.cpf =l.cpf and c.cpf = s.cpf  and c.cargo > 1 and cg.cod_cargo = c.cargo and f.cod_funcao = c.funcao and   l.inep='$inep'");
$total = mysql_result($re, 0, "total");
*/





/***********************Relatorio Escola Turno*******************************************************************************************************************************************************/
if (($selectturno=="D") && ($txtautacao1==''))
{

$sql = "SELECT distinct l.id,l.inep,l.m1,l.t1,l.n1,l.disciplina1,l.m2,l.t2,l.n2,l.disciplina2,l.m3,l.t3,l.n3,l.disciplina3,l.m4,l.t4,l.n4,l.disciplina4,l.qdtaaulas1m,l.qdtaaulas1t,l.qdtaaulas1n,l.qdtaaulas2m,l.qdtaaulas2t,l.qdtaaulas2n,l.qdtaaulas3m,l.qdtaaulas3t,l.qdtaaulas3n,l.qdtaaulas4m,l.qdtaaulas4t,l.qdtaaulas4n,(l.qdtaaulas1m + l.qdtaaulas1t +l.qdtaaulas1n + l.qdtaaulas2m + l.qdtaaulas2t + l.qdtaaulas2n + l.qdtaaulas3m+ l.qdtaaulas3t + l.qdtaaulas3n + l.qdtaaulas4m + l.qdtaaulas4t + l.qdtaaulas4n) as total,l.hextra,l.ambescola,e.descricao as descricaoe,s.cpf,s.nome,s.endereco,s.bairro,l.chlotacao,l.areaatuacao,h.descricao as descricaoh,m.descricao as descricaom,c.matricula,cg.descricao as descricaocg,f.descricao as descricaof ,li.descricao as situavervidor,rj.descricao as regimejurido FROM lotacao l,escola e,servidorrec s,habilitacao h,municipio m,contrato c,cargo cg,funcao f,licenca li ,regimejuridico rj  WHERE l.lotado ='2' and l.inep <> '' and l.inep = e.inep and l.cpf =s.cpf and l.areaatuacao = h.codigo and e.municipio = m.codigo and c.cpf = l.cpf and c.cpf =s.cpf  and cg.cod_cargo = c.cargo and
f.cod_funcao = c.funcao and l.inep='$inep'  and     cg.cod_cargo in(1,2) and ((dtsaida is null) or (dtsaida = 0000-00-00)) and li.id=l.situacao and c.regime=rj.id order by s.nome";

$re = mysql_query("select count(l.inep)-1 as total FROM lotacao l,escola e,servidorrec s,habilitacao h,municipio m,contrato c,cargo cg,funcao f,licenca li ,regimejuridico rj WHERE l.lotado ='2' and l.inep <> '' and l.inep = e.inep and l.cpf =s.cpf and l.areaatuacao = h.codigo and e.municipio = m.codigo and c.cpf = l.cpf and c.cpf =s.cpf  and cg.cod_cargo = c.cargo and
f.cod_funcao = c.funcao and l.inep='$inep' and  cg.cod_cargo in(1,2) and ((dtsaida is null) or (dtsaida = 0000-00-00)) and li.id=l.situacao and c.regime=rj.id ");
$total = mysql_result($re, 0, "total");
}
else if (($selectturno=="M"))
{
$sql = "SELECT distinct l.id,l.inep,l.m1,l.t1,l.n1,l.disciplina1,l.m2,l.t2,l.n2,l.disciplina2,l.m3,l.t3,l.n3,l.disciplina3,l.m4,l.t4,l.n4,l.disciplina4,l.qdtaaulas1m,l.qdtaaulas1t,l.qdtaaulas1n,l.qdtaaulas2m,l.qdtaaulas2t,l.qdtaaulas2n,l.qdtaaulas3m,l.qdtaaulas3t,l.qdtaaulas3n,l.qdtaaulas4m,l.qdtaaulas4t,l.qdtaaulas4n,(l.qdtaaulas1m + l.qdtaaulas1t +l.qdtaaulas1n + l.qdtaaulas2m + l.qdtaaulas2t + l.qdtaaulas2n + l.qdtaaulas3m+ l.qdtaaulas3t + l.qdtaaulas3n + l.qdtaaulas4m + l.qdtaaulas4t + l.qdtaaulas4n) as total,l.hextra,l.ambescola,e.descricao as descricaoe,s.cpf,s.nome,s.endereco,s.bairro,l.chlotacao,l.areaatuacao,h.descricao as descricaoh,m.descricao as descricaom,c.matricula,cg.descricao as descricaocg,f.descricao as descricaof,li.descricao as situavervidor,rj.descricao as regimejurido FROM lotacao l,escola e,servidorrec s,habilitacao h,municipio m,contrato c,cargo cg,funcao f,licenca li ,regimejuridico rj WHERE l.lotado ='2' and l.inep <> '' and l.inep = e.inep and l.cpf =s.cpf and l.areaatuacao = h.codigo and e.municipio = m.codigo and c.cpf = l.cpf and c.cpf =s.cpf  and cg.cod_cargo = c.cargo and
f.cod_funcao = c.funcao and l.inep='$inep' and ((l.m1='M') or (l.m2='M') or (l.m3='M') or (l.m4='M'))  and  cg.cod_cargo in(1,2) and ((dtsaida is null) or (dtsaida = 0000-00-00)) and li.id=l.situacao and c.regime=rj.id order by s.nome";

$re = mysql_query("select count(l.inep) as total FROM lotacao l,escola e,servidorrec s,habilitacao h,municipio m,contrato c,cargo cg,funcao f,licenca li ,regimejuridico rj WHERE l.lotado ='2' and l.inep <> '' and l.inep = e.inep and l.cpf =s.cpf and l.areaatuacao = h.codigo and e.municipio = m.codigo and c.cpf = l.cpf and c.cpf =s.cpf  and cg.cod_cargo = c.cargo and
f.cod_funcao = c.funcao and ((l.m1='M') or (l.m2='M') or (l.m3='M') or (l.m4='M'))  and l.inep='$inep' and  cg.cod_cargo in(1,2) and ((dtsaida is null) or (dtsaida = 0000-00-00)) and li.id=l.situacao and c.regime=rj.id");

$total = mysql_result($re, 0, "total");
$resposta = mysql_query( $sql ) or die(mysql_error());
}
else if (($selectturno=="T"))
{
$sql = "SELECT distinct l.id,l.inep,l.m1,l.t1,l.n1,l.disciplina1,l.m2,l.t2,l.n2,l.disciplina2,l.m3,l.t3,l.n3,l.disciplina3,l.m4,l.t4,l.n4,l.disciplina4,l.qdtaaulas1m,l.qdtaaulas1t,l.qdtaaulas1n,l.qdtaaulas2m,l.qdtaaulas2t,l.qdtaaulas2n,l.qdtaaulas3m,l.qdtaaulas3t,l.qdtaaulas3n,l.qdtaaulas4m,l.qdtaaulas4t,l.qdtaaulas4n,(l.qdtaaulas1m + l.qdtaaulas1t +l.qdtaaulas1n + l.qdtaaulas2m + l.qdtaaulas2t + l.qdtaaulas2n + l.qdtaaulas3m+ l.qdtaaulas3t + l.qdtaaulas3n + l.qdtaaulas4m + l.qdtaaulas4t + l.qdtaaulas4n) as total,l.hextra,l.ambescola,e.descricao as descricaoe,s.cpf,s.nome,s.endereco,s.bairro,l.chlotacao,l.areaatuacao,h.descricao as descricaoh,m.descricao as descricaom,c.matricula,cg.descricao as descricaocg,f.descricao as descricaof,li.descricao as situavervidor,rj.descricao as regimejurido FROM lotacao l,escola e,servidorrec s,habilitacao h,municipio m,contrato c,cargo cg,funcao f,licenca li ,regimejuridico rj WHERE l.lotado ='2' and l.inep <> '' and l.inep = e.inep and l.cpf =s.cpf and l.areaatuacao = h.codigo and e.municipio = m.codigo and c.cpf = l.cpf and c.cpf =s.cpf  and cg.cod_cargo = c.cargo and
f.cod_funcao = c.funcao and l.inep='$inep'  and ((l.t1='T') or (l.t2='T') or (l.t3='T') or (l.t4='T'))  and      cg.cod_cargo in(1,2) and ((dtsaida is null) or (dtsaida = 0000-00-00)) and li.id=l.situacao and c.regime=rj.id order by s.nome";

$re = mysql_query("select count(l.inep) as total FROM lotacao l,escola e,servidorrec s,habilitacao h,municipio m,contrato c,cargo cg,funcao f,licenca li ,regimejuridico rj WHERE l.lotado ='2' and l.inep <> '' and l.inep = e.inep and l.cpf =s.cpf and l.areaatuacao = h.codigo and e.municipio = m.codigo and c.cpf = l.cpf and c.cpf =s.cpf  and cg.cod_cargo = c.cargo and
f.cod_funcao = c.funcao and ((l.t1='T') or (l.t2='T') or (l.t3='T') or (l.t4='T'))  and l.inep='$inep' and  cg.cod_cargo in(1,2) and ((dtsaida is null) or (dtsaida = 0000-00-00)) and li.id=l.situacao and c.regime=rj.id ");
$total = mysql_result($re, 0, "total");
$resposta = mysql_query( $sql ) or die(mysql_error());
}
else if (($selectturno=="N"))
{
$sql = "SELECT distinct l.id,l.inep,l.m1,l.t1,l.n1,l.disciplina1,l.m2,l.t2,l.n2,l.disciplina2,l.m3,l.t3,l.n3,l.disciplina3,l.m4,l.t4,l.n4,l.disciplina4,l.qdtaaulas1m,l.qdtaaulas1t,l.qdtaaulas1n,l.qdtaaulas2m,l.qdtaaulas2t,l.qdtaaulas2n,l.qdtaaulas3m,l.qdtaaulas3t,l.qdtaaulas3n,l.qdtaaulas4m,l.qdtaaulas4t,l.qdtaaulas4n,(l.qdtaaulas1m + l.qdtaaulas1t +l.qdtaaulas1n + l.qdtaaulas2m + l.qdtaaulas2t + l.qdtaaulas2n + l.qdtaaulas3m+ l.qdtaaulas3t + l.qdtaaulas3n + l.qdtaaulas4m + l.qdtaaulas4t + l.qdtaaulas4n) as total,l.hextra,l.ambescola,e.descricao as descricaoe,s.cpf,s.nome,s.endereco,s.bairro,l.chlotacao,l.areaatuacao,h.descricao as descricaoh,m.descricao as descricaom,c.matricula,cg.descricao as descricaocg,f.descricao as descricaof,li.descricao as situavervidor,rj.descricao as regimejurido FROM lotacao l,escola e,servidorrec s,habilitacao h,municipio m,contrato c,cargo cg,funcao f,licenca li ,regimejuridico rj WHERE l.lotado ='2' and l.inep <> '' and l.inep = e.inep and l.cpf =s.cpf and l.areaatuacao = h.codigo and e.municipio = m.codigo and c.cpf = l.cpf and c.cpf =s.cpf  and cg.cod_cargo = c.cargo and
f.cod_funcao = c.funcao and l.inep='$inep'  and ((l.n1='N') or (l.n2='N') or (l.n3='N') or (l.n4='N'))  and      cg.cod_cargo in(1,2) and ((dtsaida is null) or (dtsaida = 0000-00-00)) and li.id=l.situacao and c.regime=rj.id order by s.nome";

$re = mysql_query("select count(l.inep) as total FROM lotacao l,escola e,servidorrec s,habilitacao h,municipio m,contrato c,cargo cg,funcao f,licenca li ,regimejuridico rj WHERE l.lotado ='2' and l.inep <> '' and l.inep = e.inep and l.cpf =s.cpf and l.areaatuacao = h.codigo and e.municipio = m.codigo and c.cpf = l.cpf and c.cpf =s.cpf  and cg.cod_cargo = c.cargo and
f.cod_funcao = c.funcao and l.inep='$inep' and ((l.n1='N') or (l.n2='N') or (l.n3='N') or (l.n4='N'))   and  cg.cod_cargo in(1,2) and ((dtsaida is null) or (dtsaida = 0000-00-00)) and li.id=l.situacao and c.regime=rj.id ");
$total = mysql_result($re, 0, "total");
$resposta = mysql_query( $sql ) or die(mysql_error());
}

/***********************Relatorio Escola Por Disciplina*******************************************************************************************************************************************************/

if (($txtautacao1!="") && ($selectturno==''))
{
  $sql = "SELECT distinct l.id,l.inep,l.m1,l.t1,l.n1,l.disciplina1,l.m2,l.t2,l.n2,l.disciplina2,l.m3,l.t3,l.n3,l.disciplina3,l.m4,l.t4,l.n4,l.disciplina4,l.qdtaaulas1m,l.qdtaaulas1t,l.qdtaaulas1n,l.qdtaaulas2m,l.qdtaaulas2t,l.qdtaaulas2n,l.qdtaaulas3m,l.qdtaaulas3t,l.qdtaaulas3n,l.qdtaaulas4m,l.qdtaaulas4t,l.qdtaaulas4n,(l.qdtaaulas1m + l.qdtaaulas1t +l.qdtaaulas1n + l.qdtaaulas2m + l.qdtaaulas2t + l.qdtaaulas2n + l.qdtaaulas3m+ l.qdtaaulas3t + l.qdtaaulas3n + l.qdtaaulas4m + l.qdtaaulas4t + l.qdtaaulas4n) as total,l.hextra,l.ambescola,e.descricao as descricaoe,s.cpf,s.nome,s.endereco,s.bairro,l.chlotacao,l.areaatuacao,h.descricao as descricaoh,m.descricao as descricaom,c.matricula,cg.descricao as descricaocg,f.descricao as descricaof,li.descricao as situavervidor,rj.descricao as regimejurido FROM lotacao l,escola e,servidorrec s,habilitacao h,municipio m,contrato c,cargo cg,funcao f,licenca li ,regimejuridico rj WHERE l.lotado ='2' and l.inep <> '' and l.inep = e.inep and l.cpf =s.cpf and l.areaatuacao = h.codigo and e.municipio = m.codigo and c.cpf = l.cpf and c.cpf =s.cpf  and cg.cod_cargo = c.cargo and
   f.cod_funcao = c.funcao and l.inep='$inep'  and  ((l.disciplina1 ='$txtautacao1') or (l.disciplina2 ='$txtautacao1') or (l.disciplina3 ='$txtautacao1') or (l.disciplina4 ='$txtautacao1'))    and     cg.cod_cargo in(1,2) and ((dtsaida is null) or (dtsaida = 0000-00-00)) and li.id=l.situacao and c.regime=rj.id order by s.nome";

   $re = mysql_query("select count(l.inep) as total FROM lotacao l,escola e,servidorrec s,habilitacao h,municipio m,contrato c,cargo cg,funcao f,licenca li ,regimejuridico rj WHERE l.lotado ='2' and l.inep <> '' and l.inep = e.inep and l.cpf =s.cpf and l.areaatuacao = h.codigo and e.municipio = m.codigo and c.cpf = l.cpf and c.cpf =s.cpf  and cg.cod_cargo = c.cargo and
   f.cod_funcao = c.funcao and l.inep='$inep' and  ((l.disciplina1 ='$txtautacao1') or (l.disciplina2 ='$txtautacao1') or (l.disciplina3 ='$txtautacao1') or (l.disciplina4 ='$txtautacao1'))         and  cg.cod_cargo in(1,2) and ((dtsaida is null) or (dtsaida = 0000-00-00)) and li.id=l.situacao and c.regime=rj.id");
   $total = mysql_result($re, 0, "total");
}


/***********************Relatorio Por AMbiente de lota��o*******************************************************************************************************************************************************/


if (($selectexecercio!= "") && ($selectturno=='') && ($txtautacao1==''))
{


  $sql = "SELECT distinct l.id,l.inep,l.m1,l.t1,l.n1,l.disciplina1,l.m2,l.t2,l.n2,l.disciplina2,l.m3,l.t3,l.n3,l.disciplina3,l.m4,l.t4,l.n4,l.disciplina4,l.qdtaaulas1m,l.qdtaaulas1t,l.qdtaaulas1n,l.qdtaaulas2m,l.qdtaaulas2t,l.qdtaaulas2n,l.qdtaaulas3m,l.qdtaaulas3t,l.qdtaaulas3n,l.qdtaaulas4m,l.qdtaaulas4t,l.qdtaaulas4n,(l.qdtaaulas1m + l.qdtaaulas1t +l.qdtaaulas1n + l.qdtaaulas2m + l.qdtaaulas2t + l.qdtaaulas2n + l.qdtaaulas3m+ l.qdtaaulas3t + l.qdtaaulas3n + l.qdtaaulas4m + l.qdtaaulas4t + l.qdtaaulas4n) as total,l.hextra,l.ambescola,e.descricao as descricaoe,s.cpf,s.nome,s.endereco,s.bairro,l.chlotacao,l.areaatuacao,h.descricao as descricaoh,m.descricao as descricaom,c.matricula,cg.descricao as descricaocg,f.descricao as descricaof,li.descricao as situavervidor,rj.descricao as regimejurido FROM lotacao l,escola e,servidorrec s,habilitacao h,municipio m,contrato c,cargo cg,funcao f,licenca li ,regimejuridico rj WHERE l.lotado ='2' and l.inep <> '' and l.inep = e.inep and l.cpf =s.cpf and l.areaatuacao = h.codigo and e.municipio = m.codigo and c.cpf = l.cpf and c.cpf =s.cpf  and cg.cod_cargo = c.cargo and
   f.cod_funcao = c.funcao and l.inep='$inep'  and  l.ambescola='$selectexecercio'    and     cg.cod_cargo in(1,2) and ((dtsaida is null) or (dtsaida = 0000-00-00)) and li.id=l.situacao and c.regime=rj.id order by s.nome";

   $re = mysql_query("select count(l.inep) as total FROM lotacao l,escola e,servidorrec s,habilitacao h,municipio m,contrato c,cargo cg,funcao f,licenca li ,regimejuridico rj WHERE l.lotado ='2' and l.inep <> '' and l.inep = e.inep and l.cpf =s.cpf and l.areaatuacao = h.codigo and e.municipio = m.codigo and c.cpf = l.cpf and c.cpf =s.cpf  and cg.cod_cargo = c.cargo and
   f.cod_funcao = c.funcao and l.inep='$inep' and  l.ambescola='$selectexecercio'  and  cg.cod_cargo in(1,2) and ((dtsaida is null) or (dtsaida = 0000-00-00)) and li.id=l.situacao and c.regime=rj.id");
   $total = mysql_result($re, 0, "total");
}

/***********************Fim Relatorio por AMBIENTE*******************************************************************************************************************************************************/

$resposta = mysql_query( $sql ) or die(mysql_error());


$dia = date('d');
$mes = date('m');
$ano = date('Y');
 
$data =$dia.".".$mes.".".$ano;

if ($total==0) 
  { 
	echo "<html><head><title>Resposta !!!</title></head>";
	echo "<body background=\"background_mensagens.jpg\" style=\"background-attachment:fixed; background-repeat:no-repeat\">";
	echo "<br><br><br>";
	echo "<center><img src=\"faleconosco/atencao.gif\" alt=\"\"><p><font color=\"#ff6600\" face=\"Verdana\" size=\"4\">Banco Sem Informa��o!!!! <b></b></font></center>";
	echo "<br><br><center><a href=\"../form_rel_lotacao.php\"><img src=\"faleconosco/button_voltar2_.gif\" alt=\"Voltar\" border=\"0\" /></a></center>";
    echo "</body></html>";
    exit;
   }

?>

<head>
<script language="javascript">
function DoPrinting()
{
    if (!window.print)
    {
        alert("Netscape, Internet Explorer 4.0 ou superior!")
        return
    }
    window.print();
}
</script>
</head>




<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1" />
<title>:: Escola Lota��o ::</title>
<style type="text/css">
</style>
</head>

<body>
	<form  name="form" class="form" action="insere_devolucao.php" method="POST">

<div align="left">


  <table width="100" border="1" cellpadding="0" cellspacing="0" bordercolor="#000000">
    <tr>
      <td colspan="40" rowspan="4"><table width="1000" border="0" cellpadding="0" cellspacing="0">
          <tr>
            <td width="120" class="style5"><div align="center"><img src="../img/logo_brazil.jpg" width="113" height="118" /></div></td>
            <td width="706" class="style5"><p align="center" class="style2">GOVERNO DO ESTADO DE ROND�NIA<br>
			SECRETARIA DE ESTADO DA EDUCA��O<br>
			GERENCIA RECURSOS HUMANOS</p>
              <p align="center" class="style2">N�CLEO DE APOIO AOS MUNIC�PIOS</p></td>
          </tr>
      </table></td>
      <td width="131" height="38" bgcolor="#CCCCCC"><div align="center" class="style3">Data </div></td>
    </tr>
    <tr>
      <td height="46"><div align="center" class="style3"><span class="style5"></span><span class="style5"><? echo $data ?></span></div></td>
    </tr>
    <tr>
      <td height="47" bgcolor="#CCCCCC"><div align="center" class="style3">GTI</div></td>
    </tr>
    <tr>
      <td height="38" class="style3"><div align="center"><? echo $nte ?></div></td>
    </tr>

    <tr>
      <td height="68" colspan="41" bgcolor="#999999"><div align="center" class="style7">Relat�rio Ajuste de Quadro Escola -  <?echo $inep." - ". $descescola." - ".$descmunici?> </div></td><br>
    </tr>

<tr>
 <td><font size="2"><b>Enquadramento</b></td>
 <td><font size="2"><b>CPF</b></td>
 <td><font size="2"><b>NOME</b></td>
 <td><font size="2"><b>CH</b></td>
 <td><font size="2"><b>HABILITA�AO</b></td>
 <td><font size="2"><b>MATRICULA</b></td>
 <td><font size="2"><b>FUN��O</b></td>
 <td><font size="2"><b>CARGO</b></td>

 <td><font size="2"><b>Disciplina1</b></td>
 <td><font size="2"><b>M</b></td>
 <td><font size="2"><b>Qtda</b></td>
 <td><font size="2"><b>T</b></td>
 <td><font size="2"><b>Qtda</b></td>
 <td><font size="2"><b>N</b></td>
 <td><font size="2"><b>Qtda</b></td>


 <td><font size="2"><b>Disciplina2</b></td>
 <td><font size="2"><b>M</b></td>
 <td><font size="2"><b>Qtda</b></td>
 <td><font size="2"><b>T</b></td>
 <td><font size="2"><b>Qtda</b></td>
 <td><font size="2"><b>N</b></td>
 <td><font size="2"><b>Qtda</b></td>


 <td><font size="2"><b>Disciplina3</b></td>
 <td><font size="2"><b>M</b></td>
 <td><font size="2"><b>Qtda</b></td>

 <td><font size="2"><b>T</b></td>
 <td><font size="2"><b>Qtda</b></td>
 <td><font size="2"><b>N</b></td>
 <td><font size="2"><b>Qtda</b></td>


 <td><font size="2"><b>Disciplina4</b></td>
 <td><font size="2"><b>M</b></td>
 <td><font size="2"><b>Qtda</b></td>
 <td><font size="2"><b>T</b></td>
 <td><font size="2"><b>Qtda</b></td>
 <td><font size="2"><b>N</b></td>
 <td><font size="2"><b>Qtda</b></td>
 <td><font size="2"><b>Total</b></td>
 <td><font size="2"><b>H.E</b></td>
 <td><font size="2"><b>Ambiente</b></td>
 <td><font size="2"><b>Situa��o</b></td>
 <td><font size="2"><b>Regime</b></td>






</tr>



<?
$conta=1;
while ($dado = mysql_fetch_array($resposta)) 
{
    $dtabertura    = date("d/m/Y",strtotime($dado["DTABERTURA"]));
                       $disciplina1  =$dado["disciplina1"];
                       $disciplina2  =$dado["disciplina2"];
                       $disciplina3  =$dado["disciplina3"];
                       $disciplina4  =$dado["disciplina4"];
                       $ambescola    =$dado["ambescola"];

?>
<tr>


         <td align="center"><font size="2"><a href="../form_dados_lotacao_escola.php?codigo=<?echo $dado["id"];?>"><img src="../img/cad_usuario.png" title="Distribui��o de Aulas e Disciplinas."></a>
         <td><font size="2"><?echo  trim($dado["cpf"]);?></td>
         <td><font size="2"><?echo  trim($dado["nome"]);?></td> 	  
  	  <td><font size="2"><?echo  trim($dado["chlotacao"]);?></td>
	  <td align="center"><font size="2" ><?echo trim($dado["descricaoh"]);?></td>	  
 	  <td align="center"><font size="2" ><?echo trim($dado["matricula"]);?></td>	  
 	  <td align="center"><font size="2" ><?echo trim($dado["descricaocg"]);?></td>	  
 	  <td align="center"><font size="2" ><?echo $dado["descricaof"];?></td>	  
 	  
<?


    $sqlgerencia = "SELECT id, descricao FROM ambienteescola where id='$ambescola'";
    $resultadoger=mysql_query($sqlgerencia) or die (mysql_error());
    $linhas   =mysql_num_rows($resultadoger);
	if($linhas>0)
	{
	   while($pegar=mysql_fetch_array($resultadoger))
		{
    	      $ambescola    =$pegar["descricao"];
	   }
       }





    $sqlgerencia = "SELECT codigo, descricao FROM habilitacao where codigo='$disciplina1'";
    $resultadoger=mysql_query($sqlgerencia) or die (mysql_error());
    $linhas   =mysql_num_rows($resultadoger);
	if($linhas>0)
	{
	   while($pegar=mysql_fetch_array($resultadoger))
		{
    	      $disciplina1    =$pegar["descricao"]; 	
	   }
       }	


    $sqlgerencia = "SELECT codigo, descricao FROM habilitacao where codigo='$disciplina2'";
    $resultadoger=mysql_query($sqlgerencia) or die (mysql_error());
    $linhas   =mysql_num_rows($resultadoger);
	if($linhas>0)
	{
	   while($pegar=mysql_fetch_array($resultadoger))
		{
    	      $disciplina2    =$pegar["descricao"]; 	
	   }
       }	


    $sqlgerencia = "SELECT codigo, descricao FROM habilitacao where codigo='$disciplina3'";
    $resultadoger=mysql_query($sqlgerencia) or die (mysql_error());
    $linhas   =mysql_num_rows($resultadoger);
	if($linhas>0)
	{
	   while($pegar=mysql_fetch_array($resultadoger))
		{
    	      $disciplina3    =$pegar["descricao"]; 	
	   }
       }	


    $sqlgerencia = "SELECT codigo, descricao FROM habilitacao where codigo='$disciplina4'";
    $resultadoger=mysql_query($sqlgerencia) or die (mysql_error());
    $linhas   =mysql_num_rows($resultadoger);
	if($linhas>0)
	{
	   while($pegar=mysql_fetch_array($resultadoger))
		{
    	      $disciplina4    =$pegar["descricao"]; 	
	   }
       }	








?>


 	  <td align="center"><font size="2" ><?echo $disciplina1;?></td>
 	  <td align="center"><font size="2" ><?echo $dado["m1"];?></td>
	  <td align="center"><font size="2" ><?echo $dado["qdtaaulas1m"];?></td>
 	  <td align="center"><font size="2" ><?echo $dado["t1"];?></td>
	  <td align="center"><font size="2" ><?echo $dado["qdtaaulas1t"];?></td>
         <td align="center"><font size="2" ><?echo $dado["n1"];?></td>
	  <td align="center"><font size="2" ><?echo $dado["qdtaaulas1n"];?></td>


 	  <td align="center"><font size="2" ><?echo $disciplina2;?></td>
 	  <td align="center"><font size="2" ><?echo $dado["m2"];?></td>
	  <td align="center"><font size="2" ><?echo $dado["qdtaaulas2m"];?></td>
 	  <td align="center"><font size="2" ><?echo $dado["t2"];?></td>
	  <td align="center"><font size="2" ><?echo $dado["qdtaaulas2t"];?></td>
         <td align="center"><font size="2" ><?echo $dado["n2"];?></td>
	  <td align="center"><font size="2" ><?echo $dado["qdtaaulas2n"];?></td>




 	  <td align="center"><font size="2" ><?echo $disciplina3;?></td>
 	  <td align="center"><font size="2" ><?echo $dado["m3"];?></td>
         <td align="center"><font size="2" ><?echo $dado["qdtaaulas3t"];?></td>
         <td align="center"><font size="2" ><?echo $dado["t3"];?></td>
         <td align="center"><font size="2" ><?echo $dado["qdtaaulas3t"];?></td>
         <td align="center"><font size="2" ><?echo $dado["n3"];?></td>
         <td align="center"><font size="2" ><?echo $dado["qdtaaulas3t"];?></td>


 	     <td align="center"><font size="2" ><?echo $disciplina4;?></td>
 	     <td align="center"><font size="2" ><?echo $dado["m4"];?></td>
	     <td align="center"><font size="2" ><?echo $dado["qdtaaulas4t"];?></td>
 	     <td align="center"><font size="2" ><?echo $dado["t4"];?></td>
         <td align="center"><font size="2" ><?echo $dado["qdtaaulas4t"];?></td>
         <td align="center"><font size="2" ><?echo $dado["n4"];?></td>
         <td align="center"><font size="2" ><?echo $dado["qdtaaulas4t"];?></td>

         <td align="center"><font size="2" ><?echo $dado["total"];?></td>
         <td align="center"><font size="2" ><?echo $dado["hextra"];?></td>
         <td align="center"><font size="2" ><?echo $ambescola;?></td>
         <td align="center"><font size="2" ><?echo $dado["situavervidor"];?></td>
         <td align="center"><font size="2" ><?echo $dado["regimejurido"];?></td>






</tr>

<?
 $conta++;  }//while


?>

</table>
  <script>
   cor_tabela("tabzebra");
 </script>

</div>
</div>
<?
if ($total>0)
{
?>


    </tr>
    <tr>
      <td height="47" bgcolor="#CCCCCC"><div align="center" class="style3">Total de Servidores <?echo $total;?></div></td>
    </tr>
    <tr>
<tr>

<td align="center">

<form>

 <input type="button" value=" Voltar " onclick="location.href='../form_rel_lotacao.php';">
 <input type="button"  value="Imprimir a p�gina"   onClick="DoPrinting()" />
</form>
</td>
</tr>
<?
}
?>

</body>
</html>
