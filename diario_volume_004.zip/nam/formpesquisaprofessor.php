<?php
require_once '../start.php';
$pdo = new Conexao;

$title = 'Lota��o de Professores';
//error_reporting(E_ALL);
//ini_set('display_errors', TRUE);
//ini_set('display_startup_errors', TRUE);

function nomeDisciplina($id) {
  $pdo = new Conexao;
  $sql = "SELECT descricao FROM habilitacao where codigo='{$id}';";
  return $pdo->query($sql)->fetchColumn();
}

$sql = "SELECT * FROM habilitacao";
$habilitacoes = $pdo->query($sql)->fetchAll();

$sql = "SELECT codigo, descricao FROM municipio;";
$municipios = $pdo->query($sql)->fetchAll();

$sql = "SELECT inep, descricao FROM escola;";
$escolas = $pdo->query($sql)->fetchAll();

$sql = "SELECT id, descricao FROM ambienteescola;";
$ambientes = $pdo->query($sql)->fetchAll();

$sql = "SELECT cod_funcao, descricao, cod_cargo FROM funcao;";
$funcoes = $pdo->query($sql)->fetchAll();

if(isset($_GET['cpfs']))
{
    $consultas = preg_split("/\s+/", $_GET['cpfs']);
  
    $disciplinas = "SELECT l.id, l.disciplina1, l.disciplina2, l.disciplina3, l.disciplina4 ";

    $resultados = "SELECT l.id, a.descricao AS descambescola, l.inep,e.descricao as nomeescola,m.descricao as municipio, l.m1,l.t1,l.n1,l.disciplina1,l.m2,l.t2,l.n2,l.disciplina2,l.m3,l.t3,l.n3,l.disciplina3,l.m4,l.t4,l.n4,l.disciplina4,l.qdtaaulas1m,l.qdtaaulas1t,l.qdtaaulas1n,l.qdtaaulas2m,l.qdtaaulas2t,l.qdtaaulas2n,l.qdtaaulas3m,l.qdtaaulas3t,l.qdtaaulas3n,l.qdtaaulas4m,l.qdtaaulas4t,l.qdtaaulas4n,(l.qdtaaulas1m + l.qdtaaulas1t +l.qdtaaulas1n + l.qdtaaulas2m + l.qdtaaulas2t + l.qdtaaulas2n + l.qdtaaulas3m+ l.qdtaaulas3t + l.qdtaaulas3n + l.qdtaaulas4m + l.qdtaaulas4t + l.qdtaaulas4n) as total,l.hextra,l.ambescola,e.descricao as descricaoe,s.cpf,s.nome,s.endereco,s.bairro,l.chlotacao,l.areaatuacao,h.descricao as descricaoh,c.matricula,cg.descricao as descricaocg,f.descricao as descricaof ";

    $sql ="FROM lotacao l
          JOIN escola e ON l.inep = e.inep
          JOIN municipio m ON m.codigo = e.municipio
          JOIN servidorrec s ON l.cpf = s.cpf
          JOIN contrato c ON c.cpf = l.cpf
          JOIN cargo cg ON cg.cod_cargo = c.cargo
          JOIN funcao f ON f.cod_funcao = c.funcao
          JOIN ambienteescola a ON a.id = l.ambescola
          JOIN habilitacao h ON h.codigo = l.areaatuacao
        WHERE l.lotado = '2' ";
    
    if(!empty($consultas)) 
    {
        $sql.= "AND (";
        $i = 0;
        foreach($consultas as $consulta)
        {
            if($i == 0) {
                $sql.= " l.cpf = '{$consulta}'";
                $i++;                
            }
            else {
                $sql.= " OR l.cpf = '{$consulta}'";
            }
        }
        $sql.=") ";
    }

    $sql.= " AND (cg.cod_cargo IN (1,2) OR (cg.cod_cargo = 6 AND f.cod_funcao = 77))
        AND ((l.dtsaida IS NULL) OR (l.dtsaida = '0000-00-00') OR (dtsaida = '1969-12-31'))
        GROUP BY l.id 
        ORDER BY s.nome";
    
    $resultados = $resultados.$sql;
    $sth = $pdo->prepare($resultados);
    if (!empty($consulta)) $sth->bindParam(':consulta', $consulta);
    $resultados = $sth->execute() ? $sth->fetchAll() : array();

    $sqlDisciplinas = $disciplinas.$sql;
    $sthDisciplinas = $pdo->prepare($sqlDisciplinas);
    if (!empty($consulta)) $sthDisciplinas->bindParam(':consulta', $consulta);
    $disciplinas = $sthDisciplinas->execute() ? $sthDisciplinas->fetchAll() : array();

    // $grafico = new Grafico;
    // $sets = json_encode($grafico->vennHabilitacaoProfessores($disciplinas));

}

if(isset($_GET['habilitacao']) || isset($_GET['disciplina']) || isset($_GET['municipio']) || isset($_GET['escola']) || isset($_GET['ambiente']) || isset($_GET['funcao']))
{
    $habilitacao = isset($_GET['habilitacao']) ? $_GET['habilitacao'] : null;
    $disciplina = isset($_GET['disciplina']) ? $_GET['disciplina'] : null;
    $municipio = isset($_GET['municipio']) ? $_GET['municipio'] : null;
    $funcao = isset($_GET['funcao']) ? $_GET['funcao'] : null;
    $ambiente = isset($_GET['ambiente']) ? $_GET['ambiente'] : null;
    $escola = isset($_GET['escola']) ? $_GET['escola'] : null;
  
    $disciplinas = "SELECT l.id, l.disciplina1, l.disciplina2, l.disciplina3, l.disciplina4 ";

    $resultados = "SELECT l.id, a.descricao AS descambescola, l.inep,e.descricao as nomeescola, m.descricao as municipio, l.disciplina1,l.disciplina2,l.disciplina3,l.disciplina4,l.ambescola,e.descricao as descricaoe,s.cpf,s.nome,s.endereco,s.bairro,l.chlotacao,l.areaatuacao,h.codigo, h.descricao as descricaoh,c.matricula,cg.descricao as descricaocg,f.descricao as descricaof ";

    $contagem = "SELECT DISTINCT l.cpf ";

    $sql = "FROM lotacao l
          JOIN escola e ON l.inep = e.inep
          JOIN municipio m ON m.codigo = e.municipio
          JOIN servidorrec s ON l.cpf = s.cpf
          JOIN contrato c ON c.cpf = l.cpf
          JOIN cargo cg ON cg.cod_cargo = c.cargo
          JOIN funcao f ON f.cod_funcao = c.funcao
          JOIN ambienteescola a ON a.id = l.ambescola
          JOIN habilitacao h ON h.codigo = l.areaatuacao
        WHERE l.lotado = '2' ";
    
    if(!empty($habilitacao)) 
    {
        $sql.= "AND h.codigo = '{$habilitacao}'";
    }

    if(!empty($municipio)) 
    {
        $sql.= "AND m.codigo = '{$municipio}'";
    }

    if(!empty($ambiente)) 
    {
        $sql.= "AND l.ambescola = '{$ambiente}'";
    }

    if(!empty($funcao)) 
    {
        $sql.= "AND f.cod_funcao = '{$funcao}'";
    }

    if(!empty($escola)) 
    {
        $sql.= "AND l.inep = '{$escola}'";
    }

    if(!empty($disciplina)) 
    {
        $sql.= "AND (l.disciplina1 = '{$disciplina}' 
                OR l.disciplina2 = '{$disciplina}'
                OR l.disciplina3 = '{$disciplina}'
                OR l.disciplina4 = '{$disciplina}') ";
    }

    $sql.= " AND (cg.cod_cargo IN (1,2) OR (cg.cod_cargo = 6 AND f.cod_funcao = 77))
        AND ((l.dtsaida IS NULL) OR (l.dtsaida = '0000-00-00') OR (dtsaida = '1969-12-31'))
        GROUP BY l.id
        ORDER BY s.nome";

    $resultados = $resultados.$sql;
    $sth = $pdo->prepare($resultados);
    if (!empty($consulta)) $sth->bindParam(':consulta', $consulta);
    $resultados = $sth->execute() ? $sth->fetchAll() : array();   

    $contagem = $contagem.$sql;
    $sth = $pdo->prepare($contagem);
    if (!empty($consulta)) $sth->bindParam(':consulta', $consulta);
    $contagem = $sth->execute() ? $sth->fetchAll() : array(); 

    $sqlDisciplinas = $disciplinas.$sql;
    $sthDisciplinas = $pdo->prepare($sqlDisciplinas);
    if (!empty($consulta)) $sthDisciplinas->bindParam(':consulta', $consulta);
    $disciplinas = $sthDisciplinas->execute() ? $sthDisciplinas->fetchAll() : array();

    // $grafico = new Grafico;
    // $sets = json_encode($grafico->vennHabilitacaoProfessores($disciplinas));

}
// if (isset($_POST['dt_inicio']) && isset($_POST['dt_final'])) {
//     $query = '%'.$_POST['query'].'%';
//     $dt_inicio = converteData($_POST['dt_inicio']);
//     $dt_final = converteData($_POST['dt_final']);

//     $sql = "SELECT
//               m.memo AS 'Memorando',
//               DATE_FORMAT(m.datamemo, '%d/%m/%Y') AS 'Data Memorando',
//               s.cpf AS 'CPF',
//               s.nome AS 'Nome do Servidor',
//               l.matricula AS 'Matricula',
//               CONCAT(e.inep, ' ', e.descricao) AS 'Escola',
//               CONCAT(g.descricao, '/', d.descricao) AS 'Gerencia / Departamento',
//               l.chlotacao AS 'C.H.',
//               h.descricao AS 'Habilitacao',
//               r.descricao AS 'Regime',
//               CAST(m.obs AS CHAR(10000) CHARACTER SET latin1) AS 'Observacoes'
//             FROM memo m
//               JOIN servidorrec s ON m.cpf = s.cpf
//               JOIN contrato c ON c.cpf = s.cpf
//               JOIN lotacao l ON l.cpf = s.cpf AND l.dtsaida IS NULL
//               LEFT JOIN habilitacao h ON h.codigo = l.areaatuacao
//               LEFT JOIN regimejuridico r ON r.id = c.regime
//               LEFT JOIN escola e ON e.inep = l.inep
//               LEFT JOIN gerencia g ON g.codigo = l.gerencia
//               LEFT JOIN departamento d ON d.codigo_dpto = l.departamento
//             WHERE m.memo LIKE :query
//               AND m.datamemo BETWEEN :dt_inicio AND :dt_final
//             GROUP BY m.id
//             ORDER BY m.id, l.id DESC;";
//     $sth = $pdo->prepare($sql);

//     $sth->bindParam(':query', $query);
//     $sth->bindParam(':dt_inicio', $dt_inicio);
//     $sth->bindParam(':dt_final', $dt_final);
//     $resultado = $sth->execute() ? $sth->fetchAll() : null;

//     if (sizeof($resultado) == 0) {
//         Notification::error('Nenhum resultado para exibir.');
//         redirectBack();
//     }

//     require_once '../classes/phpexcel/PHPExcel.php';
//     $excel = new PHPExcel();

//     $excel->getProperties()->setCreator("Di�rio Eletr�nico")
//                            ->setTitle("Memorandos de Lota��es");

//     $colunas = array(
//         'A' => 'Memorando',
//         'B' => 'Data Memorando',
//         'C' => 'CPF',
//         'D' => 'Nome do Servidor',
//         'E' => 'Matricula',
//         'F' => 'Escola',
//         'G' => 'Gerencia / Departamento',
//         'H' => 'C.H.',
//         'I' => 'Habilitacao',
//         'J' => 'Regime',
//         'K' => 'Observacoes'
//     );

//     $excel->setActiveSheetIndex(0);
//     foreach ($colunas as $key => $col) {
//         $colName = $key.'1';
//         $excel->getActiveSheet()->setCellValue($colName, $col);
//     }

//     $i = 2;
//     foreach ($resultado as $re) {
//         foreach ($colunas as $key => $col) {
//             $colName = $key.$i;
//             if (in_array($col, array('CPF', 'Matricula'))) {
//                 $re[$col] = ' '.$re[$col];
//             }
//             $excel->getActiveSheet()->setCellValue($colName, utf8_encode($re[$col]));
//         }
//         $i++;
//     }

//     $nomeArquivo = "memorando-lotacao-servidor-{$dt_inicio}-{$dt_final}.xls";

//     // Redirect output to a client?s web browser (Excel2007)
//     header('Content-Type: application/vnd.openxmlformats-officedocument.spreadsheetml.sheet');
//     header("Content-Disposition: attachment;filename=\"{$nomeArquivo}\"");
//     header('Cache-Control: max-age=0');
// // If you're serving to IE 9, then the following may be needed
//     header('Cache-Control: max-age=1');

// // If you're serving to IE over SSL, then the following may be needed
//     header ('Expires: Mon, 26 Jul 1997 05:00:00 GMT'); // Date in the past
//     header ('Last-Modified: '.gmdate('D, d M Y H:i:s').' GMT'); // always modified
//     header ('Cache-Control: cache, must-revalidate'); // HTTP/1.1
//     header ('Pragma: public'); // HTTP/1.0

//     $writer = PHPExcel_IOFactory::createWriter($excel, 'Excel5');
//     $writer->save('php://output');
//}

?><!DOCTYPE HTML>
<html>
<head>
    <?php require_once page_head(); ?>
    <style>
        .venntooltip {
          position: absolute;
          text-align: center;
          width: 128px;
          height: 16px;
          background: #333;
          color: #ddd;
          padding: 2px;
          border: 0px;
          border-radius: 8px;
          opacity: 0;
        }
    </style>
</head>
<body>
<?php require_once page_header(); ?>

<div class="container">

  <!-- Nav tabs -->
  <ul class="nav nav-tabs" role="tablist">
   <li role="presentation" class="<?php echo isset($_GET['cpfs']) ? "active" : "" ?>"><a href="#cpf" aria-controls="cpf" role="tab" data-toggle="tab">CPF</a></li>
   <li role="presentation" class="<?php echo isset($_GET['cpfs']) ?  "" : "active"  ?>"><a href="#habili" aria-controls="habili" role="tab" data-toggle="tab">Habilita��o</a></li>
   
  </ul>
  <br>
  <!-- Tab panes -->
  <div class="tab-content">
    <div role="tabpanel" class="tab-pane <?php echo isset($_GET['cpfs']) ? "active" : "" ?>" id="cpf">
        <form class="" method="GET">
            <div class="row">
                <div class="col-xs-10">
                    <div class="form-group">
                        <label for="cpfs">Consultar por CPF</label>
                        <textarea id="cpfs" name="cpfs" class="form-control" rows="2"><?php echo isset($_GET['cpfs']) ? $_GET['cpfs'] : "" ?></textarea>
                    </div>
                </div>
                <div class="col-xs-2" style="margin-top:4px">
                   <button type="submit" class="btn btn-primary btn-submit-wait btn-offset">CONSULTAR</button>
                </div>
            </div>
        </form>  
    </div>
       
    <div role="tabpanel" class="tab-pane <?php echo isset($_GET['cpfs']) ?  "" : "active"  ?>" id="habili">
        <form class="" method="GET">
            <div class="row">
                <div class="col-xs-3">
                    <div class="form-group">
                        <label for="habilitacao">Habilita��o de Contrato</label>
                        <select name="habilitacao" id="habilitacao" class="form-control">
                            <option value="">Selecione</option>
                            <?php foreach($habilitacoes as $habilitacao): ?>
                            <option value="<?php echo $habilitacao['codigo'] ?>" <?php echo selected(isset($_GET['habilitacao']) && $_GET['habilitacao'] == $habilitacao['codigo'] ? "select" : "" ) ?>>
                                <?php echo $habilitacao['descricao']; ?>
                            </option>
                            <?php endforeach ?>
                        </select>
                    </div>
                </div>
                <div class="col-xs-3">
                    <div class="form-group">
                        <label for="disciplina">Disciplina Ministrada</label>
                        <select name="disciplina" id="disciplina" class="form-control">
                            <option value="">Selecione</option>
                            <?php foreach($habilitacoes as $habilitacao): ?>
                            <option value="<?php echo $habilitacao['codigo'] ?>" <?php echo selected(isset($_GET['disciplina']) && $_GET['disciplina'] == $habilitacao['codigo'] ? "select" : "" ) ?> >
                                <?php echo $habilitacao['descricao']; ?>
                            </option>
                            <?php endforeach ?>
                        </select>
                    </div>
                </div>
                <div class="col-xs-4">
                    <div class="form-group">
                        <label for="municipio">Municipio</label>
                        <select name="municipio" id="municipio" class="form-control">
                            <option value="">Selecione</option>
                            <?php foreach($municipios as $municipio): ?>
                            <option value="<?php echo $municipio['codigo'] ?>" <?php echo selected(isset($_GET['municipio']) && $_GET['municipio'] == $municipio['codigo'] ? "select" : "" ) ?> >
                                <?php echo $municipio['descricao']; ?>
                            </option>
                            <?php endforeach ?>
                        </select>
                    </div>
                </div>
                <div class="col-xs-2">
                    <div class="form-group">
                        <label for="cargo">Cargo</label>
                        <input id="cargo" name="cargo" class="form-control readonly" value="PROFESSOR"/>
                    </div>
                </div>
            </div>
            <div class="row">
                <div class="col-xs-3">
                    <div class="form-group">
                        <label for="funcao">Fun��o</label>
                        <select name="funcao" id="funcao" class="form-control">
                            <option value="">Selecione</option>
                            <?php foreach($funcoes as $funcao): ?>
                            <option value="<?php echo $funcao['cod_funcao'] ?>" <?php echo selected(isset($_GET['funcao']) && $_GET['funcao'] == $funcao['cod_funcao'] ? "select" : "" ) ?>>
                                <?php echo $funcao['descricao']; ?>
                            </option>
                            <?php endforeach ?>
                        </select>
                    </div>
                </div>
                <div class="col-xs-3">
                    <div class="form-group">
                        <label for="ambiente">Ambiente</label>
                        <select name="ambiente" id="ambiente" class="form-control">
                            <option value="">Selecione</option>
                            <?php foreach($ambientes as $ambiente): ?>
                            <option value="<?php echo $ambiente['id'] ?>" <?php echo selected(isset($_GET['ambiente']) && $_GET['ambiente'] == $ambiente['id'] ? "select" : "" ) ?> >
                                <?php echo $ambiente['descricao']; ?>
                            </option>
                            <?php endforeach ?>
                        </select>
                    </div>
                </div>
                <div class="col-xs-4">
                    <div class="form-group">
                        <label for="escola">INEP - Escola</label>
                        <select name="escola" id="escola" class="form-control">
                            <option value="">Selecione</option>
                            <?php foreach($escolas as $escola): ?>
                            <option value="<?php echo $escola['inep'] ?>" <?php echo selected(isset($_GET['escola']) && $_GET['escola'] == $escola['inep'] ? "select" : "" ) ?> >
                                <?php echo $escola['descricao']; ?>
                            </option>
                            <?php endforeach ?>
                        </select>
                    </div>
                </div>

                <div class="col-xs-2" style="margin-top:4px">
                   <button type="submit" class="btn btn-primary btn-submit-wait btn-offset">CONSULTAR</button>
                </div>
            </div>
        </form>  
    </div>
   </div>

</div>

<hr>
<div class="container">
    <table class="table table-bordered table-condensed">
        <thead>
            <tr>
                <th width="200">TOTAL LOTA��ES</th>
                <td width="200" align="center"><?php echo isset($resultados) ? count($resultados): ""; ?></td>
                <th width="200">TOTAL PESSOAS</th>
                <td width="200" align="center"><?php echo isset($contagem) ? count($contagem) : ""; ?></td>
            </tr>
        </thead>
    </table>

</div>
<div class="container-fluid">
    
        <!-- <div id="venn" style="text-align:center"></div> -->
    
        <div class="row">
            <div class="col-xs-12">
            <table class="table table-bordered table-condensed">
                <thead>
                  <tr>
                    <th width="20" class="hidden-print">Lota��o</th>
                    <th width="20">CPF</th>
                    <th>Nome do servidor</th>
                    <th>Fun��o</th>
                    <th>Ambiente</th>
                    <th>INEP</th>
                    <th>Escola</th>
                    <th>Municipio</th>
                    <th>Habilita��o</th>
                    <th>Disciplina 1</th>
                    <th>Disciplina 2</th>
                    <th>Disciplina 3</th>
                    <th>Disciplina 4</th>
                  </tr>
                </thead>
                <tbody>
                    <?php if(isset($resultados)){  
                        foreach ($resultados as $serv){ ?>
                          <tr>
                            <td class="hidden-print">
                              <a class="btn btn-xs btn-default" href="<?php url("nam/form_busca_memo_cpflota.php?q={$serv['cpf']}");?>">LOTA��O</a>
                            </td>
                            <td><?php echo $serv["cpf"] ?></td>
                            <td><?php echo $serv["nome"] ?></td>
                            <td><?php echo $serv["descricaof"];?></td>
                            <td><?php echo $serv['descambescola'];?></td>
                            <td><?php echo $serv['inep'];?></td>
                            <td><?php echo $serv['nomeescola'];?></td>
                            <td><?php echo $serv['municipio'];?></td>
                            <td><?php echo $serv['descricaoh'];?></td>
                            <?php for($i=1; $i <= 4; $i++): ?>
                            <td><?php echo nomeDisciplina($serv["disciplina{$i}"]) ?></td>
                            <?php endfor ?>
                          </tr>
                    <?php } 
                    }?>
                </tbody>
            </table>
            </div>
        </div>
</div>

</div>
<?php require_once page_footer(); ?>

<script src="<?php echo js('d3.v4.min.js') ?>"></script>
<script src="<?php echo js('venn.min.js') ?>"></script>
<script type="text/javascript">
    var sets = <?php echo $sets; ?>

</script>

<!-- <script>
    var chart = venn.VennDiagram()
                     .width(500)
                     .height(500);

    var div = d3.select("#venn")

    div.datum(sets).call(chart);

    var tooltip = d3.select("body").append("div")
        .attr("class", "venntooltip");

    div.selectAll("path")
        .style("stroke-opacity", 0)
        .style("stroke", "#fff")
        .style("stroke-width", 3)

    div.selectAll("g")
        .on("mouseover", function(d, i) {
            // sort all the areas relative to the current item
            venn.sortAreas(div, d);
            // Display a tooltip with the current size
            tooltip.transition().duration(400).style("opacity", .9);
            tooltip.text(d.size + " users");
            // highlight the current path
            var selection = d3.select(this).transition("tooltip").duration(400);
            selection.select("path")
                .style("fill-opacity", d.sets.length == 1 ? .4 : .1)
                .style("stroke-opacity", 1);
        })
        .on("mousemove", function() {
            tooltip.style("left", (d3.event.pageX) + "px")
                   .style("top", (d3.event.pageY - 28) + "px");
        })
        .on("mouseout", function(d, i) {
            tooltip.transition().duration(400).style("opacity", 0);
            var selection = d3.select(this).transition("tooltip").duration(400);
            selection.select("path")
                .style("fill-opacity", d.sets.length == 1 ? .25 : .0)
                .style("stroke-opacity", 0);
        });
</script> -->

</body>
