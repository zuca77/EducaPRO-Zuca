<?php

session_start();
if (isset($_SESSION["login_usuario"]))
  {
     $login =  $_SESSION["login_usuario"];
     $nte   =  $_SESSION["nivel_usuario"];
     include ("../funcoes.php");
     echo  saudacoes()."   ". "$login" ."  -  ". $nte."  ".dataextenso();
  }
 else
  {
     		 header("Location: ../login.php");
  }  	 





if(file_exists("../conexao_mysql.php")) 
{
        require "../conexao_mysql.php";             
        mysql_query("SET NAMES 'utf8'");
       $ano  = date("Y");		             

} else 
{
        echo "Conexo nao foi encontrado";
        exit;
}

?>

<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01//EN"
	"http://www.w3.org/TR/html4/strict.dtd">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1" />
	<title>SEDUC-RO</title>
	<link rel="stylesheet" href="style/forms.css" type="text/css" />
	<link rel="stylesheet" href="estilo.css" type="text/css" />
	<link rel="stylesheet" href="style/menu.css" type="text/css" />

	
	<link href="tablecloth/tablecloth.css" rel="stylesheet" type="text/css" media="screen" />
	
	<script type="text/javascript" src="tablecloth/tablecloth.js"></script>
	<script src="lib/jquery-1.4.2.js" type="text/javascript"></script>
	<script src="lib/validate.js" type="text/javascript"></script>
	<script src="lib/forms.js" type="text/javascript"></script>
	<script src="generic.js" type="text/javascript"></script>
    <script src="lib/jquery.maskedinput-1.1.1.js" type="text/javascript"></script>


	<link type="text/css" href="jquery-ui-1.8.18.custom/css/ui-lightness/jquery-ui-1.8.18.custom.css" rel="stylesheet" />
<!--	<script type="text/javascript" src="jquery-ui-1.8.18.custom/js/jquery-1.7.1.min.js"></script>-->
	<script type="text/javascript" src="jquery-ui-1.8.18.custom/js/jquery-ui-1.8.18.custom.min.js"></script>





<script type="text/javascript">



$(function() {
		$( "#txtdtsaida" ).datepicker({
			changeMonth: true,
			changeYear: true
		});
	});

$(function() {
        $("#txtdtsaida").datepicker();
        $('#txtdtsaida').datepicker('option', 'dateFormat', 'dd/mm/yy');
});







$(function() {
		$( "#txtdtlota11" ).datepicker({
			changeMonth: true,
			changeYear: true
		});
	});

$(function() {
        $("#txtdtlota11").datepicker();
        $('#txtdtlota11').datepicker('option', 'dateFormat', 'dd/mm/yy');
});

</script>


</head>
<body>
	<div id="warpper">
		<div id="header">
		    <img src= "img/seduc_topo.jpg"/>

		</div>
    <div id="container">
			<div id="content">

				<form  name="form" class="form" action="insere_relotacao.php" method="POST">


<p><br><font size="4"> Dados Pessoais <img src= "img/check.gif"/></font> </p>

<?php

$id = $_GET['codigo'];
$sql_lotacao = "select * from lotacao where id = '$id'";
$query1 = mysql_query($sql_lotacao) or die(mysql_error());
while ( $linha_lotacao = mysql_fetch_array( $query1 ))
{ 
    
 	$cpflotacao 	     =$linha_lotacao["cpf"];
	$matriculalotacao  	 =$linha_lotacao["matricula"];
 	$lotado 	         =$linha_lotacao["lotado"];
 	$gerencia 	         =$linha_lotacao["gerencia"];
 	$dpto 	             =$linha_lotacao["departamento"];

    $inep           	 =$linha_lotacao["inep"];
    $dtlotacao           =$linha_lotacao["dtlotacao"];
    $qtdaaula            =$linha_lotacao["qtdaaula"];
    $areaatuacao         =$linha_lotacao["areaatuacao"];
    $chlotacao           =$linha_lotacao["chlotacao"];


}


/******************Escola*************************************************/

	$sqlgerencia = "SELECT inep, descricao,municipio from escola where inep='$inep'";
    $resultadoger=mysql_query($sqlgerencia) or die (mysql_error());
    $linhas   =mysql_num_rows($resultadoger);

if($linhas>0)
{
   while($pegar=mysql_fetch_array($resultadoger))
	{
    	$escola      =$pegar["descricao"]; 	
        $municipio   =$pegar["municipio"]; 			

	}
	
 }	



/******************Muicipio *************************************************/

	$sqlgerencia = "SELECT codigo, descricao from municipio where codigo='$municipio'";
    $resultadoger=mysql_query($sqlgerencia) or die (mysql_error());
    $linhas   =mysql_num_rows($resultadoger);

if($linhas>0)
{
   while($pegar=mysql_fetch_array($resultadoger))
	{
    	$descmuni      =$pegar["descricao"]; 	
	}
 }	


//************************************************************************************//
$sqlmemo="select * from contrato where matricula = '$matriculalotacao'";
$resultadomemo=mysql_query($sqlmemo) or die (mysql_error());
$linhasmemo=mysql_num_rows($resultadomemo);

if($linhasmemo>0)
{
   while($pegarmemo=mysql_fetch_array($resultadomemo))
   {
      $cpfmemo          =$pegarmemo["cpf"];
      $matricula        =$pegarmemo["matricula"];
      $dof              =$pegarmemo["dof"];
	  $cargo            =$pegarmemo["cargo"];
      $funcao           =$pegarmemo["funcao"];
      $decreto          =$pegarmemo["decreto"];
      $chcontrato       =$pegarmemo["chcontrato"];


      $dtadmissao   = date("d/m/Y",strtotime($pegarmemo["dtadmissao"]));
      $dtdecreto    = date("d/m/Y",strtotime($pegarmemo["dtdecreto"]));
   	  $dtdof        = date("d/m/Y",strtotime($pegarmemo["dtdof"]));

   }
}  



$sqldados="select * from servidorrec where cpf = '$cpflotacao'";
$resultadodados=mysql_query($sqldados) or die (mysql_error());
$linhasdados=mysql_num_rows($resultadodados);

if($linhasdados>0)
{
   while($pegardados=mysql_fetch_array($resultadodados))
   {
    $cpf              =$pegardados["cpf"];
	$nome             =$pegardados["nome"];
	$mae              =$pegardados["mae"]; 	
    $pai              =$pegardados["pai"]; 	
	$endereco         =$pegardados["endereco"]; 	
	$bairro           =$pegardados["bairro"]; 	
	$fonesetor        =$pegardados["fonesetor"]; 	
	$fonecontato      =$pegardados["fonecontato"]; 	
	$foneresidencial  =$pegardados["foneresidencial"]; 	
	$celular          =$pegardados["celular"]; 	
	$email            =$pegardados["email"]; 	
    }
}

?>
	
	
					<p>
						<label for="txtCPF">CPF<img src= "recadastramento/img/check.gif"/></label>
						<input type="text" name="cpf" style="width:110px"  maxlength="11" id="cpf"  value= "<? echo $cpf; ?>"  readonly="true"/>

					</p>
	

					<p>
						<label for="txtNome">Nome</label>
						<input type="text" name="txtNome" style="width:565px" maxlength="60" value= "<? echo $nome; ?>" id="txtNome" readonly="true"/>
					</p>
					
					<p>
						<label for="txtFoneSetor">Telefone Comercial</label>
						<input type="text" name="txtFoneSetor" style="width:90px" value= "<? echo $fonesetor; ?>" id="txtFoneSetor"  maxlength="20" readonly="true"/>
						<label for="txtFoneRes">Residencial</label>
						<input type="text" name="txtFoneRes" style="width:90px" value= "<? echo $foneresidencial; ?>" id="txtFoneRes" maxlength="20" readonly="true"/>
						<label for="txtCelular">Celular</label>
						<input type="text" name="txtCelular" style="width:90px" value= "<? echo $celular; ?>" id="txtCelular" maxlength="20" readonly="true"/>
						<label for="txtCelular">Contato</label>
						<input type="text" name="txtcontato" style="width:90px" value= "<? echo $fonecontato; ?>" id="txtcontato" maxlength="25" readonly="true"/>

					</p>
					<p>
						<label for="txtEmail">E-mail</label>
						<input type="text" name="txtEmail" style="width:565px" value= "<? echo $email; ?>" id="txtEmail" maxlength="80" readonly="true"/>
					</p>

					<p><br><font size="4"> Dados Contrato </font> </p>

 <p>
<label for="lblMatricula">ID</label>
    <input name="txtid" type="text" id="txtid" style="width:120px" title = "Campo Obrigatrio. Informe o número do memrando." MAXLENGTH="10" value= "<? echo $id; ?>"  readonly="true"/>
</p>

			
				<p>		
						<label for="lblMatricula">Matri�cula</label>
						<input type="text" name="txtMatricula1" value= "<? echo $matricula; ?>" style="width:90px" maxlength="11" id="txtMatricula1" readonly="true" />

						<label for="lblMatricula">Matri�cula</label>
						<input type="text" name="txtMatricula" value= "<? echo $matricula; ?>" style="width:90px" maxlength="11" id="txtMatricula" readonly="true"/>

						<label for="txtDataAdmissao">Data Admisso</label>
						<input type="text" name="txtdtadmissao1" value= "<? echo $dtadmissao; ?>" style="width:70px" id="txtdtadmissao1" readonly="true"/>		

						<label for="selectch1">CH - Contrato</label>
 			                <select id="selectch1" name="selectch1"  value= "<? echo $chcontrato; ?>"   style="width:40px" readonly="true">
              		          <option value="40">40</option>
            		          <option value="25">25</option>
            		          <option value="20">20</option>
    		               </select>

					</p>

					<p>
						<label for="lbldecreto">N Decreto</label>
						<input type="text" name="txtdecreto1" style="width:70px" value= "<? echo $decreto; ?>" maxlength="11" id="txtdecreto1" readonly="true"/>

						<label for="lblDataAdmissao">Data</label>
						<input type="text" name="txtdtdecreto1" style="width:70px" id="txtdtdecreto1" value= "<? echo $dtdecreto; ?>" readonly="true"/>	

						<label for="txtCPF">Publicado Di�rio</label>
						<input type="text" name="txtdiario1" style="width:70px" value= "<? echo $dof; ?>" maxlength="10" id="txtdiario1"  readonly="true" />

						<label for="txtDataAdmissao">Data</label>
						<input type="text" name="txtdtdiario1" value= "<? echo $dtdof; ?>" style="width:70px" id="txtdtdiario1" readonly="true" />		

					</p>


					<p><br><font size="4"> Lota��o Atual </font> </p>
					
					<p>

						<label for="txtNome">INEP</label>
						<input type="text" name="txtinepescola" style="width:80px" maxlength="60" value= "<? echo $inep; ?>" id="txtinepescola" readonly="true"/>

						<label for="txtNome">Escola</label>
						<input type="text" name="txtescola" style="width:448px" maxlength="60" value= "<? echo $escola; ?>" id="txtescola" readonly="true"/>
					</p>

					<p>

						<label for="txtNome">Munic�pio</label>
						<input type="text" name="txtescola" style="width:448px" maxlength="60" value= "<? echo $descmuni; ?>" id="txtescola" readonly="true"/>
					</p>

 
 					<p><br><font size="4"> Nova Lota��o </font> </p>
 
 
                   <p>
						<label for="txtdtlotacao1">Data Sa��da<img src= "img/check.gif"/></label>
						<input type="text" name="txtdtsaida" value="" style="width:70px" id="txtdtsaida"   />		

					</p>


 <p>
	<label for="lblMatricula">Memorando<img src= "img/check.gif"/></label>
    <input name="txtMemo" type="text" id="txtMemo" style="width:120px" title = "Campo Obrigatrio. Informe o número do memrando." MAXLENGTH="10" />

    <input name="txtMemor" type="hidden" id="txtMemor" style="width:120px" title = "Campo Obrigatrio. Informe o número do memrando." MAXLENGTH="10" value= "<? echo $id; ?>" />


             
<label for="lblMatricula">Ano<img src= "img/check.gif"/></label>
<input type="text" name="txtano" style="width:40px"  maxlength="60" value= "<? echo $ano; ?>" id="txtano"  readonly="true"/>
 


         </p>	





					   <p>
	  					<label for="lblqtda">Lotado<img src= "img/check.gif"/></label>
 			                <select id="selectlotacao1" name="selectlotacao1" style="width:200px" />	
						    <option value="">...Selecione Lotação...</option>
              		          <option value="1">ADMINISTRACAO</option>
            		          <option value="2">ESCOLA</option>
            		          <option value="3">ADMINISTRA��O E ESCOLA</option>							  
    		               </select>
    	       		     </p>

			      <p>
					<label for="lblgerencia">Ger�ncia<img src= "img/check.gif" /></label>
						<select name="txtgerencia" id="txtgerencia"  style="width:400px" disabled="disabled" >
						<option value="">...Selecione Administra��o..</option>
					<?php
            				include ("../conexao_mysql.php");
							$sql = "SELECT codigo, descricao
									FROM gerencia
									ORDER BY descricao";
				     		$res = mysql_query( $sql );
							while ( $row = mysql_fetch_assoc( $res ) ) {
							echo '<option value="'.$row['codigo'].'">'.$row['descricao'].'</option>';
						}
					?>
					</select>

		       </p>
			
			
			<p>
          		<label for="lbldpto">Departamento<img src= "img/check.gif"/></label>
	         	<!--	<span class="carregando">Aguarde, carregando...</span>-->
		          <select name="txtdpto" id="txtdpto" style="width:400px" disabled="disabled">
			           <option value="">-- Escolha Departamento --</option>
            	 </select>
				 
			
	</p>		

           <p>
			  	<label for="selectcontrato3">Escola(s)<img src= "img/check.gif"/></label>
 			    <select id="selectqtdaescola" name="selectqtdaescola" style="width:40px" disabled="disabled">
                   <option value="1">1</option>
                   <option value="2">2</option>
                   <option value="3">3</option>				   
    		     </select>

           </p>

           <p>
				<label for="lblinep1">INEP<img src= "img/check.gif"/></label>
				<input type="text" name="txtinep1" value="" style="width:90px" maxlength="8" id="txtinep1" disabled="disabled" onKeyPress="return Enum(event)"/>


          		   <label for="lbldesescola">Escola</label>
         		   <span class="carregando">Aguarde, carregando...</span>
		             <select name="txtdescescola1" id="txtdescescola1" style="width:350px">
			           <option value="">-- Informe o INEP --</option>
            	    </select>
			</p>


              <p>
						<label for="txtdtlotacao1">Data Lota��o<img src= "img/check.gif"/></label>
						<input type="text" name="txtdtlota11" value="" style="width:70px" id="txtdtlota11" />		



						<label for="selectcontrato1">CH<img src= "img/check.gif"/></label>
 			                <select id="selectch1lota" name="selectch1lota" style="width:40px"  disabled="disabled">
              		          <option value="0">0</option>
              		          <option value="40">40</option>
            		          <option value="25">25</option>
            		          <option value="20">20</option>
    		               </select>

						<label for="lblqtdaaula1">Qtda Aulas<img src= "img/check.gif"/></label>
						<input type="text" name="txtqdtaaulas1" value="0" style="width:30px" id="txtqdtaaulas1" maxlength="2" disabled="disabled"  onKeyPress="return Enum(event)"/>
                  </p>
                  <p>

					<label for="lblareaatuacao1">Area de Atua��o</label>
						<select name="txtautacao1" id="txtautacao1" disabled="disabled" style="width:300px" >
						<option value="">Selecione Area de Atuação</option>
					<?php
							include ("../conexao_mysql.php");
							$sql = "SELECT codigo, descricao
									FROM habilitacao
									ORDER BY descricao";
				     		$res = mysql_query( $sql );
							while ( $row = mysql_fetch_assoc( $res ) ) {
							echo '<option value="'.$row['codigo'].'">'.$row['descricao'].'</option>';
						}
	
					?>
					</select>
			</p>

	    <p>
         <label for="lblcod_cpf">Obs.:<img src= "img/check.gif"/></label>
 			<textarea name = "txtobs"   cols="100" rows = "10" id = "txtobs"  type = "text"  onkeyup="blocTexto(txtobs.value)"></textarea>
       </p>



				<p id="finish">
            <input name='Voltar' type='button' class="botao" onclick='javascript:history.go(-1);' value='Voltar' >
            <input type="submit" value="Gravar" />
            <input type="reset" value="limpar" />

					</p>

<? 


?>



				</form>
			</div>
		</div>


 </div><!-- Div corpodetalhe-->
</div><!-- Div corpo2-->

<?
//  mysql_close($conexao);
?>				
  <div id="rodapeconsulta" class="fonterodape">
</div>
		<div id="footer">
			<p>Todos direitos reservados GTI/SEDUC</p>
		</div>
	</div>
</body>

