<?
session_start();
if (isset($_SESSION["login_usuario"]))
  {
     $login     =  $_SESSION["login_usuario"];
     $nte       =  $_SESSION["nivel_usuario"];
     $inep      =  $_SESSION["inep_usuario"] ;
     $ntelogin  =  $_SESSION["nte_login"];
   
     include ("../funcoes.php");
     echo  saudacoes()."   ". "$login" ."  -  ". $nte."  ".dataextenso() ." - ".$inep;
  }
 else
  {
     		 header("Location: login.php");
  }



//verifico se a fun��o que eu criei existe, vai que alguem pegou meu script e apagou ela = )

if(file_exists("../conexao_mysql.php"))
{
        require "../conexao_mysql.php";             
        mysql_query("SET NAMES 'latin1_swedish_ci'");
}
else 
{
        echo "Arquivo conexao_mysql nao foi encontrado";
        exit;
}


/*verifico se os dados estao vindos do formulario, porque se uma pessoa acessar essa pagina diretamente 
poderia dar erro, entao eu testo antes*/
if($_SERVER["REQUEST_METHOD"] == "POST") 
{

$txtid                 = $_POST['txtid'];
$selectsituacao        = $_POST['selectsituacao'];
$txtobsescola           = $_POST['txtobsescola'];
$txtautacao1           = $_POST['txtautacao1'];
$txtautacao2           = $_POST['txtautacao2'];
$txtautacao3           = $_POST['txtautacao3'];
$txtautacao4           = $_POST['txtautacao4'];
$selectexecercio       = $_POST['selectexecercio'];

$txthe                 = $_POST['txthe'];

$txttfundamental       = $_POST['txttfundamental'];
$txttmedio             = $_POST['txttmedio'];
$txtteja               = $_POST['txtteja'];








$m1           = $_POST['m1'];
$t1           = $_POST['t1'];
$n1           = $_POST['n1'];

$txtqdtaaulas1m           = $_POST['txtqdtaaulas1m'];
$txtqdtaaulas1t           = $_POST['txtqdtaaulas1t'];
$txtqdtaaulas1n           = $_POST['txtqdtaaulas1n'];

//*****************************************************************************************************************************************
if ($txtautacao1=='')
    {
echo "<html><head><title>Resposta !!!</title></head>";
echo "<body background=\"background_mensagens.jpg\" style=\"background-attachment:fixed; background-repeat:no-repeat\">";
echo "<br><br><br>";
echo "<center><img src=\"faleconosco/atencao.gif\" alt=\"\"><p><font color=\"#ff6600\" face=\"Verdana\" size=\"4\">Campo Obrigat�rio. Informe a primeira disciplina.! <b></b></font></center>";
echo "<br><br><center><a href=\"mnadmescola.php\"><img src=\"faleconosco/button_voltar2_.gif\" alt=\"Voltar\" border=\"0\" /></a></center>";
echo "</body></html>";
exit;
    }


if (($txtautacao1!='') && (($m1=='')  &&  ($t1=='') &&  ($n1=='')))
   {
echo "<html><head><title>Resposta !!!</title></head>";
echo "<body background=\"background_mensagens.jpg\" style=\"background-attachment:fixed; background-repeat:no-repeat\">";
echo "<br><br><br>";
echo "<center><img src=\"faleconosco/atencao.gif\" alt=\"\"><p><font color=\"#ff6600\" face=\"Verdana\" size=\"4\">Campo Obrigat�rio. Informe os turnos que o servidor trabalha. <b></b></font></center>";
echo "<br><br><center><a href=\"mnadmescola.php\"><img src=\"faleconosco/button_voltar2_.gif\" alt=\"Voltar\" border=\"0\" /></a></center>";
echo "</body></html>";
exit;
   }


if (($m1!='') && ($txtqdtaaulas1m==0 || $txtqdtaaulas1m==''))
   {
echo "<html><head><title>Resposta !!!</title></head>";
echo "<body background=\"background_mensagens.jpg\" style=\"background-attachment:fixed; background-repeat:no-repeat\">";
echo "<br><br><br>";
echo "<center><img src=\"faleconosco/atencao.gif\" alt=\"\"><p><font color=\"#ff6600\" face=\"Verdana\" size=\"4\">Campo Obrigat�rio. Informe a quantidade de aulas no per�odo da manh�. <b></b></font></center>";
echo "<br><br><center><a href=\"mnadmescola.php\"><img src=\"faleconosco/button_voltar2_.gif\" alt=\"Voltar\" border=\"0\" /></a></center>";
echo "</body></html>";
exit;
   }


if (($t1!='') && ($txtqdtaaulas1t==0 || $txtqdtaaulas1t==''))
   {
echo "<html><head><title>Resposta !!!</title></head>";
echo "<body background=\"background_mensagens.jpg\" style=\"background-attachment:fixed; background-repeat:no-repeat\">";
echo "<br><br><br>";
echo "<center><img src=\"faleconosco/atencao.gif\" alt=\"\"><p><font color=\"#ff6600\" face=\"Verdana\" size=\"4\">Campo Obrigat�rio. Informe a quantidade de aulas no per�odo da tarde. <b></b></font></center>";
echo "<br><br><center><a href=\"mnadmescola.php\"><img src=\"faleconosco/button_voltar2_.gif\" alt=\"Voltar\" border=\"0\" /></a></center>";
echo "</body></html>";
exit;
   }


if (($n1!='') && ($txtqdtaaulas1n==0 || $txtqdtaaulas1n==''))
   {
echo "<html><head><title>Resposta !!!</title></head>";
echo "<body background=\"background_mensagens.jpg\" style=\"background-attachment:fixed; background-repeat:no-repeat\">";
echo "<br><br><br>";
echo "<center><img src=\"faleconosco/atencao.gif\" alt=\"\"><p><font color=\"#ff6600\" face=\"Verdana\" size=\"4\">Campo Obrigat�rio. Informe a quantidade de aulas no per�odo da noite. <b></b></font></center>";
echo "<br><br><center><a href=\"mnadmescola.php\"><img src=\"faleconosco/button_voltar2_.gif\" alt=\"Voltar\" border=\"0\" /></a></center>";
echo "</body></html>";
exit;
   }
//*****************************************************************************************************************************************
$m2           = $_POST['m2'];
$t2           = $_POST['t2'];
$n2           = $_POST['n2'];
$txtqdtaaulas2m           = $_POST['txtqdtaaulas2m'];
$txtqdtaaulas2t           = $_POST['txtqdtaaulas2t'];
$txtqdtaaulas2n           = $_POST['txtqdtaaulas2n'];
//*****************************************************************************************************************************************


if (($txtautacao2!='') && (($m2=='')  &&  ($t2=='') &&  ($n2=='')))
   {
echo "<html><head><title>Resposta !!!</title></head>";
echo "<body background=\"background_mensagens.jpg\" style=\"background-attachment:fixed; background-repeat:no-repeat\">";
echo "<br><br><br>";
echo "<center><img src=\"faleconosco/atencao.gif\" alt=\"\"><p><font color=\"#ff6600\" face=\"Verdana\" size=\"4\">Campo Obrigat�rio. Informe os turnos que o servidor trabalha. <b></b></font></center>";
echo "<br><br><center><a href=\"mnadmescola.php\"><img src=\"faleconosco/button_voltar2_.gif\" alt=\"Voltar\" border=\"0\" /></a></center>";
echo "</body></html>";
exit;
   }


if (($txtautacao2!='') && ($m2!='') && ($txtqdtaaulas2m==0 || $txtqdtaaulas2m==''))
   {
echo "<html><head><title>Resposta !!!</title></head>";
echo "<body background=\"background_mensagens.jpg\" style=\"background-attachment:fixed; background-repeat:no-repeat\">";
echo "<br><br><br>";
echo "<center><img src=\"faleconosco/atencao.gif\" alt=\"\"><p><font color=\"#ff6600\" face=\"Verdana\" size=\"4\">Campo Obrigat�rio. Informe a quantidade de aulas no per�odo da manh�. <b></b></font></center>";
echo "<br><br><center><a href=\"form_rel_lotacao.php\"><img src=\"faleconosco/button_voltar2_.gif\" alt=\"Voltar\" border=\"0\" /></a></center>";
echo "</body></html>";
exit;
   }


if (($txtautacao2!='') && ($t2!='') && ($txtqdtaaulas2t==0 || $txtqdtaaulas2t==''))
   {
echo "<html><head><title>Resposta !!!</title></head>";
echo "<body background=\"background_mensagens.jpg\" style=\"background-attachment:fixed; background-repeat:no-repeat\">";
echo "<br><br><br>";
echo "<center><img src=\"faleconosco/atencao.gif\" alt=\"\"><p><font color=\"#ff6600\" face=\"Verdana\" size=\"4\">Campo Obrigat�rio. Informe a quantidade de aulas no per�odo da tarde. <b></b></font></center>";
echo "<br><br><center><a href=\"form_rel_lotacao.php\"><img src=\"faleconosco/button_voltar2_.gif\" alt=\"Voltar\" border=\"0\" /></a></center>";
echo "</body></html>";
exit;
   }


if (($txtautacao2!='') && ($n2!='') && ($txtqdtaaulas2n==0 || $txtqdtaaulas2n==''))
   {
echo "<html><head><title>Resposta !!!</title></head>";
echo "<body background=\"background_mensagens.jpg\" style=\"background-attachment:fixed; background-repeat:no-repeat\">";
echo "<br><br><br>";
echo "<center><img src=\"faleconosco/atencao.gif\" alt=\"\"><p><font color=\"#ff6600\" face=\"Verdana\" size=\"4\">Campo Obrigat�rio. Informe a quantidade de aulas no per�odo da noite. <b></b></font></center>";
echo "<br><br><center><a href=\"form_rel_lotacao.php\"><img src=\"faleconosco/button_voltar2_.gif\" alt=\"Voltar\" border=\"0\" /></a></center>";
echo "</body></html>";
exit;
   }
//*****************************************************************************************************************************************
$m3           = $_POST['m3'];
$t3           = $_POST['t3'];
$n3           = $_POST['n3'];
$txtqdtaaulas3m           = $_POST['txtqdtaaulas3m'];
$txtqdtaaulas3t           = $_POST['txtqdtaaulas3t'];
$txtqdtaaulas3n           = $_POST['txtqdtaaulas3n'];


//*****************************************************************************************************************************************


if (($txtautacao3!='') && (($m3=='')  &&  ($t3=='') &&  ($n3=='')))
   {
echo "<html><head><title>Resposta !!!</title></head>";
echo "<body background=\"background_mensagens.jpg\" style=\"background-attachment:fixed; background-repeat:no-repeat\">";
echo "<br><br><br>";
echo "<center><img src=\"faleconosco/atencao.gif\" alt=\"\"><p><font color=\"#ff6600\" face=\"Verdana\" size=\"4\">Campo Obrigat�rio. Informe os turnos que o servidor trabalha. <b></b></font></center>";
echo "<br><br><center><a href=\"form_rel_lotacao.php\"><img src=\"faleconosco/button_voltar2_.gif\" alt=\"Voltar\" border=\"0\" /></a></center>";
echo "</body></html>";
exit;
   }


if (($txtautacao3!='') && ($m3!='') && ($txtqdtaaulas3m==0 || $txtqdtaaulas3m==''))
   {
echo "<html><head><title>Resposta !!!</title></head>";
echo "<body background=\"background_mensagens.jpg\" style=\"background-attachment:fixed; background-repeat:no-repeat\">";
echo "<br><br><br>";
echo "<center><img src=\"faleconosco/atencao.gif\" alt=\"\"><p><font color=\"#ff6600\" face=\"Verdana\" size=\"4\">Campo Obrigat�rio. Informe a quantidade de aulas no per�odo da manh�. <b></b></font></center>";
echo "<br><br><center><a href=\"mnadmescola.php\"><img src=\"faleconosco/button_voltar2_.gif\" alt=\"Voltar\" border=\"0\" /></a></center>";
echo "</body></html>";
exit;
   }


if (($txtautacao3!='') && ($t3!='') && ($txtqdtaaulas3t==0 || $txtqdtaaulas3t==''))
   {
echo "<html><head><title>Resposta !!!</title></head>";
echo "<body background=\"background_mensagens.jpg\" style=\"background-attachment:fixed; background-repeat:no-repeat\">";
echo "<br><br><br>";
echo "<center><img src=\"faleconosco/atencao.gif\" alt=\"\"><p><font color=\"#ff6600\" face=\"Verdana\" size=\"4\">Campo Obrigat�rio. Informe a quantidade de aulas no per�odo da tarde. <b></b></font></center>";
echo "<br><br><center><a href=\"mnadmescola.php\"><img src=\"faleconosco/button_voltar2_.gif\" alt=\"Voltar\" border=\"0\" /></a></center>";
echo "</body></html>";
exit;
   }


if (($txtautacao3!='') && ($n3!='') && ($txtqdtaaulas3n==0 || $txtqdtaaulas3n==''))
   {
echo "<html><head><title>Resposta !!!</title></head>";
echo "<body background=\"background_mensagens.jpg\" style=\"background-attachment:fixed; background-repeat:no-repeat\">";
echo "<br><br><br>";
echo "<center><img src=\"faleconosco/atencao.gif\" alt=\"\"><p><font color=\"#ff6600\" face=\"Verdana\" size=\"4\">Campo Obrigat�rio. Informe a quantidade de aulas no per�odo da noite. <b></b></font></center>";
echo "<br><br><center><a href=\"mnadmescola.php\"><img src=\"faleconosco/button_voltar2_.gif\" alt=\"Voltar\" border=\"0\" /></a></center>";
echo "</body></html>";
exit;
   }
//*****************************************************************************************************************************************

$m4           = $_POST['m4'];
$t4           = $_POST['t4'];
$n4           = $_POST['n4'];
$txtqdtaaulas4m           = $_POST['txtqdtaaulas4m'];
$txtqdtaaulas4t           = $_POST['txtqdtaaulas4t'];
$txtqdtaaulas4n           = $_POST['txtqdtaaulas4n'];


//*****************************************************************************************************************************************


if (($txtautacao4!='') && (($m4=='')  &&  ($t4=='') &&  ($n4=='')))
   {
echo "<html><head><title>Resposta !!!</title></head>";
echo "<body background=\"background_mensagens.jpg\" style=\"background-attachment:fixed; background-repeat:no-repeat\">";
echo "<br><br><br>";
echo "<center><img src=\"faleconosco/atencao.gif\" alt=\"\"><p><font color=\"#ff6600\" face=\"Verdana\" size=\"4\">Campo Obrigat�rio. Informe os turnos que o servidor trabalha. <b></b></font></center>";
echo "<br><br><center><a href=\"form_rel_lotacao.php\"><img src=\"faleconosco/button_voltar2_.gif\" alt=\"Voltar\" border=\"0\" /></a></center>";
echo "</body></html>";
exit;
   }


if (($txtautacao4!='') && ($m4!='') && ($txtqdtaaulas4m==0 || $txtqdtaaulas4m==''))
   {
echo "<html><head><title>Resposta !!!</title></head>";
echo "<body background=\"background_mensagens.jpg\" style=\"background-attachment:fixed; background-repeat:no-repeat\">";
echo "<br><br><br>";
echo "<center><img src=\"faleconosco/atencao.gif\" alt=\"\"><p><font color=\"#ff6600\" face=\"Verdana\" size=\"4\">Campo Obrigat�rio. Informe a quantidade de aulas no per�odo da manh�. <b></b></font></center>";
echo "<br><br><center><a href=\"form_rel_lotacao.php\"><img src=\"faleconosco/button_voltar2_.gif\" alt=\"Voltar\" border=\"0\" /></a></center>";
echo "</body></html>";
exit;
   }


if (($txtautacao4!='') && ($t4!='') && ($txtqdtaaulas4t==0 || $txtqdtaaulas4t==''))
   {
echo "<html><head><title>Resposta !!!</title></head>";
echo "<body background=\"background_mensagens.jpg\" style=\"background-attachment:fixed; background-repeat:no-repeat\">";
echo "<br><br><br>";
echo "<center><img src=\"faleconosco/atencao.gif\" alt=\"\"><p><font color=\"#ff6600\" face=\"Verdana\" size=\"4\">Campo Obrigat�rio. Informe a quantidade de aulas no per�odo da tarde. <b></b></font></center>";
echo "<br><br><center><a href=\"form_rel_lotacao.php\"><img src=\"faleconosco/button_voltar2_.gif\" alt=\"Voltar\" border=\"0\" /></a></center>";
echo "</body></html>";
exit;
   }


if (($txtautacao4!='') && ($n4!='') && ($txtqdtaaulas4n==0 || $txtqdtaaulas4n==''))
   {
echo "<html><head><title>Resposta !!!</title></head>";
echo "<body background=\"background_mensagens.jpg\" style=\"background-attachment:fixed; background-repeat:no-repeat\">";
echo "<br><br><br>";
echo "<center><img src=\"faleconosco/atencao.gif\" alt=\"\"><p><font color=\"#ff6600\" face=\"Verdana\" size=\"4\">Campo Obrigat�rio. Informe a quantidade de aulas no per�odo da noite. <b></b></font></center>";
echo "<br><br><center><a href=\"form_rel_lotacao.php\"><img src=\"faleconosco/button_voltar2_.gif\" alt=\"Voltar\" border=\"0\" /></a></center>";
echo "</body></html>";
exit;
   }
//*****************************************************************************************************************************************


//echo "$dtemissaorg";
$dia = date('d');
$mes = date('m');
$ano = date('Y');

$data =$ano.".".$mes.".".$dia;



$sql="select * from lotacao where  id ='$txtid'";
$resultado=mysql_query($sql) or die (mysql_error());
$linhas=mysql_num_rows($resultado);
if ($linhas>0)
{

   while($pegardados=mysql_fetch_array($resultado))
      {
        $dtsaidabd          =$pegardados["dtsaida"];
        $inepbd             =$pegardados["inep"];

     }

        if (($inepbd==$inep) && ($dtsaidabd!=''))
           {
            $dtsaida= NULL; 
           }
        else
          {
            $dtsaida= '$dtsaidabd'; 
         
          }

//echo "dtsaida banco $dtsaidabd";
//echo "inep banco $inepbd";
//echo "inep $inep";
//echo "dtsaida $dtsaida";



       $sql = "update lotacao set
            disciplina1='$txtautacao1',
            disciplina2='$txtautacao2',
            disciplina3='$txtautacao3',
            disciplina4='$txtautacao4',
            m1='$m1',
            t1='$t1',
            n1='$n1',
            m2='$m2',
            t2='$t2',
            n2='$n2',
            m3='$m3',
            t3='$t3',
            n3='$n3',
            m4='$m4',
            t4='$t4',
            n4='$n4',
            qdtaaulas1m='$txtqdtaaulas1m',
            qdtaaulas1t='$txtqdtaaulas1t',
            qdtaaulas1n='$txtqdtaaulas1n',
            qdtaaulas2m='$txtqdtaaulas2m',
            qdtaaulas2t='$txtqdtaaulas2t',
            qdtaaulas2n='$txtqdtaaulas2n',
            qdtaaulas3m='$txtqdtaaulas3m',
            qdtaaulas3t='$txtqdtaaulas3t',
            qdtaaulas3n='$txtqdtaaulas3n',
            qdtaaulas4m='$txtqdtaaulas4m',
            qdtaaulas4t='$txtqdtaaulas4t',
            qdtaaulas4n='$txtqdtaaulas4n',
            obsescola  ='$txtobsescola',
            situacao   ='$selectsituacao',
            ambescola  ='$selectexecercio',
            dtescola   ='$data',
            hextra     ='$txthe',
            dtsaida    ='$dtsaida',
            tfundamental    ='$txttfundamental',
            tmedio          ='$txttmedio',
            teja            ='$txtteja',
            usuario    ='$login'
            where id   ='$txtid'";

if(@mysql_query($sql))
    {
       //verifiquei acima se deu certo o comando e aqui verifico se foi mesmo gravado o dado no banco


        if(mysql_affected_rows() == 1)
		{
echo "<html><head><title>Resposta !!!</title></head>";
echo "<body background=\"background_mensagens.jpg\" style=\"background-attachment:fixed; background-repeat:no-repeat\">";
echo "<br><br><br>";
echo "<center><img src=\"faleconosco/atencao.gif\" alt=\"\"><p><font color=\"#ff6600\" face=\"Verdana\" size=\"4\">Dados Alterado Com Sucesso.!!!! <b></b></font></center>";
echo "<br><br><center><a href=\"form_rel_lotacao.php\"><img src=\"faleconosco/button_voltar2_.gif\" alt=\"Voltar\" border=\"0\" /></a></center>";
echo "</body></html>";
 exit;
 @mysql_close();
//************************************************************************************************************
        }

echo "<html><head><title>Resposta !!!</title></head>";
echo "<body background=\"background_mensagens.jpg\" style=\"background-attachment:fixed; background-repeat:no-repeat\">";
echo "<br><br><br>";
echo "<center><img src=\"faleconosco/atencao.gif\" alt=\"\"><p><font color=\"#ff6600\" face=\"Verdana\" size=\"4\">Usuario Houver erro na Gravacao Tente Novamente.!!!! <b></b></font></center>";
echo "<br><br><center><a href=\"form_rel_lotacao.php\"><img src=\"faleconosco/button_voltar2_.gif\" alt=\"Voltar\" border=\"0\" /></a></center>";
echo "</body></html>";


} 
else 
   {
        //verifico se nao estao tentando gravar um dado que ja existe, pois usei UNIQUE na tabela 
        if(mysql_errno() == 1062) 
		  {
                echo $erros[mysql_errno()];
                exit;
          } 
		  else 
		  {        
                echo "Erro nao foi possivel efetuar o cadastro";
                exit;
          }       
        @mysql_close();
     }
}//if 

else
{
echo "<html><head><title>Resposta !!!</title></head>";
echo "<body background=\"background_mensagens.jpg\" style=\"background-attachment:fixed; background-repeat:no-repeat\">";
echo "<br><br><br>";
echo "<center><img src=\"faleconosco/atencao.gif\" alt=\"\"><p><font color=\"#ff6600\" face=\"Verdana\" size=\"4\">Lota��o n�o cadastrado! <b></b></font></center>";
echo "<br><br><center><a href=\"form_rel_lotacao.php\"><img src=\"faleconosco/button_voltar2_.gif\" alt=\"Voltar\" border=\"0\" /></a></center>";
echo "</body></html>";

}

}//esle  post

 
?>
