<?

//verifico se a fun��o que eu criei existe, vai que alguem pegou meu script e apagou ela = )


session_start();
if (isset($_SESSION["login_usuario"]))
  {
     $login =  $_SESSION["login_usuario"];
     $nte   =  $_SESSION["nivel_usuario"];
     include ("../funcoes.php");
     echo  saudacoes()."   ". "$login" ."  -  ". $nte."  ".dataextenso();
  }
 else
  {
     		 header("Location: ../login.php");
  }



if(file_exists("../conexao_mysql.php")) 
{
        require "../conexao_mysql.php";             
     mysql_query("SET NAMES 'latin1_swedish_ci'");
} else 
{
        echo "Arquivo conexao_mysql nao foi encontrado";
        exit;
}


if($_SERVER["REQUEST_METHOD"] == "POST")
{


$cpf           		     = $_POST['cpf'];
$txtinep1 			     = $_POST['txtinep1']; 
$selectlotacao1 		     = $_POST['selectlotacao1'];
$selectch1lota 		     = $_POST['selectch1lota'];
$txtdtlota11 			     = $_POST['txtdtlota11'];
$txtdtlota1imprimi 		     = $_POST['txtdtlota11'];
$txtqdtaaulas1 		     = $_POST['txtqdtaaulas1']; 
$txtMatricula1 		     = $_POST['txtMatricula1'];
$txtgerencia 			     = $_POST['txtgerencia']; 
$txtdpto 			     = $_POST['txtdpto']; 
$txtautacao1 			     = $_POST['txtautacao1']; 
$txtMemor			     = $_POST['txtMemor']; 
$txtMemo			     = $_POST['txtMemo'];
$txtobs			     = $_POST['txtobs'];
$txtdtren                        = $_POST['txtdtren'];
$txtgerenciarem                  = $_POST['txtgerenciarem'];
$txtdptorem                      = $_POST['txtdptorem'];
$txtgerenciadest                 = $_POST['txtgerenciadest'];
$txtdptodest                     = $_POST['txtdptodest'];
$cod_estado                      = $_POST['cod_estado'];
$txtautacao1                     = $_POST['txtautacao1']; 






$diarg 			    = substr($txtdtlota11, 0,2);
$anorg				    = substr($txtdtlota11, -4);
$mesrg 			    = substr($txtdtlota11, -7,2);


$txtdtlota11			    = $anorg.".".$mesrg.".".$diarg;





$diasaida 				= substr($txtdtren, 0,2);
$anosaida				= substr($txtdtren, -4);
$messaida 				= substr($txtdtren, -7,2);


$txtdtren		    	= $anosaida.".".$messaida.".".$diasaida;



//echo "$dtemissaorg";
$dia = date('d');
$mes = date('m');
$ano = date('Y');
$data1 =$ano.".".$mes.".".$dia;
$data =$dia.".".$mes.".".$ano;



/*******************************memorando************************************/
//echo "memo $txtMemo";
//echo "origem $txtgerenciarem";
//echo "destino $txtdptorem";

    $sqlgerencia = "SELECT * fROM memo WHERE memo='$txtMemo' and ORIGADM='$txtgerenciarem' and   ORIGDPTO='$txtdptorem' and dtemissao >= '2013-01-01' ";
    $resultadoger=mysql_query($sqlgerencia) or die (mysql_error());
    $linhas   =mysql_num_rows($resultadoger);
if($linhas<=0)
{

   while($pegar=mysql_fetch_array($resultadoger))
	{


    	$origadm    =$pegar["ORIGADM"];
    	$origdpto   =$pegar["ORIGDPTO"];
    	$destadm    =$pegar["DESTADM"];
    	$destdepto  =$pegar["DESTDEPTO"];


    	$munilota    =$pegar["MUNILOTA"];
	$lotaintcap  =$pegar["LOTAINTCAP"];
	$lotaadmesc  =$pegar["LOTAADMESC"];
       $dtemissao   =$pegar["DTEMISSAO"];

    }
 }
else
{
echo "<html><head><title>Resposta !!!</title></head>";
echo "<body background=\"background_mensagens.jpg\" style=\"background-attachment:fixed; background-repeat:no-repeat\">";
echo "<br><br><br>";
echo "<center><img src=\"faleconosco/atencao.gif\" alt=\"\"><p><font color=\"#ff6600\" face=\"Verdana\" size=\"4\">Memorando j� Cadastrado! <b></b></font></center>";
echo "<br><br><center><a href=\"mnlotacao.php\"><img src=\"faleconosco/button_voltar2_.gif\" alt=\"Voltar\" border=\"0\" /></a></center>";
echo "</body></html>";
exit;

}



/*******************************escola************************************/

$sqlgerencia = "select inep,descricao,endereco,bairro,numero,tipo,cep,fone from escola where inep='$txtinep1'";
$resultadoger=mysql_query($sqlgerencia) or die (mysql_error());
$linhas   =mysql_num_rows($resultadoger);
if($linhas>0)
{
   while($pegar=mysql_fetch_array($resultadoger))
	{

    	$descescola    =$pegar["descricao"];
    	$endescola     =$pegar["endereco"];
    	$bairroescola  =$pegar["bairro"];
    	$numeescola    =$pegar["numero"];
    	$tipoescola    =$pegar["tipo"];
    	$cepeescola    =$pegar["cep"];
       $foneescola    =$pegar["fone"];
		

    }
 }









/***************memorando remetente***************dEPARTAMENTO dESTINO************************************/

	$sqlgerencia = "SELECT codigo_dpto, descricao fROM departamento WHERE codigo_dpto='$txtdptorem'";
    $resultadoger=mysql_query($sqlgerencia) or die (mysql_error());
    $linhas   =mysql_num_rows($resultadoger);
if($linhas>0)
{
   while($pegar=mysql_fetch_array($resultadoger))
	{
    	$descdptorem    =$pegar["descricao"];

    }
 }

/******************************* memo rem gerencia**********************************/

	$sqlgerencia = "SELECT codigo,descricao fROM gerencia WHERE codigo='$txtgerenciarem'";
    $resultadoger=mysql_query($sqlgerencia) or die (mysql_error());
    $linhas   =mysql_num_rows($resultadoger);
if($linhas>0)
{
   while($pegar=mysql_fetch_array($resultadoger))
	{
    	$descgerenciarem    =$pegar["descricao"];

    }
 }




/***************memo destinatario***************dEPARTAMENTO dESTINO************************************/

	$sqlgerencia = "SELECT codigo_dpto, descricao fROM departamento WHERE codigo_dpto='$txtdptodest'";
    $resultadoger=mysql_query($sqlgerencia) or die (mysql_error());
    $linhas   =mysql_num_rows($resultadoger);
if($linhas>0)
{
   while($pegar=mysql_fetch_array($resultadoger))
	{
    	$descdptodest    =$pegar["descricao"];

    }
 }

/*******************************gerencia dest memo**********************************/


	$sqlgerencia = "SELECT codigo,descricao fROM gerencia WHERE codigo='$txtgerenciadest'";
    $resultadoger=mysql_query($sqlgerencia) or die (mysql_error());
    $linhas   =mysql_num_rows($resultadoger);
if($linhas>0)
{
   while($pegar=mysql_fetch_array($resultadoger))
	{
    	$descgerenciadest    =$pegar["descricao"];

    }
 }




/***lotacao****************************dEPARTAMENTO dESTINO************************************/

	$sqlgerencia = "SELECT codigo_dpto, descricao fROM departamento WHERE codigo_dpto='$txtdpto'";
    $resultadoger=mysql_query($sqlgerencia) or die (mysql_error());
    $linhas   =mysql_num_rows($resultadoger);
if($linhas>0)
{
   while($pegar=mysql_fetch_array($resultadoger))
	{
    	$descdpto    =$pegar["descricao"];

    }
 }

/*******************************gerencia************************************/

	$sqlgerencia = "SELECT codigo,descricao fROM gerencia WHERE codigo='$txtgerencia'";
    $resultadoger=mysql_query($sqlgerencia) or die (mysql_error());
    $linhas   =mysql_num_rows($resultadoger);
if($linhas>0)
{
   while($pegar=mysql_fetch_array($resultadoger))
	{
    	$descgerencia    =$pegar["descricao"];

    }
 }


/*******************************Habiltacao************************************/
	$sqlhab = "select codigo, descricao as descricao from habilitacao where codigo='$txtautacao1'";
    $resultadohab=mysql_query($sqlhab) or die (mysql_error());
    $linhashab   =mysql_num_rows($resultadohab);
	if($linhashab>0)
    {
       while($pegar=mysql_fetch_array($resultadohab))
	    {
        	$deschab    =$pegar["descricao"];
	    }
    }




/******************************************************************************************************/
$sqlgerencia = "select s.nome,s.email,s.fonecontato,s.celular,c.matricula,c.cargo,c.funcao,c.regime,c.chcontrato,c.dtadmissao,c.chcontrato,c.decreto,c.dtdecreto from contrato c,servidorrec s where c.matricula = '$txtMatricula1' and c.cpf =s.cpf";
    $resultadoger=mysql_query($sqlgerencia) or die (mysql_error());
    $linhas   =mysql_num_rows($resultadoger);


if($linhas>0)
{
   while($pegar=mysql_fetch_array($resultadoger))
	{
    	      

              $nome           =$pegar["nome"];
		$matricula      =$pegar["matricula"];
		$cargo          =$pegar["cargo"];
		$funcao         =$pegar["funcao"];
		$email          =$pegar["email"];
		$fonecontato    =$pegar["fonecontato"];
		$ch             =$pegar["chcontrato"];
		$regime         =$pegar["regime"];
		$celular        =$pegar["celular"];
    }
 }


/****************************************************************************************************************/
    $sqlgerencia = "select * from cargo  where cod_cargo = '$cargo' ";
    $resultadoger=mysql_query($sqlgerencia) or die (mysql_error());
    $linhas   =mysql_num_rows($resultadoger);

if($linhas>0)
{
   while($pegar=mysql_fetch_array($resultadoger))
	{
		$cargo         =$pegar["descricao"];
	}
 }




/****************************************************************************************************************/
    $sqlgerencia = "select * from funcao  where cod_funcao = '$funcao' ";
    $resultadoger=mysql_query($sqlgerencia) or die (mysql_error());
    $linhas   =mysql_num_rows($resultadoger);

if($linhas>0)
{
   while($pegar=mysql_fetch_array($resultadoger))
	{
		$funcaodesc         =$pegar["descricao"];
	}
 }
/********************************************************************/






$sqllota="select * from lotacao where cpf = '$cpf' and matricula = '$txtMatricula1'";
$resultadolota=mysql_query($sqllota) or die (mysql_error());
$linhaslota=mysql_num_rows($resultadolota);
if ($linhaslota > 0)
{




/*ATUALIZACAO  DA LOTACAO*/

   while($pegarlota=mysql_fetch_array($resultadolota))
	  {
	     $id          =$pegarlota["ID"];
         }


$sqlalteralota = "update lotacao set obslotacao = '$txtobs',dtsaida = '$data1' where id = '$id'";
if(@mysql_query($sqlalteralota))
 {

//echo "aaa $txtqdtaaulas1";
  /*INSERINDO LOTACAO  DA LOTACAO*/ 
  $sqllotacao1 = "insert into lotacao(cpf,matricula,lotado,gerencia,departamento,inep,dtlotacao,qtdaaula,areaatuacao,chlotacao,usuario,memo)
 values ('$cpf','$txtMatricula1','$selectlotacao1','$txtgerencia','$txtdpto','$txtinep1','$txtdtlota11','$txtqdtaaulas1','$txtautacao1','$selectch1lota','$login','$txtMemo')";


   if(@mysql_query($sqllotacao1))
    {


     $sqlid = "select last_insert_id()";
     $respid= mysql_query($sqlid);
     $idlotacao  = mysql_fetch_array($respid);
     $idlotacao = $idlotacao[0]; 



      // echo "Registro efetuado com sucesso<br/>";

//*****************inserindo memorando******************************


$sql = "insert into memo(ORIGADM,ORIGDPTO,DESTADM,DESTDEPTO,MEMO,ANO,ASSUNTO,DATAMEMO,MATRICULA,SITUACAO,OBS,CPF,DESCDPTOO,DESCDPTOD,DTEMISSAO,LOTAINTCAP,LOTAADMESC,MUNILOTA,DATA,USUARIO,MEMOR,DEPARTAMENTO) 
values ('$txtgerenciarem','9','$txtgerenciadest','$txtdptodest','$txtMemo','$ano','12','$data1','$txtMatricula1','A','$txtobs','$cpf','LOTACAO','ESCOLA','$data1','C','E','$cod_estado','$data','$login','$idlotacao','$nte')";



             if(@mysql_query($sql))
             {
		         //verifiquei acima se deu certo o comando e aqui verifico se foi mesmo gravado o dado no banco
              if(mysql_affected_rows() == 1)
	         	 {
         //          echo "Registro efetuado com sucesso<br/>";

?>




<html>
<head>
<script language="javascript">
function DoPrinting() {
    if (!window.print) {
        alert("Netscape, Internet Explorer 4.0 ou superior!")
        return
    }
    window.print();
}
</script>



<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1" />
<title>SEDUC-RO</title>

</head>




<title>:: Memo Lota��o ::</title>
<style type="text/css">
<!--
.style1 {
	font-size: large;
	font-weight: bold;
}
.style2 {
	font-size: x-large;
	font-weight: bold;
}
.style3 {
	font-size: large;
	font-family: Verdana, Arial, Helvetica, sans-serif;
}
.style5 {font-family: Verdana, Arial, Helvetica, sans-serif}
.style6 {font-size: xx-large; font-weight: bold; font-family: Verdana, Arial, Helvetica, sans-serif; }
.style7 {font-size: x-large; font-weight: bold; font-family: Verdana, Arial, Helvetica, sans-serif; }
.style8 {font-size: large; font-weight: bold; font-family: Verdana, Arial, Helvetica, sans-serif; }
-->
</style>
</head>

<body><center>
<div align="center">
  <table width="988" border="1" cellpadding="0" cellspacing="0" bordercolor="#000000">
    <tr>
      <td colspan="7" rowspan="4"><table width="100%" border="0" cellpadding="0" cellspacing="0">
        <tr>
          <td width="120" class="style5"><div align="center"><img src="img/logo_brazil.jpg" /></div></td>
          <td width="706" class="style5"><p align="center" class="style2">SECRETARIA DE ESTADO DA EDUCA��O<br>
            N�cleo de Apoio aos Munic�pios</p></td>
        </tr>
      </table></td>
      <td width="131" height="36" bgcolor="#CCCCCC"><div align="center" class="style3">Data </div></td>
    </tr>
    <tr>
      <td height="46"><div align="center" class="style3"><span class="style5"></span><span class="style5"><? echo $data ?></span></div></td>
    </tr>
    <tr>
      <td height="47" bgcolor="#CCCCCC"><div align="center" class="style3">NAM</div></td>
    </tr>
    <tr>
      <td height="38" class="style3"><div align="center"><? echo $nte ?></div></td>
    </tr>
    <tr>
      <td height="68" colspan="8" bgcolor="#999999"><div align="center" class="style7">Memorando de Lota��o-<? echo $txtMemo ?>/<? echo $ano ?></div></td>
      <br>
    </tr>
    <tr>
      <td width="550"></td>
      <td width="400"></td>
    </tr>
  </table><BR>
    <table width="988" border="0" cellpadding="0" cellspacing="0" bordercolor="#000000">

    <tr>
      <td><div align="left" class="style3"> MEMO N.<? echo $txtMemo ?>/<? echo $ano ?>LOTACA��O/GRH/SEDUC </div></td>
      <td><div align="left" class="style3"><span class="style31"></span></div></td>
    </tr>
    
    <tr>
      <td colspan="2" align="right" class="style5">Porto Velho, <strong><? echo $data ?></strong></td>
    </tr>

    <tr>
      <td>&nbsp;</td>
      <td>&nbsp;</td>
    </tr>

    <tr>
      <td><strong><div align="left"  class="style5">LOTACA��O/GRH/SEDUC</div></strong></td>
      <td>&nbsp;</td>
    </tr>

    <tr>
      <td><div align="left" class="style5">PARA: <? echo $descgerenciadest?>/<? echo $descgerencia1 ?>/SEDUC </div></td>
      <td>&nbsp;</td>
    </tr>

    



    <tr>
      <td><div align="left" class="style5">ASSUNTO: <strong>Lota��o de Servidor</strong></div></td>
      <td>&nbsp;</td>
    </tr>

    <tr>
      <td>&nbsp;</td>
      <td>&nbsp;</td>
    </tr>


    <tr>
      <td>APRESENTA��O DE SERVIDOR</td>
      <td></td>
    </tr>

    <tr>
      <td>&nbsp;</td>
      <td>&nbsp;</td>
    </tr>

    <tr>
      <td>&nbsp;</td>
      <td>&nbsp;</td>
    </tr>

<?

if (trim($selectlotacao1)=='2')
 {   
?>

    <tr>
       <td>
          <p>
            INEP: <strong><? echo $txtinep1 ?></strong><br>
            Escola: <strong><? echo $descescola ?></strong><br>
            Endere�o: <strong><? echo $endescola ?></strong><br>
            Bairro: <strong><? echo $bairroescola ?></strong><br>
            Nr: <strong><? echo $numeescola ?></strong><br>
		    Tipo: <strong><? echo $tipoescola ?></strong><br>
            CEP: <strong><? echo $cepeescola ?></strong><br>
		    Fone: <strong><? echo $foneescola ?></strong><br>
		   </p>
      </td>
    </tr>

<?
}
else
 {   
?>
    <tr>
       <td>
          <p>
            Gerencia: <strong><? echo $descgerencia ?></strong><br>
            Departamento: <strong><? echo $descdpto ?></strong><br>
		   </p>
      </td>
    </tr>
<?
}
?>



     <tr>
      <td>&nbsp;</td>
      <td>&nbsp;</td>
    </tr>
    <tr>
      <td>&nbsp;</td>
      <td>&nbsp;</td>
    </tr>
     <tr>
      <td>&nbsp;</td>
      <td>&nbsp;</td>
    </tr>
    <tr>
      <td>
        <div align="left" class="style5">

         <p>
		    Nome:     <strong><? echo $nome ?>       </strong><br>
            E-MAIL:   <strong><? echo $email ?>      </strong><br>
            Telefone: <strong><? echo $fonecontato?> </strong><br>
            Celular:  <strong><? echo $celular ?>    </strong><br>
	    Regime:   <strong><? echo $regime ?>     </strong><br>
	    Data Lota��o:   <strong><? echo $txtdtlota1imprimi ?>     </strong><br>


		  </p>
      </div>

      </td>
      <td>
    <p>MATRICULA: <strong><? echo $matricula ?></strong></p>
    <p>CPF: <strong><? echo $cpf ?></strong></p></td>
    </tr>
    <tr>
      <td>&nbsp;</td>
      <td>&nbsp;</td>
    </tr>




    <tr>
      <td class="style5">
        <p>Habilita��o: <strong><? echo $deschab ?></strong></p>
        <p>Fun��o: <strong><? echo $funcaodesc ?></strong></p>
      </td>
      <td class="style5">
        <p>Vinculo: <strong><? echo $regime ?></strong></p>
        </td>
    </tr>
    <tr>
      <td class="style5">&nbsp;</td>
      <td class="style5">&nbsp;</td>
    </tr>
    <tr>
      <td class="style5">&nbsp;</td>
      <td class="style5">&nbsp;</td>
    </tr>
    <tr>
      <td colspan="2" class="style5"><blockquote>
        <p><strong>Obs: </strong></p>
      </blockquote></td>
      </tr>
    <tr>
      <td colspan="2" class="style5"><blockquote><strong><? echo $txtobs ?></strong></blockquote></td>
     </tr>
    

	
	<tr>
      <td class="style5">&nbsp;</td>
      <td class="style5">&nbsp;</td>
    </tr>
    <tr>
      <td class="style5">&nbsp;</td>
      <td class="style5">&nbsp;</td>
    </tr>
    <tr>
      <td class="style5">&nbsp;</td>
      <td class="style5">&nbsp;</td>
    </tr>
    <tr>
      <td colspan="2" class="style5"><p align="center">__________________________________<br>

      </tr>
    <tr>
      <td class="style5">&nbsp;</td>
      <td class="style5">&nbsp;</td>
    </tr>

<tr>
<td align="left">
<form>
  <input type="button"  value="Imprimir a p�gina"   onClick="DoPrinting()"  align="left" />
  <li><a href="mnlotacao.php"   title="Volta ao menu principal">Volta ao Menu</a></li>
</form>
</td>
</tr>



  </table>
  <script>
   cor_tabela("tabzebra");
 </script>

</div>
</div>
    </tr>
    <tr>

    </tr>
    <tr>
<tr>
<td align="center">

</td>
</tr>
</body>
</html>



<?
                }
            }
            
          else
           {
        //verifico se nao estao tentando gravar um dado que ja existe, pois usei UNIQUE na tabela
           if(mysql_errno() == 1062)
		     {
                echo $erros[mysql_errno()];
                exit;
             }
		    else
		     {
             echo "Erro nao foi possivel efetuar o cadastro";
             exit;
             }
          }
    }

 }

}
@mysql_close();
}
?>
