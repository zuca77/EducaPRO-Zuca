<?php

    require_once '../start.php';
    $pdo = new Conexao;

    $title = 'Relota��o';

    $id = $_GET['codigo'];

    $form_data = isset($_SESSION['form_data']) ? $_SESSION['form_data'] : null;
    unset($_SESSION['form_data']);

    function oldInputvalue($input_name, $returnIfNull = null) {
        global $form_data;
        return isset($form_data[$input_name]) ? $form_data[$input_name] : $returnIfNull;
    }

    $sql = "SELECT * FROM lotacao WHERE id = :id";
    $query = $pdo->prepare($sql);
    $query->execute([':id' => $id]);
    $lotacao = $query->fetch();

    $sql = "SELECT inep, descricao,municipio FROM escola WHERE inep = :inep";
    $query = $pdo->prepare($sql);
    $query->execute([':inep' => $lotacao['inep']]);
    $escola = $query->fetch();

    $sql = "SELECT codigo, descricao FROM municipio WHERE codigo = :municipio";
    $query = $pdo->prepare($sql);
    $query->execute([':municipio' => $escola['municipio']]);
    $municipio = $query->fetch();

    $sql = "SELECT * FROM contrato WHERE matricula = :matricula AND cpf = :cpf";
    $query = $pdo->prepare($sql);
    $query->bindParam(':matricula',  $lotacao['matricula']);
    $query->bindParam(':cpf', $lotacao['cpf']);
    $contrato = $query->execute() ? $query->fetch() : null;

    $sql = "SELECT * FROM servidorrec WHERE CPF = :cpflotacao";
    $query = $pdo->prepare($sql);
    $query->execute([':cpflotacao' => $lotacao['cpf']]);
    $servidor = $query->fetch();

    //lista ger�ncias ativas
    $sql = "SELECT codigo, descricao
                  FROM gerencia WHERE ativo = 'S'
                  ORDER BY descricao";
    $gerencias = $pdo->query($sql)->fetchAll();

    //Lista de municipios
    $sql = "SELECT codigo, descricao as nome FROM municipio ORDER BY descricao";
    $list_municipios = $pdo->query($sql)->fetchAll();

    //Get anos letivos
    $sql = "SELECT ano FROM ano_letivo WHERE ano >= :anoAtual ORDER BY ano DESC";
    $query = $pdo->prepare($sql);
    $query->execute([':anoAtual' => date('Y')]);
    $anos_letivos = $query->fetchAll();

    $sql = "SELECT codigo, descricao
                FROM habilitacao
                WHERE codigo NOT IN (69,70,71, 72,73, 53)
                ORDER BY descricao";
    $habilitacoes = $pdo->query($sql)->fetchAll();

    $departamentos_remetente = null;
    $departamentos_lotacao = null;

    $sqlDepartamento = "SELECT codigo_dpto, descricao
                        FROM departamento
                        WHERE gerencia = :codigo_departamento
                        ORDER BY descricao";

    if ($old_input_value_dpto_remetente = oldInputvalue('txtdptorem')) {
        $query = $pdo->prepare($sqlDepartamento);
        $query->execute([':codigo_departamento' => oldInputvalue('txtgerenciarem') ]);
        $departamentos_remetente = $query->fetchAll();
    }

    if ($old_input_value_departamento_lotacao = oldInputvalue('txtdpto')) {
        $query = $pdo->prepare($sqlDepartamento);
        $query->execute([':codigo_departamento' => oldInputvalue('txtgerencia')]);
        $departamentos_lotacao = $query->fetchAll();
    }

    //lista ger�ncias ativas
    $sql = "SELECT codigo, descricao
                  FROM gerencia WHERE ativo = 'S'
                  ORDER BY descricao";
    $gerencias = $pdo->query($sql)->fetchAll();

    //Lista de municipios
    $sql = "SELECT codigo, descricao as nome FROM municipio ORDER BY descricao";
    $list_municipios = $pdo->query($sql)->fetchAll();

    //Get anos letivos
    $sql = "SELECT ano FROM ano_letivo WHERE ano >= :anoAtual ORDER BY ano DESC";
    $query = $pdo->prepare($sql);
    $query->execute([':anoAtual' => date('Y')]);
    $anos_letivos = $query->fetchAll();

    $sql = "SELECT codigo, descricao
                FROM habilitacao
                ORDER BY descricao";
    $habilitacoes = $pdo->query($sql)->fetchAll();

?>

<!DOCTYPE HTML>
<html>
<head>
    <?php require_once page_head(); ?>
    <link rel="stylesheet" href="/js/jquery-ui-1.12.1/jquery-ui.min.css">
    <link rel="stylesheet" href="/js/jquery-ui-1.12.1/jquery-ui.theme.css">
    <style>
        .ui-autocomplete-loading {
            background: white url("/img/ui-anim_basic_16x16.gif") right center no-repeat;
        }
    </style>
</head>
<body>
    <?php require_once page_header(); ?>

    <div class="container">
        <form  name="form" class="form" action="insere_relotacao.php" method="POST">
            <fieldset class="well well-sm">
                <legend>Dados Pessoais</legend>

                <div class="row">
                    <div class="col-md-2">
                        <div class="form-group">
                            <label for="cpf">CPF</label>
                            <input type="text" class="form-control" name="cpf" id="cpf" value="<?= $lotacao['cpf']; ?>" readonly>
                        </div>
                    </div>
                    <div class="col-md-6">
                        <div class="form-group">
                            <label for="txtNome">Nome completo</label>
                            <input type="text" class="form-control" name="txtNome" value="<?= $servidor['nome']; ?>" id="txtNome" readonly>
                        </div>
                    </div>
                </div>

                <div class="row">
                    <div class="col-md-2">
                        <div class="form-group">
                            <label for="txtFoneSetor">Telefone Comercial</label>
                            <input type="text" class="form-control" name="txtFoneSetor" value="<?= $servidor['fonesetor']; ?>" id="txtFoneSetor"  maxlength="20" readonly>
                        </div>
                    </div>
                    <div class="col-md-2">
                        <div class="form-group">
                            <label for="txtFoneRes">Telefone Residencial</label>
                            <input type="text" class="form-control" name="txtFoneRes" value="<?= $servidor['foneresidencial']; ?>" id="txtFoneRes" maxlength="20" readonly>
                        </div>
                    </div>
                    <div class="col-md-2">
                        <div class="form-group">
                            <label for="txtCelular">Telefone Celular</label>
                            <input type="text" class="form-control" name="txtCelular" value="<?= $servidor['celular']; ?>" id="txtCelular" maxlength="20" readonly>
                        </div>
                    </div>
                    <div class="col-md-2">
                        <div class="form-group">
                            <label for="txtcontato">Telefone Contato</label>
                            <input type="text" class="form-control" name="txtcontato" value="<?= $servidor['fonecontato']; ?>" id="txtcontato" maxlength="25" readonly>
                        </div>
                    </div>
                    <div class="col-md-4">
                        <div class="form-group">
                            <label for="txtEmail">E-mail</label>
                            <input type="text" class="form-control" name="txtEmail" value="<?= $servidor['email']; ?>" id="txtEmail" maxlength="80" readonly>
                        </div>
                    </div>
                </div>
            </fieldset>

            <fieldset class="well well-sm">
                <legend>Dados Contrato</legend>

                <div class="row">
                    <div class="col-md-2">
                        <div class="form-group">
                            <label for="txtid">ID</label>
                            <input type="text" name="txtid" id="txtid" class="form-control" value="<?= $id ?>"  readonly/>
                        </div>
                    </div>
                    <div class="col-md-2">
                        <div class="form-group">
                            <label for="txtCpf">CPF</label>
                            <input type="text" name="txtCpf" id="txtCpf" class="form-control" value="<?= $contrato['cpf']; ?>"  readonly />
                        </div>
                    </div>
                    <div class="col-md-2">
                        <div class="form-group">
                            <label for="txtMatricula1">Matricula</label>
                            <input type="text" name="txtMatricula1" id="txtMatricula1" class="form-control" value="<?= $contrato['matricula']; ?>"  readonly />
                        </div>
                    </div>
                </div>

                <div class="row">
                    <div class="col-md-2">
                        <div class="form-group">
                            <label for="txtDataAdmissao">Data Admiss�o</label>
                            <input type="text" name="txtDataAdmissao" id="txtDataAdmissao" class="form-control" value="<?= date("d/m/Y",strtotime($contrato['dtadmissao'])); ?>"  readonly/>
                        </div>
                    </div>
                    <div class="col-md-2">
                        <div class="form-group">
                            <label for="txtChContrato">CH Contrato</label>
                            <input type="text" name="txtChContrato" id="txtChContrato" class="form-control" value="<?= $contrato['chcontrato']; ?>" readonly/>
                        </div>
                    </div>
                </div>

                <div class="row">
                    <div class="col-md-2">
                        <div class="form-group">
                            <label for="txtDecreto">N� Decreto</label>
                            <input type="text" name="txtDecreto"  class="form-control" value="<?= $contrato['decreto']; ?>" maxlength="11" id="txtDecreto" readonly/>
                        </div>
                    </div>
                    <div class="col-md-2">
                        <div class="form-group">
                            <label for="txtDataAdmissao">Data Decreto</label>
                            <input type="text" name="txtDataAdmissao"  id="txtDataAdmissao" class="form-control" value="<?= date("d/m/Y", strtotime($contrato['dtdecreto'])); ?>" readonly/>
                        </div>
                    </div>
                    <div class="col-md-2">
                        <div class="form-group">
                            <label for="dof">Publicado DIOF</label>
                            <input type="text" name="dof"  class="form-control" value="<?= $contrato['dof']; ?>" maxlength="10" id="dof"  readonly />
                        </div>
                    </div>
                    <div class="col-md-2">
                        <div class="form-group">
                            <label for="dtdof">Data DIOF</label>
                            <input type="text" name="dtdof" class="form-control" value="<?= date("d/m/Y", strtotime($contrato['dtdof'])); ?>"  id="dtdof" readonly />
                        </div>
                    </div>
                </div>
            </fieldset>

            <fieldset class="well well-sm">
                <legend>Lota��o Atual</legend>

                <div class="row">
                    <div class="col-md-2">
                        <div class="form-group">
                            <label for="txtInepEscola">INEP</label>
                            <input type="text" name="txtInepEscola" id="txtInepEscola" class="form-control" value="<?= $lotacao['inep']; ?>" readonly/>
                        </div>
                    </div>

                    <div class="col-md-4">
                        <div class="form-group">
                            <label for="txtescola">Escola</label>
                            <input type="text" name="txtescola" class="form-control" value="<?= $escola['descricao']; ?>" id="txtescola" readonly/>
                        </div>
                    </div>

                    <div class="col-md-4">
                        <div class="form-group">
                            <label for="txt">Munic�pio</label>
                            <input type="text" name="txtescola" class="form-control" value="<?= $municipio['descricao']; ?>" id="txtescola" readonly/>
                        </div>
                    </div>
                    <div class="col-md-2">
                        <div class="form-group">
                            <label for="txtdtren">Data de Apresenta��o</label>
                            <input type="text" name="txtdtren" class="form-control" value="<?= date('d/m/Y');?>"  id="txtdtren"  readonly/>
                        </div>
                    </div>
                </div>
            </fieldset>

            <h3>Nova Lota��o - Memorando</h3>
            <hr>
            <div class="row">
                <div class="col-md-12">
                    <fieldset class="well well-sm">
                        <legend>Rementente</legend>
                        <div class="row">
                            <div class="col-md-6">
                                <div class="form-group">
                                    <label for="txtgerenciarem">Ger�ncia</label>&nbsp;
                                    <select name="txtgerenciarem" id="txtgerenciarem" class="form-control input-lg" autofocus required>
                                        <option value=" ">Selecione a administra��o</option>
                                        <?php
                                            foreach ($gerencias as $gerencia) {
                                                echo "<option value='{$gerencia['codigo']}'";
                                                echo oldInputvalue('txtgerenciarem') == $gerencia['codigo'] ? ' selected' : '';
                                                echo ">{$gerencia['descricao']}</option>";
                                            }
                                        ?>
                                    </select>
                                </div>
                            </div>
                            <div class="col-md-6">
                                <div class="form-group">
                                    <label for="txtdptorem">Departamento</label> &nbsp;
                                    <select name="txtdptorem" id="txtdptorem" class="form-control input-lg" <?= $old_input_value_dpto_remetente ? '' : ' disabled' ?>>
                                        <?php
                                            if ($old_input_value_dpto_remetente) {
                                                foreach ($departamentos_remetente as $departamento) {
                                                    echo "<option value='{$departamento['codigo_dpto']}'";
                                                    echo $old_input_value_dpto_remetente == $departamento['codigo_dpto'] ? ' selected' : '';
                                                    echo ">{$departamento['descricao']}</option>";
                                                }
                                            } else {
                                                echo '<option value="">Primeiro escolha uma ger�ncia</option>';
                                            }
                                        ?>
                                    </select>
                                </div>
                            </div>
                        </div>
                    </fieldset>
                </div>
            </div>

            <fieldset class="well well-sm">
                <legend>Lota��o</legend>
                <div class="row">
                    <div class="col-md-2">
                        <div class="form-group">
                            <label for="txtdtlota11">Data Lota��o</label>
                            <input type="text" name="txtdtlota11" class="form-control input-lg data" value="<?= oldInputvalue('txtdtlota11', '') ? oldInputvalue('txtdtlota11', '') : date('d/m/Y')?>" id="txtdtlota11" required>
                        </div>
                    </div>

                    <div class="col-md-2">
                        <div class="form-group">
                            <label for="txtMemo">Memorando</label>
                            <input type="text" name="txtMemo" class="form-control input-lg" value="<?= oldInputvalue('txtMemo', '')?>" id="txtMemo" required style="text-transform: uppercase;">
                        </div>
                    </div>
                </div>

                <div class="row">
                    <div class="col-md-4">
                        <div class="form-group" title="Campo obrigat�rio">
                            <label for="selectlotacao1">Lota��o</label>
                            <select id="selectlotacao1" name="selectlotacao1" class="form-control input-lg" required>
                                <?php
                                    $options = [
                                        null => 'Selecione a lota��o',
                                        1 => 'ADMINISTRACAO',
                                        2 => 'ESCOLA',
                                        3 => 'ADMINISTRA��O E ESCOLA'
                                    ];

                                    foreach ($options as $key => $value) {
                                        echo "<option value='{$key}' ";
                                        echo oldInputvalue('selectlotacao1') == $key ? 'selected' : '';
                                        echo ">{$value}</option>";
                                    }
                                ?>
                            </select>
                        </div>
                    </div>
                    <div class="col-md-4">
                        <div class="form-group" title="Campo obrigat�rio">
                            <label for="txtgerencia">Ger�ncia</label>
                            <select name="txtgerencia" id="txtgerencia" class="form-control input-lg" <?=  oldInputvalue('txtgerencia') ? '' : ' disabled'?>>
                                <option value="">Selecione a administra��o</option>
                                <?php
                                    foreach ($gerencias as $gerencia) {
                                        echo "<option value='{$gerencia['codigo']}'";
                                        echo oldInputvalue('txtgerencia') == $gerencia['codigo'] ? ' selected' : '';
                                        echo ">{$gerencia['descricao']}</option>";
                                    }
                                ?>
                            </select>
                        </div>
                    </div>
                    <div class="col-md-4">
                        <div class="form-group" title="Campo obrigat�rio">
                            <label for="txtdpto">Departamento</label>
                            <select name="txtdpto" id="txtdpto" class="form-control input-lg" <?= empty($departamentos_lotacao) ? ' disabled' : ''?>>
                                <?php
                                if ($old_input_value_departamento_lotacao) {
                                    foreach ($departamentos_lotacao as $departamento) {
                                        echo "<option value='{$departamento['codigo_dpto']}'";
                                        echo $old_input_value_departamento_lotacao == $departamento['codigo_dpto'] ? ' selected' : '';
                                        echo ">{$departamento['descricao']}</option>";
                                    }
                                }
                                ?>
                            </select>
                        </div>
                    </div>
                </div>

                <div class="collapse <?= oldInputvalue('selectlotacao1') == 2 ? ' in' : ''?>" id="row_escola">
                    <div class="row">
                        <div class="col-md-8">
                            <div class="form-group">
                                <label for="txtdescescola1">Escola</label>
                                <input type="text" name="txtdescescola1" class="form-control input-lg ui-autocomplete-input" value="<?= oldInputvalue('txtdescescola1') ?>" id="txtdescescola1" autocomplete="off" placeholder="Digite o INEP ou o nome da escola">
                                <input type="hidden" name="txtinep1" value="<?= oldInputvalue('txtinep1') ?>" id="txtinep1">

                                <span class="help-block" id="escola-message-box"></span>
                            </div>
                        </div>

                        <div class="col-md-2">
                            <div class="form-group">
                                <label for="txtqdtaaulas1">Qtd Aulas</label>
                                <input type="text" name="txtqdtaaulas1" value="<?= oldInputvalue('txtqdtaaulas1')?>" class="form-control input-lg" id="txtqdtaaulas1" maxlength="2">
                            </div>
                        </div>

                        <div class="col-md-2">
                            <div class="form-group">
                                <label for="selectch1lota">Carga Hor�ria</label>
                                <select id="selectch1lota" class="form-control input-lg" name="selectch1lota" >
                                    <?php
                                        $options = [
                                            '' => 'Selecione',
                                            0 => 0,
                                            20 => '20',
                                            25 => '25',
                                            40 => '40'
                                        ];
                                        foreach ($options as $key => $value) {
                                            echo "<option value='{$key}' ";
                                            echo oldInputvalue('selectch1lota') == $key ? 'selected' : '';
                                            echo ">{$value}</option>";
                                        }
                                    ?>
                                </select>
                            </div>
                        </div>
                    </div>
                </div>

                <div class="row">
                    <div class="col-md-6">
                        <div class="form-group">
                            <label for="txtautacao1">Area de Atua��o</label>
                            <select name="txtautacao1" id="txtautacao1"  class="form-control input-lg" required>
                                <option value="">Selecione uma area de atua��o</option>
                                <?php
                                    foreach ($habilitacoes as $habilitacao) {
                                        echo "<option value='{$habilitacao['codigo']}'";
                                        echo (oldInputvalue('txtautacao1') == $habilitacao['codigo']) ? ' selected' : '';
                                        echo ">{$habilitacao['descricao']}</option>";
                                    }
                                ?>
                            </select>
                        </div>
                    </div>

                </div>

                <div class="row">
                    <div class="col-md-12">
                        <div class="form-group">
                            <label for="txtobs">Observa��o:</label>
                            <textarea name="txtobs" class="form-control" rows="5" id="txtobs" required><?= trim(oldInputvalue('txtobs', ''))?></textarea>
                        </div>
                    </div>
                </div>

            </fieldset>

            <div class="well well-sm">
                <button type="submit" class="btn btn-primary btn-submit-wait" id="btn-salvar-relotacao">SALVAR</button>
                <button type="button" class="btn btn-default btn-back pull-right">VOLTAR</button>
            </div>
        </form>
    </div>

    <?php require_once page_footer(); ?>

    <script src="/js/jquery-ui-1.12.1/jquery-ui.min.js"></script>
    <script src="js/form-lotacao-relotacao-001.js"></script>
</body>
</html>