<?php

if(file_exists("../conexao_mysql.php")) 
{
        require "../conexao_mysql.php";             
		$ano  = date("Y");
}
else 
{
        echo "Conex�o nao foi encontrado";
        exit;
}


?>

<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01//EN"
	"http://www.w3.org/TR/html4/strict.dtd">
<head>


    <meta http-equiv="content-type" content="text/html; charset=ISO-8859-1" />
	<title>SEDUC-RO</title>
	<link rel="stylesheet" href="style/forms.css" type="text/css" />
	<link rel="stylesheet" href="estilo.css" type="text/css" />
	<link rel="stylesheet" href="style/menu.css" type="text/css" />

	
	<link href="tablecloth/tablecloth.css" rel="stylesheet" type="text/css" media="screen" />
	
	<script type="text/javascript" src="tablecloth/tablecloth.js"></script>
	<script src="lib/jquery-1.4.2.js" type="text/javascript"></script>
	<script src="lib/validate.js" type="text/javascript"></script>
	<script src="lib/forms.js" type="text/javascript"></script>
	<script src="genericlota.js" type="text/javascript"></script>
    <script src="lib/jquery.maskedinput-1.1.1.js" type="text/javascript"></script>


	<link type="text/css" href="jquery-ui-1.8.18.custom/css/ui-lightness/jquery-ui-1.8.18.custom.css" rel="stylesheet" />
	<script type="text/javascript" src="jquery-ui-1.8.18.custom/js/jquery-ui-1.8.18.custom.min.js"></script>

<script language="javascript">
function DoPrinting() {
    if (!window.print) {
        alert("Netscape, Internet Explorer 4.0 ou superior!")
        return
    }
    window.print();
}
</script>


</head>
<body>
	<div id="warpper">
		<div id="header">
		    <img src= "img/seduc_topo.jpg"/>

		</div>
    <div id="container">
			<div id="content">

				<form  name="form" class="form" action="insere_lotacao.php" method="POST">
				 <div id="tema">
<p><center><font size="4"> Lota��o</font> </center></p>
				  </div>

<?php

$id      = $_GET['codigo'];
$cpf     =  $_POST["cpf"];
$cpflota =  $_POST["cpf"];





$sqldados="select * from servidorrec where cpf = '$cpf'";
$resultadodados=mysql_query($sqldados) or die (mysql_error());
$linhasdados=mysql_num_rows($resultadodados);
if($linhasdados>0)
{
   while($pegardados=mysql_fetch_array($resultadodados))
   {
    $cpf              =$pegardados["cpf"];
	$nome             =$pegardados["nome"];
	$mae              =$pegardados["mae"]; 	
    $pai              =$pegardados["pai"]; 	
	$endereco         =$pegardados["endereco"]; 	
	$bairro           =$pegardados["bairro"]; 	
	$fonesetor        =$pegardados["fonesetor"]; 	
	$fonecontato      =$pegardados["fonecontato"]; 	
	$foneresidencial  =$pegardados["foneresidencial"]; 	
	$celular          =$pegardados["celular"]; 	
	$email            =$pegardados["email"]; 	

    }
  }
 else
  {
					echo "<html><head><title>Resposta. </title></head>";
					echo "<body background=\"background_mensagens.jpg\" style=\"background-attachment:fixed; background-repeat:no-repeat\">";
					echo "<br>";
					echo "<center><p><font color=\"#ff6600\" face=\"Verdana\" size=\"4\">Servidor n�o Localizado. <b></b></font></center>";
					echo "<br><br><center><a href=\"form_mov_serv.php\"><img src=\"faleconosco/button_voltar2_.gif\" alt=\"Voltar\" border=\"0\" /></a></center>";
					echo "</body></html>";
					exit;


  }

?>
	
	
					<p>
						<label for="txtCPF">CPF</label>
						<input type="text" name="cpf" style="width:110px"  maxlength="11" id="cpf"  value= "<? echo $cpf; ?>"  readonly="true"/>

					</p>
	

					<p>
						<label for="txtNome">Nome</label>
						<input type="text" name="txtNome" style="width:565px" maxlength="60" value= "<? echo $nome; ?>" id="txtNome" readonly="true"/>
					</p>
					
					<p>
						<label for="lblmae">Nome M�e</label>
						<input type="text" name="txtmae" style="width:565px" maxlength="60" value= "<? echo $mae; ?>" id="txtmae" readonly="true"/>
					</p>
					<p>
						<label for="lblpai">Nome Pai</label>
						<input type="text" name="txtpai" style="width:565px" maxlength="60" value= "<? echo $pai; ?>" id="txtpai"  readonly="true"/>
					</p>


					<p>
						<label for="lblEndereco">Endere�o</label>
						<input type="text" name="txtEndereco" style="width:565px" value= "<? echo $endereco; ?>"  maxlength="60" size="60" id="txtEndereco" readonly="true"/>
					</p>

					<p>
						<label for="lblEndereco">Complemento</label>
						<input type="text" name="txtcomplemento" style="width:565px" value= "<? echo $bairro; ?>"  maxlength="40" size="60" id="txtcomplemento" readonly="true"/>
					</p>


					<p>
						<label for="lblBairro">Bairro</label>
						<input type="text" name="txtBairro" value= "<? echo $bairro; ?>" id="txtBairro"  maxlength="40" readonly="true"/>
						<label for="lblBairro">N.</label>
						<input type="text" name="txtnr" style="width:60px" value= "<? echo $numero; ?>" id="txtnr" maxlength="5" readonly="true"/>
			            <label for="txtCEP">CEP</label>
            			<input id="txtcep" name="txtcep" type="text" style="width:90px" value= "<? echo $cep; ?>" maxlength="8" onKeyPress="return Enum(event)" readonly="true"/>
					</p>
					<p>
						<label for="txtFoneSetor">Telefone Comercial</label>
						<input type="text" name="txtFoneSetor" style="width:90px" value= "<? echo $fonesetor; ?>" id="txtFoneSetor"  maxlength="20" readonly="true"/>
						<label for="txtFoneRes">Resid�ncial</label>
						<input type="text" name="txtFoneRes" style="width:90px" value= "<? echo $foneresidencial; ?>" id="txtFoneRes" maxlength="20" readonly="true"/>
						<label for="txtCelular">Celular</label>
						<input type="text" name="txtCelular" style="width:90px" value= "<? echo $celular; ?>" id="txtCelular" maxlength="20" readonly="true"/>
						<label for="txtCelular">Contato</label>
						<input type="text" name="txtcontato" style="width:90px" value= "<? echo $fonecontato; ?>" id="txtcontato" maxlength="25" readonly="true"/>

					</p>
					<p>
						<label for="txtEmail">E-mail</label>
						<input type="text" name="txtEmail" style="width:565px" value= "<? echo $email; ?>" id="txtEmail" maxlength="80" readonly="true"/>
					</p>

				<p id="finish">
<input type="button" value=" Voltar " onclick="history.go(-1);">
<input type="button"  value="Imprimir a p�gina"   onClick="DoPrinting()" />
					</p>

<? 


?>



				 <div id="tema">
<p><center><font size="4"> Hist�rico</font> </center></p>
				  </div>
				</form>
			</div>
		</div>

<table border="0" width="100%">
<tr>
 <td width="5"><b>Matricula</b></td><td><b>Ger�ncia/INEP</b></td><td><b>Descri��o</b></td><td><b>Data Lota��o</b></td><td><b>Data Saida</b></td>
<td><b>Data Ren</b></td><td><b>Data Escola</b></td>
<td><b>CH</b></td><td><b>Qtda Aula</b>
</tr>


<?
/**************Seleciona toda tabela**********/

 $idlota	 = $cpflota;


 $tabela_toda = "select * from lotacao where cpf = '$idlota'";
 $query = mysql_query($tabela_toda, $conexao) or die(mysql_error());


 $re = mysql_query("SELECT count(*) as codigo FROM lotacao where cpf = '$idlota'");
 $total = mysql_result($re, 0, "codigo");

 $pagina = 1;
 $limite = 10;

if(isset($_GET["pagina"])) 
  {
	$pagina = $_GET["pagina"];
  }

 $paginas = ceil($total / $limite);

 $inicio = ($pagina-1) * $limite; 
 
 
if ($inicio < 0)
  {
      $inicio=1;
  }


$tabela_toda1 = "select * from lotacao where cpf = '$idlota'";
$query1 = mysql_query($tabela_toda1) or die(mysql_error());
while ( $linhatotal1 = mysql_fetch_array( $query1 ))
{ 

 	    $data = date("d/m/Y",strtotime($linhatotal1["dtlotacao"]));
	    $dtadmissao = date("d/m/Y",strtotime($linhatotal1["dtsaida"]));
           $mat = $linhatotal1["matricula"];;

        if ($dtadmissao=='31/12/1969')
		   {
		     $dtadmissao='';
		   }

        if ($data=='31/12/1969')
		   {
		     $data='';
		   }




 $lotado =$linhatotal1["lotado"];
 $ineppesq=  $linhatotal1["inep"];

 $gerenciapesq=  $linhatotal1["gerencia"];
 $dptopesq=  $linhatotal1["departamento"];


if ($lotado=='2') 
 {
 $sqlfiltro = mysql_query("select l.id ,l.cpf,l.matricula,l.lotado,l.gerencia,l.departamento,l.qtdaaula ,l.inep,l.dtlotacao,l.chlotacao,e.descricao,l.dtsaida,l.dtren,l.dtescola,l.dtren,l.dtescola from lotacao l,escola e where l.matricula = '$mat' and  l.inep=e.inep and l.inep='$ineppesq'");
 $conta = mysql_num_rows($sqlfiltro);

         $idx               = mysql_result($sqlfiltro, 0, "id");
         $matricula        = mysql_result($sqlfiltro, 0, "matricula");
         $inep             = mysql_result($sqlfiltro, 0, "inep");
         $descricao        = mysql_result($sqlfiltro, 0, "descricao");
         $chlotacao        = mysql_result($sqlfiltro, 0, "chlotacao");
         $qtdaaula         = mysql_result($sqlfiltro, 0, "qtdaaula");


 }
else
 {
   $sqlfiltro = mysql_query("SELECT l.id,l.cpf,l.matricula,l.chlotacao,l.dtlotacao,l.dtsaida,l.qtdaaula,l.dtren,l.dtescola,g.descricao,d.descricao as descricaod FROM
   lotacao l,gerencia g,departamento d WHERE l.lotado ='1' and l.gerencia = g.codigo
   and  l.gerencia <> ''and  l.cpf = '$idlota'  and d.codigo_dpto=l.departamento and d.gerencia = l.gerencia and l.departamento ='$dptopesq'
   and l.gerencia ='$gerenciapesq'");
   $conta = mysql_num_rows($sqlfiltro);

         $idx               = mysql_result($sqlfiltro, 0, "id");
         $matricula        = mysql_result($sqlfiltro, 0, "matricula");
         $descricao        = mysql_result($sqlfiltro, 0, "descricao");
         $chlotacao        = mysql_result($sqlfiltro, 0, "chlotacao");
         $descricaod       = mysql_result($sqlfiltro, 0, "descricaod");
         $qtdaaula         = mysql_result($sqlfiltro, 0, "qtdaaula");
         $dtren            = mysql_result($sqlfiltro, 0, "dtren");
         $dtescola         = mysql_result($sqlfiltro, 0, "dtescola");


 }



if($conta == 0)
   {
     $pagina = $pagina-1;
   }


if($total >=1)
   { 
?>
<tr>

<?
if ($lotado=='2')
{
?>
   	  <td class="fonte"><?echo $matricula;?></td>
      <td><?echo $inep;?></td>
      <td><?echo $descricao;?></td>
      <td><?echo $data;?></td>	
      <td><?echo $dtadmissao;?></td>	
      <td><?echo  $dtren;?></td>
      <td><?echo  $dtescola;?></td>
      <td><?echo  $chlotacao;?></td>
      <td><?echo  $qtdaaula;?></td>

  </tr>
<?
}
else
{
?>
   	  <td class="fonte"><?echo $matricula;?></td>
      <td><?echo $descricao;?></td>
      <td><?echo $descricaod;?></td>
      <td><?echo $data;?></td>	
      <td><?echo $dtadmissao;?></td>	
      <td><?echo  $dtren;?></td>
      <td><?echo  $dtescola;?></td>
      <td><?echo  $chlotacao;?></td>
      <td><?echo  $qtdaaula;?></td>
  </tr>
<?
}


// }
}
}//fim while1
?>
</table>
 </div><!-- Div corpodetalhe-->
</div><!-- Div corpo2-->

<?
  mysql_close($conexao);
?>				
  <div id="rodapeconsulta" class="fonterodape">
<? 
if($paginas != 1)
{
 if($pagina != 1)
   {
    $menos = $pagina - 1;
    $url = $_SERVER["PHP_SELF"]."?pagina=".$menos;
    echo "<a href=\"?pagina=1\">&lt;&lt;Primeira </a> ";
    echo "<a href=\"$url\">&lt;Anterior </a> ";
   }
   if($paginas > 1)
   {
	for($x=1;$x<=$paginas;$x++)
	 {
		$url = $_SERVER["PHP_SELF"]."?pagina=".$x;
		if($x == $pagina)
		{
			echo "<strong>$x</strong> ";
		}
		else
		{
			echo "<a href=\"$url\">$x</a> ";
		}	
	  }
   }
if($pagina != $paginas)
 {
   $mais = $pagina + 1;
   $url = $_SERVER["PHP_SELF"]."?pagina=".$mais;
   echo "<a href=\"$url\"> Próxima&gt; </a> ";
   echo "<a href=\"?pagina=$paginas\"> Última&gt;&gt; </a> ";
 }
 }



 
?>
</div>
		<div id="footer">
			<p>Todos direitos reservados GTI/SEDUC</p>
		</div>
	</div>
</body>

