<?php
session_start();

if (isset($_SESSION["login_usuario"]))
  {
   // session_cache_expire(1);
	 $login     =  $_SESSION["login_usuario"];
     $nte       =  $_SESSION["nivel_usuario"];
	 $inep      =  $_SESSION["inep_usuario"] ;
     $ntelogin  =  $_SESSION["nte_login"];
     $cpf       = $_SESSION["cpf_usuario"];

	 include ("../../funcoes.php");
     echo  saudacoes()."   ". "$login" ."  -  ". $nte."  ".dataextenso()." ".$inep;

  }
 else
  {
     		 header("../../Location: login.php");
  }


include ("../../conexao_mysql.php");

if(file_exists("../../conexao_mysql.php"))
{
        require "../../conexao_mysql.php";

} else
{
        echo "Conex�o nao foi encontrado";
        exit;
}




$cpf =  $_GET['codigo'];

if(!empty($cpf))
{ 


$sql="select * from quadronecessidade where  id = '$cpf'";
$resultado=mysql_query($sql) or die (mysql_error());
$linhas=mysql_num_rows($resultado);
if($linhas>0)
{
   while($pegar=mysql_fetch_array($resultado))
     {
         $tipo        =$pegar["tipo"];
     }

if ($tipo!='T')
 {
$sql="select q.id_disciplina as discip,q.licenca,q.emergencial,q.inep,q.projeto,q.saldo,q.saldohe,q.qtdahe,e.inep,e.descricao as descescola,h.descricao as desdisciplina,q.t_vagas,q.id_turno,q.motivo,q.usuario  from quadronecessidade q,escola e,habilitacao h where e.inep=q.inep and h.codigo=q.id_disciplina and q.id = '$cpf'";
$resultado=mysql_query($sql) or die (mysql_error());
$linhas=mysql_num_rows($resultado);

if($linhas>0)
  {
   while($pegar=mysql_fetch_array($resultado))
     {
    $id               =$pegar["id"];
    $descescola       =$pegar["descescola"];
    $descdisciplina       =$pegar["desdisciplina"];
    $turmas           =$pegar["id_turmas"];
	$tvagas           =$pegar["t_vagas"];
	$tvagashe         =$pegar["qtdahe"];
	$saldo            =$pegar["saldo"];
	$saldohe          =$pegar["saldohe"];
    $codturno         =$pegar["id_turno"];
	$saldoprojeto     =$pegar["projeto"];
	$saldolicenca     =$pegar["licenca"];
	$inep             =$pegar["inep"];
	$disciplina       =$pegar["discip"];
    $emergencial      =$pegar["emergencial"];

     }

  }
 }
else
{
$sql="select q.id_disciplina as discip,q.licenca,q.emergencial,q.inep,q.projeto,q.saldo,q.saldohe,q.qtdahe,e.inep,e.descricao as descescola,h.descricao as desdisciplina,q.t_vagas,q.id_turno,q.motivo,q.usuario  from quadronecessidade q,escola e,funcao h where e.inep=q.inep and h.cod_funcao=q.id_disciplina and q.id = '$cpf'";
$resultado=mysql_query($sql) or die (mysql_error());
$linhas=mysql_num_rows($resultado);

if($linhas>0)
  {
   while($pegar=mysql_fetch_array($resultado))
     {
    $id               =$pegar["id"];
    $descescola       =$pegar["descescola"];
    $descdisciplina       =$pegar["desdisciplina"];
    $turmas           =$pegar["id_turmas"];
	$tvagas           =$pegar["t_vagas"];
	$tvagashe         =$pegar["qtdahe"];
	$saldo            =$pegar["saldo"];
	$saldohe          =$pegar["saldohe"];
    $codturno         =$pegar["id_turno"];
	$saldoprojeto     =$pegar["projeto"];
	$saldolicenca     =$pegar["licenca"];
	$inep             =$pegar["inep"];
	$disciplina       =$pegar["discip"];
    $emergencial      =$pegar["emergencial"];

     }

  }
}







 }
}


?>

<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01//EN"
	"http://www.w3.org/TR/html4/strict.dtd">
<head>
    <meta http-equiv="content-type" content="text/html; charset=ISO-8859-1" />
	<title>SEDUC - RO</title>
	<link rel="stylesheet" href="style/forms.css" type="text/css" />
	<link rel="stylesheet" href="estilo.css" type="text/css" />
	<link rel="stylesheet" href="style/menu.css" type="text/css" />

	
	<link href="tablecloth/tablecloth.css" rel="stylesheet" type="text/css" media="screen" />
	
	<script type="text/javascript" src="tablecloth/tablecloth.js"></script>
	<script src="lib/jquery-1.4.2.js" type="text/javascript"></script>
	<script src="lib/validate.js" type="text/javascript"></script>
	<script src="lib/forms.js" type="text/javascript"></script>
	<script src="generic_movimento.js" type="text/javascript"></script>
    <script src="lib/jquery.maskedinput-1.1.1.js" type="text/javascript"></script>
	<meta http-equiv="Content-type" content="text/html; charset=utf-8" />





 	<link type="text/css" href="jquery-ui-1.8.18.custom/css/ui-lightness/jquery-ui-1.8.18.custom.css" rel="stylesheet" />
<!--	Versao nao trabalha com validade <script type="text/javascript" src="jquery-ui-1.8.18.custom/js/jquery-1.7.1.min.js"></script>-->
	<script type="text/javascript" src="jquery-ui-1.8.18.custom/js/jquery-ui-1.8.18.custom.min.js"></script>

<script src="script.js"></script>

<script>
function pesquisa(form)
{
  var valor = document.form.txtMatricula.value;
  url="busca_servidor_matricula.php?valor="+valor;
  ajax(url);
}
</script>


<script>
	$(function() {
		$( "#txtdtfim" ).datepicker({
			changeMonth: true,
			changeYear: true
		});
	});

$(function() {
        $("#txtdtfim").datepicker();
        $('#txtdtfim').datepicker('option', 'dateFormat', 'dd/mm/yy');
});




	$(function() {
		$( "#txtdtinicio" ).datepicker({
			changeMonth: true,
			changeYear: true
		});
	});

$(function() {
        $("#txtdtinicio").datepicker();
        $('#txtdtinicio').datepicker('option', 'dateFormat', 'dd/mm/yy');
});


</script>





</head>
<body>
	<div id="warpper">
		<div id="header">
		      <img src= "../img/seduc_topo.jpg"/>
		</div>



			<div id="content">
				<form name = "form" class="form" action="insere_detalhe.php" method="post">

				 <div id="tema"> 
					   <p><center>Altera��o</center></p>
				  </div>

					<p>
						<label for="txtCPF">ID</label>
						<input type="text" name="id" style="width:110px"  maxlength="11" id="id"  value= "<? echo $cpf; ?>"   readonly="true"/>

					</p>

					<p>




        				 <label for="lblEndereco">Escola</label>
						 <input type="text" name="txtinep" style="width:80px" value= "<? echo $inep; ?>"  maxlength="60" size="60" id="txtinep" readonly="true"/>
						 <input type="text" name="txtturmas" style="width:300px" value= "<? echo $descescola; ?>"  maxlength="60" size="60" id="txtturmas" readonly="true"/>
					</p>



					<p>

						 <label for="lblEndereco">Disciplina/Cargo</label>
						 <input type="text" name="txtinep" style="width:80px" value= "<? echo $disciplina; ?>"  maxlength="60" size="60" id="txtinep" readonly="true"/>
						 <input type="text" name="txtdisciplina" style="width:300px" value= "<? echo $descdisciplina; ?>"  maxlength="60" size="60" id="txtdisciplina" readonly="true"/>
					</p>



   					<p>

						 <label for="lblEndereco">Turno</label>
						 <input type="text" name="selecturno" style="width:300px" value= "<? echo $codturno; ?>"  maxlength="60" size="60" id="selecturno" readonly="true"/>
					</p>




					<p>
						<input type="hidden" name="txt_tvagas" style="width:100px" value= "<? echo $tvagas; ?>"  maxlength="40" size="60" id="txt_tvagas" readonly="true"/>
					</p>




					<p>
						<label for="lblEndereco">Saldo de Aulas Normal</label>
						<input type="text" name="txtsaldoatual" style="width:100px" value= "<? echo $saldo; ?>"  maxlength="40" size="60" id="txtsaldoatual" readonly="true"/>
					</p>



					<p>
						<input type="hidden" name="txt_tvagashe" style="width:100px" value= "<? echo $tvagashe; ?>"  maxlength="40" size="60" id="txt_tvagashe" readonly="true"/>
					</p>



					<p>
						<label for="lblEndereco">Saldo de H.E</label>
						<input type="text" name="txtsaldoatualhe" style="width:100px" value= "<? echo $saldohe; ?>"  maxlength="40" size="60" id="txtsaldoatualhe" readonly="true"/>
					</p>



					<p>
						<label for="lblEndereco">Saldo Projeto</label>
						<input type="text" name="txtsaldoprojeto" style="width:100px" value= "<? echo $saldoprojeto; ?>"  maxlength="40" size="60" id="txtsaldoprojeto" readonly="true"/>
					</p>

					<p>
						<label for="lblEndereco">Saldo Licen�aa</label>
						<input type="text" name="txtsaldolicenca" style="width:100px" value= "<? echo $saldolicenca; ?>"  maxlength="40" size="60" id="txtsaldolicenca" readonly="true"/>
					</p>


					<p>
						<label for="lblEndereco">Saldo Emerg�ncial</label>
						<input type="text" name="txtsaldoemergencia" style="width:100px" value= "<? echo $emergencial; ?>"  maxlength="40" size="60" id="txtsaldoemergencia" readonly="true"/>
					</p>



		  <p>
		         <label for="lblMatricula">Matricula<img src= "../img/check.gif"/></label>
                 <input name="txtMatricula" type="text" id="txtMatricula" size="15" title = "Campo Obrigatrio. Digite a matricula do servidor." MAXLENGTH="11"  onBlur = pesquisa(form) />

         	   <!-- AQUI SER APRESENTADO O RESULTADO DA BUSCA DINMICA.. OU SEJA OS NOMES -->
     	       <div id="pagina">

               </div>
         </p>




					<p>
						<label for="lblEndereco" style="width:150px">Aula Normal</label>
						<input type="text" name="txtvagas" style="width:100px" value= "0"  maxlength="40" size="60" id="txtvagas"  onKeyPress="return Enum(event)"/>
					</p>



					<p>
						<label for="lblEndereco" style="width:150px">Aula H.E</label>
						<input type="text" name="txtvagashe" style="width:100px" value= "0"  maxlength="40" size="60" id="txtvagashe"  onKeyPress="return Enum(event)"/>
					</p>




					<p>
						<label for="lblEndereco" style="width:150px">Aula Projeto</label>
						<input type="text" name="txtvagasprojeto" style="width:100px" value= "0"  maxlength="40" size="60" id="txtvagasprojeto"  onKeyPress="return Enum(event)"/>
					</p>





					<p>
						<label for="lblEndereco" style="width:150px">Aula Licenca</label>
						<input type="text" name="txtvagaslicenca" style="width:100px" value= "0"  maxlength="40" size="60" id="txtvagaslicenca"  onKeyPress="return Enum(event)"/>
					</p>

				<p> <BR><font size="4"> Contrato Emerg�ncial </font> </p>


					<p>
						<label for="txtCPF">Emerg�ncial</label>
						<input type="text" name="qtdaemergencia" style="width:100px" value="0" maxlength="4" id="qtdaemergencia"  onKeyPress="return Enum(event)"/>
					</p>


					<p>
           			  <label for="lbldtnascimento">Contrato Emerg�ncial Inicial</label>
					   <input type="text" name="txtdtinicio" value="" style="width:70px" id="txtdtinicio" />
           			  <label for="lbldtnascimento">Final</label>
					   <input type="text" name="txtdtfim" value="" style="width:70px" id="txtdtfim" />
					</p>




   	    <p>
            <label for="lblcod_cpf">Justificativa<img src= "../img/check.gif"/></label>
 			<textarea name = "txtobs"  maxlength= "200" cols="100" rows = "10" id = "txtobs"  type = "text"  onkeyup="blocTexto(txtdescvolume.value)"></textarea>
       </p>



    		<p id="finish">
                  <input type="submit" value="Alterar Dados" />
                  <input type="button" value=" Voltar " onclick="location.href='form_inclusao_saldo.php';">
	    	</p>
				</form>
			</div>
		</div>
		<div id="footer">
			<p>Todos direitos reservados GTI/SEDUC-RO</p>
   </p>
		</div>
	</div>
</body>

