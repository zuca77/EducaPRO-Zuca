<?php

session_start();

if (isset($_SESSION["login_usuario"]))
  {
   // session_cache_expire(1);
	 $login     =  $_SESSION["login_usuario"];
     $nte       =  $_SESSION["nivel_usuario"];
	 $inep      =  $_SESSION["inep_usuario"] ;
     $ntelogin  =  $_SESSION["nte_login"];
     $cpf       = $_SESSION["cpf_usuario"];

	 include ("../../funcoes.php");
     echo  saudacoes()."   ". "$login" ."  -  ". $nte."  ".dataextenso()." ".$inep;

  }
 else
  {
     		 header("../../Location: login.php");
  }


include ("../../conexao_mysql.php");

if(file_exists("../../conexao_mysql.php"))
{
        require "../../conexao_mysql.php";

} else
{
        echo "Conex�o nao foi encontrado";
        exit;
}




if($_SERVER["REQUEST_METHOD"] == "POST")
{
$id	                   = $_POST["id"];
$txtsaldoatual	       = $_POST['txtsaldoatual'];
$txtsaldoatualhe       = $_POST['txtsaldoatualhe'];
$txt_tvagashe          = $_POST['txt_tvagashe'];
$txt_tvagas	           = $_POST['txt_tvagas'];
$tipomov	           = $_POST['tipomov'];
$txtvagaslicenca	   = $_POST['txtvagaslicenca'];
$txtnormal	           = $_POST['txtvagas'];
$txtvagashe	           = $_POST['txtvagashe'];
$txtvagasprojeto	   = $_POST['txtvagasprojeto'];
$txtobs	               = $_POST['txtobs'];
$txtinep               = $_POST['txtinep'];
$selecturno            = $_POST['selecturno'];
$txtdisciplina         = $_POST['txtdisciplina'];
$txtMatricula          = $_POST['txtMatricula'];
$motivo                = $_POST['txtobs'];

$qtdaemergencia     = $_POST['qtdaemergencia'];


$txtdtinicio     = $_POST['txtdtinicio'];
$txtdtfim        = $_POST['txtdtfim'];


/***********Analisando Saldo*****/
$txtsaldoatual       = $_POST['txtsaldoatual'];
$txtsaldoatualhe     = $_POST['txtsaldoatualhe'];
$txtsaldoprojeto     = $_POST['txtsaldoprojeto'];
$txtsaldolicenca     = $_POST['txtsaldolicenca'];
$txtsaldoemergencia   = $_POST['txtsaldolicenca'];




$txtsaldoatual=$txtsaldoatual-$txtnormal;
$txtsaldolicenca=$txtsaldolicenca-$txtvagaslicenca;
$txtsaldoatualhe=$txtsaldoatualhe-$txtvagashe;
$txtsaldoprojeto=$txtsaldoprojeto-$txtvagasprojeto;
$txtsaldoemergencia=$txtsaldoemergencia-$qtdaemergencia;



if (($txtnormal==0) && ($txtvagaslicenca==0) && ($txtvagashe==0) && ($txtvagasprojeto==0) && ($qtdaemergencia==0))
 {
    echo "<html><head><title>Resposta !!!</title></head>";
    echo "<body background=\"background_mensagens.jpg\" style=\"background-attachment:fixed; background-repeat:no-repeat\">";
    echo "<br><br><br>";
    echo "<center><img src=\"faleconosco/atencao.gif\" alt=\"\"><p><font color=\"#FF0000\" face=\"Verdana\" size=\"4\"><blink>Usuario defina uma lota��o.</blink> <b></b></font></center>";
    echo "<br><br><center><a href=\"form_pesq_quadrodevagas.php\"><img src=\"faleconosco/button_voltar2_.gif\" alt=\"Voltar\" border=\"0\" /></a></center>";
    echo "</body></html>";
    exit;
 }



if (($qtdaemergencia>0) && (($txtdtinicio=="") || ($txtdtfim=="")))
 {
    echo "<html><head><title>Resposta !!!</title></head>";
    echo "<body background=\"background_mensagens.jpg\" style=\"background-attachment:fixed; background-repeat:no-repeat\">";
    echo "<br><br><br>";
    echo "<center><img src=\"faleconosco/atencao.gif\" alt=\"\"><p><font color=\"#FF0000\" face=\"Verdana\" size=\"4\"><blink>Data do Contrato Emergencia nao Definida.!</blink> <b></b></font></center>";
    echo "<br><br><center><a href=\"form_pesq_quadrodevagas.php\"><img src=\"faleconosco/button_voltar2_.gif\" alt=\"Voltar\" border=\"0\" /></a></center>";
    echo "</body></html>";
    exit;
 }




/*******************************************************************/


if ($txtsaldoatual<0)
 {
    echo "<html><head><title>Resposta !!!</title></head>";
    echo "<body background=\"background_mensagens.jpg\" style=\"background-attachment:fixed; background-repeat:no-repeat\">";
    echo "<br><br><br>";
    echo "<center><img src=\"faleconosco/atencao.gif\" alt=\"\"><p><font color=\"#FF0000\" face=\"Verdana\" size=\"4\"><blink>Saldo Normal Nao Atende a Necessidade.!</blink> <b></b></font></center>";
    echo "<br><br><center><a href=\"form_pesq_quadrodevagas.php\"><img src=\"faleconosco/button_voltar2_.gif\" alt=\"Voltar\" border=\"0\" /></a></center>";
    echo "</body></html>";
    exit;
 }



if ($txtsaldoatual<0)
 {
    echo "<html><head><title>Resposta !!!</title></head>";
    echo "<body background=\"background_mensagens.jpg\" style=\"background-attachment:fixed; background-repeat:no-repeat\">";
    echo "<br><br><br>";
    echo "<center><img src=\"faleconosco/atencao.gif\" alt=\"\"><p><font color=\"#FF0000\" face=\"Verdana\" size=\"4\"><blink>Saldo Normal Nao Atende a Necessidade.!</blink> <b></b></font></center>";
    echo "<br><br><center><a href=\"form_pesq_quadrodevagas.php\"><img src=\"faleconosco/button_voltar2_.gif\" alt=\"Voltar\" border=\"0\" /></a></center>";
    echo "</body></html>";
    exit;
 }



if ($txtsaldolicenca<0)
 {
    echo "<html><head><title>Resposta !!!</title></head>";
    echo "<body background=\"background_mensagens.jpg\" style=\"background-attachment:fixed; background-repeat:no-repeat\">";
    echo "<br><br><br>";
    echo "<center><img src=\"faleconosco/atencao.gif\" alt=\"\"><p><font color=\"#FF0000\" face=\"Verdana\" size=\"4\"><blink>Saldo Licenca Nao Atende a Necessidade.!</blink> <b></b></font></center>";
    echo "<br><br><center><a href=\"form_pesq_quadrodevagas.php\"><img src=\"faleconosco/button_voltar2_.gif\" alt=\"Voltar\" border=\"0\" /></a></center>";
    echo "</body></html>";
    exit;
 }






 if ($txtsaldoatualhe<0)
 {
    echo "<html><head><title>Resposta !!!</title></head>";
    echo "<body background=\"background_mensagens.jpg\" style=\"background-attachment:fixed; background-repeat:no-repeat\">";
    echo "<br><br><br>";
    echo "<center><img src=\"faleconosco/atencao.gif\" alt=\"\"><p><font color=\"#FF0000\" face=\"Verdana\" size=\"4\"><blink>Saldo H.E Nao Atende a Necessidade.!</blink> <b></b></font></center>";
    echo "<br><br><center><a href=\"form_pesq_quadrodevagas.php\"><img src=\"faleconosco/button_voltar2_.gif\" alt=\"Voltar\" border=\"0\" /></a></center>";
    echo "</body></html>";
    exit;
 }


 if ($txtsaldoprojeto<0)
 {
    echo "<html><head><title>Resposta !!!</title></head>";
    echo "<body background=\"background_mensagens.jpg\" style=\"background-attachment:fixed; background-repeat:no-repeat\">";
    echo "<br><br><br>";
    echo "<center><img src=\"faleconosco/atencao.gif\" alt=\"\"><p><font color=\"#FF0000\" face=\"Verdana\" size=\"4\"><blink>Saldo Projeto Nao Atende a Necessidade.!</blink> <b></b></font></center>";
    echo "<br><br><center><a href=\"form_pesq_quadrodevagas.php\"><img src=\"faleconosco/button_voltar2_.gif\" alt=\"Voltar\" border=\"0\" /></a></center>";
    echo "</body></html>";
    exit;
 }



/*******************************/




if (trim($txtinep)=='')
   {
    echo "<html><head><title>Resposta !!!</title></head>";
    echo "<body background=\"background_mensagens.jpg\" style=\"background-attachment:fixed; background-repeat:no-repeat\">";
    echo "<br><br><br>";
    echo "<center><img src=\"faleconosco/atencao.gif\" alt=\"\"><p><font color=\"#FF0000\" face=\"Verdana\" size=\"4\"><blink>Escola n�o localizada.!</blink> <b></b></font></center>";
    echo "<br><br><center><a href=\"form_inclusao_saldo.php\"><img src=\"faleconosco/button_voltar2_.gif\" alt=\"Voltar\" border=\"0\" /></a></center>";
    echo "</body></html>";
    exit;

   }

if (trim($selecturno)=='')
   {
    echo "<html><head><title>Resposta !!!</title></head>";
    echo "<body background=\"background_mensagens.jpg\" style=\"background-attachment:fixed; background-repeat:no-repeat\">";
    echo "<br><br><br>";
    echo "<center><img src=\"faleconosco/atencao.gif\" alt=\"\"><p><font color=\"#FF0000\" face=\"Verdana\" size=\"4\"><blink>Informe o turno.!</blink> <b></b></font></center>";
    echo "<br><br><center><a href=\"form_inclusao_saldo.php\"><img src=\"faleconosco/button_voltar2_.gif\" alt=\"Voltar\" border=\"0\" /></a></center>";
    echo "</body></html>";
    exit;

   }


if (($txtnormal)<0)
   {
    echo "<html><head><title>Resposta !!!</title></head>";
    echo "<body background=\"background_mensagens.jpg\" style=\"background-attachment:fixed; background-repeat:no-repeat\">";
    echo "<br><br><br>";
    echo "<center><img src=\"faleconosco/atencao.gif\" alt=\"\"><p><font color=\"#FF0000\" face=\"Verdana\" size=\"4\"><blink>A Quantidade de Vaga deve ser maior ou igual a 1.!</blink> <b></b></font></center>";
    echo "<br><br><center><a href=\"form_inclusao_saldo.php\"><img src=\"faleconosco/button_voltar2_.gif\" alt=\"Voltar\" border=\"0\" /></a></center>";
    echo "</body></html>";
    exit;
    }



if (($qtdavagahe)<0)
   {
    echo "<html><head><title>Resposta !!!</title></head>";
    echo "<body background=\"background_mensagens.jpg\" style=\"background-attachment:fixed; background-repeat:no-repeat\">";
    echo "<br><br><br>";
    echo "<center><img src=\"faleconosco/atencao.gif\" alt=\"\"><p><font color=\"#FF0000\" face=\"Verdana\" size=\"4\"><blink>A Quantidade de Vaga deve ser maior ou igual a 1.!</blink> <b></b></font></center>";
    echo "<br><br><center><a href=\"form_inclusao_saldo.php\"><img src=\"faleconosco/button_voltar2_.gif\" alt=\"Voltar\" border=\"0\" /></a></center>";
    echo "</body></html>";
    exit;
    }


if (($qtdaprojeto)<0)
   {
    echo "<html><head><title>Resposta !!!</title></head>";
    echo "<body background=\"background_mensagens.jpg\" style=\"background-attachment:fixed; background-repeat:no-repeat\">";
    echo "<br><br><br>";
    echo "<center><img src=\"faleconosco/atencao.gif\" alt=\"\"><p><font color=\"#FF0000\" face=\"Verdana\" size=\"4\"><blink>A Quantidade de Vaga deve ser maior ou igual a 1.!</blink> <b></b></font></center>";
    echo "<br><br><center><a href=\"form_inclusao_saldo.php\"><img src=\"faleconosco/button_voltar2_.gif\" alt=\"Voltar\" border=\"0\" /></a></center>";
    echo "</body></html>";
    exit;
    }


if (($qtdalicenca)<0)
   {
    echo "<html><head><title>Resposta !!!</title></head>";
    echo "<body background=\"background_mensagens.jpg\" style=\"background-attachment:fixed; background-repeat:no-repeat\">";
    echo "<br><br><br>";
    echo "<center><img src=\"faleconosco/atencao.gif\" alt=\"\"><p><font color=\"#FF0000\" face=\"Verdana\" size=\"4\"><blink>A Quantidade de Vaga deve ser maior ou igual a 1.!</blink> <b></b></font></center>";
    echo "<br><br><center><a href=\"form_inclusao_saldo.php\"><img src=\"faleconosco/button_voltar2_.gif\" alt=\"Voltar\" border=\"0\" /></a></center>";
    echo "</body></html>";
    exit;
    }












$diainicio 				= substr($txtdtinicio, 0,2);
$anoinicio				= substr($txtdtinicio, -4);
$mesinicio 				= substr($txtdtinicio, -7,2);
$txtdtinicio			= $anoinicio.".".$mesinicio.".".$diainicio;



$diafim 				= substr($txtdtfim, 0,2);
$anofim				    = substr($txtdtfim, -4);
$mesfim 				= substr($txtdtfim, -7,2);
$txtdtfim			    = $anofim.".".$mesfim.".".$diafim;


/*tratamento das datas*/

$dia = date('d');
$mes = date('m');
$ano = date('Y');

$data =$ano.".".$mes.".".$dia;



$sql="select * from quadronecessidade where id= $id";
$resultado=mysql_query($sql) or die (mysql_error());
$linhas=mysql_num_rows($resultado);
if ($linhas > 0)
   {
       $sql = "update quadronecessidade set T_VAGAS   ='$txt_tvagas',
       saldo       = saldo - '$txtnormal',
       MOTIVO      = CONCAT(MOTIVO,'--','$txtobs'),
       saldohe     = saldohe - '$txtvagashe',
       projeto     = projeto - '$txtvagasprojeto',
       emergencial = '$qtdaemergencia',
       licenca     = licenca - '$txtvagaslicenca',
       tipo        = 'P',
       DATA ='$data'
       where  id='$id'";
    }
if(@mysql_query($sql))
   {

    if(mysql_affected_rows() == 1)
          {

            $sql = "insert into quadro_detalhe(inep,id_disciplina,id_turno,normal,he,projeto,licenca,cpf,tipo,motivo,data,usuario,dtinicio,dtfim) values
            ('$txtinep','$txtdisciplina','$selecturno','$txtnormal','$txtvagashe','$txtvagasprojeto','$txtvagaslicenca','$txtMatricula','P','$motivo','$data','$cpf','$txtdtinicio','$txtdtfim')";
        if(@mysql_query($sql))
          {
           if(mysql_affected_rows() == 1)
             {
            ?>
             <html><head><title>Resposta !!!</title>
              <style type="text/css">

              .style3 {
	font-size: 36px;
	font-weight: bold;
	color: #0000FF;
                    }
           </style>
      </head>
      <body background=\"background_mensagens.jpg\" style=\"background-attachment:fixed; background-repeat:no-repeat\">
      <META HTTP-EQUIV=Refresh CONTENT="1; URL=form_pesq_quadrodevagas.php">
       <br><br><br>
       <center>
               <span class="style3"><font face=\"Verdana\">Dados Registrado Com Sucesso.!</font> </span>
                                      </center>
        </body></html>

 <?
 }

 }











   }
}
/*
$sql="select * from  quadro_detalhe where  INEP= '$inep' and id_disciplina = '$txtdisciplina' and  id_turno= '$selecturno' and tipo = 'P'";
$resultado=mysql_query($sql) or die (mysql_error());
$linhas=mysql_num_rows($resultado);
if ($linhas>0)
 { 
    echo "<html><head><title>Resposta !!!</title></head>";
    echo "<body background=\"background_mensagens.jpg\" style=\"background-attachment:fixed; background-repeat:no-repeat\">";
    echo "<br><br><br>";
    echo "<center><img src=\"faleconosco/atencao.gif\" alt=\"\"><p><font color=\"#FF0000\" face=\"Verdana\" size=\"4\"><blink>Quadro de vagas  ja cadastrado para esta escola e  turma - Click em Voltar.!</blink> <b></b></font></center>";
    echo "<br><br><center><a href=\"form_inclusao_saldo.php\"><img src=\"faleconosco/button_voltar2_.gif\" alt=\"Voltar\" border=\"0\" /></a></center>";
    echo "</body></html>";
    exit;
}

else
{
/*********inserindo pedidio***********/


/*
$sql = "insert into quadro_detalhe(inep,id_disciplina,id_turno,t_vagas,data,usuario,motivo,saldo,qtdahe,saldohe,tipo,projeto,licenca)
values ('$txtinep','$txtdisciplina','$selecturno','$qtdavaga','$data','$cpf','$motivo','$qtdavaga','$qtdahe','$qtdahe','P','$qtdaprojeto','$qtdalicenca')";

if(@mysql_query($sql))
{
  if(mysql_affected_rows() == 1)
   {

     $_SESSION['escola']=$txtinep;

  ?>
 <html><head><title>Resposta !!!</title>
 <style type="text/css">
<!--
.style3 {
	font-size: 36px;
	font-weight: bold;
	color: #0000FF;
}
-->
 </style>
 </head>
 <body background=\"background_mensagens.jpg\" style=\"background-attachment:fixed; background-repeat:no-repeat\">
<!-- <META HTTP-EQUIV=Refresh CONTENT="1; URL=form_inclusao_saldo.php">->
 <br><br><br>
 <center>
               <span class="style3"><font face=\"Verdana\">Dados Registrado Com Sucesso.!</font> </span>
                                      </center>
 </body></html>

 <?
/* }
else
   {
        //verifico se nao estao tentando gravar um dado que ja existe, pois usei UNIQUE na tabela
        if(mysql_errno() == 1062)
		  {
                echo $erros[mysql_errno()];
                exit;
          }
		  else
		  {
                echo "Erro nao foi possivel incluir o registro de detalhe";
                exit;
          }
        @mysql_close();
   }
  }
 }  */
}//post

?>



