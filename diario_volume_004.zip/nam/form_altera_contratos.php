<?php
require_once '../start.php';

?>
<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01//EN"
	"http://www.w3.org/TR/html4/strict.dtd">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1" />

	<title>SEDUC-RO</title>
	<link rel="stylesheet" href="style/forms.css" type="text/css" />
	<link rel="stylesheet" href="estilo.css" type="text/css" />
	<link rel="stylesheet" href="style/menu.css" type="text/css" />

	
	<link href="tablecloth/tablecloth.css" rel="stylesheet" type="text/css" media="screen" />
	
	<script type="text/javascript" src="tablecloth/tablecloth.js"></script>
	<script src="lib/jquery-1.4.2.js" type="text/javascript"></script>
	<script src="lib/validate.js" type="text/javascript"></script>
	<script src="lib/forms.js" type="text/javascript"></script>
<!--	<script src="genericlota.js" type="text/javascript"></script>-->
	<script src="genericcontrato.js" type="text/javascript"></script>
    <script src="lib/jquery.maskedinput-1.1.1.js" type="text/javascript"></script>


	<link type="text/css" href="jquery-ui-1.8.18.custom/css/ui-lightness/jquery-ui-1.8.18.custom.css" rel="stylesheet" />
<!--	<script type="text/javascript" src="jquery-ui-1.8.18.custom/js/jquery-1.7.1.min.js"></script>-->
	<script type="text/javascript" src="jquery-ui-1.8.18.custom/js/jquery-ui-1.8.18.custom.min.js"></script>





<script type="text/javascript">








</script>


</head>
<body>
	<div id="warpper">
		<div id="header">
         <img src= "../escola/img/chamadaescolar.jpg"/>

		</div>
    <div id="container">
			<div id="content">

				<form  name="form" class="form" action="altera_contratos.php" method="POST">
				 <div id="tema"> 
					   <p><center>Altera Contrato</center></p>
				  </div>

<?php

$id = $_GET['codigo'];
$sqlmemo="select * from contrato where id = '$id'";
$resultadomemo=mysql_query($sqlmemo) or die (mysql_error());
$linhasmemo=mysql_num_rows($resultadomemo);

if($linhasmemo>0)
{
   while($pegarmemo=mysql_fetch_array($resultadomemo))
   {

      $cpfmemo          =$pegarmemo["cpf"];
      $matricula        =$pegarmemo["matricula"];
      $dof              =$pegarmemo["dof"];
	  $cargo            =$pegarmemo["cargo"];
      $funcao           =$pegarmemo["funcao"];
      $decreto          =$pegarmemo["decreto"];
      $chcontrato       =$pegarmemo["chcontrato"];
	  $regime           =$pegarmemo["regime"];
        $habilitacao      =$pegarmemo["habilitacao"];
        $cds              =$pegarmemo["cds"];



      $dtadmissao   = date("d/m/Y",strtotime($pegarmemo["dtadmissao"]));
      $dtdecreto    = date("d/m/Y",strtotime($pegarmemo["dtdecreto"]));
   	  $dtdof        = date("d/m/Y",strtotime($pegarmemo["dtdof"]));


   }
}  


$sqldados="select * from servidorrec where cpf = '$cpfmemo'";
$resultadodados=mysql_query($sqldados) or die (mysql_error());
$linhasdados=mysql_num_rows($resultadodados);

if($linhasdados>0)
{
   while($pegardados=mysql_fetch_array($resultadodados))
   {
    $cpf              =$pegardados["cpf"];
	$nome             =$pegardados["nome"];
	$mae              =$pegardados["mae"]; 	
    $pai              =$pegardados["pai"]; 	
	$endereco         =$pegardados["endereco"]; 	
	$bairro           =$pegardados["bairro"]; 	
	$fonesetor        =$pegardados["fonesetor"]; 	
	$fonecontato      =$pegardados["fonecontato"]; 	
	$foneresidencial  =$pegardados["foneresidencial"]; 	
	$celular          =$pegardados["celular"]; 	
	$email            =$pegardados["email"]; 	
       $cep              =$pegardados["cep"]; 		
       $numero           =$pegardados["numero"]; 		
	
    }
  }

?>
	
	
					<p>
						<label for="txtCPF">CPF<img src= "img/check.gif"/></label>
						<input type="text" name="cpf" style="width:110px"  maxlength="11" id="cpf"  value= "<? echo $cpf; ?>"  readonly="true"/>

					</p>
	

					<p>
						<label for="txtNome">Nome</label>
						<input type="text" name="txtNome" style="width:565px" maxlength="60" value= "<? echo $nome; ?>" id="txtNome" readonly="true"/>
					</p>
					
					<p>
						<label for="lblmae">Nome M�e</label>
						<input type="text" name="txtmae" style="width:565px" maxlength="60" value= "<? echo $mae; ?>" id="txtmae" readonly="true"/>
					</p>
					<p>
						<label for="lblpai">Nome Pai</label>
						<input type="text" name="txtpai" style="width:565px" maxlength="60" value= "<? echo $pai; ?>" id="txtpai"  readonly="true"/>
					</p>


					<p>
						<label for="lblEndereco">Endereco</label>
						<input type="text" name="txtEndereco" style="width:565px" value= "<? echo $endereco; ?>"  maxlength="60" size="60" id="txtEndereco" readonly="true"/>
					</p>

					<p>
						<label for="lblEndereco">Complemento</label>
						<input type="text" name="txtcomplemento" style="width:565px" value= "<? echo $bairro; ?>"  maxlength="40" size="60" id="txtcomplemento" readonly="true"/>
					</p>


					<p>
						<label for="lblBairro">Bairro</label>
						<input type="text" name="txtBairro" style="width:300px" value= "<? echo $bairro; ?>" id="txtBairro"  maxlength="40" readonly="true"/>
						<label for="lblBairro">N.</label>
						<input type="text" name="txtnr" style="width:60px" value= "<? echo $numero; ?>" id="txtnr" maxlength="5" readonly="true"/>
			            <label for="txtCEP">CEP</label>
            			<input id="txtcep" name="txtcep" type="text" style="width:90px" value= "<? echo $cep; ?>" maxlength="8" onKeyPress="return Enum(event)" readonly="true"/>
					</p>
					<p>
						<label for="txtFoneSetor">Telefone Comercial</label>
						<input type="text" name="txtFoneSetor" style="width:90px" value= "<? echo $fonesetor; ?>" id="txtFoneSetor"  maxlength="20" readonly="true"/>
						<label for="txtFoneRes">Residencial</label>
						<input type="text" name="txtFoneRes" style="width:90px" value= "<? echo $foneresidencial; ?>" id="txtFoneRes" maxlength="20" readonly="true"/>
						<label for="txtCelular">Celular</label>
						<input type="text" name="txtCelular" style="width:90px" value= "<? echo $celular; ?>" id="txtCelular" maxlength="20" readonly="true"/>
						<label for="txtCelular">Contato</label>
						<input type="text" name="txtcontato" style="width:90px" value= "<? echo $fonecontato; ?>" id="txtcontato" maxlength="25" readonly="true"/>

					</p>
					<p>
						<label for="txtEmail">E-mail</label>
						<input type="text" name="txtEmail" style="width:565px" value= "<? echo $email; ?>" id="txtEmail" maxlength="80" readonly="true"/>
					</p>

					

 <p>
<label for="lblMatricula" style="width:120px">ID</label>
    <input name="txtid" type="text" id="txtid" style="width:120px" title = "Campo Obrigatrio. Informe o n�mero do memrando." MAXLENGTH="10" value= "<? echo $id; ?>"  readonly="true"/>
</p>



					<p>

					<label for="lblcod_estados">Regime:</label>
					   <select name="selectcontrato1" id="selectcontrato1" >
					   <option value=""></option>
  					  <?php
						   $sql = "select id, descricao FROM regimejuridico order by id"; 
						   $res = mysql_query($sql); 
						   if($res)
							  {
								while($row = mysql_fetch_array($res)){ 
							    ?>
  			                    <option value="<?php echo $row['id']?>"
						        <?php if($row['id'] == $regime){ echo "selected";}?>>
								<?php echo $row['descricao'];?>
								<?php 
							      } }
						        ?>
					   </select>
					</p>
			
			


<p>

					<label for="lblcod_estados">Cargo Comissionado</label>
					   <select name="txtcargo_comisionado" id="txtcargo_comisionado"  readonly="true"  >
					   <option value=""></option>
  					  <?php
						   $sql = "select id, descricao FROM cds order by id"; 
						   $res = mysql_query($sql); 
						   if($res)
							  {
								while($row = mysql_fetch_array($res)){ 
							    ?>
  			                    <option value="<?php echo $row['id']?>"
						        <?php if($row['id'] == $cds){ echo "selected";}?>>
								<?php echo $row['descricao'];?>
								<?php 
							      } }
						        ?>
					   </select>


</p>



			
			
	
			
			
			
			
			
     <p>
					<label for="lblcod_cargo">Cargo - Nomea��o</label>
 				     <select name="txtcod_cargo" id="txtcod_cargo" style="width:210px" >
						<option value=""></option>
					     <?php
						   $sql = "select cod_cargo, descricao FROM cargo order by cod_cargo"; 
						   $res = mysql_query($sql); 
						   if($res)
							  {
								while($row = mysql_fetch_array($res)){ 
							    ?>
  			                    <option value="<?php echo $row['cod_cargo']?>"
						        <?php if($row['cod_cargo'] == $cargo){ echo "selected";}?>>
								<?php echo $row['descricao'];?>
								<?php 
							      } }
						        ?>

					  </select>
	           </p>		



	           <p>		
          		   <label for="lblcodfuncao0">Funcao<img src= "img/check.gif"/></label>
         		   <span class="carregando"></span>
		             <select name="cod_funcao0" id="cod_funcao0" style="width:200px">
					     <?php
						   $sql = "select cod_funcao , descricao FROM funcao order by cod_funcao"; 
						   $res = mysql_query($sql); 
						   if($res)
							  {
								while($row = mysql_fetch_array($res)){ 
							    ?>
  			                    <option value="<?php echo $row['cod_funcao']?>"
						        <?php if($row['cod_funcao'] == $funcao){ echo "selected";}?>>
								<?php echo $row['descricao'];?>
								<?php 
							      } }
						        ?>
            	    </select>

   	           </p>		









					<p>

					<label for="lblhabilitacao">Habilita��o/TAE<img src= "img/check.gif"/></label>
						<select name="txthabilitacao" id="txthabilitacao" >
						<option value="">Selecione Habilita��o</option>
					<?php
							$sql = "SELECT codigo, descricao
									FROM habilitacao where codigo  <> '28'
									ORDER BY descricao";
				     		$res = mysql_query( $sql );
							while ( $row = mysql_fetch_assoc( $res ) ) {
							echo '<option value="'.$row['codigo'].'">'.$row['descricao'].'</option>';



								while($row = mysql_fetch_array($res)){
							    ?>
  			                    <option value="<?php echo $row['codigo']?>"
						        <?php if($row['codigo'] == $habilitacao){ echo "selected";}?>>
								<?php echo $row['descricao'];?>
								<?php
							      } }
						        ?>

					</select>

					</p>





				<p>		
						<label for="lblMatricula">Matricula<img src= "img/check.gif"/></label>
						<input type="text" name="txtMatricula1" value= "<? echo $matricula; ?>" style="width:90px" maxlength="11" id="txtMatricula1" onKeyPress="return Enum(event)" />

						<label for="lblMatricula">Matricula<img src= "img/check.gif"/></label>
						<input type="text" name="txtMatricula" value= "<? echo $matricula; ?>" style="width:90px" maxlength="11" id="txtMatricula" readonly="true"/>

						<label for="txtDataAdmissao">Data Admiss�o<img src= "img/check.gif"/></label>
						<input type="text" name="txtdtadmissao1" value= "<? echo $dtadmissao; ?>" style="width:70px" id="txtdtadmissao1" />

						<label for="selectch1">CH - Contrato<img src= "img/check.gif"/></label>
                          <input type="text" name="selectch1" value= "<? echo $chcontrato; ?>" style="width:40px" id="selectch1" />
                        </p>
				    	
				    	
				    	
				    	
				    	
				    	
				    	

					<p>
						<label for="lbldecreto">N Decreto<img src= "img/check.gif"/></label>
						<input type="text" name="txtdecreto1" style="width:70px" value= "<? echo $decreto; ?>" maxlength="11" id="txtdecreto1" />

						<label for="lblDataAdmissao">Data<img src= "img/check.gif"/></label>
						<input type="text" name="txtdtdecreto1"   value= "<? echo $dtdecreto; ?>"    style="width:70px" id="txtdtdecreto1"  />

						<label for="txtCPF">Publicado Di�rio<img src= "img/check.gif"/></label>
						<input type="text" name="txtdiario1" style="width:70px" value= "<? echo $dof; ?>" maxlength="10" id="txtdiario1"  />

						<label for="txtDataAdmissao">Data<img src= "img/check.gif"/></label>
						<input type="text" name="txtdtdiario1" value= "<? echo $dtdof; ?>" style="width:70px" id="txtdtdiario1"  />

					</p>



					

				<p id="finish">
           <input type="button" value=" Voltar " onclick="location.href='mnnam.php';">



            <input type="submit" value="Altera" />
            <input type="reset" value="limpar" />
					</p>

<? 


?>



				</form>
			</div>
		</div>


 </div><!-- Div corpodetalhe-->
</div><!-- Div corpo2-->

<?
  mysql_close($conexao);
?>				
  <div id="rodapeconsulta" class="fonterodape">
</div>
		<div id="footer">
			<p>Todos direitos reservados GTI/SEDUC-RO</p>
		</div>
	</div>
</body>

