<?php
    require_once '../start.php';
    $pdo = new Conexao;

    $title = 'Relota��o';

    if (isset($_SESSION["login_usuario"])) {

        $login = $_SESSION["login_usuario"];
        $nte = $_SESSION["nivel_usuario"];

    } else {
        header("Location: ../login.php");
    }

    $cpf = $_POST['cpf'];
    $txtdtlota11 = $txtdtlota1imprimi = $_POST['txtdtlota11'];
    $txtMatricula1 = $_POST['txtMatricula1'];
    $txtgerencia = isset($_POST['txtgerencia']) ? $_POST['txtgerencia'] : '';
    $txtdpto = isset($_POST['txtdpto']) ? $_POST['txtdpto'] : '';
    $txtdtren = $_POST['txtdtren'];
    $txtgerenciarem = $_POST['txtgerenciarem'];

    $txtdptorem = ($_POST['selectlotacao1'] == 2) ? 257 : $_POST['txtdptorem'];
    $txtgerenciadest = ($_POST['selectlotacao1'] == 2) ? 55 : $_POST['txtgerencia'];
    $txtdptodest = ($_POST['selectlotacao1'] == 2) ? 257 : $_POST['txtdpto'];

    $cod_estado = isset($_POST['cod_estado']) ? $_POST['cod_estado'] : 44;//Porto Velho

    $txtobs = trim($_POST['txtobs']);
    $selectlotacao1 = $_POST['selectlotacao1'];
    $txtMemo = strtoupper(trim($_POST['txtMemo']));
    //Seta como vazio se a lota��o n�o for uma escola
    $txtinep1 = $selectlotacao1 <> 2 ? '' : $_POST['txtinep1'];
    $selectch1lota = $selectlotacao1 <> 2 ? '' : $_POST['selectch1lota'];
    $txtqdtaaulas1 = $selectlotacao1 <> 2 ? '' : $_POST['txtqdtaaulas1'];
    $txtautacao1 = $_POST['txtautacao1'];

    if (!$txtMatricula1) {
        $msg = "N�o encontramos a matr�cula do servidor!";
        Notification::error($msg);

        redirectBackWithInputsInSession();
    }

    $sql = "SELECT c.cpf,s.nome,s.email,s.fonecontato,s.celular,c.matricula,c.cargo,c.funcao,
                        c.regime,c.chcontrato,c.dtadmissao,c.chcontrato,c.decreto,c.dtdecreto,c.dof,c.dtdof,c.dtdecreto
                        FROM contrato c, servidorrec s
                        WHERE c.cpf = s.cpf
                        AND c.matricula = :matricula;";
    $sth = $pdo->prepare($sql);
    $sth->bindParam(':matricula', $txtMatricula1);
    $servidor = $sth->execute() ? $sth->fetch() : null;

    if (!$servidor) {
        $msg = "N�o foi encontrado contrato de servidor com CPF <b>{$cpf}</b> e matr�cula <b>{$txtMatricula1}</b>.";
        Notification::error($msg);

        redirectBack();
    }

    $ano = date('Y');
    $diarg = substr($txtdtlota11, 0, 2);
    $anorg = substr($txtdtlota11, -4);
    $mesrg = substr($txtdtlota11, -7, 2);

    $txtdtlota11 = $anorg . "." . $mesrg . "." . $diarg;

    $diasaida = substr($txtdtren, 0, 2);
    $anosaida = substr($txtdtren, -4);
    $messaida = substr($txtdtren, -7, 2);

    $txtdtren = $anosaida . "." . $messaida . "." . $diasaida;

    $date_now = (string) date('Y-m-d');
    $data = date('d') . "." . date('m') . "." . date('Y');


//    /******************************* Escola ************************************/
//
    $sqlEscola = "SELECT inep, descricao, endereco, bairro, numero, tipo, cep, fone 
                              FROM escola 
                              WHERE inep = :txtinep1";
//
//    $query = $pdo->prepare($sqlEscola);
//    $query->bindParam(':txtinep1', $txtinep1);
//    $escola = $query->execute() ? $query->fetch() : null;
//
//    $descescola = $escola ? $escola["descricao"] : '';
//    $endescola = $escola ? $escola["endereco"] : '';
//    $bairroescola = $escola ? $escola["bairro"] : '';
//    $numeescola = $escola ? $escola["numero"] : '';
//    $tipoescola = $escola ? $escola["tipo"] : '';
//    $cepeescola = $escola ? $escola["cep"] : '';
//    $foneescola = $escola ? $escola["fone"] : '';

    /*************** Memorando Remetente *************** Departamento de Destino ************************************/

    $sqlDepartamento = "SELECT codigo_dpto, descricao 
                                              FROM departamento 
                                              WHERE codigo_dpto = :codigo";
//
//    $query = $pdo->prepare($sqlDepartamento);
//    $query->bindParam(':codigo', $txtdptorem);
//    $query->execute();
//    $result = $query->fetch();
//    $descdptorem = $result ? $result["descricao"] : '';

    /******************************* Memorando remetente gerencia **********************************/

    $sqlGerencia = "SELECT codigo,descricao 
                              FROM gerencia 
                              WHERE codigo = :codigo";
//
//    $query = $pdo->prepare($sqlGerencia);
//    $query->execute([':codigo' => $txtgerenciarem]);
//    $gerenciaRemetente = $query->fetch();
//    $descgerenciarem = $gerenciaRemetente ? $gerenciaRemetente["descricao"] : null;

    /*************** Memorando destinat�rio *************** Departamento destinat�rio **************/
//    $query = $pdo->prepare($sqlDepartamento);
//    $query->execute([':codigo' => $txtdptodest]);
//    $departamentoDestinatario = $query->fetch();
//    $descdptodest = $departamentoDestinatario ? $departamentoDestinatario["descricao"] : null;

    /******************************* Gerencia destinatario memorando *******************************/
//    $query = $pdo->prepare($sqlGerencia);
//    $query->execute([':codigo' => $txtgerenciadest]);
//    $gerenciaDestinataria = $query->fetch();
//    $descgerenciadest = $gerenciaDestinataria ? $gerenciaDestinataria["descricao"] : null;

    /***lotacao*********************Departamento destino ******************************************/
//    $query = $pdo->prepare($sqlDepartamento);
//    $query->execute([':codigo' => $txtdpto]);
//    $departamentoDestinatario = $query->fetch();
//    $descdpto = $departamentoDestinatario ? $departamentoDestinatario["descricao"] : null;

    /******************************* Gerencia ****************************************************/
//    $query = $pdo->prepare($sqlGerencia);
//    $query->execute([':codigo' => $txtgerencia]);
//    $gerenciaDestinataria = $query->fetch();
//    $descgerencia = $gerenciaDestinataria ? $gerenciaDestinataria["descricao"] : null;

    /*******************************Habiltacao************************************/
//    $sqlHabilitacao = "SELECT codigo, descricao AS descricao
//                                  FROM habilitacao
//                                  WHERE codigo = :codigo";
//
//    $query = $pdo->prepare($sqlHabilitacao);
//    $query->execute([':codigo' => $txtautacao1]);
//    $habilitacao = $query->fetch();
//    $deschab = $habilitacao ? $habilitacao["descricao"] : null;

    $sql = "SELECT s.nome,s.email,s.fonecontato,s.celular,c.matricula,c.cargo,c.funcao,c.regime,
                                 c.chcontrato,c.dtadmissao,c.chcontrato,c.decreto,c.dtdecreto
                                 FROM contrato c, servidorrec s
                                 WHERE c.matricula = :matricula
                                 AND c.cpf = s.cpf";

    $query = $pdo->prepare($sql);
    $query->bindParam(':matricula', $txtMatricula1);
    $query->execute();
    $resultadoger = $query->fetch();
    $resultadoger = isset($resultadoger) ? $resultadoger : null;
//
//    $nome = $resultadoger ? $resultadoger["nome"] : '';
//    $matricula = $resultadoger ? $resultadoger["matricula"] : '';
//    $cargo = $resultadoger ? $resultadoger["cargo"] : '';
//    $funcao = $resultadoger ? $resultadoger["funcao"] : '';
//    $email = $resultadoger ? $resultadoger["email"] : '';
//    $fonecontato = $resultadoger ? $resultadoger["fonecontato"] : '';
//    $ch = $resultadoger ? $resultadoger["chcontrato"] : '';
//    $regime = $resultadoger ? $resultadoger["regime"] : '';
//    $celular = $resultadoger ? $resultadoger["celular"] : '';

    /****************************************************************************************************************/
    $sqlgCargo = "SELECT * FROM cargo  WHERE cod_cargo = :codigo_cargo";

    $query = $pdo->prepare($sqlgCargo);
    $query->execute([':codigo_cargo' => $resultadoger["cargo"]]);
    $cargoResultado = $query->fetch();
    $cargo = $cargoResultado ? $cargoResultado["descricao"] : null;
//dd($txtMatricula1);
    /****************************************************************************************************************/
    $sqlFuncao = "SELECT * FROM funcao  WHERE cod_funcao = :codigo_funcao";
    $query = $pdo->prepare($sqlFuncao);
    $query->execute([':codigo_funcao' => $funcao]);
    $funcaoResultado = $query->fetch();
    $funcaodesc = $funcaoResultado ? $funcaoResultado["descricao"] : null;

    /********************************************************************/
    $sqlLotacao = "SELECT * FROM lotacao WHERE cpf = :cpf AND matricula = :matricula";
    $query = $pdo->prepare($sqlLotacao);
    $query->execute([
        ':matricula' => $txtMatricula1,
        ':cpf' => $cpf
    ]);
    $lotacaoResultado = $query->fetch();
    $lotacaoId = $lotacaoResultado ? $lotacaoResultado["ID"] : null;

    /*************************** Update Lota��o ****************************/
    $sqlUpdateLotacao = "UPDATE lotacao 
                                  SET obslotacao = :observacao, dtsaida = :data_saida 
                                  WHERE id = :id";

    try {
        $queryLotacao = $pdo->prepare($sqlUpdateLotacao);
        $queryLotacao->bindParam(':observacao', $txtobs);
        $queryLotacao->bindParam(':data_saida', $date_now);
        $queryLotacao->bindParam(':id', $lotacaoId);

        if ($queryLotacao->execute()) {
            $userNameArray = explode(' ', $login);
            $shortName = $userNameArray[0] . ' ' . $userNameArray[1];

            $sqlInsertLotacao = "INSERT INTO lotacao(cpf,matricula,lotado,gerencia,departamento,inep,dtlotacao,qtdaaula,areaatuacao,chlotacao,usuario,memo)
                                             VALUES (:cpf,:txtMatricula1,:selectlotacao1,:txtgerencia,:txtdpto,:txtinep1,:txtdtlota11,:txtqdtaaulas1,:txtautacao1,:selectch1lota,:login,:txtMemo)";

            $queryInsertLotacao = $pdo->prepare($sqlInsertLotacao);

            $queryInsertLotacao->bindParam(':cpf', $cpf);
            $queryInsertLotacao->bindParam(':txtMatricula1', $txtMatricula1);
            $queryInsertLotacao->bindParam(':selectlotacao1', $selectlotacao1);
            $queryInsertLotacao->bindParam(':txtgerencia', $txtgerencia);
            $queryInsertLotacao->bindParam(':txtdpto', $txtdpto);
            $queryInsertLotacao->bindParam(':txtinep1', $txtinep1);
            $queryInsertLotacao->bindParam(':txtdtlota11', $txtdtlota11);
            $queryInsertLotacao->bindParam(':txtqdtaaulas1', $txtqdtaaulas1);
            $queryInsertLotacao->bindParam(':txtautacao1', $txtautacao1);
            $queryInsertLotacao->bindParam(':selectch1lota', $selectch1lota);
            $queryInsertLotacao->bindParam(':login', $shortName);
            $queryInsertLotacao->bindParam(':txtMemo', $txtMemo);

            if ($queryInsertLotacao->execute()) {
                $newLotacaoId = $pdo->lastInsertId();

                // Inserindo memorando
                $sqlMemorando = "INSERT INTO memo(ORIGADM,ORIGDPTO,DESTADM,DESTDEPTO,MEMO,ANO,ASSUNTO,DATAMEMO,MATRICULA,SITUACAO,OBS,CPF,DESCDPTOO,DESCDPTOD,DTEMISSAO,LOTAINTCAP,LOTAADMESC,MUNILOTA,DATA,USUARIO,MEMOR,DEPARTAMENTO) 
                                              VALUES (:txtgerenciarem,'9',:txtgerenciadest,:txtdptodest,:txtMemo,:ano,'12',:data_memo,:txtMatricula1,'A' ,:txtobs,:cpf,'LOTACAO','ESCOLA',:data_emissao, 'C', 'E',:cod_estado,:data1,:login,:idlotacao,:nte)";

                $queryMemorando = $pdo->prepare($sqlMemorando);
                $queryMemorando->bindParam(':txtgerenciarem', $txtgerenciarem);
                $queryMemorando->bindParam(':txtgerenciadest', $txtgerenciadest);
                $queryMemorando->bindParam(':txtdptodest', $txtdptodest);
                $queryMemorando->bindParam(':txtMemo', $txtMemo);
                $queryMemorando->bindParam(':ano', $ano);
                $queryMemorando->bindParam(':data_memo', $date_now);
                $queryMemorando->bindParam(':txtMatricula1', $txtMatricula1);
                $queryMemorando->bindParam(':txtobs', $txtobs);
                $queryMemorando->bindParam(':cpf', $cpf);
                $queryMemorando->bindParam(':data_emissao', $date_now);
                $queryMemorando->bindParam(':cod_estado', $cod_estado);
                $queryMemorando->bindParam(':data1', $date_now);
                $queryMemorando->bindParam(':login', $userName);
                $queryMemorando->bindParam(':idlotacao', $newLotacaoId);
                $queryMemorando->bindParam(':nte', $nte);
                $queryMemorando->execute();

                $memorando_id = $pdo->lastInsertId();
            }
        }

    } catch (Exception $e) {
        Notification::ex($e);
        // Dados do formul�rio salvos
        // para inserir nos inputs ap�s o redirect
        redirectBackWithInputsInSession();
    }

    Notification::success('Servidor lotado com sucesso!');

    redirect('nam/rel_memorando_relotacao.php?codigo=' . $memorando_id);


