<?php
require_once '../start.php';

$id = $_GET['codigo'];
//echo "id $id";

$sqlmemo="select * from memo where id = $id";
$resultadomemo=mysql_query($sqlmemo) or die (mysql_error());
$linhasmemo=mysql_num_rows($resultadomemo);

if($linhasmemo>0)
{
   while($pegarmemo=mysql_fetch_array($resultadomemo))
   {
      $cpfmemo          =$pegarmemo["CPF"];
      $matricula        =$pegarmemo["MATRICULA"];
      $lotaintcap       =$pegarmemo["LOTAINTCAP"];
      $lotaadmesc       =$pegarmemo["LOTAADMESC"];
      $cod_estado       =$pegarmemo["MUNILOTA"];
      $txtMemo          =$pegarmemo["MEMO"];	
      $txtdataMemo      = date("d/m/Y",strtotime($pegarmemo["DATAMEMO"]));
      $dtemissao      = date("d/m/Y",strtotime($pegarmemo["DTEMISSAO"]));
  
      $txtMemor          =$pegarmemo["MEMOR"];
 
//      $dtemissao          =$pegarmemo["DTEMISSAO"];


//     echo "memo $txtdataMemo";     

      $txtano          =$pegarmemo["ANO"];	


      $txtdptoorg           =$pegarmemo["ORIGDPTO"];
      $txtdpto           =$pegarmemo["DESTDEPTO"];
      $txtMatricula       =$pegarmemo["MATRICULA"];
      //$cod_estado       =$pegarmemo["CPF"];	  	  	  

      $txtgerencia       =$pegarmemo["ORIGADM"];
      $txtgerencia1      =$pegarmemo["DESTADM"];
      $selectassunto      =$pegarmemo["ASSUNTO"];
      $txtobs1			=$pegarmemo["OBS"];	

   }
}  

if ($lotaintcap=='I')
{
  $intcap ='INTERIOR';
}
else
{
  $intcap ='CAPITAL';
}

if ($lotaadmesc=='A')
    $local ='ADM';
else	
   $local ='ESCOLA';




/******************contrato*************************************************/
/*  $sqlgerencia = "SELECT codigo, descricao FROM contrato where matricula='$matricula' and cpf =''";
    $resultadoger=mysql_query($sqlgerencia) or die (mysql_error());
    $linhas   =mysql_num_rows($resultadoger);


if($linhas>0)
{
   while($pegar=mysql_fetch_array($resultadoger))
	{
    	$descgerencia    =$pegar["descricao"]; 	
	}
 }	







/******************GERENCIA ORIGEM*************************************************/
    $sqlgerencia = "SELECT codigo, descricao FROM gerencia where codigo='$txtgerencia'";
    $resultadoger=mysql_query($sqlgerencia) or die (mysql_error());
    $linhas   =mysql_num_rows($resultadoger);

if($linhas>0)
{
   while($pegar=mysql_fetch_array($resultadoger))
	{
    	$descgerencia    =$pegar["descricao"]; 	
	}
 }	

/************************************Municipio*************************************************/
/*	$sqlgerencia = "SELECT codigo, descricao FROM municipio where codigo='$cod_estado'";
    $resultadoger=mysql_query($sqlgerencia) or die (mysql_error());
    $linhas   =mysql_num_rows($resultadoger);

if($linhas>0)
{
   while($pegar=mysql_fetch_array($resultadoger))
	{
    	$descmunicipio    =$pegar["descricao"]; 	
	}
 }	





/*******************************dEPARTAMENTO dESTINO************************************/
	$sqlgerencia = "SELECT codigo_dpto, descricao fROM departamento WHERE codigo_dpto='$txtdpto'";
    $resultadoger=mysql_query($sqlgerencia) or die (mysql_error());
    $linhas   =mysql_num_rows($resultadoger);

if($linhas>0)
{
   while($pegar=mysql_fetch_array($resultadoger))
	{
    	$descdpto    =$pegar["descricao"]; 	
	}
 }	



/*******************************dEPARTAMENTO origem************************************/
	$sqlgerencia = "SELECT codigo_dpto, descricao fROM departamento WHERE codigo_dpto='$txtdptoorg'";
    $resultadoger=mysql_query($sqlgerencia) or die (mysql_error());
    $linhas   =mysql_num_rows($resultadoger);

if($linhas>0)
{
   while($pegar=mysql_fetch_array($resultadoger))
	{
    	$descdptoorigem    =$pegar["descricao"]; 	
	}
 }	






/******************GERENCIA DESTINO*************************************************/
	$sqlgerencia = "SELECT codigo, descricao FROM gerencia where codigo='$txtgerencia1'";
    $resultadoger=mysql_query($sqlgerencia) or die (mysql_error());
    $linhas   =mysql_num_rows($resultadoger);

if($linhas>0)
{
   while($pegar=mysql_fetch_array($resultadoger))
	{
    	$descgerencia1    =$pegar["descricao"]; 	
	}
 }	



/*******************************dEPARTAMENTO dESTINO************************************/
/*	$sqlgerencia = "SELECT codigo_dpto, descricao fROM departamento WHERE codigo_dpto='$txtdpto1'";
    $resultadoger=mysql_query($sqlgerencia) or die (mysql_error());
    $linhas   =mysql_num_rows($resultadoger);

if($linhas>0)
{
   while($pegar=mysql_fetch_array($resultadoger))
	{
    	$descdpto1    =$pegar["descricao"]; 	
	}
 }	
*/
/****************************************************************************************************************/

$sqlgerencia = "select c.cpf,s.nome,s.email,s.fonecontato,s.celular,c.matricula,c.cargo,c.funcao,c.regime,c.chcontrato,c.dtadmissao,c.chcontrato,c.decreto,c.dtdecreto,c.dof,c.dtdof,c.dtdecreto,c.habilitacao 
from contrato c,servidorrec s where c.matricula = '$txtMatricula' and c.cpf =s.cpf and c.cpf = '$cpfmemo'";
    $resultadoger=mysql_query($sqlgerencia) or die (mysql_error());
    $linhas   =mysql_num_rows($resultadoger);

if($linhas>0)
{
   while($pegar=mysql_fetch_array($resultadoger))
	{
    	       $nome           =$pegar["nome"]; 	
		$matricula      =$pegar["matricula"]; 	
		$cargo          =$pegar["cargo"]; 	
		$funcao         =$pegar["funcao"]; 
		$email          =$pegar["email"]; 	
		$fonecontato    =$pegar["fonecontato"]; 
		$cpf            =$pegar["cpf"]; 		
		$ch             =$pegar["chcontrato"]; 					
		$regime         =$pegar["regime"]; 					
		$celular        =$pegar["celular"]; 					
		$decreto        =$pegar["decreto"]; 							
		$dof            =$pegar["dof"]; 							
		$habilitacao    =$pegar["habilitacao"]; 							
		


  	       $dtdecreto       = date("d/m/Y",strtotime($pegar["dtdecreto"]));
		
        if ($dtdecreto=='31/12/1969')
		   {
		     $dtdecreto='';
		   }


        if ($dtdecreto=='0000-00-00')
		   {
		     $dtdecreto='';
		   }



        if ($dtdecreto=='30/11/-0001')
		   {
		     $dtdecreto='';
		   }


              $dtdof           = date("d/m/Y",strtotime($pegar["dtdof"]));


        if ($dtdof =='31/12/1969')
		   {
		     $dtdof ='';
		   }


        if ($dtdof =='0000-00-00')
		   {
		     $dtdof ='';
		   }



        if ($dtdof =='30/11/-0001')
		   {
		     $dtdof ='';
		   }




		$dtadmissao    =date("d/m/Y",strtotime($pegar["dtadmissao"]));





        if ($dtadmissao=='31/12/1969')
		   {
		     $dtadmissao='';
		   }


        if ($dtadmissao=='0000-00-00')
		   {
		     $dtadmissao='';
		   }



        if ($dtadmissao=='30/11/-0001')
		   {
		     $dtadmissao='';
		   }




	}
 }	

/****************************************************************************************************************/


//echo "$nome";




$sqlgerencia = "select * from regimejuridico  where id = '$regime' ";
    $resultadoger=mysql_query($sqlgerencia) or die (mysql_error());
    $linhas   =mysql_num_rows($resultadoger);

if($linhas>0)
{
   while($pegar=mysql_fetch_array($resultadoger))
	{
		$regime         =$pegar["descricao"]; 					
	}
 }	


/****************************************************************************************************************/
     $sqlgerencia = "select * from cargo  where cod_cargo = '$cargo' ";
    $resultadoger=mysql_query($sqlgerencia) or die (mysql_error());
    $linhas   =mysql_num_rows($resultadoger);

if($linhas>0)
{
   while($pegar=mysql_fetch_array($resultadoger))
	{
		$cargodesc         =$pegar["descricao"]; 					
	}
 }	




/****************************************************************************************************************/

$sqlgerencia = "select * from funcao  where cod_funcao = '$funcao' ";
    $resultadoger=mysql_query($sqlgerencia) or die (mysql_error());
    $linhas   =mysql_num_rows($resultadoger);

if($linhas>0)
{
   while($pegar=mysql_fetch_array($resultadoger))
	{
		$funcao         =$pegar["descricao"]; 					
	}
 }	
/********************************************************************/

$sqlgerencia = "select * from assuntomemo  where id  = '$selectassunto' ";
    $resultadoger=mysql_query($sqlgerencia) or die (mysql_error());
    $linhas   =mysql_num_rows($resultadoger);

if($linhas>0)
{
   while($pegar=mysql_fetch_array($resultadoger))
	{
		$assunto         =$pegar["descricao"]; 					
	}
 }	

/*************Lotacao************************************************/

    $sqlgerencia = "select * from lotacao  where cpf  = '$cpfmemo' and matricula  = '$matricula' and id = '$txtMemor'";
    $resultadoger=mysql_query($sqlgerencia) or die (mysql_error());
    $linhas   =mysql_num_rows($resultadoger);

if($linhas>0)
{
   while($pegar=mysql_fetch_array($resultadoger))
	{
		$idlotacao         =$pegar["ID"];
	}
 }





//  if ($dtemissao > '2013-02-20')

//echo "$idlotacao";
//echo "$txtMemor";

if ($idlotacao==$txtMemor)  
 {
  //echo "!";
    $sqlgerencia = "select * from lotacao  where cpf  = '$cpfmemo' and matricula  = '$matricula' and id = '$txtMemor' ";

   }
  else
    {
      $sqlgerencia = "select * from lotacao  where cpf  = '$cpfmemo' and matricula  = '$matricula'";
    }



    $resultadoger=mysql_query($sqlgerencia) or die (mysql_error());
    $linhas   =mysql_num_rows($resultadoger);
if($linhas>0)
{
   while($pegar=mysql_fetch_array($resultadoger))
	{
		$inep              =$pegar["inep"];
              $dtlotacao         =$pegar["dtlotacao"];
  	       $dtlotacao         = date("d/m/Y",strtotime($pegar["dtlotacao"]));
              $lotadolotacao     =$pegar["lotado"];
 
             



	
	}
 }
/********************Escola************************************************/




$sqlgerencia = "select inep,descricao,endereco,bairro,numero,tipo,cep,fone from escola where inep='$inep'";
$resultadoger=mysql_query($sqlgerencia) or die (mysql_error());
$linhas   =mysql_num_rows($resultadoger);
if($linhas>0)
{
   while($pegar=mysql_fetch_array($resultadoger))
	{

    	$descescola    =$pegar["descricao"];
    	$endescola     =$pegar["endereco"];
    	$bairroescola  =$pegar["bairro"];
    	$numeescola    =$pegar["numero"];
    	$tipoescola    =$pegar["tipo"];
    	$cepeescola    =$pegar["cep"];
        $foneescola    =$pegar["fone"];
        // $cod_estado    =$pegar["municipio"];

    }
 }


/*******************************Habiltacao************************************/
   $sqlhab = "select codigo, descricao as descricao from habilitacao where codigo='$habilitacao'";
    $resultadohab=mysql_query($sqlhab) or die (mysql_error());
    $linhashab   =mysql_num_rows($resultadohab);
	if($linhashab>0)
    {
       while($pegar=mysql_fetch_array($resultadohab))
	    {
        	$deschab    =$pegar["descricao"];

           }
    }


/******************************************************************************************************/











//echo "$dtemissaorg";
$dia = date('d');
$mes = date('m');
$ano = date('Y');
 
$data1 =$ano.".".$mes.".".$dia;

$data =$dia.".".$mes.".".$ano;

$sql="select * from memo where memo = '$txtMemo' and DESTDEPTO= '$txtdpto'";
$resultado=mysql_query($sql) or die (mysql_error());
$linhas=mysql_num_rows($resultado);


if ($linhas>0)
{

?>
<html>
<head>
<script language="javascript">
function DoPrinting() {
    if (!window.print) {
        alert("Netscape, Internet Explorer 4.0 ou superior!")
        return
    }
    window.print();
}
</script>
</head>




<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1" />
<title>:: Memo Lota&ccedil;&atilde;o ::</title>
<style type="text/css">
<!--
.style1 {
	font-size: large;
	font-weight: bold;
}
.style2 {
	font-size: x-large;
	font-weight: bold;
}
.style3 {
	font-size: large;
	font-family: Verdana, Arial, Helvetica, sans-serif;
}
.style5 {font-family: Verdana, Arial, Helvetica, sans-serif}
.style6 {font-size: xx-large; font-weight: bold; font-family: Verdana, Arial, Helvetica, sans-serif; }
.style7 {font-size: x-large; font-weight: bold; font-family: Verdana, Arial, Helvetica, sans-serif; }
.style8 {font-size: large; font-weight: bold; font-family: Verdana, Arial, Helvetica, sans-serif; }
-->
</style>
</head>

<body><center>
<div align="center">
  <table width="988" border="1" cellpadding="0" cellspacing="0" bordercolor="#000000">
    <tr>
      <td colspan="7" rowspan="4"><table width="100%" border="0" cellpadding="0" cellspacing="0">
        <tr>
          <td width="120" class="style5"><div align="center"><img src="img/logo_brazil.jpg" /></div></td>
          <td width="706" class="style5"><p align="center" class="style2">SECRETARIA DE ESTADO DA EDUCA��O<br>
            <? echo $descdptoorigem?>/GRH/SEDUC</p></td>
        </tr>
      </table></td>
      <td width="131" height="36" bgcolor="#CCCCCC"><div align="center" class="style3">Data </div></td>
    </tr>
    <tr>
      <td height="46"><div align="center" class="style3"><span class="style5"></span><span class="style5"><? echo $data ?></span></div></td>
    </tr>
    <tr>
      <td height="47" bgcolor="#CCCCCC"><div align="center" class="style3">GRH</div></td>
    </tr>
    <tr>
      <td height="38" class="style3"><div align="center"><?  ?></div></td>
    </tr>
    <tr>
      <td height="68" colspan="8" bgcolor="#999999"><div align="center" class="style7">
        Memorando <? echo $txtMemo ?>/<? echo $txtano ?>
        </div></td>
      <br>
    </tr>
    <tr>
      <td width="550"></td>
      <td width="400"></td>
    </tr>
  </table><BR>  
    <table width="988" border="0" cellpadding="0" cellspacing="0" bordercolor="#000000">
    <tr>
      <td><div align="left" class="style3"> MEMO N.<? echo $txtMemo ?>/<? echo $txtano ?>-<? echo $descdptoorigem ?>/<? echo $descgerencia ?>/SEDUC </div></td>
      <td><div align="left" class="style3"><span class="style31"></span></div></td>
    </tr>
    <tr>
      <td colspan="2" align="right" class="style5">Porto Velho, <strong><? echo $data ?></strong></td>
    </tr>
    <tr>
      <td>&nbsp;</td>
      <td>&nbsp;</td>
    </tr>

    <tr>
      <td><div align="left" class="style5">DO: <? echo $descdptoorigem ?>/<? echo $descgerencia ?>/SEDUC</div></td>
      <td>&nbsp;</td>
    </tr>

    <tr>
      <td><div align="left" class="style5">PARA: <? echo $descdpto ?>/<? echo $descgerencia1 ?>/SEDUC </div></td>
      <td>&nbsp;</td>
    </tr>


  

    <tr>
      <td>&nbsp;</td>
      <td>&nbsp;</td>
    </tr>
     <tr>
      <td>&nbsp;</td>
      <td>&nbsp;</td>
    </tr>
    <tr>
      <td><div align="left" class="style5">ASSUNTO: <strong><? echo $assunto ?>;</strong></div></td>
      <td>&nbsp;</td>
    </tr>
    <tr>
      <td>&nbsp;</td>
      <td>&nbsp;</td>
    </tr>
     <tr>
      <td>&nbsp;</td>
      <td>&nbsp;</td>
    </tr>
    <tr>
      <td>
        <div align="left" class="style5">
         <p>Nome: <strong><? echo $nome ?></strong><br>
            E-MAIL: <strong><? echo $email ?></strong><br>
            Telefone: <strong><? echo $fonecontato ?></strong><br>
            Celular: <strong><? echo $celular ?></strong><br>
		    Regime: <strong><? echo $regime ?></strong><br>
		    
            Lota��o: <strong><? echo $intcap ?></strong><br>
		    Lota��o em: <strong><? echo $local ?></strong><br>
	
			
			Decreto: <strong><? echo $decreto ?></strong><br>						
			Data : <strong><? echo $dtdecreto ?></strong><br>			

			Di�rio Oficial: <strong><? echo $dof ?></strong><br>						
			Data : <strong><? echo $dtdof ?></strong><br>			

			Data Admiss�o: <strong><? echo $dtadmissao ?></strong><br>			
			Data Memo : <strong><? echo $dtemissao ?></strong><br>			
  		       Data Lota��o: <strong><? echo $dtlotacao ?></strong><br>			


			
		  </p>
      </div>

      </td>

<?  

//echo "$lotaadmesc";
//if (trim($lotaadmesc)=='E')

//echo "aaa $lotadolotacao";
//echo "aaaa aa $txtdptoorg";
//if ((trim($lotadolotacao)=='2') &&  ($txtdptoorg== 9))
if ((trim($lotadolotacao)=='2') &&  ($lotaadmesc== "E"))

 {   
?>

    <tr>
       <td>
          <p>
            INEP: <strong><? echo $inep?></strong><br>
            Escola: <strong><? echo $descescola ?></strong><br>
            Endere�o: <strong><? echo $endescola ?></strong><br>
            Bairro: <strong><? echo $bairroescola ?></strong><br>
            Nr: <strong><? echo $numeescola ?></strong><br>
            Tipo: <strong><? echo $tipoescola ?></strong><br>
            CEP: <strong><? echo $cepeescola ?></strong><br>
	     Fone: <strong><? echo $foneescola ?></strong><br>
         </p>
      </td>
    </tr>

<?
}
else
 {   

if (($txtdptoorg== 9))
{
?>
    <tr>
       <td>
          <p>
            Gerencia: <strong><? echo $descgerencia ?></strong><br>
            Departamento: <strong><? echo $descdpto ?></strong><br>
		   </p>
      </td>
    </tr>
<?
 }
}
?>








    <td>
    <p>MATRICULA: <strong><? echo $matricula ?></strong></p>
    <p>CPF: <strong><? echo $cpf ?></strong></p></td>
    </tr>
    <tr>
      <td>&nbsp;</td>
      <td>&nbsp;</td>
    </tr>
    <tr>
        <td class="style5">
        <p>Cargo: <strong><? echo $cargodesc ?></strong></p>
        <p>Fun&ccedil;&atilde;o: <strong><? echo $funcao ?></strong></p>
       
<?  
if (trim($cargo)=='1')
 {   
?>
            
        <p>Habilita��o/TAE : <strong><? echo $deschab ?></strong></p>

<?  
 }   
?>


      </td>
      <td class="style5">
        <p>V&iacute;nculo: <strong><? echo $regime ?></strong></p>
        </td>
    </tr>
    <tr>
      <td class="style5">&nbsp;</td>
      <td class="style5">&nbsp;</td>
    </tr>
    <tr>
      <td class="style5">&nbsp;</td>
      <td class="style5">&nbsp;</td>
    </tr>
    <tr>
      <td colspan="2" class="style5"><blockquote>
        <p><strong>Obs: </strong></p>
      </blockquote></td>
      </tr>
    <tr>
      <td colspan="2" class="style5"><blockquote><strong><? echo $txtobs1 ?></strong></blockquote></td>
      </tr>
    <tr>
      <td class="style5">&nbsp;</td>
      <td class="style5">&nbsp;</td>
    </tr>
    <tr>
      <td class="style5">&nbsp;</td>
      <td class="style5">&nbsp;</td>
    </tr>
    <tr>
      <td class="style5">&nbsp;</td>
      <td class="style5">&nbsp;</td>
    </tr>
    <tr>
      <td colspan="2" class="style5"><p align="center">__________________________________<br>

      </tr>
    <tr>
      <td class="style5">&nbsp;</td>
      <td class="style5">&nbsp;</td>
    </tr>
    <tr>
      <td class="style5">&nbsp;</td>
      <td class="style5">&nbsp;</td>
    </tr>

<tr>
<td align="left">
<form>
  <input type="button"  value="Imprimir a p�gina"   onClick="DoPrinting()"  align="left" />
</form>
</td>
</tr>



  </table>
  <script>
   cor_tabela("tabzebra");
 </script>

</div>
</div>
    </tr>
    <tr>

    </tr>
    <tr>
<tr>
<td align="center">

</td>
</tr>
</body>
</html>















<?
}
 
?>
