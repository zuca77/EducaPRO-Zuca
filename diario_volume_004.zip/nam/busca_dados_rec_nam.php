<?php
require_once '../start.php';
$pdo = new Conexao;

$title = 'Editar servidor';

if(empty($_GET['codigo'])) {
	redirectBack();
}

$servidor = Servidor::get($_GET['codigo']);

if($servidor) {

	$sql = "SELECT * FROM estados WHERE cod_estados = :estado;";
	$sth = $pdo->prepare($sql);
	$sth->bindParam(':estado', $servidor['estado']);
	$estado = $sth->execute() ? $sth->fetch() : null;

	$sql = "SELECT * FROM cidades WHERE cod_cidades = :cidade;";
	$sth = $pdo->prepare($sql);
	$sth->bindParam(':cidade', $servidor['cidade']);
	$cidade = $sth->execute() ? $sth->fetch() : null;

	$sql = "SELECT * FROM grauinstrucao WHERE codigo = :grauinstrucao;";
	$sth = $pdo->prepare($sql);
	$sth->bindParam(':grauinstrucao', $servidor['grauinstrucao']);
	$grauinstrucao = $sth->execute() ? $sth->fetch() : null;

} else {
	Notification::error('Servidor com CPF <b>' . $_GET['codigo'] . '</b> n�o localizado.');
	redirectBack();
}

$sql = "SELECT * FROM grauinstrucao";
$grauinstrucoes = $pdo->query($sql)->fetchAll();

$sql = "SELECT cod_estados, CONCAT(sigla, ' - ', nome) AS descricao FROM estados ORDER BY sigla";
$estados = $pdo->query($sql)->fetchAll();

$sql = "SELECT * FROM cidades WHERE estados_cod_estados = :estado;";
$sth = $pdo->prepare($sql);
$sth->bindParam(':estado', $servidor['estado']);
$cidades = $sth->execute() ? $sth->fetchAll() : null;

$sql = "SELECT codigo, descricao FROM municipio;";
$municipios = $pdo->query($sql)->fetchAll();

?><!DOCTYPE HTML>
<html>
	<head>
		<?php require_once page_head(); ?>
	</head>
	<body>
		<?php require_once page_header(); ?>
		<div class="container">
			<form class="submit-wait" action="altera_dados_pessoais_lota.php" method="POST">
				<fieldset class="well well-sm">
					<legend>Dados pessoais</legend>

					<div class="row">
						<div class="col-md-2">
							<div class="form-group">
								<label for="cpf">CPF</label>
								<input type="text" class="form-control" name="cpf" maxlength="11" id="cpf" value="<?php echo $servidor['cpf']; ?>" readonly>
							</div>
						</div>
						<div class="col-md-8">
							<div class="form-group">
								<label for="txtNome">Nome completo</label>
								<input type="text" class="form-control" name="txtNome" maxlength="60" value="<?php echo $servidor['nome']; ?>" id="txtNome">
							</div>
						</div>
						<div class="col-md-2">
							<div class="form-group">
								<label for="txtdtnascimento">Data de Nascimento</label>
								<input type="text" class="form-control mask-data" name="txtdtnascimento" value="<?php echo formataData($servidor['dtnascimento']); ?>" id="txtdtnascimento">
							</div>
						</div>
					</div>
					<div class="row">
						<div class="col-md-2">
							<div class="form-group">
								<label for="selectsexo">Sexo</label>
	       				<select id="selectsexo1" name="selectsexo1" class="form-control">
	              	<option value="M" <?php selected($servidor['sexo'] == 'M') ?>>MASCULINO</option>
	               	<option value="F" <?php selected($servidor['sexo'] == 'F') ?>>FEMININO</option>
				   			</select>
							</div>
						</div>
						<div class="col-md-2">
							<div class="form-group">
								<label for="lblselectecivil">Estado Civil</label>
								<?php $estadosCivils = array('CASADO' => 'CASADO', 'SOLTEIRO' => 'SOLTEIRO', 'DESQUITADO' => 'DESQUITADO', 'DIVORCIADO' => 'DIVORCIADO', 
									'UNIAOESTAVEL' => 'UNI�O EST�VEL', 'VIUVO' => 'VI�VO'); ?>
		          	<select id="selectcivil" name="selectcivil" class="form-control">
		          		<?php foreach ($estadosCivils as $key => $value): ?>
		           		<option value="<?php echo $key ?>" <?php selected($servidor['estcivil'] == $key) ?>><?php echo $value ?></option>
		          		<?php endforeach ?>
		            </select>
							</div>
						</div>
						<div class="col-md-2">
							<div class="form-group">
		  				 	<label for="pis">PIS / PASEP</label>
								<input type="text" class="form-control" name="pis" id="pis" value="<?php echo $servidor['pis']; ?>" maxlength="25">
							</div>
						</div>
						<div class="col-md-2">
							<div class="form-group">
								<label for="txtRG">RG</label>
								<input type="text" class="form-control" name="txtRG" value="<?php echo $servidor['rg']; ?>" id="txtRG" maxlength="20">
							</div>
						</div>
						<div class="col-md-2">
							<div class="form-group">
								<label for="txtOrgaoExp" >Org�o Expedidor RG</label>
								<input type="text" class="form-control" name="txtOrgaoExp" value="<?php echo $servidor['orgaoexp']; ?>" id="txtOrgaoExp"  maxlength="10">
							</div>
						</div>
						<div class="col-md-2">
							<div class="form-group">
								<label for="txtDataEmissao">Data Emiss�o RG</label>
								<input type="text" class="form-control mask-data" name="txtDataEmissao" value="<?php echo formataData($servidor['dtemissaorg']); ?>" id="txtDataEmissao" maxlength="12">
							</div>
						</div>
					</div>

					<div class="row">
						<div class="col-md-2">
							<div class="form-group">
								<label for="txtte">T�tulo de Eleitor</label>
								<input type="text" class="form-control" name="txtte" value="<?php echo $servidor['te']; ?>" id="txtte" maxlength="20">
							</div>
						</div>
						<div class="col-md-2">
							<div class="form-group">
								<label for="lblzona">Zona T�tulo</label>
								<input type="text" class="form-control" name="txtzona" value="<?php echo $servidor['zona']; ?>" id="txtzona" maxlength="10">
							</div>
						</div>
						<div class="col-md-2">
							<div class="form-group">
								<label for="lblsecao">Se��o T�tulo</label>
								<input type="text" class="form-control" name="txtsecao" value="<?php echo $servidor['secao']; ?>" id="txtsecao" maxlength="5">
							</div>
						</div>
						<div class="col-md-2">
							<div class="form-group">
								<label for="lbldtemissaote">Data de Emiss�o T�tulo</label>
								<input type="text" class="form-control mask-data" name="txttdtte" value="<?php echo formataData($servidor['dtemissaote']); ?>" id="txttdtte" maxlength="12">
							</div>
						</div>
						<div class="col-md-4">
							<div class="form-group">
								<label for="txtinstrucao">Grau de Instru��o</label>
								<select name="txtinstrucao" id="txtinstrucao" class="form-control">
									<option value="">Selecione</option>
									<?php foreach($grauinstrucoes as $grau): ?>
									<option value="<?php echo $grau['codigo'] ?>" <?php selected($grau['codigo']==$servidor['grauinstrucao']) ?>>
										<?php echo $grau['descricao']; ?>
									</option>
									<?php endforeach ?>
								</select>
							</div>
						</div>
					</div>

					<div class="row">
						<div class="col-md-6">
							<div class="form-group">
								<label for="lblmae">Nome da m�e</label>
								<input type="text" class="form-control" name="txtmae" maxlength="60" value="<?php echo $servidor['mae']; ?>" id="txtmae">
							</div>
						</div>
						<div class="col-md-6">
							<div class="form-group">
								<label for="lblpai">Nome do pai</label>
								<input type="text" class="form-control" name="txtpai" maxlength="60" value="<?php echo $servidor['pai']; ?>" id="txtpai">
							</div>
						</div>
					</div>

					<div class="row">
						<div class="col-md-5">
							<div class="form-group">
								<label for="txtconjuge">Nome do c�njuge</label>
								<input type="text" class="form-control" name="txtconjuge" maxlength="60" value="<?php echo $servidor['conjuge']; ?>" id="txtconjuge">
							</div>
						</div>
						<div class="col-md-3">
							<div class="form-group">
								<label for="cod_estado">Estado Natural</label>
						   	<select name="cod_estado" id="cod_estado" class="form-control chosen">
					   			<option value=""></option>
								  <?php foreach($estados as $estado): ?>
			            <option value="<?php echo $estado['cod_estados']?>" <?php selected($estado['cod_estados'] == $servidor['estado']) ?>>
										<?php echo $estado['descricao'];?>
									<?php endforeach ?>
							  </select>
							</div>
						</div>
						<div class="col-md-4">
							<div class="form-group">
								<label for="lblcod_cidades">Cidade Natural</label>
			          <select name="cod_cidades" id="cod_cidades" class="form-control chosen">
		           		<option value=""></option>
									<?php foreach($cidades as $c): ?>
									<option value="<?php echo $c['cod_cidades']; ?>" <?php selected($c['cod_cidades'] == $servidor['cidade']) ?>>
										<?php echo $c['nome'] ?>
									</option>
									<?php endforeach ?>
								</select>
							</div>
						</div>
					</div>
				</fieldset>

				<fieldset class="well well-sm">
					<legend>Endere�o e contato</legend>

					<div class="row">
						<div class="col-md-6">
							<div class="form-group">
								<label for="lblEndereco">Logradouro</label>
								<input type="text" class="form-control" name="txtEndereco" value="<?php echo $servidor['endereco']; ?>"  maxlength="60" size="60" id="txtEndereco">
							</div>
						</div>
						<div class="col-md-2">
							<div class="form-group">
								<label for="txtnr">N�mero</label>
								<input type="text" class="form-control" name="txtnr" value="<?php echo $servidor['numero']; ?>" id="txtnr" maxlength="10">
							</div>
						</div>
						<div class="col-md-4">
							<div class="form-group">
								<label for="txtBairro">Bairro</label>
								<input type="text" class="form-control" name="txtBairro" value="<?php echo $servidor['bairro']; ?>" id="txtBairro"  maxlength="60"/>
							</div>
						</div>
					</div>

					<div class="row">
						<div class="col-md-2">
							<div class="form-group">
								<label for="txtCEP">CEP</label>
	        			<input id="txtcep" name="txtcep" type="text" class="form-control" value="<?php echo $servidor['cep']; ?>" maxlength="8">
							</div>
						</div>
						<div class="col-md-4">
							<div class="form-group">
								<label for="lblEndereco">Complemento</label>
								<input type="text" class="form-control" name="txtcomplemento" value="<?php echo $servidor['complemento']; ?>"  maxlength="40" size="60" id="txtcomplemento">
							</div>
						</div>
						<div class="col-md-6">
							<div class="form-group">
								<label for="cod_muni">Munic�pio</label>
						  	<select name="cod_muni" id="cod_muni" class="form-control chosen">
								  <option value=""></option>
								  <?php foreach($municipios as $mu): ?>
			            <option value="<?php echo $mu['codigo']?>" <?php selected($mu['codigo']==$servidor['municipio']) ?>><?php echo $mu['descricao'];?></option>
									<?php endforeach ?>
						   	</select>
							</div>
						</div>
					</div>

					<div class="row">
						<div class="col-md-2">
							<div class="form-group">
								<label for="txtFoneSetor">Telefone Comercial</label>
								<input type="text" class="form-control" name="txtFoneSetor" value="<?php echo $servidor['fonesetor']; ?>" id="txtFoneSetor"  maxlength="20"/>
							</div>
						</div>
						<div class="col-md-2">
							<div class="form-group">
								<label for="txtFoneRes">Telefone Residencial</label>
								<input type="text" class="form-control" name="txtFoneRes" value="<?php echo $servidor['foneresidencial']; ?>" id="txtFoneRes" maxlength="20"/>
							</div>
						</div>
						<div class="col-md-2">
							<div class="form-group">
								<label for="txtCelular">Telefone Celular</label>
								<input type="text" class="form-control" name="txtCelular" value="<?php echo $servidor['celular']; ?>" id="txtCelular" maxlength="20"/>
							</div>
						</div>
						<div class="col-md-2">
							<div class="form-group">
								<label for="txtCelular">Telefone Contato</label>
								<input type="text" class="form-control" name="txtcontato" value="<?php echo $servidor['fonecontato']; ?>" id="txtcontato" maxlength="25"/>
							</div>
						</div>
						<div class="col-md-4">
							<div class="form-group">
								<label for="txtEmail">E-mail</label>
								<input type="text" class="form-control" name="txtEmail" value="<?php echo $servidor['email']; ?>" id="txtEmail" maxlength="80"/>
							</div>
						</div>
					</div>
				</fieldset>

				<div class="row">
					<div class="col-md-6">
						<fieldset class="well well-sm">
							<legend>Dados banc�rios</legend>

							<div class="row">
								<div class="col-md-4">
									<div class="form-group">
									  <label for="txtBanco">Banco</label>
									  <input type="text" class="form-control" name="txtBanco" value="<?php echo str_pad($servidor['banco'], 3, '0', STR_PAD_LEFT); ?>" id="txtBanco" maxlength="3">
									</div>
								</div>
								<div class="col-md-4">
									<div class="form-group">
									  <label for="txtAgencia">Ag�ncia</label>
									  <input type="text" class="form-control" name="txtAgencia" value="<?php echo $servidor['agencia']; ?>" id="txtAgencia" maxlength="10">
									</div>
								</div>
								<div class="col-md-4">
									<div class="form-group">
									  <label for="txtConta">Conta</label>
									  <input type="text" class="form-control" name="txtConta" value="<?php echo $servidor['cc']; ?>" id="txtConta" maxlength="20"/>
									</div>
								</div>
							</div>
						</fieldset>
					</div>
					<div class="col-md-6">
						<div class="form-group">
							<label for="txtobs">Observa��es</label>
							<textarea name="txtobs" id="txtobs" class="form-control" rows="5"><?php echo $servidor['observacao'] ?></textarea>
						</div>
					</div>
				</div>

    		<div class="well well-sm">
          <input type="submit" class="btn btn-primary btn-submit-wait" value="SALVAR ALTERA��ES">
     	    <input type="button" value="Voltar " class="btn btn-default btn-back pull-right">
	    	</div>
			</form>
		</div>
		<?php require_once page_footer(); ?>
		<script>
			$(function() {
			$('#cod_estado').on('change', function() {
				var estado = $(this).val();
				$.get('cidades.ajax.php', { cod_estado: estado })
					.success(function(cidades) {
						var options = '<option value=""></option>';
						for (key in cidades) {
							options += '<option value="' + cidades[key].cod_cidades + '">' + cidades[key].nome + '</option>';
						}
						$('#cod_cidades').html(options).trigger('chosen:updated');
					})
					.error(function() {
						$('#cod_cidades').html('<option value=""></option>').trigger('chosen:updated');
					});
			})
		});
		</script>
	</body>
</html>