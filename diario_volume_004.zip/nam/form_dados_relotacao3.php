<?php
if(file_exists("../conexao_mysql.php"))
{
        require "../conexao_mysql.php";
        mysql_query("SET NAMES 'utf8'");
		$ano  = date("Y");
} else
{
        echo "Conexão nao foi encontrado";
        exit;
}


?>

<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01//EN"
	"http://www.w3.org/TR/html4/strict.dtd">
<head>
	<meta http-equiv="Content-type" content="text/html; charset=utf-8" />
	<title>SEDUC-RO</title>
	<link rel="stylesheet" href="style/forms.css" type="text/css" />
	<link rel="stylesheet" href="estilo.css" type="text/css" />
	<link rel="stylesheet" href="style/menu.css" type="text/css" />


	<link href="tablecloth/tablecloth.css" rel="stylesheet" type="text/css" media="screen" />

	<script type="text/javascript" src="tablecloth/tablecloth.js"></script>
	<script src="lib/jquery-1.4.2.js" type="text/javascript"></script>
	<script src="lib/validate.js" type="text/javascript"></script>
	<script src="lib/forms.js" type="text/javascript"></script>
	<script src="genericlota.js" type="text/javascript"></script>
    <script src="lib/jquery.maskedinput-1.1.1.js" type="text/javascript"></script>


	<link type="text/css" href="jquery-ui-1.8.18.custom/css/ui-lightness/jquery-ui-1.8.18.custom.css" rel="stylesheet" />
<!--	<script type="text/javascript" src="jquery-ui-1.8.18.custom/js/jquery-1.7.1.min.js"></script>-->
	<script type="text/javascript" src="jquery-ui-1.8.18.custom/js/jquery-ui-1.8.18.custom.min.js"></script>





<script type="text/javascript">


$(function() {
		$( "#txtdtlota11" ).datepicker({
			changeMonth: true,
			changeYear: true
		});
	});

$(function() {
        $("#txtdtlota11").datepicker();
        $('#txtdtlota11').datepicker('option', 'dateFormat', 'dd/mm/yy');
});

</script>


</head>
<body>
	<div id="warpper">
		<div id="header">
		    <img src= "img/seduc_topo.jpg"/>

		</div>
    <div id="container">
			<div id="content">

				<form  name="form" class="form" action="insere_lotacao.php" method="POST">
				 <div id="tema">
					   <p><center>Lotacao</center></p>
				  </div>

<?php

$id = $_GET['codigo'];

$cpf=  $_POST["cpf"];
$cpflota=  $_POST["cpf"];


/*$sqlmemo="select * from memo where id = $id";
$resultadomemo=mysql_query($sqlmemo) or die (mysql_error());
$linhasmemo=mysql_num_rows($resultadomemo);

if($linhasmemo>0)
{
   while($pegarmemo=mysql_fetch_array($resultadomemo))
   {

      $cpfmemo          =$pegarmemo["CPF"];
      $matricula        =$pegarmemo["MATRICULA"];
      $lotaintcap       =$pegarmemo["LOTAINTCAP"];
      $lotaadmesc       =$pegarmemo["LOTAADMESC"];
      $cod_estado       =$pegarmemo["MUNILOTA"];

   }
}


if ($lotaintcap=='I')
    $lotaintcap ='INTERIOR';
else
   $lotaintcap ='CAPITAL';


if ($lotaadmesc=='A')
    $lotaadmesc ='ADM';
else
   $lotaadmesc ='ESCOLA';


/******************Municipio*************************************************/
/*	$sqlgerencia = "SELECT codigo, descricao FROM municipio where codigo='$cod_estado'";
    $resultadoger=mysql_query($sqlgerencia) or die (mysql_error());
    $linhas   =mysql_num_rows($resultadoger);

if($linhas>0)
{
   while($pegar=mysql_fetch_array($resultadoger))
	{
    	$munilota    =$pegar["descricao"];
	}
 }
/*******************************************************************/








$sqldados="select * from servidorrec where cpf = '$cpf'";
$resultadodados=mysql_query($sqldados) or die (mysql_error());
$linhasdados=mysql_num_rows($resultadodados);

if($linhasdados>0)
{
   while($pegardados=mysql_fetch_array($resultadodados))
   {
    $cpf              =$pegardados["cpf"];
	$nome             =$pegardados["nome"];
	$mae              =$pegardados["mae"];
    $pai              =$pegardados["pai"];
	$endereco         =$pegardados["endereco"];
	$bairro           =$pegardados["bairro"];
	$fonesetor        =$pegardados["fonesetor"];
	$fonecontato      =$pegardados["fonecontato"];
	$foneresidencial  =$pegardados["foneresidencial"];
	$celular          =$pegardados["celular"];
	$email            =$pegardados["email"];

    }
  }

?>


					<p>
						<label for="txtCPF">CPF<img src= "recadastramento/img/check.gif"/></label>
						<input type="text" name="cpf" style="width:110px"  maxlength="11" id="cpf"  value= "<? echo $cpf; ?>"  readonly="true"/>

					</p>


					<p>
						<label for="txtNome">Nome</label>
						<input type="text" name="txtNome" style="width:565px" maxlength="60" value= "<? echo $nome; ?>" id="txtNome" readonly="true"/>
					</p>

					<p>
						<label for="lblmae">Nome Mãe</label>
						<input type="text" name="txtmae" style="width:565px" maxlength="60" value= "<? echo $mae; ?>" id="txtmae" readonly="true"/>
					</p>
					<p>
						<label for="lblpai">Nome Pai</label>
						<input type="text" name="txtpai" style="width:565px" maxlength="60" value= "<? echo $pai; ?>" id="txtpai"  readonly="true"/>
					</p>


					<p>
						<label for="lblEndereco">Endereco</label>
						<input type="text" name="txtEndereco" style="width:565px" value= "<? echo $endereco; ?>"  maxlength="60" size="60" id="txtEndereco" readonly="true"/>
					</p>

					<p>
						<label for="lblEndereco">Complemento</label>
						<input type="text" name="txtcomplemento" style="width:565px" value= "<? echo $bairro; ?>"  maxlength="40" size="60" id="txtcomplemento" readonly="true"/>
					</p>


					<p>
						<label for="lblBairro">Bairro</label>
						<input type="text" name="txtBairro" value= "<? echo $bairro; ?>" id="txtBairro"  maxlength="40" readonly="true"/>
						<label for="lblBairro">N.</label>
						<input type="text" name="txtnr" style="width:60px" value= "<? echo $numero; ?>" id="txtnr" maxlength="5" readonly="true"/>
			            <label for="txtCEP">CEP</label>
            			<input id="txtcep" name="txtcep" type="text" style="width:90px" value= "<? echo $cep; ?>" maxlength="8" onKeyPress="return Enum(event)" readonly="true"/>
					</p>
					<p>
						<label for="txtFoneSetor">Telefone Comercial</label>
						<input type="text" name="txtFoneSetor" style="width:90px" value= "<? echo $fonesetor; ?>" id="txtFoneSetor"  maxlength="20" readonly="true"/>
						<label for="txtFoneRes">Residencial</label>
						<input type="text" name="txtFoneRes" style="width:90px" value= "<? echo $foneresidencial; ?>" id="txtFoneRes" maxlength="20" readonly="true"/>
						<label for="txtCelular">Celular</label>
						<input type="text" name="txtCelular" style="width:90px" value= "<? echo $celular; ?>" id="txtCelular" maxlength="20" readonly="true"/>
						<label for="txtCelular">Contato</label>
						<input type="text" name="txtcontato" style="width:90px" value= "<? echo $fonecontato; ?>" id="txtcontato" maxlength="25" readonly="true"/>

					</p>
					<p>
						<label for="txtEmail">E-mail</label>
						<input type="text" name="txtEmail" style="width:565px" value= "<? echo $email; ?>" id="txtEmail" maxlength="80" readonly="true"/>
					</p>

				<p id="finish">
            <input type="button" value=" Voltar " onclick="history.go(-1);">
            <input type="submit" value="Gravar" />
            <input type="reset" value="limpar" />
					</p>

<?


?>



				 <div id="tema">
					   <p><center>Histórico Lotação</center></p>
				  </div>
				</form>
			</div>
		</div>



<table border="0" width="100%">
<tr>
 <td width="20"><b>Relotar</b></td>
 <td width="5"><b>Matricula</b></td><td><b>Gerência/INEP</b></td><td><b>Descrição</b></td><td><b>Data Lotação</b></td><td><b>Data Saída</b></td><td>
 <b>CH</b></td>
</tr>





<?
/**************Seleciona toda tabela**********/

 $id	 = $cpflota;


 $tabela_toda = "select * from lotacao where cpf = '$id'";
 $query = mysql_query($tabela_toda, $conexao) or die(mysql_error());


 $re = mysql_query("SELECT count(*) as codigo FROM lotacao where cpf = '$id'");
 $total = mysql_result($re, 0, "codigo");

 $pagina = 1;
 $limite = 7;

if(isset($_GET["pagina"]))
  {
	$pagina = $_GET["pagina"];
  }

 $paginas = ceil($total / $limite);

 $inicio = ($pagina-1) * $limite;


if ($inicio < 0)
  {
      $inicio=1;
  }


$tabela_toda1 = "select * from lotacao where cpf = '$id'";
$query1 = mysql_query($tabela_toda1) or die(mysql_error());
while ( $linhatotal1 = mysql_fetch_array( $query1 ))
{
 $lotado =$linhatotal1["lotado"];


if ($lotado=='2')
 {
$sqlfiltro = mysql_query("select l.id,l.cpf,l.matricula,l.lotado,l.gerencia,l.departamento, l.inep,l.dtlotacao,l.chlotacao,e.descricao,l.dtsaida from lotacao l,escola e where l.cpf = '$id' and  l.inep=e.inep");
 $conta = mysql_num_rows($sqlfiltro);
 }

else
 {

   $sqlfiltro = mysql_query("SELECT distinct l.cpf,l.id,l.matricula,l.chlotacao,s.nome,l.dtlotacao,l.dtsaida,s.endereco,s.bairro,g.descricao,cg.descricao as descricaocg,f.descricao as descricaof,d.descricao as descricaod FROM lotacao   l,servidorrec s,gerencia g,cargo cg,funcao f,contrato c,departamento d WHERE l.lotado ='1' and l.cpf =s.cpf and l.gerencia = g.codigo  and  l.gerencia <> '' AND cg.cod_cargo = c.cargo AND f.cod_funcao = c.funcao and  c.cpf =l.cpf and c.cpf = s.cpf and l.cpf = '$id' and d.codigo_dpto=l.departamento and d.gerencia = l.gerencia order by s.nome");
 $conta = mysql_num_rows($sqlfiltro);
 }











if($conta == 0)
   {
     $pagina = $pagina-1;
   }


if($total >=1)
   {

  while ( $linha1 = mysql_fetch_array( $sqlfiltro ))
   {
          $data = date("d/m/Y",strtotime($linha1["dtlotacao"]));
	    $dtadmissao = date("d/m/Y",strtotime($linha1["dtsaida"]));

        if ($dtadmissao=='31/12/1969')
		   {
		     $dtadmissao='';
		   }



?>
<tr>

<?
 if ($dtadmissao=='')
  {
?>
<td align="center"><a href="form_lotacao_relotacao.php?codigo=<?echo $linha1["id"];?>"><img src="/public/img/editar.png" title="Permiti relotar servidor"></a></td>
<?
   }//dtadminssao
else
{
?>
    <td align="center"><a href="#"><img src="/public/img/sucess.png" title="Contrato não pode ser movimentado"></a></td>
<?
}


if ($lotado=='2')
{
?>
   	  <td class="fonte"><?echo $linha1["matricula"];?></td>
      <td><?echo $linha1["inep"];?></td>
      <td><?echo $linha1["descricao"];?></td>
      <td><?echo $data;?></td>
      <td><?echo $dtadmissao;?></td>
     <td><?echo $linha1["chlotacao"];?></td>
  </tr>
<?
}
else
{
?>
   	  <td class="fonte"><?echo $linha1["matricula"];?></td>
      <td><?echo $linha1["descricao"];?></td>
      <td><?echo $linha1["descricaod"];?></td>
      <td><?echo $data;?></td>
      <td><?echo $dtadmissao;?></td>
     <td><?echo $linha1["chlotacao"];?></td>

  </tr>
<?
}





 }
}
}//fim while1
?>
</table>
      <script>
     <!--  cor_tabela("tabzebra");-->
    </script>
 </div><!-- Div corpodetalhe-->
</div><!-- Div corpo2-->

<?
  mysql_close($conexao);
?>
  <div id="rodapeconsulta" class="fonterodape">
<?
if($paginas != 1)
{
 if($pagina != 1)
   {
    $menos = $pagina - 1;
    $url = $_SERVER["PHP_SELF"]."?pagina=".$menos;
    echo "<a href=\"?pagina=1\">&lt;&lt;Primeira </a> ";
    echo "<a href=\"$url\">&lt;Anterior </a> ";
   }
   if($paginas > 1)
   {
	for($x=1;$x<=$paginas;$x++)
	 {
		$url = $_SERVER["PHP_SELF"]."?pagina=".$x;
		if($x == $pagina)
		{
			echo "<strong>$x</strong> ";
		}
		else
		{
			echo "<a href=\"$url\">$x</a> ";
		}
	  }
   }
if($pagina != $paginas)
 {
   $mais = $pagina + 1;
   $url = $_SERVER["PHP_SELF"]."?pagina=".$mais;
   echo "<a href=\"$url\"> Próxima&gt; </a> ";
   echo "<a href=\"?pagina=$paginas\"> Última&gt;&gt; </a> ";
 }
 }




?>
</div>
		<div id="footer">
			<p>Todos direitos reservados GTI/SEDUC</p>
		</div>
	</div>
</body>

