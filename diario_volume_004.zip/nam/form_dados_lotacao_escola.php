<?php
session_start();
if (isset($_SESSION["login_usuario"]))
  {
     $login =  $_SESSION["login_usuario"];
     $nte   =  $_SESSION["nivel_usuario"];
     include ("../funcoes.php");
     echo  saudacoes()."   ". "$login" ."  -  ". $nte."  ".dataextenso();
  }
 else
  {
     		 header("Location: ../login.php");
  }


if(file_exists("../conexao_mysql.php")) 
{
        require "../conexao_mysql.php";             
        mysql_query("SET NAMES 'latin1_swedish_ci'");
       $ano  = date("Y");		             

} else 
{
        echo "Conexo nao foi encontrado";
        exit;
}




$dia = date('d');
$mes = date('m');
$ano = date('Y');

$data =$dia."/".$mes."/".$ano;


?>

<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01//EN"
	"http://www.w3.org/TR/html4/strict.dtd">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1" />
	<title>SEDUC-RO</title>
	<link rel="stylesheet" href="style/forms.css" type="text/css" />
	<link rel="stylesheet" href="estilo.css" type="text/css" />
	<link rel="stylesheet" href="style/menu.css" type="text/css" />

	
	<link href="tablecloth/tablecloth.css" rel="stylesheet" type="text/css" media="screen" />
	
	<script type="text/javascript" src="tablecloth/tablecloth.js"></script>
	<script src="lib/jquery-1.4.2.js" type="text/javascript"></script>
	<script src="lib/validate.js" type="text/javascript"></script>
	<script src="lib/forms.js" type="text/javascript"></script>
	<script src="genericescola.js" type="text/javascript"></script>
    <script src="lib/jquery.maskedinput-1.1.1.js" type="text/javascript"></script>


	<link type="text/css" href="jquery-ui-1.8.18.custom/css/ui-lightness/jquery-ui-1.8.18.custom.css" rel="stylesheet" />
	<script type="text/javascript" src="jquery-ui-1.8.18.custom/js/jquery-ui-1.8.18.custom.min.js"></script>







</head>
<body>
	<div id="warpper">
		<div id="header">
		    <img src= "img/seduc_topo.jpg"/>

		</div>
    <div id="container">
			<div id="content">

				<form  name="form" class="form" action="dados_pessoal_escola.php" method="POST">
				 <div id="tema"> 
					   <p><center>Lotacao</center></p>
				  </div>

<?php

$id = $_GET['codigo'];
$idlota = $_GET['codigo'];



$sqlmemo="select * from lotacao where id = $id";
$resultadomemo=mysql_query($sqlmemo) or die (mysql_error());
$linhasmemo=mysql_num_rows($resultadomemo);

if($linhasmemo>0)
{
   while($pegarmemo=mysql_fetch_array($resultadomemo))
   {

      $cpfmemo          =$pegarmemo["cpf"];
      $matricula        =$pegarmemo["matricula"];
      $inep             =$pegarmemo["inep"];
      $habilitacao      =$pegarmemo["areaatuacao"];
      $chlotacao        =$pegarmemo["chlotacao"];

      $txtautacao1bd        =$pegarmemo["disciplina1"];
      $txtautacao2bd        =$pegarmemo["disciplina2"];
      $txtautacao3bd        =$pegarmemo["disciplina3"];
      $txtautacao4bd        =$pegarmemo["disciplina4"];


      $txtqdtaaulas1m     =$pegarmemo["qdtaaulas1m"];
      $txtqdtaaulas1t     =$pegarmemo["qdtaaulas1t"];
      $txtqdtaaulas1n     =$pegarmemo["qdtaaulas1n"];

      $txtqdtaaulas2m    =$pegarmemo["qdtaaulas2m"];
      $txtqdtaaulas2t    =$pegarmemo["qdtaaulas2t"];
      $txtqdtaaulas2n    =$pegarmemo["qdtaaulas2n"];


      $txtqdtaaulas3m    =$pegarmemo["qdtaaulas3m"];
      $txtqdtaaulas3t    =$pegarmemo["qdtaaulas3t"];
      $txtqdtaaulas3n    =$pegarmemo["qdtaaulas3n"];



      $txtqdtaaulas4m    =$pegarmemo["qdtaaulas4m"];
      $txtqdtaaulas4t    =$pegarmemo["qdtaaulas4t"];
      $txtqdtaaulas4n    =$pegarmemo["qdtaaulas4n"];


      $m1                =$pegarmemo["m1"];
      $t1                =$pegarmemo["t1"];
      $n1                =$pegarmemo["n1"];



      $m2                =$pegarmemo["m2"];
      $t2                =$pegarmemo["t2"];
      $n2                =$pegarmemo["n2"];

      $m3                =$pegarmemo["m3"];
      $t3                =$pegarmemo["t3"];
      $n3                =$pegarmemo["n3"];

      $m4                =$pegarmemo["m4"];
      $t4                =$pegarmemo["t4"];
      $n4                =$pegarmemo["n4"];


      $txtobsescola        =$pegarmemo["obsescola"];
      $selectexecercio     =$pegarmemo["ambescola"];
      $txthe               =$pegarmemo["hextra"];



      $txttfundamental        =$pegarmemo["tfundamental"];
      $txttmedio              =$pegarmemo["tmedio"];
      $txtteja                =$pegarmemo["teja"];



      $txtsituacao               =$pegarmemo["situacao"];


   }
}  






/******************Municipio*************************************************/
	$sqlgerencia = "SELECT codigo, descricao FROM habilitacao where codigo='$habilitacao'";
    $resultadoger=mysql_query($sqlgerencia) or die (mysql_error());
    $linhas   =mysql_num_rows($resultadoger);

if($linhas>0)
{
   while($pegar=mysql_fetch_array($resultadoger))
	{
    	$deschabilitacao   =$pegar["descricao"];
	}
 }	
/*******************************************************************/


$sqldados="select * from servidorrec where cpf = '$cpfmemo'";
$resultadodados=mysql_query($sqldados) or die (mysql_error());
$linhasdados=mysql_num_rows($resultadodados);

if($linhasdados>0)
{
   while($pegardados=mysql_fetch_array($resultadodados))
   {
    $cpf              =$pegardados["cpf"];
	$nome             =$pegardados["nome"];
	$mae              =$pegardados["mae"]; 	
    $pai              =$pegardados["pai"]; 	
	$endereco         =$pegardados["endereco"]; 	
	$bairro           =$pegardados["bairro"]; 	
	$fonesetor        =$pegardados["fonesetor"]; 	
	$fonecontato      =$pegardados["fonecontato"]; 	
	$foneresidencial  =$pegardados["foneresidencial"]; 	
	$celular          =$pegardados["celular"]; 	
	$email            =$pegardados["email"]; 	
	$txtcep           =$pegardados["cep"];
	$txtnr            =$pegardados["numero"];
    }
  }

?>
	
	
					<p>
						<label for="txtCPF">ID<img src= "recadastramento/img/check.gif"/></label>
						<input type="text" name="txtid" style="width:110px"  maxlength="11" id="txtid"  value= "<? echo $idlota; ?>"  readonly="true"/>

					</p>

					<p>
						<label for="txtCPF">CPF<img src= "recadastramento/img/check.gif"/></label>
						<input type="text" name="cpf" style="width:110px"  maxlength="11" id="cpf"  value= "<? echo $cpf; ?>"  readonly="true"/>

					</p>
	

					<p>
						<label for="txtNome">Nome</label>
						<input type="text" name="txtNome" style="width:565px" maxlength="60" value= "<? echo $nome; ?>" id="txtNome" readonly="true"/>
					</p>
					
					<p>
						<label for="lblmae">Nome M�e</label>
						<input type="text" name="txtmae" style="width:565px" maxlength="60" value= "<? echo $mae; ?>" id="txtmae" readonly="true"/>
					</p>
					<p>
						<label for="lblpai">Nome Pai</label>
						<input type="text" name="txtpai" style="width:565px" maxlength="60" value= "<? echo $pai; ?>" id="txtpai"  readonly="true"/>
					</p>


					<p>
						<label for="lblEndereco">Endere�o</label>
						<input type="text" name="txtEndereco" style="width:565px" value= "<? echo $endereco; ?>"  maxlength="60" size="60" id="txtEndereco" readonly="true"/>
					</p>

					<p>
						<label for="lblEndereco">Complemento</label>
						<input type="text" name="txtcomplemento" style="width:565px" value= "<? echo $bairro; ?>"  maxlength="40" size="60" id="txtcomplemento" readonly="true"/>
					</p>


					<p>
						<label for="lblBairro">Bairro</label>
						<input type="text" name="txtBairro" value= "<? echo $bairro; ?>" id="txtBairro"  maxlength="40" readonly="true"/>
						<label for="lblBairro">N.</label>
						<input type="text" name="txtnr" style="width:60px" value= "<? echo $txtnr; ?>" id="txtnr" maxlength="5" readonly="true"/>
			            <label for="txtCEP">CEP</label>
            			<input id="txtcep" name="txtcep" type="text" style="width:90px" value= "<? echo $txtcep; ?>" maxlength="8" onKeyPress="return Enum(event)" readonly="true"/>
					</p>
					<p>
						<label for="txtFoneSetor">Telefone Comercial</label>
						<input type="text" name="txtFoneSetor" style="width:90px" value= "<? echo $fonesetor; ?>" id="txtFoneSetor"  maxlength="20" readonly="true"/>
						<label for="txtFoneRes">Residencial</label>
						<input type="text" name="txtFoneRes" style="width:90px" value= "<? echo $foneresidencial; ?>" id="txtFoneRes" maxlength="20" readonly="true"/>
						<label for="txtCelular">Celular</label>
						<input type="text" name="txtCelular" style="width:90px" value= "<? echo $celular; ?>" id="txtCelular" maxlength="20" readonly="true"/>
						<label for="txtCelular">Contato</label>
						<input type="text" name="txtcontato" style="width:90px" value= "<? echo $fonecontato; ?>" id="txtcontato" maxlength="25" readonly="true"/>

					</p>
					<p>
						<label for="txtEmail">E-mail</label>
						<input type="text" name="txtEmail" style="width:565px" value= "<? echo $email; ?>" id="txtEmail" maxlength="80" readonly="true"/>
					</p>

					<p>
						<label for="txtEmail">Matricula</label>
						<input type="text" name="txtmatricula" style="width:150px" value= "<? echo $matricula; ?>" id="txtmatricula" maxlength="80" readonly="true"/>
					</p>
					
					<p>
						<label for="txtEmail">Lota��o</label>
						<input type="text" name="txtlotacao" style="width:200px" value= "<? echo $deschabilitacao; ?>" id="txtlotacao" maxlength="80" readonly="true"/>
						<label for="txtEmail">C.H</label>
						<input type="text" name="txtch" style="width:70px" value= "<? echo $chlotacao; ?>" id="txtch" maxlength="80" readonly="true"/>
					</p>

                      <p>
						<label for="txtdtlotacao1">Dt Apresenta��o</label>
						<input type="text" name="txtdtlota11" value ="<? echo $data;?>" style="width:70px" id="txtdtlota11"  readonly="true"/>	
                     </p>






		                <p>
			  	<label for="selectncontrato">Situa��o<img src= "img/check.gif"/></label>
 			    <select id="selectsituacao" name="selectsituacao" style="width:350px" >
				   <option value="">Selecione a Situa��o</option>
  					<?php
							include ("../conexao_mysql.php");
							$sql = "SELECT id, descricao
									FROM licenca
									ORDER BY descricao";
						   $res = mysql_query($sql);
						   if($res)
							  {
								while($row = mysql_fetch_array($res)){
							    ?>
  			                    <option value="<?php echo $row['id']?>"
						        <?php if($row['id'] == $txtsituacao){ echo "selected";}?>>
								<?php echo $row['descricao'];?>
								<?php
							      } }
						        ?>
					   </select>
					</p>















					<p>

			  	<label for="selectncontrato">Local Exerc�cio<img src= "img/check.gif"/></label>
 			    <select id="selectexecercio" name="selectexecercio" style="width:350px" >
				   <option value="">Selecione o Local de Exerc�cio</option>
  					  <?php
						   $sql = "SELECT id, descricao
									FROM ambienteescola
									ORDER BY descricao";
						   $res = mysql_query($sql);
						   if($res)
							  {
								while($row = mysql_fetch_array($res)){
							    ?>
  			                    <option value="<?php echo $row['id']?>"
						        <?php if($row['id'] == $selectexecercio){ echo "selected";}?>>
								<?php echo $row['descricao'];?>
								<?php
							      } }
						        ?>
					   </select>
					</p>




   	 </p>




                  <p>
			

                       		<label for="lblareaatuacao1" style="width:150px">Disciplina<img src= "img/check.gif"/></label>
						<select name="txtautacao1" id="txtautacao1" style="width:300px" >
						<option value="">Selecione Disciplina</option>
  					<?php
							include ("../conexao_mysql.php");
							$sql = "SELECT codigo, descricao
									FROM habilitacao
									ORDER BY descricao";
						   $res = mysql_query($sql);
						   if($res)
							  {
								while($row = mysql_fetch_array($res)){
							    ?>
  			                    <option value="<?php echo $row['codigo']?>"
						        <?php if($row['codigo'] == $txtautacao1bd){ echo "selected";}?>>
								<?php echo $row['descricao'];?>
								<?php
							      } }
						        ?>
					   </select>


<?
  if ($m1=='M')
    {
?>
		  <label for="lbldeficienten">Manha
		      <input name="m1" type="checkbox"  value ="M"  id="m1"  checked="checked">
		  </label>
<?
   }
else
  {
?>	
		  <label for="lbldeficienten">Manha
		      <input name="m1" type="checkbox"  value ="M"  id="m1" >
		  </label>
<?
	}
?>

      		  <input type="text" name="txtqdtaaulas1m" value= "<? echo $txtqdtaaulas1m; ?>" style="width:30px" id="txtqdtaaulas1m" maxlength="2"   onKeyPress="return Enum(event)"/>


<?
  if ($t1=='T')
    {
?>
		  <label for="lbldeficienten">Tarde
		      <input name="t1" type="checkbox"  value ="T"  id="t1"  checked="checked">
		  </label>
<?
   }
else
  {
?>	
		  <label for="lbldeficienten">Tarde
		      <input name="t1" type="checkbox"  value ="T"  id="t1"  >
		  </label>
<?
	}
?>



   			 <input type="text" name="txtqdtaaulas1t" value= "<? echo $txtqdtaaulas1t; ?>" style="width:30px" id="txtqdtaaulas1t" maxlength="2"   onKeyPress="return Enum(event)"/>




<?
  if ($n1=='N')
    {
?>
          <label for="lbldeficienten">Noite
		      <input name="n1" type="checkbox"  value ="N"  id="n1" checked="checked" >
          </label>
<?
   }
else
  {
?>	
          <label for="lbldeficienten">Noite
		      <input name="n1" type="checkbox"  value ="N"  id="n1"  >
          </label>
<?
	}
?>



  			  <input type="text" name="txtqdtaaulas1n" value= "<? echo $txtqdtaaulas1n; ?>" style="width:30px" id="txtqdtaaulas1n" maxlength="2"   onKeyPress="return Enum(event)"/>
			</p>


                  <p>



					 <label for="lblareaatuacao1">Disciplina</label>
						<select name="txtautacao2" id="txtautacao2" style="width:300px" >
						<option value="">Selecione Disciplina</option>
  					<?php
							include ("../conexao_mysql.php");
							$sql = "SELECT codigo, descricao
									FROM habilitacao
									ORDER BY descricao";
						   $res = mysql_query($sql);
						   if($res)
							  {
								while($row = mysql_fetch_array($res)){
							    ?>
  			                    <option value="<?php echo $row['codigo']?>"
						        <?php if($row['codigo'] == $txtautacao2bd){ echo "selected";}?>>
								<?php echo $row['descricao'];?>
								<?php
							      } }
						        ?>
					   </select>




<?
  if ($m2=='M')
    {
?>
		  <label for="lbldeficienten">Manha
		      <input name="m2" type="checkbox"  value ="M"  id="m2" checked="checked" >
		  </label>
<?
   }
else
  {
?>	
		  <label for="lbldeficienten">Manha
		      <input name="m2" type="checkbox"  value ="M"  id="m2"  >
		  </label>
<?
	}
?>



  			  <input type="text" name="txtqdtaaulas2m" value= "<? echo $txtqdtaaulas2m; ?>" style="width:30px" id="txtqdtaaulas2m" maxlength="2"   onKeyPress="return Enum(event)"/>

<?
  if ($t2=='T')
    {
?>

		  <label for="lbldeficienten">Tarde
		      <input name="t2" type="checkbox"  value ="T"  id="t2" checked="checked"  >
		  </label>
<?
   }
else
  {
?>	

		  <label for="lbldeficienten">Tarde
		      <input name="t2" type="checkbox"  value ="T"  id="t2"  >
		  </label>
<?
	}
?>



  			  <input type="text" name="txtqdtaaulas2t" value= "<? echo $txtqdtaaulas2t; ?>" style="width:30px" id="txtqdtaaulas2t" maxlength="2"   onKeyPress="return Enum(event)"/>


<?
  if ($n2=='N')
    {
?>
          <label for="lbldeficienten">Noite
		      <input name="n2" type="checkbox"  value ="N"  id="n2"  checked="checked">
		  </label>
<?
   }
else
  {
?>	

          <label for="lbldeficienten">Noite
		      <input name="n2" type="checkbox"  value ="N"  id="n2"  >
		  </label>
<?
	}
?>

  			  <input type="text" name="txtqdtaaulas2n" value= "<? echo $txtqdtaaulas2n; ?>" style="width:30px" id="txtqdtaaulas2n" maxlength="2"   onKeyPress="return Enum(event)"/>


			</p>



                  <p>


					<label for="lblareaatuacao1">Disciplina</label>
						<select name="txtautacao3" id="txtautacao3" style="width:300px" >
						<option value="">Selecione Disciplina</option>
  					<?php
							include ("../conexao_mysql.php");
							$sql = "SELECT codigo, descricao
									FROM habilitacao
									ORDER BY descricao";
						   $res = mysql_query($sql);
						   if($res)
							  {
								while($row = mysql_fetch_array($res)){
							    ?>
  			                    <option value="<?php echo $row['codigo']?>"
						        <?php if($row['codigo'] == $txtautacao3bd){ echo "selected";}?>>
								<?php echo $row['descricao'];?>
								<?php
							      } }
						        ?>
					   </select>








<?
  if ($m3=='M')
    {
?>
		  <label for="lbldeficienten">Manha
		      <input name="m3" type="checkbox"  value ="M"  id="m3"  checked="checked">
		  </label>
<?
   }
else
  {
?>	
		  <label for="lbldeficienten">Manha
		      <input name="m3" type="checkbox"  value ="M"  id="m3"  >
		  </label>
<?
	}
?>


  			  <input type="text" name="txtqdtaaulas3m" value= "<? echo $txtqdtaaulas3m; ?>" style="width:30px" id="txtqdtaaulas3m" maxlength="2"   onKeyPress="return Enum(event)"/>
		  
		  
<?
  if ($t3=='T')
    {
?>
		  <label for="lbldeficienten">Tarde
		      <input name="t3" type="checkbox"  value ="T"  id="t3"  checked="checked">
		  </label>
<?
   }
else
  {
?>	
		  <label for="lbldeficienten">Tarde
		      <input name="t3" type="checkbox"  value ="T"  id="t3"  >
		  </label>
<?
	}
?>

		  
		  
  			  <input type="text" name="txtqdtaaulas3t" value= "<? echo $txtqdtaaulas3t; ?>" style="width:30px" id="txtqdtaaulas3t" maxlength="2"   onKeyPress="return Enum(event)"/>



<?
  if ($n3=='N')
    {
?>

          <label for="lbldeficienten">Noite
		      <input name="n3" type="checkbox"  value ="N"  id="n3"  checked="checked">
		  </label>
<?
   }
else
  {
?>	

          <label for="lbldeficienten">Noite
		      <input name="n3" type="checkbox"  value ="N"  id="n3"  >
		  </label>
<?
	}
?>


  			  <input type="text" name="txtqdtaaulas3n" value= "<? echo $txtqdtaaulas3n; ?>" style="width:30px" id="txtqdtaaulas3n" maxlength="2"   onKeyPress="return Enum(event)"/>

			</p>


 <p>



					<label for="lblareaatuacao1">Disciplina</label>
						<select name="txtautacao4" id="txtautacao4" style="width:300px" >
						<option value="">Selecione Disciplina</option>
  					<?php
							include ("../conexao_mysql.php");
							$sql = "SELECT codigo, descricao
									FROM habilitacao
									ORDER BY descricao";
						   $res = mysql_query($sql);
						   if($res)
							  {
								while($row = mysql_fetch_array($res)){
							    ?>
  			                    <option value="<?php echo $row['codigo']?>"
						        <?php if($row['codigo'] == $txtautacao4bd){ echo "selected";}?>>
								<?php echo $row['descricao'];?>
								<?php
							      } }
						        ?>
					   </select>




<?
  if ($m4=='M')
    {
?>

		  <label for="lbldeficienten">Manha
		      <input name="m4" type="checkbox"  value ="M"  id="m4"  checked="checked">
		  </label>
<?
   }
else
  {
?>	

		  <label for="lbldeficienten">Manha
		      <input name="m4" type="checkbox"  value ="M"  id="m4"  >
		  </label>
<?
	}
?>


  			  <input type="text" name="txtqdtaaulas4m" value= "<? echo $txtqdtaaulas4m; ?>" style="width:30px" id="txtqdtaaulas4m" maxlength="2"   onKeyPress="return Enum(event)"/>

<?
  if ($t4=='T')
    {
?>

		  <label for="lbldeficienten">Tarde
		      <input name="t4" type="checkbox"  value ="T"  id="t4"  checked="checked">
		  </label>
<?
   }
else
  {
?>	

		  <label for="lbldeficienten">Tarde
		      <input name="t4" type="checkbox"  value ="T"  id="t4"  >
		  </label>
<?
	}
?>


  			  <input type="text" name="txtqdtaaulas4t" value= "<? echo $txtqdtaaulas4t; ?>" style="width:30px" id="txtqdtaaulas4t" maxlength="2"   onKeyPress="return Enum(event)"/>

<?
  if ($n4=='N')
    {
?>

          <label for="lbldeficienten">Noite
		      <input name="n4" type="checkbox"  value ="N"  id="n4"  checked="checked">
		  </label>
<?
   }
else
  {
?>	

          <label for="lbldeficienten">Noite
		      <input name="n4" type="checkbox"  value ="N"  id="n4"  >
		  </label>
<?
	}
?>


  			  <input type="text" name="txtqdtaaulas4n" value= "<? echo $txtqdtaaulas4n; ?>" style="width:30px" id="txtqdtaaulas4n" maxlength="2"   onKeyPress="return Enum(event)"/>

       </p>




       <p>

        <label for="lbldeficienten">Hora Extra</label>
  			  <input type="text" name="txthe" value= "<? echo $txthe; ?>" style="width:30px" id="txthe" maxlength="2"   onKeyPress="return Enum(event)"/>

			</p>


       <p>
        <label for="lbldeficienten">Turma(s) Fundamental</label>
  			  <input type="text" name="txttfundamental" value= "<? echo $txttfundamental; ?>" style="width:30px" title="Informe o total de turmas do ensino fundamenal" id="txttfundamental" maxlength="2"   onKeyPress="return Enum(event)"/>
			</p>

       <p>

        <label for="lbldeficienten">Turma(s) M�dio</label>
  			  <input type="text" name="txttmedio" value= "<? echo $txttmedio; ?>" style="width:30px" id="txttmedio" maxlength="2"   onKeyPress="return Enum(event)" title="Informe o total de turmas do ensino m�dio" />
			</p>

       <p>

        <label for="lbldeficienten">Turma(s) EJA</label>
  			  <input type="text" name="txtteja" value= "<? echo $txtteja; ?>" style="width:30px" id="txtteja" maxlength="2"   onKeyPress="return Enum(event)" title="Informe o total de turmas do ensino EJA" />
			</p>

   <p>

     		<label for="regularizacao">Obs.</label>
 			<textarea name = "txtobsescola"   cols="100" rows = "10" id = "txtobsescola"  type = "text" ><? echo $txtobsescola; ?></textarea>
  </p> 








					

				<p id="finish">
            <input type="button" value=" Voltar " onclick="history.go(-1);"> </td> 
            <input type="submit" value="Gravar" />
            <input type="reset" value="limpar" />
					</p>

<? 


?>


				</form>
			</div>
		</div>



      <script>
     <!--  cor_tabela("tabzebra");-->
    </script>
 </div><!-- Div corpodetalhe-->
</div><!-- Div corpo2-->

<?
  mysql_close($conexao);
?>				
  <div id="rodapeconsulta" class="fonterodape">
</div>
		<div id="footer">
			<p>Todos direitos reservados GTI/SEDUC</p>
		</div>
	</div>
</body>

