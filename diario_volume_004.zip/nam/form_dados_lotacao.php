<?php
require_once '../start.php';
$pdo = new Conexao;

$title = 'Lota��o';

$form_data = isset($_SESSION['form_data']) ? $_SESSION['form_data'] : null;
unset($_SESSION['form_data']);

function oldInputvalue($input_name, $returnIfNull = null) {
    global $form_data;
    return isset($form_data[$input_name]) ? $form_data[$input_name] : $returnIfNull;
}

$memorando = Memorando::findBy('ID', $_GET['codigo']);

if (!$memorando) {
    Notification::error("Memorando #{$_GET['codigo']} n�o encontrado!");
    redirect("nam/form_busca_memo_cpflota.php");
}

$servidor = Servidor::get($memorando['CPF']);

$municipio_lotacao = Municipio::getByCodigo($memorando['MUNILOTA'], 'descricao');

$gerencias = Gerencia::getAll();

if (oldInputvalue('departamento')) {
    $departamentos = Departamento::getByDepartamentoId(oldInputvalue('gerencia'));
}

$sql = "SELECT codigo, descricao
                    FROM habilitacao
                    WHERE codigo NOT IN (69,70,71, 72,73, 53)
                    ORDER BY descricao";
$habilitacoes = $pdo->query($sql)->fetchAll();

?>

<!DOCTYPE HTML>
<html>
<head>
    <?php require_once page_head(); ?>
</head>
<body>
<?php require_once page_header(); ?>

<div class="container">
    <form class="form" action="insere_lotacao.php" method="POST">
        <fieldset class="well well-sm">
            <legend>Dados do servidor</legend>

            <div class="row">
                <div class="col-md-2">
                    <div class="form-group">
                        <label for="cpf">CPF</label>
                        <input type="text" class="form-control" id="cpf" name="cpf" value="<?= $servidor['cpf']; ?>" readonly>
                    </div>
                </div>
                <div class="col-md-2">
                    <div class="form-group">
                        <label for="matricula">Matr�cula</label>
                        <input type="text" class="form-control" value="<?= $memorando['MATRICULA'] ?>" id="matricula" name="matricula" maxlength="80" readonly>
                    </div>
                </div>
                <div class="col-md-6">
                    <div class="form-group">
                        <label for="nome">Nome completo</label>
                        <input type="text" class="form-control" value="<?= $servidor['nome']; ?>" id="nome" readonly>
                    </div>
                </div>
            </div>

            <div class="row">
                <div class="col-md-2">
                    <label for="lotacao_servidor">Lota��o</label>
                    <input type="text" class="form-control" id="lotacao_servidor" value="<?= ($memorando['LOTAINTCAP'] == 'I') ? 'INTERIOR' : 'CAPITAL' ?>" readonly>
                </div>
                <div class="col-md-2">
                    <label for="tipo_lotacao">Tipo da lota��o</label>
                    <input type="text" class="form-control" id="tipo_lotacao" value="<?= ($memorando['LOTAADMESC'] == 'A') ? 'ADM' : 'ESCOLA' ?>" readonly>
                </div>
                <div class="col-md-2">
                    <label for="municipio_lotacao">Municipio</label>
                    <input type="text" class="form-control" id="municipio_lotacao" value="<?= $municipio_lotacao['descricao'] ?>" readonly>
                </div>
            </div>
        </fieldset>

        <fieldset class="well well-sm">
            <legend>Lotar servidor</legend>
            <div class="row">
                <div class="col-md-2">
                    <div class="form-group">
                        <label for="data_lotacao">Data Lota��o</label>
                        <input type="text" name="data_lotacao" class="form-control input-lg data" value="<?= oldInputvalue('data_lotacao', '') ? oldInputvalue('data_lotacao', '') : date('d/m/Y')?>" id="txtdtlota11" required>
                    </div>
                </div>
                <div class="col-md-2">
                    <div class="form-group">
                        <label for="memorando">Memorando</label>
                        <input type="text" id="memorando" name="memorando" class="form-control input-lg" value="<?= oldInputvalue('memorando', '') ? oldInputvalue('memorando', '') : '' ?>" required style="text-transform: uppercase;">
                        <input type="hidden" name="memorando_id" value="<?= $_GET['codigo'] ?>">
                    </div>
                </div>
            </div>
            <div class="row">
                <div class="col-md-4">
                    <div class="form-group" title="Campo obrigat�rio">
                        <label for="lotacao">Lota��o</label>
                        <select id="lotacao" name="lotacao" class="form-control input-lg" required>
                            <?php
                            $options = [
                                null => 'Selecione a lota��o',
                                1 => 'ADMINISTRACAO',
                                2 => 'ESCOLA'
                            ];

                            foreach ($options as $key => $value) {
                                echo "<option value='{$key}' ";
                                echo oldInputvalue('lotacao') == $key ? 'selected' : '';
                                echo ">{$value}</option>";
                            }
                            ?>
                        </select>
                    </div>
                </div>
                <div class="col-md-4">
                    <div class="form-group" title="Campo obrigat�rio">
                        <label for="gerencia">Ger�ncia</label>
                        <select name="gerencia" id="gerencia" class="form-control input-lg" <?=  oldInputvalue('gerencia') ? '' : ' disabled'?>>
                            <option value="">Selecione a administra��o</option>
                            <?php
                            foreach ($gerencias as $gerencia) {
                                echo "<option value='{$gerencia['codigo']}'";
                                echo oldInputvalue('gerencia') == $gerencia['codigo'] ? ' selected' : '';
                                echo ">{$gerencia['descricao']}</option>";
                            }
                            ?>
                        </select>
                    </div>
                </div>
                <div class="col-md-4">
                    <div class="form-group" title="Campo obrigat�rio">
                        <label for="departamento">Departamento</label>
                        <select name="departamento" id="departamento" class="form-control input-lg" <?= !oldInputvalue('departamento') ? ' disabled' : ''?>>
                            <?php
                            if (oldInputvalue('departamento')) {
                                foreach ($departamentos as $departamento) {
                                    echo "<option value='{$departamento['codigo_dpto']}'";
                                    echo (oldInputvalue('departamento') == $departamento['codigo_dpto']) ? ' selected' : '';
                                    echo ">{$departamento['descricao']}</option>";
                                }
                            }
                            ?>
                        </select>
                    </div>
                </div>
            </div>

            <div class="collapse <?= oldInputvalue('lotacao') == 2 ? ' in' : ''?>" id="row_escola">
                <div class="row">
                    <div class="col-md-8">
                        <div class="form-group">
                            <label for="nome_escola">Escola</label>
                            <input type="text" name="nome_escola" class="form-control input-lg ui-autocomplete-input" value="<?= oldInputvalue('nome_escola') ?>" id="nome_escola" autocomplete="off" placeholder="Digite o INEP ou o nome da escola">
                            <input type="hidden" name="inep_escola" value="<?= oldInputvalue('inep_escola') ?>" id="inep_escola">

                            <span class="help-block" id="escola-message-box"></span>
                        </div>
                    </div>

                    <div class="col-md-2">
                        <div class="form-group">
                            <label for="quantidade_aulas">Quantidade de Aulas</label>
                            <input type="text" name="quantidade_aulas" value="<?= oldInputvalue('quantidade_aulas') ? oldInputvalue('quantidade_aulas') : '0'?>" class="form-control input-lg" id="quantidade_aulas" maxlength="2">
                        </div>
                    </div>

                    <div class="col-md-2">
                        <div class="form-group">
                            <label for="carga_horaria">Carga Hor�ria</label>
                            <select id="carga_horaria" class="form-control input-lg" name="carga_horaria" >
                                <?php
                                $options = [
                                    '' => 'Selecione',
                                    0 => 0,
                                    20 => '20',
                                    25 => '25',
                                    40 => '40'
                                ];
                                foreach ($options as $key => $value) {
                                    echo "<option value='{$key}' ";
                                    echo oldInputvalue('carga_horaria') == $key ? 'selected' : '';
                                    echo ">{$value}</option>";
                                }
                                ?>
                            </select>
                        </div>
                    </div>
                </div>
            </div>

            <div class="row">
                <div class="col-md-6">
                    <div class="form-group">
                        <label for="habilitacao">Area de Atua��o</label>
                        <select name="habilitacao" id="habilitacao"  class="form-control input-lg" required>
                            <option value="">Selecione uma area de atua��o</option>
                            <?php
                            foreach ($habilitacoes as $habilitacao) {
                                echo "<option value='{$habilitacao['codigo']}'";
                                echo oldInputvalue('habilitacao') == $habilitacao['codigo'] ? ' selected' : '';
                                echo ">{$habilitacao['descricao']}</option>";
                            }
                            ?>
                        </select>
                    </div>
                </div>

            </div>

            <div class="row">
                <div class="col-md-12">
                    <div class="form-group">
                        <label for="observacoes">Observa��o:</label>
                        <textarea name="observacoes" class="form-control" rows="5" id="observacoes"><?= trim(oldInputvalue('observacoes', ''))?></textarea>
                    </div>
                </div>
            </div>
        </fieldset>

        <div class="well well-sm">
            <button type="submit" class="btn btn-primary btn-submit-wait" id="btn-salvar-lotacao">SALVAR</button>
            <button type="button" class="btn btn-default btn-back pull-right">VOLTAR</button>
        </div>
    </form>
</div>

<?php require_once page_footer(); ?>

<script src="/js/jquery-ui-1.12.1/jquery-ui.min.js"></script>
<script src="js/form-lotacao-lotacao.js"></script>
</body>
</html>