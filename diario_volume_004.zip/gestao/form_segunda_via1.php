<?
/*session_start();
if (isset($_SESSION["login_usuario"]))
  {
     $login =  $_SESSION["login_usuario"];
     $nte   =  $_SESSION["nivel_usuario"];
     include ("../funcoes.php");
     echo  saudacoes()."   ". "$login" ."  -  ". $nte."  ".dataextenso();
  }
 else
  {
     		 header("Location: ../login.php");
  }
*/

include ("../conexao_mysql.php");

include ("../funcoes.php");

$id = $_POST['cpf'];

$re = mysql_query("select count(*) as total from transicao where inep = '$id'");
$total = mysql_result($re, 0, "total");


if ($total==0) 
  { 
	echo "<html><head><title>Resposta !!!</title></head>";
	echo "<body background=\"background_mensagens.jpg\" style=\"background-attachment:fixed; background-repeat:no-repeat\">";
	echo "<br><br><br>";
	echo "<center><img src=\"faleconosco/atencao.gif\" alt=\"\"><p><font color=\"#ff6600\" face=\"Verdana\" size=\"4\">Escola n�o cadastrada!!!! <b></b></font></center>";
	echo "<br><br><center><a href=\"formsegvia.php\"><img src=\"faleconosco/button_voltar2_.gif\" alt=\"Voltar\" border=\"0\" /></a></center>";
    echo "</body></html>";
   }
else
{
$sql = "SELECT e.DESCRICAO,e.MUNICIPIO,e.TIPO,e.ENDERECO,e.NUMERO,e.BAIRRO,e.CEP,e.FONE,e.DIRETOR,e.VICEDIRETOR,e.NPROFESSORES,e.NALUNOS,e.NEMERGENCIAL,e.NADMINISTRATIVO,e.DTVALIDADE as EDTVALIDADE,t.INEP,t.REGULARIZACAO,t.PORTARIA,t.DTEMISSAO,t.PATRIMONIO,t.SPATRIMONIO,t.ACERVO,t.QTDASALA,t.SLEITURA,t.LIE,t.QUADRA,t.SQUADRA,t.QCOBERTA,t.PDE,t.PROGRAMA,t.QTDAPROGRAMA,t.IDEB,t.ENEM,t.PBRASIL,t.PROVINHABR,t.FONTER,t.CANTINA,t.MAIS,t.LAUDO,t.FISCALMUNI,t.FISCALESTADO,t.FISCALFEDERAL,t.FISCALFGTS,t.CONTABIL,t.INSS,t.PROAFI,t.PENAI,t.PROFIPES,t.PDEF,t.MODALIDADE1,t.MODALIDADE2,t.MODALIDADE3,t.MODALIDADE4,t.MODALIDADE5,t.SITUACAO,e.DTPORTARIA,t.DTVALIDADE as TDTVALIDADE ,t.MODALIDADE6,t.MODALIDADE7  from transicao t,escola e,municipio m where t.inep=e.inep and e.municipio= m.codigo and t.inep = $id";
$resposta = mysql_query( $sql );
while ( $linha = mysql_fetch_array( $resposta ))
 {

 if ($linha["MODALIDADE1"]!='')
    {
	   $MODALIDADE1 ='S';
	}
  else   
    {
	   $MODALIDADE1 ='N';
     }
if ($linha["MODALIDADE2"]!='')
    {
	   $MODALIDADE2 ='S';
	}
  else   
    {
	   $MODALIDADE2 ='N';
    }
 if ($linha["MODALIDADE3"]!='')
    {
	   $MODALIDADE3 ='S';
	}
  else   
    {
	   $MODALIDADE3 ='N';
	}



 if ($linha["MODALIDADE4"]!='')
    {
	   $MODALIDADE4 ='S';
	}
  else   
    {
	   $MODALIDADE4 ='N';
	}

 if ($linha["MODALIDADE5"]!='')
    {
	   $MODALIDADE5 ='S';
	}
  else   
    {
	   $MODALIDADE5 ='N';
	}

 if ($linha["MODALIDADE6"]!='')
    {
	   $MODALIDADE6 ='S';
	}
  else   
    {
	   $MODALIDADE6 ='N';
	}

 if ($linha["MODALIDADE7"]!='')
    {
	   $MODALIDADE7 ='S';
	}
  else   
    {
	   $MODALIDADE7 ='N';
	}








?>



<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01//EN"
	"http://www.w3.org/TR/html4/strict.dtd">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1" />
	<title>SEDUC-RO</title>


	<link rel="stylesheet" href="style/forms.css" type="text/css" />
	<link rel="stylesheet" href="estilo.css" type="text/css" />
	<link rel="stylesheet" href="style/menu.css" type="text/css" />

	<link href="tablecloth/tablecloth.css" rel="stylesheet" type="text/css" media="screen" />


	<script type="text/javascript" src="tablecloth/tablecloth.js"></script>
	<script src="lib/jquery-1.4.2.js" type="text/javascript"></script>
	<script src="lib/validate.js" type="text/javascript"></script>
	<script src="lib/forms.js" type="text/javascript"></script>
    <script src="generic.js"    type="text/javascript"></script>
    <script src="lib/jquery.maskedinput-1.1.1.js" type="text/javascript"></script>




	<link type="text/css" href="jquery-ui-1.8.18.custom/css/ui-lightness/jquery-ui-1.8.18.custom.css" rel="stylesheet" />
	<script type="text/javascript" src="jquery-ui-1.8.18.custom/js/jquery-1.7.1.min.js"></script>
	<script type="text/javascript" src="jquery-ui-1.8.18.custom/js/jquery-ui-1.8.18.custom.min.js"></script>




<script type="text/javascript">



function DoPrinting() {
    if (!window.print) {
        alert("Netscape, Internet Explorer 4.0 ou superior!")
        return
    }
    window.print();
}


</script>






<script src="../script.js"></script>

<script>


	$(function() {
		$( "#txtdtemisao" ).datepicker({
			changeMonth: true,
			changeYear: true
		});
	});

$(function() {
        $("#txtdtemisao").datepicker();
        $('#txtdtemisao').datepicker('option', 'dateFormat', 'dd/mm/yy');
});






	$(function() {
		$( "#txtdtvalidade" ).datepicker({
			changeMonth: true,
			changeYear: true
		});
	});

$(function() {
        $("#txtdtvalidade").datepicker();
        $('#txtdtvalidade').datepicker('option', 'dateFormat', 'dd/mm/yy');
});



</script>



</head>
<body>
	<div id="warpper">
		<div id="header">
		    <img src= "img/seduc_topo.jpg"/>
		</div>

<div id="content">
    <form name ="form" id="form" class="form" action="altera_escola.php" method="post" >


<p>
		<label for="lbldtemissaote">INEP<img src= "img/check.gif"/></label>
         <input  name="inep"  id="inep" readonly="true" size="10" maxlength="10" type="text" value = "<?echo  $linha["INEP"];?>"/>
</p>


 <p>
		<label for="lbldtemissaote">Descri��o<img src= "img/check.gif"/></label>
        <input  name="descricao" id="descricao" readonly="true" size="60" maxlength="60" type="text" value="<?echo $linha["DESCRICAO"];?>" >
</p>

 <p>
 <label for="lbldtemissaote">Endere�o<img src= "img/check.gif"/></label>
 <input name="endereco" type="text" id="endereco" size="60" readonly="true" MAXLENGTH="60"  value="<?echo $linha["ENDERECO"];?>">
 </p>


 <p>
 <label for="lbldtemissaote">Bairro<img src= "img/check.gif"/></label>
        <input name="bairro" type="text" id="bairro" size="40" readonly="true" MAXLENGTH="40" value="<?echo $linha["BAIRRO"];?>" >
 <label for="lbldtemissaote">N<img src= "img/check.gif"/></label>
	   <input name="nr" type="text" id="nr" size="10" MAXLENGTH="4" readonly="true" value="<?echo $linha["NUMERO"];?>" >

    <label for="txtCEP">CEP<img src= "img/check.gif"/></label>
	<input id="txtcep" name="txtcep" type="text" readonly="true" style="width:90px" maxlength="8" value="<?echo $linha["CEP"];?>"/>


</p>





<p>
 <label for="lbldtemissaote">FONE<img src= "img/check.gif"/></label>
 <input name="fone" type="text" id="fone" size="20" MAXLENGTH="20" readonly="true" Value="<?echo $linha["FONE"];?>" >
</p>

<p>

<?
$codmuni=$linha["MUNICIPIO"];
$sqlconulta        = "select codigo,descricao from municipio where codigo = $codmuni";
$respconsulta      = mysql_query( $sqlconulta );
while ( $dado = mysql_fetch_array( $respconsulta ))
{
   $descricao = $dado["descricao"];
   $codigo    = $dado["codigo"];
}
?>
</p>


 <p>
 <label for="lbldtemissaote">Munic�pio<img src= "img/check.gif"/></label>
 <input  name="municodigo" size="8" type="text" readonly="true" value="<?echo "$codigo";?>">
 <input  name="municipio1" size="60" type="text" readonly="true" value="<?echo "$descricao";?>">
 </p>







  			     	<p>
						<label for="regularizacao">Quantidade Servidores</label>
						<label for="regularizacao">*********************************</label>


     	  			</p>

<P>
 <label for="lbldtemissaote">Prof Estatut�rio<img src="img/check.gif"/></label>
 <input name="nprofessores" type="text" id="nprofessores" size="5" MAXLENGTH="10" value="<?echo $linha["NPROFESSORES"];?>" readonly="true">


<label for="lbldtemissaote">Prof Emerg�ncial<img src=

"img/check.gif"/></label>
 <input name="nemergencial" type="text" id="nemergencial" size="5" MAXLENGTH="10" value="<?echo $linha["NEMERGENCIAL"];?>" readonly="true">


 <label for="lbldtemissaote">T�c Administrativo<img src="img/check.gif"/></label>
 <input name="nadm" type="text" id="nadm" size="5" MAXLENGTH="10" value="<?echo $linha["NADMINISTRATIVO"];?>" readonly="true">

 <label for="lbldtemissaote">Alunos<img src= "img/check.gif"/></label>
  <input name="nalunos" type="text" id="nalunos" size="5" MAXLENGTH="10" value="<?echo $linha["NALUNOS"];?>" readonly="true">

</p>



	   <p>
         <label for="lblcod_cpf">Diretor<img src= "img/check.gif"/></label>
         <input name="diretor" type="text" id="diretor" size="60" MAXLENGTH="60" value= "<?echo $linha["DIRETOR"];?>" readonly="true">
       </p>


	   <p>
         <label for="lblcod_cpf">Vice Diretor<img src= "img/check.gif"/></label>
		 <input name="vicediretor" type="text" id="vicediretor" readonly="true" size="60" maxlength="60" value= "<?echo $linha["VICEDIRETOR"];?>">
       </p>


   <p>
 <label for="regularizacao">Regularizada<img src= "img/check.gif"/></label>
  <input name="nalunos" type="text" id="nalunos" size="5" MAXLENGTH="10" readonly="true" value= "<?echo $linha["REGULARIZACAO"];?>">

 <label for="regularizacao">Situa��o<img src= "img/check.gif"/></label>
  <input name="selectsituacao" type="text" id="selectsituacao" size="5" MAXLENGTH="10" readonly="true" value= "<?echo $linha["SITUACAO"];?>">




<label for="lbldtemissaote">Portaria/Decreto<img src= "img/check.gif"/></label>
<input type="text" name="txtportaria" style="width:140px"  id="txtportaria" readonly="true" maxlength="12" value= "<?echo $linha["PORTARIA"];?>">
 </p>



<P>
<label for="lbldtemissaote">Data Emiss�o<img src= "img/check.gif"/></label>
<input type="text" name="txtdtemisao1" id="txtdtemisao1" readonly="true" value="<? $data = date("d/m/Y",strtotime($linha["DTEMISSAO"]));
    if ($data=='31/12/1969')
  {
	$data="";
	echo $data;
  }
else
{
 echo $data;
 }
 ?>">



<label for="lbldtemissaote1">Data Validade<img src= "img/check.gif"/></label>
 <input name= "txtdtvalidade1" type="text" id="txtdtvalidade1" readonly="true" value="<? $data1 = date("d/m/Y",strtotime($linha["TDTVALIDADE"]));
 if ($data1=='31/12/1969')
  {
	$data1="";
  }
 else
{
 echo $data1;
 }
 ?>">

</p>	







<P>
<label for="lbldtemissaote">Data Emiss�o Alterada<img src= "img/check.gif"/></label>
<input type="text" name="txtdtemisao1" id="txtdtemisao1" readonly="true" value="<? $data = date("d/m/Y",strtotime($linha["DTPORTARIA"]));
    if ($data=='31/12/1969')
  {
	$data="";
	echo $data;
  }
else
{
 echo $data;
 }
 ?>">



<label for="lbldtemissaote1">Data Validade Alterada<img src= "img/check.gif"/></label>
 <input name= "txtdtvalidade1" type="text" id="txtdtvalidade1" readonly="true" value="<? $data1 = date("d/m/Y",strtotime($linha["EDTVALIDADE"]));
 if ($data1=='31/12/1969')
  {
	$data1="";
  }
 else
{
 echo $data1;
 }
 ?>">

</p>	








<p>
<label for="regularizacao">Patrim�nio<img src= "img/check.gif"/></label>
<input type="text" name="selectpatrimonio" style="width:140px"  id="selectpatrimonio" maxlength="12" readonly="true" value= "<?echo $linha["PATRIMONIO"];?>">


<label for="regularizacao">Status<img src= "img/check.gif"/></label>
<input type="text" name="selectstatuspatri" style="width:140px"  id="selectstatuspatri" maxlength="12" readonly="true" value= "<?echo $linha["SPATRIMONIO"];?>">
</p>





   	 <p>
		<label for="regularizacao">Sala de Aula<img src= "img/check.gif"/></label>
		  <input type="text" name="txtqdtasala" style="width:30px" id="txtqdtasala" readonly="true" value= "<?echo $linha["QTDASALA"];?>">
	</p>

  			     	<p>
						<label for="regularizacao">Sala de Leitura<img src= "img/check.gif"/></label>
				  <input type="text" name="selectleitura"  style="width:30px" id="selectleitura" readonly="true" value= "<?echo $linha["SLEITURA"];?>">

					</p>

  			     	<p>
						<label for="regularizacao">Laborat�rio Inform�tica<img src= "img/check.gif"/></label>
			  <input type="text" name="selectlie"  style="width:30px" id="selectlie" readonly="true" value= "<?echo $linha["LIE"];?>">

					</p>

  			     	<p>
						<label for="regularizacao">Quadra de Esporte<img src= "img/check.gif"/></label>
			  <input type="text" name="selectquadra"  style="width:30px" id="selectquadra" readonly="true" value= "<?echo $linha["QUADRA"];?>">

						<label for="regularizacao">Status<img src= "img/check.gif"/></label>
			  <input type="text" name="selectstatusqd"  style="width:30px" id="selectstatusqd" readonly="true" value= "<?echo $linha["SQUADRA"];?>">



						<label for="regularizacao">Coberta<img src= "img/check.gif"/></label>
			  <input type="text" name="selectcoberta"  style="width:30px" id="selectcoberta" readonly="true" value= "<?echo $linha["QCOBERTA"];?>">

					</p>
  			     	<p>
						<label for="regularizacao">PDE<img src= "img/check.gif"/></label>
	  <input type="text" name="selectpde"  style="width:30px" id="selectpde" readonly="true" value= "<?echo $linha["PDE"];?>">
					</p>

  			     	<p>
						<label for="regularizacao">Programas<img src= "img/check.gif"/></label>
<input type="text" name="selectprogramas"  style="width:30px" id="selectprogramas" readonly="true" value= "<?echo $linha["PROGRAMA"];?>">

					<label for="regularizacao">Quantidede<img src= "img/check.gif"/></label>
<input type="text" name="txtqdtaprograma" style="width:30px" id="txtqdtaprograma" maxlength="4" readonly="true" value= "<?echo $linha["QTDAPROGRAMA"];?>">

		</p>



  			     	<p>
						<label for="regularizacao">Acervo Bibliografico<img src= "img/check.gif"/></label>
  <input type="text" name="selectacervo"  style="width:30px" id="selectacervo"  readonly="true" value= "<?echo $linha["ACERVO"];?>">


						<label for="regularizacao">Status <img src= "img/check.gif"/></label>
  <input type="text" name="selectstatus"  style="width:30px" id="selectstatus" readonly="true" value= "<?echo $linha["SPATRIMONIO"];?>">
					</p>

			 <p>  
			  <label for="lbldeficienten">IDEB<img src= "img/check.gif"/></label>
			  <input type="text" name="txtideb"  style="width:30px" id="txtideb" maxlength="3" readonly="true" value= "<?echo $linha["IDEB"];?>">
			  <label for="lbldeficienten">ENEM<img src= "img/check.gif"/></label>
			  <input type="text" name="txtenem"  style="width:30px" id="txtenem" maxlength="3" readonly="true" value= "<?echo $linha["ENEM"];?>">
			  <label for="lbldeficienten">Prova Brasil<img src= "img/check.gif"/></label>
			  <input type="text" name="txtprasil"  style="width:30px" id="txtprasil" maxlength="3" readonly="true" value= "<?echo $linha["PBRASIL"];?>">
			 <label for="lbldeficienten">Provinha Brasil<img src= "img/check.gif"/></label>
			 <input type="text" name="txtprovlhabr"  style="width:30px" id="txtprovlhabr" maxlength="3"  readonly="true" value= "<?echo $linha["PROVINHABR"];?>">

			 </p>  




        <p>		
		   <label for="lbldeficienten">Fundamental Regular 1 a 5 --><?echo $MODALIDADE1;?></label>
		   <label for="lbldeficienten">Fundamental Regular 6 a 9 --><?echo $MODALIDADE2;?></label>
 		   <label for="lbldeficienten">Fundamental Regular 1 a 9 --><?echo $MODALIDADE3;?></label>
   		  <label for="lbldeficienten">Fundamental EJA --><?echo $MODALIDADE4;?></label>
      </p>

  
     <p>		
  <label for="lbldeficienten">Ensino M�dio Regular --><?echo $MODALIDADE5;?></label>
  <label for="lbldeficienten">Ensino M�dio EJA --><?echo $MODALIDADE6;?></label>
  <label for="lbldeficienten">Educa��o Especial --><?echo $MODALIDADE7;?></label>
  </p>



  			     	<p>
						<label for="regularizacao">Fonte de Recurso<img src= "img/check.gif"/></label>
	  <input type="text" name="selectfonte"  style="width:100px" id="selectfonte" readonly="true" value= "<?echo $linha["FONTER"];?>">
     	  			</p>

  			     	<p>
						<label for="regularizacao">Cantina Alugado<img src= "img/check.gif"/></label>
	  <input type="text" name="selectcantina"  style="width:30px" id="selectcantina" readonly="true" value= "<?echo $linha["CANTINA"];?>">

     	  			</p>


  			     	<p>
						<label for="regularizacao">Mais Educa��o<img src= "img/check.gif"/></label>
	  <input type="text" name="selectmais"  style="width:30px" id="selectmais" readonly="true" value= "<?echo $linha["MAIS"];?>">

     	  			</p>



  			     	<p>
						<label for="regularizacao">Regularidade Fiscal</label>
						<label for="regularizacao">*********************************</label>


     	  			</p>
  			     	<p>
						<label for="regularizacao">Municipio<img src= "img/check.gif"/></label>
	  <input type="text" name="fiscalmuni"  style="width:30px" id="fiscalmuni" readonly="true" value= "<?echo $linha["FISCALMUNI"];?>">

						<label for="regularizacao" style="width:58px">Estado<img src= "img/check.gif"/></label>
	  <input type="text" name="fiscalmuni"  style="width:30px" id="fiscalmuni" readonly="true" value= "<?echo $linha["FISCALESTADO"];?>">

						<label for="regularizacao">Federal<img src= "img/check.gif"/></label>
	  <input type="text" name="fiscalmuni"  style="width:30px" id="fiscalmuni" readonly="true" value= "<?echo $linha["FISCALFEDERAL"];?>">
     	  			</p>


  			     	<p>
						  <label for="regularizacao" style="width:49px">FGTS<img src= "img/check.gif"/></label>
	  <input type="text" name="fiscalmuni"  style="width:30px" id="fiscalmuni" readonly="true" value= "<?echo $linha["FISCALFGTS"];?>">     	  			
						<label for="regularizacao">Contabil<img src= "img/check.gif"/></label>
	  <input type="text" name="fiscalmuni"  style="width:30px" id="fiscalmuni" readonly="true" value= "<?echo $linha["CONTABIL"];?>">
						<label for="regularizacao" style="width:55px">INSS<img src= "img/check.gif"/></label>
	  <input type="text" name="fiscalmuni"  style="width:30px" id="fiscalmuni" readonly="true" value= "<?echo $linha["INSS"];?>">


					</p>


  			     	<p>
						<label for="regularizacao">Presta��o Contas 2010/2011</label>
						<label for="regularizacao">*********************************</label>

     	  			</p>


  			     	<p>
						<label for="regularizacao">PROAFI<img src= "img/check.gif"/></label>
	  <input type="text" name="fiscalmuni"  style="width:30px" id="fiscalmuni" readonly="true" value= "<?echo $linha["PROAFI"];?>">
	  
	  
						<label for="regularizacao" style="width:60px">PENAI<img src= "img/check.gif"/></label>
	  <input type="text" name="fiscalmuni"  style="width:30px" id="fiscalmuni" readonly="true" value= "<?echo $linha["PENAI"];?>">

     	  			</p>


  			     	<p>
						<label for="regularizacao">PROFIPES<img src= "img/check.gif"/></label>
	  <input type="text" name="fiscalmuni"  style="width:30px" id="fiscalmuni" readonly="true" value= "<?echo $linha["PROFIPES"];?>">



						<label for="regularizacao" style="width:60px">PDE<img src= "img/check.gif"/></label>
	  <input type="text" name="fiscalmuni"  style="width:30px" id="fiscalmuni" readonly="true" value= "<?echo $linha["PDEF"];?>">

     	  			</p>

   <p> 
     		<label for="regularizacao">Laudo<img src= "img/check.gif"/></label>

<?echo $linha["LAUDO"];?>

  </p> 



					<p id="finish">
             <input type="button"  value="Imprimir a p�gina"   onClick="DoPrinting()" />
					</p>
				</form>
			</div>
		</div>
	</div>

<?
}
}
?>

</body>
</html>