<?
session_start();
if (isset($_SESSION["login_usuario"]))
  {
     $login =  $_SESSION["login_usuario"];
     $nte   =  $_SESSION["nivel_usuario"];
     include ("../funcoes.php");
     echo  saudacoes()."   ". "$login" ."  -  ". $nte."  ".dataextenso();
  }
 else
  {
     		 header("Location: ../login.php");
  }

?>




<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01//EN"
	"http://www.w3.org/TR/html4/strict.dtd">
<head>
	<title>SEDUC-RO</title>


	<link rel="stylesheet" href="style/forms.css" type="text/css" />
	<link rel="stylesheet" href="estilo.css" type="text/css" />
	<link rel="stylesheet" href="style/menu.css" type="text/css" />

	<link href="tablecloth/tablecloth.css" rel="stylesheet" type="text/css" media="screen" />



	<script type="text/javascript" src="tablecloth/tablecloth.js"></script>
	<script src="lib/jquery-1.4.2.js" type="text/javascript"></script>
	<script src="lib/validate.js" type="text/javascript"></script>
	<script src="lib/forms.js" type="text/javascript"></script>
	<script src="generic.js"    type="text/javascript"></script>
    <script src="lib/jquery.maskedinput-1.1.1.js" type="text/javascript"></script>




	<link type="text/css" href="jquery-ui-1.8.18.custom/css/ui-lightness/jquery-ui-1.8.18.custom.css" rel="stylesheet" />
	<script type="text/javascript" src="jquery-ui-1.8.18.custom/js/jquery-1.7.1.min.js"></script>
	<script type="text/javascript" src="jquery-ui-1.8.18.custom/js/jquery-ui-1.8.18.custom.min.js"></script>






	<meta http-equiv="Content-type" content="text/html; charset=utf-8" />






<!--<script language="javascript" src="generic.js"></script>-->


		<script type="text/javascript">
			$(function(){

				// Accordion
				$("#accordion").accordion({ header: "h3" });

				// Tabs
				$('#tabs').tabs();


				// Dialog
				$('#dialog').dialog({
					autoOpen: false,
					width: 600,
					buttons: {
						"Ok": function() {
							$(this).dialog("close");
						},
						"Cancel": function() {
							$(this).dialog("close");
						}
					}
				});

				// Dialog Link
				$('#dialog_link').click(function(){
					$('#dialog').dialog('open');
					return false;
				});

				// Datepicker
				$('#datepicker').datepicker({
					inline: true
				});

				// Slider
				$('#slider').slider({
					range: true,
					values: [17, 67]
				});

				// Progressbar
				$("#progressbar").progressbar({
					value: 20
				});

				//hover states on the static widgets
				$('#dialog_link, ul#icons li').hover(
					function() { $(this).addClass('ui-state-hover'); },
					function() { $(this).removeClass('ui-state-hover'); }
				);

			});
		</script>






<script src="../script.js"></script>

<script>
function pesquisa(form1)
{
  var valor = document.form1.cpf1.value;

  url="/busca_gestao_escola.php?valor="+valor;
  ajax(url);
}




	$(function() {
		$( "#txtdtemisao" ).datepicker({
			changeMonth: true,
			changeYear: true
		});
	});

$(function() {
        $("#txtdtemisao").datepicker();
        $('#txtdtemisao').datepicker('option', 'dateFormat', 'dd/mm/yy');
});






	$(function() {
		$( "#txtdtvalidade" ).datepicker({
			changeMonth: true,
			changeYear: true
		});
	});

$(function() {
        $("#txtdtvalidade").datepicker();
        $('#txtdtvalidade').datepicker('option', 'dateFormat', 'dd/mm/yy');
});







</script>



</head>
<body>
	<div id="warpper">
		<div id="header">
		    <img src= "img/seduc_topo.jpg"/>
		</div>



			<div id="content">

				<form name = "form1" class="form" action="insere_transicao.php" method="post">



		  <p>
					<label for="lblcod_cpf">INEP<img src= "img/check.gif"/></label>
              <input name="cpf1" type="text" id="cpf1" size="15" title = "Campo Obrigatrio. Digite o INEP de sua escola." MAXLENGTH="11"  onBlur = pesquisa(form1) onKeyPress="return Enum(event)" />

	   <!-- AQUI SER APRESENTADO O RESULTADO DA BUSCA DINMICA.. OU SEJA OS NOMES -->
     	    <div id="pagina">
             </div>
         </p>

		<p>
						 <label for="regularizacao">Ato Regularização<img src= "img/check.gif"/></label>
 			               <select id="selectregularizacao" name="selectregularizacao" style="width:80px">
              		          <option value="S">Sim</option>
            		          <option value="N">Não</option>
    		               </select>

						 <label for="regularizacao">Situação<img src= "img/check.gif"/></label>
 			               <select id="selectsituacao" name="selectsituacao" style="width:105px">
              		          <option value=""></option>
			 				   <option value="A">Autorizada</option>
			            		          <option value="R">Reconhecida</option>
			            		          <option value="I">Irregular</option>
    		               </select>




						<label for="lbldtemissaote">Portaria/Decreto<img src= "img/check.gif"/></label>
						<input type="text" name="txtportaria" value="" style="width:140px" id="txtportaria" maxlength="12" />
         </P>



  <P>





<label for="lbldtemissaote">Data Emissão<img src= "img/check.gif"/></label>
<input type="text" name="txtdtemisao" id="txtdtemisao" readonly="true"/></p>


<label for="lbldtemissaote">Data Validade<img src= "img/check.gif"/></label>
<input type="text" name="txtdtvalidade"  id="txtdtvalidade" readonly="true"/>


 			     	<p>
						<label for="regularizacao">Patrimônio<img src= "img/check.gif"/></label>
 			               <select id="selectpatrimonio" name="selectpatrimonio" style="width:140px">
              		          <option value="S">Sim</option>
            		          <option value="N">Não</option>
    		               </select>

						<label for="regularizacao">Status<img src= "img/check.gif"/></label>
 			               <select id="selectstatuspatri" name="selectstatuspatri" style="width:140px">
              		          <option value=""></option>
              		          <option value="R">Regular</option>
            		          <option value="B">Bom</option>
            		          <option value="O">Otimo</option>
    		               </select>


					</p>
		     	 <p>

					<label for="regularizacao">Sala de Aula<img src= "img/check.gif"/></label>
				  <input type="text" name="txtqdtasala" value="0" style="width:30px" id="txtqdtasala" onKeyPress="return Enum(event)"/>
					</p>

  			     	<p>
						<label for="regularizacao">Sala de Leitura<img src= "img/check.gif"/></label>
 			               <select id="selectleitura" name="selectleitura" style="width:140px">
              		          <option value="S">Sim</option>
            		          <option value="N">Não</option>
    		               </select>

					</p>

  			     	<p>
						<label for="regularizacao">Laboratório Informática<img src= "img/check.gif"/></label>
 			               <select id="selectlie" name="selectlie" style="width:140px"/>
              		          <option value="S">Sim</option>
            		          <option value="N">Não</option>
    		               </select>
					</p>

  			     	<p>
						<label for="regularizacao">Quadra de Esporte<img src= "img/check.gif"/></label>
 			               <select id="selectquadra" name="selectquadra" style="width:140px">
              		          <option value="S">Sim</option>
            		          <option value="N">Não</option>
    		               </select>

						<label for="regularizacao">Status<img src= "img/check.gif"/></label>
 			               <select id="selectstatusqd" name="selectstatusqd" style="width:140px">
              		          <option value=""></option>
              		          <option value="R">Regular</option>
            		          <option value="B">Bom</option>
            		          <option value="O">Otimo</option>
    		               </select>



						<label for="regularizacao">Coberta<img src= "img/check.gif"/></label>
 			               <select id="selectcoberta" name="selectcoberta" style="width:140px">
              		          <option value=""></option>
              		          <option value="S">Sim</option>
            		          <option value="N">Não</option>
    		               </select>




					</p>
  			     	<p>
						<label for="regularizacao">PDE<img src= "img/check.gif"/></label>
 			               <select id="selectpde" name="selectpde" style="width:140px">
              		          <option value="S">Sim</option>
            		          <option value="N">Não</option>
    		               </select>
					</p>

  			     	<p>
						<label for="regularizacao">Programas<img src= "img/check.gif"/></label>
 			               <select id="selectprogramas" name="selectprogramas" style="width:140px">
              		          <option value="S">Sim</option>
            		          <option value="N">Não</option>
    		               </select>
					<label for="regularizacao">Quantidade<img src= "img/check.gif"/></label>
				  <input type="text" name="txtqdtaprograma" value="0" style="width:30px" id="txtqdtaprograma" maxlength="4" onKeyPress="return Enum(event)"/>



					</p>



  			     	<p>
						<label for="regularizacao">Acervo Bibliografico<img src= "img/check.gif"/></label>
 			               <select id="selectacervo" name="selectacervo" style="width:140px">
              		          <option value="S">Sim</option>
            		          <option value="N">Não</option>
    		               </select>


						<label for="regularizacao">Status<img src= "img/check.gif"/></label>
 			               <select id="selectstatus" name="selectstatus" style="width:140px">
              		          <option value=""></option>
              		          <option value="R">Regular</option>
            		          <option value="B">Bom</option>
            		          <option value="O">Otimo</option>
    		               </select>


					</p>

			 <p>
			  <label for="lbldeficienten">IDEB<img src= "img/check.gif"/></label>
			  <input type="text" name="txtideb" value="0" style="width:30px" id="txtideb" maxlength="3" onKeyPress="return Enum(event)"/>
			  <label for="lbldeficienten">ENEM<img src= "img/check.gif"/></label>
			  <input type="text" name="txtenem" value="0" style="width:30px" id="txtenem" maxlength="3" onKeyPress="return Enum(event)"/>
			  <label for="lbldeficienten">Prova Brasil<img src= "img/check.gif"/></label>
			  <input type="text" name="txtprasil" value="0" style="width:30px" id="txtprasil" maxlength="3" onKeyPress="return Enum(event)"/>
			 <label for="lbldeficienten">Provinha Brasil<img src= "img/check.gif"/></label>
			 <input type="text" name="txtprovlhabr" value="0" style="width:30px" id="txtprovlhabr" maxlength="3"  onKeyPress="return Enum(event)"/>

			 </p>


        <p>
		   <label for="lbldeficienten">Fundamental Regular 1 a 5 </label>


		   <label for="lbldeficienten"><input name="modalidade1" type="checkbox"  value ="1"  id="modalidade1"/> Fundamental Regular 6 a 9<input name="modalidade2" type="checkbox"  value ="2"  id="modalidade2" /></label>


		  <label for="lbldeficienten">Fundamental Regular 1 a 9<input name="modalidade3" type="checkbox"  value ="3"  id="modalidade3"  /></label>


		  <label for="lbldeficienten">Fundamental EJA<input name="modalidade4" type="checkbox"  value ="4"  id="modalidade4" /></label>


      </p>


     <p>
  <label for="lbldeficienten">Ensino Médio Regular</label>
  <label for="lbldeficienten"><input name="modalidade5" type="checkbox"  value ="5"  id="modalidade5" />Ensino Médio EJA<input name="modalidade6" type="checkbox"  value ="6"  id="modalidade6"  ></label>

<label for="lbldeficienten">Educação Especial  <input name="modalidade7" type="checkbox"  value ="7"  id="modalidade7"/ ></label>
  </p>



  			     	<p>
						<label for="regularizacao">Fonte de Recurso<img src= "img/check.gif"/></label>
 			               <select id="selectfonte" name="selectfonte" style="width:140px">
              		          <option value="FNDE">FNDE</option>
            		          <option value="ESTADO">ESTADO</option>
							  <option value="OUTROS">OUTROS</option>
              		          <option value="FNDEESTADO">FNDE/ESTADO</option>
							  <option value="FNESOUTROS">FNDE/ESTADO/OUTROS</option>
    		               </select>

     	  			</p>

  			     	<p>
						<label for="regularizacao">Cantina Alugado<img src= "img/check.gif"/></label>
 			               <select id="selectcantina" name="selectcantina" style="width:140px">
              		          <option value="S">SIM</option>
            		          <option value="N">NÃO</option>
    		               </select>

     	  			</p>


  			     	<p>
						<label for="regularizacao">Mais Educação<img src= "img/check.gif"/></label>
 			               <select id="selectmais" name="selectmais" style="width:140px">
              		          <option value="S">SIM</option>
            		          <option value="N">NÃO</option>
    		               </select>

     	  			</p>



  			     	<p>
						<label for="regularizacao">Regularidade Fiscal</label>
						<label for="regularizacao">*********************************</label>


     	  			</p>
  			     	<p>
						<label for="regularizacao">Municipio<img src= "img/check.gif"/></label>
 			               <select id="fiscalmuni" name="fiscalmuni" style="width:140px">
              		          <option value="S">SIM</option>
            		          <option value="N">NÃO</option>
    		               </select>

						<label for="regularizacao" style="width:58px">Estado<img src= "img/check.gif"/></label>
 			                <select id="fiscalestado" name="fiscalestado" style="width:140px">
              		          <option value="S">SIM</option>
            		          <option value="N">NÃO</option>
    		               </select>

						<label for="regularizacao">Federal<img src= "img/check.gif"/></label>
 			               <select id="fiscalfedera" name="fiscalfedera" style="width:140px">
              		          <option value="S">SIM</option>
            		          <option value="N">NÃO</option>
    		               </select>



     	  			</p>


  			     	<p>
						  <label for="regularizacao" style="width:49px">FGTS<img src= "img/check.gif"/></label>
 			              <select id="fiscalfgts" name="fiscalfgts" style="width:140px">
              		          <option value="S">SIM</option>
            		          <option value="N">NÃO</option>
    		               </select>

						<label for="regularizacao">Contabil<img src= "img/check.gif"/></label>
 			               <select id="contabil" name="contabil" style="width:140px">
              		          <option value="S">SIM</option>
            		          <option value="N">NÃO</option>
    		               </select>

						<label for="regularizacao" style="width:55px">INSS<img src= "img/check.gif"/></label>
 			               <select id="inss" name="inss" style="width:140px">
              		          <option value="S">SIM</option>
            		          <option value="N">NÃO</option>
    		               </select>



					</p>


  			     	<p>
						<label for="regularizacao">Prestação Contas 2010/2011</label>
						<label for="regularizacao">*********************************</label>

     	  			</p>


  			     	<p>
						<label for="regularizacao">PROAFI<img src= "img/check.gif"/></label>
 			               <select id="proafi" name="proafi" style="width:140px">
              		          <option value="S">SIM</option>
            		          <option value="N">NÃO</option>
    		               </select>

						<label for="regularizacao" style="width:60px">PNAE<img src= "img/check.gif"/></label>
 			               <select id="penai" name="penai" style="width:140px">
              		          <option value="S">SIM</option>
            		          <option value="N">NÃO</option>
    		               </select>



     	  			</p>


  			     	<p>
						<label for="regularizacao">PROFIPES<img src= "img/check.gif"/></label>
 			               <select id="profipes" name="profipes" style="width:140px">
              		          <option value="S">SIM</option>
            		          <option value="N">NÃO</option>
    		               </select>

						<label for="regularizacao" style="width:60px">PDE<img src= "img/check.gif"/></label>
 			               <select id="pde" name="pde" style="width:140px">
              		          <option value="S">SIM</option>
            		          <option value="N">NÃO</option>
    		               </select>


     	  			</p>






   <p>

     		<label for="regularizacao">Laudo<img src= "img/check.gif"/></label>
 			<textarea name = "laudo"   cols="100" rows = "40" id = "laudo"  type = "text"  onkeyup="blocTexto(laudo.value)"></textarea>
  </p>



					<p id="finish">
            <input type="submit" value="Gravar" onClick="javascript:return validatransicao();"  />
            <input type="reset" value="limpar" />
					</p>
				</form>
			</div>
		</div>
	</div>
</body>

