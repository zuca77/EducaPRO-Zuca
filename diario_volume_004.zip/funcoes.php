<?php

define('ROOT_DIR', __DIR__);

$arquivo = __FILE__;
$pasta   = str_replace('funcoes.php', '', $arquivo);

require_once "{$pasta}/constants.php";
require_once "{$pasta}/conexao_mysql.php";

function dd($val) {
    new dBug($val);
    die;
}

function url($file, $return = false) {
    $urlFile = BASE_URL.'/'.$file;
    if ($return) return $urlFile;
    echo $urlFile;
}

function nomeAmbiente() {
    $ambiente = '';

//    switch ($_SERVER['HTTP_HOST']) {
//        case 'dev.seduc.ro.gov.br':
//            $ambiente = 'DEV';
//        break;
//
//        case 'qa.seduc.ro.gov.br':
//            $ambiente = 'Q.A.';
//        break;
//
//        case 'diario.seduc.ro.gov.br':
//            $ambiente = '';
//        break;
//
//        case 'localhost':
//        case 'local.diario.seduc.ro.gov.br':
//            $ambiente = 'Local';
//        break;
//    }

    if (ENV !== 'production' && ENV !== '') {
        $ambiente = 'DB local';
    }

    return $ambiente;
}

function page_head() {
    return ROOT_DIR.'/partials/head.php';
}

function page_header() {
    return ROOT_DIR.'/partials/header.php';
}

function page_footer() {
    return ROOT_DIR.'/partials/footer.php';
}

function modal_cre() {
    return ROOT_DIR.'/partials/modalAmbienteCRE.php';
}

function asset($filename) {
    $manifest_path = ROOT_DIR . '/public/build/rev-manifest.json';

    if (file_exists($manifest_path)) {
        $manifest = json_decode(file_get_contents($manifest_path), TRUE);
    } else {
        $manifest = [];
    }

    if (array_key_exists($filename, $manifest)) {
        return BASE_URL . '/public/build/' . $manifest[$filename];
    }

    return BASE_URL . '/public/' . $filename;
}

function resources($asset) {
    return BASE_URL . '/resources/' . $asset;
}

function css($css) {
    return BASE_URL . '/css/'.$css;
}

function js($js) {
    return BASE_URL . '/js/'.$js;
}

function img($img) {
    return BASE_URL . '/public/img/'.$img;
}

function redirect($url) {
    header('Location: '.BASE_URL.'/'.$url);
    EXIT;
}

function redirectBack() {
    $location = isset($_SERVER['HTTP_REFERER']) ? $_SERVER['HTTP_REFERER'] : BASE_URL;
    header('Location: '.$location);
    die;
}

function redirectBackWithInputsInSession() {
    $_SESSION['form_data'] = $_POST;
    redirectBack();
}

function decimalVirgula($d) {
    if ($d == null) return null;
    return str_replace(',', '.', $d);
}

function saudacoes() {
    $hr = date(" H ");
    if ($hr >= 12 && $hr < 18) {
        $resp = "Boa tarde!!!!     ";
    } else if ($hr >= 0 && $hr < 12) {
        $resp = "Bom dia!!!      ";
    } else {
        $resp = "Boa noite!!!     ";
    }
    echo "$resp";
}

function dataextenso() {
    $dia = date('d');
    $mes = date('m');
    $ano = date('Y');
    $semana = date('w');

    switch ($mes) {
        case 1: $mes = "JANEIRO";
            break;
        case 2: $mes = "FEVEREIRO";
            break;
        case 3: $mes = "MAR�O";
            break;
        case 4: $mes = "ABRIL";
            break;
        case 5: $mes = "MAIO";
            break;
        case 6: $mes = "JUNHO";
            break;
        case 7: $mes = "JULHO";
            break;
        case 8: $mes = "AGOSTO";
            break;
        case 9: $mes = "SETEMBRO";
            break;
        case 10: $mes = "OUTUBRO";
            break;
        case 11: $mes = "NOVEMBRO";
            break;
        case 12: $mes = "DEZEMBRO";
            break;
    }

    switch ($semana) {
        case 0: $semana = "DOMINGO";
            break;
        case 1: $semana = "SEGUNDA FEIRA";
            break;
        case 2: $semana = "TER�A-FEIRA";
            break;
        case 3: $semana = "QUARTA-FEIRA";
            break;
        case 4: $semana = "QUINTA-FEIRA";
            break;
        case 5: $semana = "SEXTA-FEIRA";
            break;
        case 6: $semana = "S�BADO";
            break;
    }
//Agora basta imprimir na tela...
    print ("$semana, $dia DE $mes DE $ano");
}

function descricaoMes($mes) {
    switch($mes) {
        case"01": return "Janeiro";
        case"02": return "Fevereiro";
        case"03": return "Marco";
        case"04": return "Abril";
        case"05": return "Maio";
        case"06": return "Junho";
        case"07": return "Julho";
        case"08": return "Agosto";
        case"09": return "Setembro";
        case"10": return "Outubro";
        case"11": return "Novembro";
        case"12": return "Dezembro";
    }
}

function combo_pastas() {
    $consulta = mysql_query("SELECT * FROM pasta order by nome_pasta ASC");
    $resultado = mysql_num_rows($consulta);
    if ($resultado == "") {
        echo "<font face=verdana size=-1> existe categoria!!!</font>";
        echo "<a href=cria_categoria.php><font face=verdana size=-1>Criar categoria</font></a>";
    } else {
        echo "<select name=select>";
        while ($dados = mysql_fetch_array($consulta)) {
            echo "<option>$dados[nome_pasta]</option>";
        }
        echo "</select>";
    }
}

function combo_cursoproinfo() {
    $consulta = mysql_query("SELECT descricao FROM cursoproinfo order by descricao ASC");
    $resultado = mysql_num_rows($consulta);
    if ($resultado == "") {
        echo "<font face=verdana size=-1> existe categoria!!!</font>";
        echo "<a href=cria_categoria.php><font face=verdana size=-1>Criar categoria</font></a>";
    } else {
        echo "<select name=oficina  onBlur = pesquisa(form1)>";
        while ($dados = mysql_fetch_array($consulta)) {
            echo "<option>$dados[descricao]</option>";
        }
        echo "</select>";
    }
}

function combo_processopassagem() {
    $consulta = mysql_query("SELECT processo FROM processopassagem order by processo ASC");
    $resultado = mysql_num_rows($consulta);
    if ($resultado == "") {
        echo "<font face=verdana size=-1> existe categoria!!!</font>";
        echo "<a href=cria_categoria.php><font face=verdana size=-1>Criar categoria</font></a>";
    } else {
        echo "<select name=processo  onBlur = pesquisa(form1)>";
        while ($dados = mysql_fetch_array($consulta)) {
            echo "<option>$dados[processo]</option>";
        }
        echo "</select>";
    }
}

function combo_trecho() {
    $consulta = mysql_query("select * from trecho");
    $resultado = mysql_num_rows($consulta);
    if ($resultado == "") {
        echo "<font face=verdana size=-1> existe categoria!!!</font>";
        echo "<a href=cria_categoria.php><font face=verdana size=-1>Criar categoria</font></a>";
    } else {
        echo "<select name=trecho onBlur = pesquisa(form)>";
        while ($dados = mysql_fetch_array($consulta)) {
            echo "<option value=$dados[CODIGO]>$dados[DESCRICAO]</option>";
        }
        echo "</select>";
    }
}

function lista_programa() {
    $consulta = mysql_query("select * from programa");
    $resultado = mysql_num_rows($consulta);
    if ($resultado == "") {
        echo "<font face=verdana size=-1> existe categoria!!!</font>";
        echo "<a href=cria_categoria.php><font face=verdana size=-1>Criar categoria</font></a>";
    } else {
        echo "<select name=programa>";
        while ($dados = mysql_fetch_array($consulta)) {
            echo "<option value=$dados[PROGRAMA]>$dados[PROGRAMA]</option>";
        }
        echo "</select>";
    }
}

function protocolo() {
    $consulta = mysql_query("SELECT * FROM chamado by nome_pasta ASC");
    $resultado = mysql_num_rows($consulta);
    if ($resultado == "") {
        echo "<font face=verdana size=-1> existe categoria!!!</font>";
        echo "<a href=cria_categoria.php><font face=verdana size=-1>Criar categoria</font></a>";
    } else {
        echo "<select name=select>";
        while ($dados = mysql_fetch_array($consulta)) {
            echo "<option>$dados[nome_pasta]</option>";
        }
        echo "</select>";
    }
}

function logar($login, $password) {
    $resultado = mysql_query("SELECT * FROM usuario WHERE user = '$login' AND pass = '$password'");
    $linhas = mysql_num_rows($resultado);
    if ($linhas == 0) {
        echo "<font face=verdana size=-1>Senha incorreta ou usuario cadastrado, tente novamente !!!</font><br>";
        echo "<a href=index.php><font face=verdana size=-1>voltar</fonte></a>";
    } else {
        while ($dados = mysql_fetch_array($resultado)) {
            session_start();
            $_SESSION['login_arquivo'] = $login;
            $_SESSION['grupo_login'] = $dados[grupo];
            $_SESSION['senha_arquivo'] = $password;
            header("Location: manager.php");
        }
    }
}

function lista_municipio() {
    $consulta = mysql_query("select * from  municipio ");
    $resultado = mysql_num_rows($consulta);
    if ($resultado == "") {
        echo "<font face=verdana size=-1> existe categoria!!!</font>";
        echo "<a href=cria_categoria.php><font face=verdana size=-1>Criar categoria</font></a>";
    } else {
        echo "<select name=municipio>";
        while ($dados = mysql_fetch_array($consulta)) {
            echo "<option value=$dados[CODIGO]>$dados[DESCRICAO]</option>";
        }
        echo "</select>";
    }
}

function lista_escola() {
    $consulta = mysql_query("select * from escola ");
    $resultado = mysql_num_rows($consulta);
    if ($resultado == "") {
        echo "<font face=verdana size=-1> existe categoria!!!</font>";
        echo "<a href=cria_categoria.php><font face=verdana size=-1>Criar categoria</font></a>";
    } else {
        echo "<select name=escola>";
        while ($dados = mysql_fetch_array($consulta)) {
            echo "<option value=$dados[INEP]>$dados[DESCRICAO]</option>";
        }
        echo "</select>";
    }
}

function lista_municipio_Altera() {
    $consulta = mysql_query("select * from  municipio ");
    $resultado = mysql_num_rows($consulta);
    if ($resultado == "") {
        echo "<font face=verdana size=-1> existe categoria!!!</font>";
        echo "<a href=cria_categoria.php><font face=verdana size=-1>Criar categoria</font></a>";
    } else {
        echo "<select name=municipio onChange=alteramuni(this.value)>";
        while ($dados = mysql_fetch_array($consulta)) {
            echo "<option value=$dados[CODIGO]>$dados[DESCRICAO]</option>";
        }
        echo "</select>";
    }
}

function lista_municipio_Altera1() {
    $consulta = mysql_query("select * from  municipio ");
    $resultado = mysql_num_rows($consulta);
    if ($resultado == "") {
        echo "<font face=verdana size=-1> existe categoria!!!</font>";
        echo "<a href=cria_categoria.php><font face=verdana size=-1>Criar categoria</font></a>";
    } else {
        echo "<select name=municipio onChange=alteramuni(this.value)>";
        while ($dados = mysql_fetch_array($consulta)) {
            echo "<option value=$dados[CODIGO]>$dados[DESCRICAO]</option>";
        }
        echo "</select>";
    }
}

function lista_escola1($nome_campo = "escola", $MULT = FALSE) {
    $sql = "select CODIGO,DESCRICAO from escola";
    $resposta = mysql_query($sql);

    $ufs = array();
    while ($linha = mysql_fetch_array($resposta)) {
        $ufs[] = ($linha["DESCRICAO"]);
    }
    $ret = "<select name='$nome_campo'";
    $ret.=($MULT) ? " MULTIPLE" : " ";
    $ret.= ">\n";
    foreach ($ufs as $chv => $vlr) {
        $ret.= "<option value='$chv'>$vlr</option>\n";
    }
    $ret.="</select>\n";
    return $ret;
}

function lista_ativo() {
    $consulta = mysql_query("select * from ativo ");
    $resultado = mysql_num_rows($consulta);
    if ($resultado == "") {
        echo "<font face=verdana size=-1> existe categoria!!!</font>";
        echo "<a href=cria_categoria.php><font face=verdana size=-1>Criar categoria</font></a>";
    } else {
        echo "<select name=ativo onblur= disabilitainternet() >";
        while ($dados = mysql_fetch_array($consulta)) {
            echo "<option value=$dados[DESCRICAO]>$dados[DESCRICAO]</option>";
        }
        echo "</select>";
    }
}

function tpoficina($nome_campo = "USR_UF", $MULT = FALSE) {
    $ufs = array("" => "...Selecione Tipo...",
        "BLOG" => "BLOG",
        "MOVIE" => "MOVIEMAKER",
        "PIKASA" => "PIKASA",
        "AUDACITY" => "AUDACITY",
        "OFFICE" => "OFIICE");

    $ret = "<select name='$nome_campo'";
    $ret.=($MULT) ? " MULTIPLE" : " ";
    $ret.= ">\n";

    foreach ($ufs as $chv => $vlr) {
        $ret.= "<option value='$chv'>$vlr</option>\n";
    }
    $ret.="</select>\n";
    return $ret;
}

function tpformacao($nome_campo = "tipo", $MULT = FALSE) {
    $ufs = array("" => "...Selecione Tipo...",
        "IED" => "INTRODUCAO A ED DIGITAL 40H - PROINFO",
        "EAT" => "ENS APRENDENDO C TIC S 100H - PROINFO");

    $ret = "<select name='$nome_campo'";
    $ret.=($MULT) ? " MULTIPLE" : " ";
    $ret.= ">\n";

    foreach ($ufs as $chv => $vlr) {
        $ret.= "<option value='$chv'>$vlr</option>\n";
    }
    $ret.="</select>\n";
    return $ret;
}

function programa($nome_campo = "programa", $MULT = FALSE) {
    $ufs = array("" => "...Selecione Programa...",
        "PROINFO" => "PROINFO",
        "ALVORADA" => "ALVORADA",
        "DESPERTAR" => "DESPERTAR",
        "PROMED" => "PROMED",
        "PROINESP" => "PROINESP",
        "TELINHA ESCOLA" => "TELINHA NA ESCOLA");

    $ret = "<select name='$nome_campo'";
    $ret.=($MULT) ? " MULTIPLE" : " ";
    $ret.= ">\n";

    foreach ($ufs as $chv => $vlr) {
        $ret.= "<option value='$chv'>$vlr</option>\n";
    }
    $ret.="</select>\n";
    return $ret;
}

function departamento($nome_campo = "departamento", $MULT = FALSE) {
    $ufs = array("" => "...Selecione Departamento...",
        "GAB" => "GABINETE",
        "ASS-JURIDICA" => "ASSESSORIA JURIDICA",
        "CPL" => "COMISS�O PERMANTE LICITA��O",
        "COORD-PEDAGOGICA" => "COORD PEDAGOGICA",
        "DAF" => "DIRETORIA ADM FINANCEIRA",
        "DAP" => "DIRETORIA DE ALMOXARIFADO E PATRIM�NIO",
        "DME" => "DIRETORIA DE MANUTEN��O ESCOLAR",
        "DERA" => "DIRETORIA EDIFIC REFORMA E AMPLIA��O",
        "GT" => "GER�NCIA DE TRANSPORTES ESCOLAR",
        "GCI" => "GER�NCIA DE CONTROLE E INTERNO",
        "GTI" => "GER�NCIA DE TECNOLOGIA E INFORMA��O",
        "GPOP" => "GER�NCIA PLANEJAMENTO E OR�AMENTO PROJETO",
        "GCPC" => "GER�NCIA DE CONV�NIO E PRESTA��O DE CONTAS",
        "GE" => "GER�NCIA DE EDUCA��O",
        "GEP" => "GER�NCIA DE EDUCA��O PROFISSIONAL",
        "GPE" => "GER�NCIA DE PROJETOS ESPECIAIS",
        "CAP" => "CAP",
        "NEJA" => "NEJA",
        "NAM" => "NAM",
        "PROINFANTIL" => "PROINFANTIL",
        "CONS ESTADUAL" => "CONSELHO ESTADUAL",
        "TV-ESCOLA" => "TV ESCOLA",
        "CAS" => "CAS",
        "PRO-FUNCIONARIO" => "PRO-FUNCIONARIO",
        "REGIMENTO" => "REGIMENTO",
        "PTE" => "PTE",
        "NTE" => "NTE",
        "GACA" => "GER�NCIA DE APARELHAMENTO CONTR E AVALIA��O",
        "RENCENTRO" => "REN CENTRO",
        "RENSUL" => "REN SUL",
        "RENLESTE" => "REN LESTE",
        "PIE" => "PIE",
        "CEC" => "CEC-COORD DE ESPORTE E CURLTURA",
        "PRODEF/GE" => "PRODEF/GE",
        "PEDEM/GE" => "PRODEF/GE",
        "ALMOXARIFADO/SEDUC" => "ALMOXARIFADO/SEDUC",
        "NUCELI/DAF/SEDUC" => "NUCELI/DAF/SEDUC",
    );
    $ret = "<select name='$nome_campo'";
    $ret.=($MULT) ? " MULTIPLE" : " ";
    $ret.= ">\n";

    foreach ($ufs as $chv => $vlr) {
        $ret.= "<option value='$chv'>$vlr</option>\n";
    }
    $ret.="</select>\n";
    return $ret;
}


function empresa($nome_campo = "empresa", $MULT = FALSE) {
    $ufs = array("" => "...Selecione Empresa...",
        "GLOBAL SYSTEM" => "GLOBAL SYSTEM",
        "ITECH" => "ITECH",
        "SEDUC" => "SEDUC");

    $ret = "<select name='$nome_campo'";
    $ret.=($MULT) ? " MULTIPLE" : " ";
    $ret.= ">\n";

    foreach ($ufs as $chv => $vlr) {
        $ret.= "<option value='$chv'>$vlr</option>\n";
    }
    $ret.="</select>\n";
    return $ret;
}

function zebrar($i) {
    return func_get_arg(abs($i) % (func_num_args() - 1) + 1);
}

function idade($dataNascimento) {
    if (strtotime($dataNascimento)) {
        $diff = date_diff(new DateTime($dataNascimento), new DateTime());    
        return $diff->format('%Y%');
    }
    else {
        return '-';
    }
}

function converteData($data, $separador='.') {
    $dia = substr($data, 0,2);
    $ano = substr($data, -4);
    $mes = substr($data, -7,2);

    return "{$ano}{$separador}{$mes}{$separador}{$dia}";
}

function formataData($data) {
    if(in_array($data, array(null, '', '0000-00-00'))) return '';

    return date("d/m/Y", strtotime($data));
}

function formataDataHora($datahora) {
    if(in_array($datahora, array(null, '', '0000-00-00'))) return '';

    return date("d/m/Y H:i:s", strtotime($datahora));
}

function validaData($date, $formato = "d/m/Y")
{
    $d = DateTime::createFromFormat($formato, $date);
    return $d && $d->format($formato) == $date;
}

function comparaData($d1, $f1, $d2, $f2) {
    $d1 = DateTime::createFromFormat($f1, $d1);
    $d2 = DateTime::createFromFormat($f2, $d2);
    return ($d1 > $d2) ? 1 : (($d1 == $d2) ? 0 : -1);
}

function date_in_range($date_from_user, $start_date, $end_date)
{
    // Convert to timestamp
    $start_ts = strtotime($start_date);
    $end_ts = strtotime($end_date);
    $user_ts = strtotime($date_from_user);

    // Check that user date is between start & end
    return (($user_ts >= $start_ts) && ($user_ts <= $end_ts));
}

function porcent($todo, $parte) {
    if ($todo == 0) {
        return '0';
    }
    return number_format($parte * 100 / $todo, 2, ',','.');
}

function limpaNome($str) {
    return preg_replace("/[^\w\space\pL]/", "", $str);
}

function selected($exp) {
    echo $exp ? 'selected' : '';
}

function checked($exp) {
    echo $exp ? 'checked' : '';
}

function disabled($exp) {
    echo $exp ? 'disabled' : '';
}

function required($exp) {
    echo $exp ? 'required' : '';
}

function readonly($exp) {
    echo $exp ? 'readonly' : '';
}

function upImagemBig($tam, $arquivo, $largura, $altura_crop) {
    $dir = "fotos/";

    // ler extensão de arquivo
    preg_match("/\.(gif|png|jpg|jpeg){1}$/i", $arquivo["name"], $ext);

    if (preg_match("/png|jpg|jpeg/i", $ext[1])) {
        // Renomear arquivo para evitar quebras
        $file_nome = md5(uniqid(time())) . "-" . $tam . "." . $ext[1];

        $imagem = $dir . $file_nome;
        //caminho com nome da imagem e local para guardar

        if (move_uploaded_file($_FILES['imagem']['tmp_name'], $imagem))//copy(,$imagem))
        //aqui nada especial so movo a tmp_name dando caminho
            redCropImagemBig($tam, $arquivo, $largura, $altura_crop, $imagem, $file_nome, $ext[1]);

        return $file_nome;
    }
    else {
        echo "G. Formato de imagem n&atilde;o suportado!";
        exit();
    }
}

function redCropImagemBig($tam, $arquivo, $largura, $altura_crop, $imagem, $file_nome, $ext) {
    // Pega as dimensões
    $imagesize = getimagesize($imagem);

    //regra de 3
    $largura_original = $imagesize[0]; // 0 será a largura.
    $altura_original = $imagesize[1]; // 1 será a altura.

    if ($tam == 'g') {
        $altura = ($altura_original * $largura) / $largura_original;
    }
    if ($tam == 't') {
        $altura = $altura_crop;
    }
    if ($tam == 'in') {
        $altura = $altura_crop;
    }

    //criamos uma nova imagem ( que vai ser a redimensionada) a partir da imagem original
    //$imagem_orig = imagecreatefromjpeg($imagem);
    if ($ext == "jpg" || $ext == "jpeg" || $ext == "JPEG" || $ext == "JPG") {
        $imagem_orig = imagecreatefromjpeg($imagem);
    } elseif ($ext == "png") {
        $imagem_orig = imagecreatefrompng($imagem);
    }
    if (!$imagem_orig) {
        echo("Erro ao carregar a imagem, talvez formato nao suportado");
        return false;
        exit;
    }

    //pegamos a altura e a largura da imagem original
    $pontox = imagesx($imagem_orig);
    $pontoy = imagesy($imagem_orig);

    //criamos a imagem redimensionada com a funcao imagecreatetruecolor para suportar um grande numero de cores
    $imagem_fin = imagecreatetruecolor($largura, $altura);

    //copiamos o conteudo da imagem original e passamos para o espaco reservado a redimencao
    imagecopyresampled($imagem_fin, $imagem_orig, 0, 0, 0, 0, $largura + 1, $altura + 1, $pontox, $pontoy);

    //salva a imagem
    //imagejpeg($imagem_fin, $imagem,100);
    if ($ext == "jpg" || $ext == "jpeg" || $ext == "JPEG" || $ext == "JPG") {
        imagejpeg($imagem_fin, $imagem, 100);
        return true;
    } elseif ($ext == "png") {
        imagepng($imagem_fin, $imagem);
        return true;
    } else {
        echo("Formato de arquivo nao suportado");
        return false;
    }

    #crop
    $LIMG = $largura;
    $AIMG = $altura_crop;
    $g_srcfile = $imagem;

    if (file_exists($g_srcfile)) {

        $g_is = getimagesize($g_srcfile);

        $g_ih = $AIMG;
        $g_iw = ($g_ih / $g_is[1]) * $g_is[0];

        if ($LIMG > $g_iw) {
            $g_iw = $LIMG;
            $g_ih = ($LIMG / $g_is[0]) * $g_is[1];
        }

        // se a largura redimensionada($g_iw)  for
        // maior ou igual a altura redimensionada($g_ih)
        if ($g_iw >= $g_ih) {
            $scr_x = 0;
            $src_y = 0;
        } else {
            $scr_x = 0;
            $src_y = 0;
        }

        $img_src = imagecreatefromjpeg($g_srcfile);
        $img_dst = imagecreatetruecolor($LIMG, $AIMG);
        imagecopyresampled($img_dst, $img_src, 0, 0, $scr_x, $src_y, $g_iw, $g_ih, $g_is[0], $g_is[1]);

        //imagejpeg($img_dst,$imagem);
        if ($ext == "jpg" || $ext == "jpeg" || $ext == "JPEG" || $ext == "JPG") {
            imagejpeg($img_dst, $imagem, 100);
            return true;
        } elseif ($ext == "gif") {
            imagepng($img_dst, $imagem);
            return true;
        } elseif ($ext == "png") {
            imagepng($img_dst, $imagem);
            return true;
        } else {
            echo("Formato de arquivo nao suportado");
            return false;
        }
        imagedestroy($img_dst);
        //libera a memoria
        imagedestroy($imagem_orig);
        imagedestroy($imagem_fin);
    }
}

function redCropImagemT($tam, $arquivo, $largura, $altura_crop, $imagem, $file_nome, $ext) {


    #crop
    $LIMG = $largura;
    $AIMG = $altura_crop;
    $g_srcfile = $imagem;

    if (file_exists($g_srcfile)) {

        $g_is = getimagesize($g_srcfile);

        $g_ih = $AIMG;
        $g_iw = ($g_ih / $g_is[1]) * $g_is[0];

        if ($LIMG > $g_iw) {
            $g_iw = $LIMG;
            $g_ih = ($LIMG / $g_is[0]) * $g_is[1];
        }

        // se a largura redimensionada($g_iw)  for
        // maior ou igual a altura redimensionada($g_ih)
        if ($g_iw >= $g_ih) {
            $scr_x = 0;
            $src_y = 0;
        } else {
            $scr_x = 0;
            $src_y = 0;
        }

        $img_src = imagecreatefromjpeg($g_srcfile);
        $img_dst = imagecreatetruecolor($LIMG, $AIMG);
        imagecopyresampled($img_dst, $img_src, 0, 0, $scr_x, $src_y, $g_iw, $g_ih, $g_is[0], $g_is[1]);

        //imagejpeg($img_dst,$imagem);
        if ($ext == "jpg" || $ext == "jpeg" || $ext == "JPEG" || $ext == "JPG") {
            imagejpeg($img_dst, $imagem, 100);
            return true;
        } elseif ($ext == "gif") {
            imagepng($img_dst, $imagem);
            return true;
        } elseif ($ext == "png") {
            imagepng($img_dst, $imagem);
            return true;
        } else {
            echo("Formato de arquivo nao suportado");
            return false;
        }
        imagedestroy($img_dst);
        //libera a memoria
        imagedestroy($imagem_orig);
        imagedestroy($imagem_fin);
    }
}

if (!function_exists('array_column'))
{
    function array_column($input, $column_key=null, $index_key=null)
    {
        $result = array();
        $i = 0;
        foreach ($input as $v)
        {
            $k = $index_key === null || !isset($v[$index_key]) ? $i++ : $v[$index_key];
            $result[$k] = $column_key === null ? $v : (isset($v[$column_key]) ? $v[$column_key] : null);
        }
        return $result;
    }
}

function print_default($value, $default = '') {
    return isset($value) ? $value : $default;
}

function menor($x, $y, $escala = 1) {
    return bccomp($x, $y, $escala) == -1;
}

function executar_async($url)
{
    exec('bash -c "wget -O {$url} > /dev/null 2>&1 &"');
}

function ifEmpty($value, $alt) {
    return empty($value) || is_null($value) ? $alt : $value;
}

/**
 * simple method to encrypt or decrypt a plain text string
 * initialization vector(IV) has to be the same when encrypting and decrypting
 * PHP 5.4.9 ( check your PHP version for function definition changes )
 *
 * this is a beginners template for simple encryption decryption
 * before using this in production environments, please read about encryption
 * use at your own risk
 *
 * @param string $action: can be 'encrypt' or 'decrypt'
 * @param string $string: string to encrypt or decrypt
 *
 * @return string
 */
function encrypt_decrypt($action, $string) {
    $output = false;

    $encrypt_method = "AES-256-CBC";
    $secret_key = 'a4af08ac-38d7-4092-9cd9-b9f6f64f4dcf';
    $secret_iv = '68ec3ff3-d736-4aa5-973f-81be11f27c44';

    // hash
    $key = hash('sha256', $secret_key);
    
    // iv - encrypt method AES-256-CBC expects 16 bytes - else you will get a warning
    $iv = substr(hash('sha256', $secret_iv), 0, 16);

    if( $action == 'encrypt' ) {
        $output = openssl_encrypt($string, $encrypt_method, $key, 0, $iv);
        $output = base64_encode($output);
    }
    else if( $action == 'decrypt' ){
        $output = openssl_decrypt(base64_decode($string), $encrypt_method, $key, 0, $iv);
    }

    return $output;
}

function validarCPF($cpf) {
    $cpf = preg_replace('/[^0-9]/', '', (string) $cpf);
    // Valida tamanho
    if (strlen($cpf) != 11)
    {
        return false;
    }
    else if ($cpf == '00000000000' || 
        $cpf == '11111111111' || 
        $cpf == '22222222222' || 
        $cpf == '33333333333' || 
        $cpf == '44444444444' || 
        $cpf == '55555555555' || 
        $cpf == '66666666666' || 
        $cpf == '77777777777' || 
        $cpf == '88888888888' || 
        $cpf == '99999999999') 
    {
        return false;
    }
    // Calcula e confere primeiro dgito verificador
    for ($i = 0, $j = 10, $soma = 0; $i < 9; $i++, $j--)
        $soma += $cpf{$i} * $j;
    $resto = $soma % 11;
    if ($cpf{9} != ($resto < 2 ? 0 : 11 - $resto))
        return false;
    // Calcula e confere segundo dgito verificador
    for ($i = 0, $j = 11, $soma = 0; $i < 10; $i++, $j--)
        $soma += $cpf{$i} * $j;
    $resto = $soma % 11;
    return $cpf{10} == ($resto < 2 ? 0 : 11 - $resto);

}

function checkEmailValido($email) {
    list($user, $domain) = explode('@', $email);

    return filter_var($email, FILTER_VALIDATE_EMAIL) && checkdnsrr($domain, 'MX');
}

function obfuscateEmail($email) {
    $em   = explode("@",$email);
    $name = implode(array_slice($em, 0, count($em)-1), '@');
    $len  = floor(strlen($name)/2);

    return substr($name,0, $len) . str_repeat('*', $len) . "@" . end($em);
}

function json($r) {
    header('Content-Type: application/json; charset=utf-8');
    die(json_encode($r));
}

function tFrequenciaAluno($ano) {
    return ($ano <= 2014) ? 'frequencia_aluno' : "frequencia_aluno{$ano}";
}

function tFrequenciaCabeca($ano) {
    return ($ano <= 2014) ? 'frequencia_cabeca' : "frequencia_cabeca{$ano}";
}
