<?php




$agent = strtolower($_SERVER["HTTP_USER_AGENT"]);
if(!strstr($agent, "chrome") && !strstr($agent, "msie")) {// Mostra seu conteudo
} else
{
	echo "<html><head><title>Resposta !!!</title></head>";
   	echo "<body background=\"background_mensagens.jpg\" style=\"background-attachment:fixed; background-repeat:no-repeat\">";
   	echo "<br><br><br>";
   	echo "<center><img src=\"faleconosco/atencao.gif\" alt=\"\"><p><font color=\"#ff6600\" face=\"Verdana\" size=\"4\">Usu�rio para melhor funcionamento e seguranca utilize o navegaor Mozilla FireFox ! <b></b></font></center>";
   	echo "<br><br><center><a href=\"login.php\"><img src=\"faleconosco/button_voltar2_.gif\" alt=\"Voltar\" border=\"0\" /></a></center>";
    echo "</body></html>";
    exit;
}




function anti_injection($sql)
{
// remove palavras que contenham sintaxe sql
$sql = preg_replace(sql_regcase("/(from|select|insert|delete|where|drop table|show tables|#|\*|--|\\\\)/"),"",$sql);
$sql = trim($sql);//limpa espa�os vazio
$sql = strip_tags($sql);//tira tags html e php
$sql = addslashes($sql);//Adiciona barras invertidas a uma string
return $sql;
}


$login    = anti_injection($_POST["cpf"]);
$senha    = md5(anti_injection(($_POST["password"])));
$inep     = anti_injection($_POST["inep"]);
$nte      = $_POST["nte"];
$ntelogin = $_POST["nte"];
/*
echo "login $login";
echo "senha $senha";
echo "inep $inep";
echo "nte $nte";
echo "ntelogin $login";
  */
//modo de usar pegando dados vindos do formulario



//$nte      = $_POST["nte"];
//$inep     = $_POST["inep"];
//$ntelogin = $_POST["nte"];
//echo "inep $inep";


include ("../conexao_mysql.php");

$resultado  = mysql_query("select cpf,nome,nivel,senha,nte,dpto from usuario where cpf = '$login'") or die("ERRO no SQL : ".mysql_error());
$linhas     = mysql_num_rows($resultado);

if ($linhas ==0)//testa se a consulta retornou algum registro
  {
			
			echo "<html><head><title>Resposta !!!</title></head>";
        	echo "<body background=\"background_mensagens.jpg\" style=\"background-attachment:fixed; background-repeat:no-repeat\">";
        	echo "<br><br><br>";
        	echo "<center><img src=\"faleconosco/atencao.gif\" alt=\"\"><p><font color=\"#ff6600\" face=\"Verdana\" size=\"4\">Usu�rio Senha Incorreta, Tente Novamente!!!! <b></b></font></center>";
        	echo "<br><br><center><a href=\"../login.php\"><img src=\"faleconosco/button_voltar2_.gif\" alt=\"Voltar\" border=\"0\" /></a></center>";
           echo "</body></html>";
           exit;

   } 
else
 {
       //     echo  mysql_result($resultado, 0,"senha");

    if ($senha != mysql_result($resultado, 0,"senha"))            
	  {
            
			echo "<html><head><title>Resposta !!!</title></head>";
        	echo "<body background=\"background_mensagens.jpg\" style=\"background-attachment:fixed; background-repeat:no-repeat\">";
        	echo "<br><br><br>";
        	echo "<center><img src=\"faleconosco/atencao.gif\" alt=\"\"><p><font color=\"#ff6600\" face=\"Verdana\" size=\"4\">Usu�rio Senha Incorreta, Tente Novamente!!!! <b></b></font></center>";
        	echo "<br><br><center><a href=\"login.php\"><img src=\"faleconosco/button_voltar2_.gif\" alt=\"Voltar\" border=\"0\" /></a></center>";
           echo "</body></html>";
           exit;

  	  }

    else 
	  {
         session_start();     //nunca esque�a de por isso antes de usar session
         $nivel           = mysql_result($resultado, 0, "nivel");
         $nome            = mysql_result($resultado, 0, "nome");
         $cpf             = mysql_result($resultado, 0, "cpf");
         $nte_bd          = mysql_result($resultado, 0, "nivel");
         $user_senha      = mysql_result($resultado, 0, "senha");
         $user_dpto       = mysql_result($resultado, 0, "dpto");
 	
    	 $_SESSION["login_usuario"]   = $nome;
         $_SESSION["senha_usuario"]   = $senha;
         $_SESSION["nivel_usuario"]   = $nivel;   
         $_SESSION["cpf_usuario"]     = $cpf;   
         $_SESSION["nte_usuario"]     = $nte_bd;  
	     $_SESSION["nte_login"]       = $ntelogin;
         $_SESSION["inep_usuario"]    = $inep;
   	     $_SESSION["dpto_usuario"]    = $dpto;




if ($nivel=="ADM")
	     {
         header("Location: mnusuario.php");
		 }
else if ($nivel=="PTE")     	
	    { 
		 header("Location: mnpte.php");
		} 

else if ((trim($senha)==$user_senha) && ($nte)==($nte_bd)   && trim($cpf)==trim($login)  && trim($user_dpto)==trim($inep) && ($ntelogin)==("ESCOLA"))
	    { 
		 $re = mysql_query("select count(*) as total from escola where inep  = '$inep'");
         $total = mysql_result($re, 0, "total");
         if ($total==0) 
           {    
         	echo "<html><head><title>Resposta !!!</title></head>";
        	echo "<body background=\"background_mensagens.jpg\" style=\"background-attachment:fixed; background-repeat:no-repeat\">";
        	echo "<br><br><br>";
        	echo "<center><img src=\"faleconosco/atencao.gif\" alt=\"\"><p><font color=\"#ff6600\" face=\"Verdana\" size=\"4\">Usu�rio Informe o INEP da Sua Escola!!!! <b></b></font></center>";
        	echo "<br><br><center><a href=\"../login.php\"><img src=\"faleconosco/button_voltar2_.gif\" alt=\"Voltar\" border=\"0\" /></a></center>";
           echo "</body></html>";
           exit;
	       }
		 else
		   {

               

	if  (($nivel=="PVH") || ($nivel=="JPR") || ($nivel=="RLM") || ($nivel=="CAC")  || ($nivel=="VLH") || ($nivel=="ESCOLA") || ($ntelogin=="PTE") || ($nivel=="GTI")) 
		          {
	     	         header("Location: mnescola.php");
			 	   }	
		  }    
       }

else if ((trim($senha)==trim($user_senha)) && (trim($nte)==trim($nte_bd))   && trim($cpf)==trim($login)  && trim($user_dpto)==trim($inep) && $ntelogin =="ADME")
	   {
         $re = mysql_query("select count(*) as total from escola where inep  = '$inep'");
         $total = mysql_result($re, 0, "total");
          if ($total==0)
           {
         	echo "<html><head><title>Resposta !!!</title></head>";
        	echo "<body background=\"background_mensagens.jpg\" style=\"background-attachment:fixed; background-repeat:no-repeat\">";
        	echo "<br><br><br>";
        	echo "<center><img src=\"faleconosco/atencao.gif\" alt=\"\"><p><font color=\"#ff6600\" face=\"Verdana\" size=\"4\">Usu�rio Informe o INEP da Sua Escola!!!! <b></b></font></center>";
        	echo "<br><br><center><a href=\"../login.php\"><img src=\"faleconosco/button_voltar2_.gif\" alt=\"Voltar\" border=\"0\" /></a></center>";
             echo "</body></html>";
           exit;
	       }
		 else
		   {
      		  header("Location: ../escola/mnadmescola.php");
		  }
       }

else if (($nivel=="GTI") && (trim($senha)==trim($user_senha))  && trim($cpf)==trim($login))
          {
		        $_SESSION["inep_usuario"]  = $inep;   
    	        header("Location: mngti.php");
    	   }	

else if (($nivel =="GTI") && ($nivel=="PVH") && (trim($senha)==trim($user_senha))  && trim($cpf)==trim($login))
          {
		        $_SESSION["inep_usuario"]  = $inep;   
    	        header("Location: ../mngti.php");
    	   }	



else if (($nivel=="CER") && (trim($senha)==trim($user_senha))  && trim($cpf)==trim($login))
           {
		        $_SESSION["inep_usuario"]  = $inep;   
    	        header("Location: cerimonial/mncerimonial.php");
    	   }	


else if (($nivel=="NEP") && (trim($senha)==trim($user_senha))  && trim($cpf)==trim($login))
           {
			    $_SESSION["inep_usuario"]  = $inep;   
    	        header("Location: ../gestao/mnnep.php");
    	   }	


else if (($ntelogin =="DIA") && ($nivel =="DIA") && (trim($senha)==trim($user_senha))  && trim($cpf)==trim($login))
         {
		        $_SESSION["inep_usuario"]  = $inep;   
    	        header("Location: ../diarias/mndiarias.php");
    	   }	


else if (($ntelogin =="PVH") && ($nivel=="PVH") && (trim($senha)==trim($user_senha))  && trim($cpf)==trim($login))
	    { 
		 header("Location: ../mnnte.php");
		} 

else if  ((($ntelogin =="JPR") && ($nivel=="JPR"))  && (trim($senha)==trim($user_senha))  && trim($cpf)==trim($login))
	    { 

		 header("Location: ../mnnte.php");
		} 

else if  (($ntelogin =="RLM") && ($nivel=="RLM") && (trim($senha)==trim($user_senha))  && trim($cpf)==trim($login))
	    { 
		 header("Location: ../mnnte.php");
		} 

else if   (($ntelogin =="CAC") && ($nivel=="CAC")&& (trim($senha)==trim($user_senha))  && trim($cpf)==trim($login))
	    { 
		 header("Location: ../mnnte.php");
		} 

else if  (($ntelogin =="VLH") && ($nivel=="VLH") && (trim($senha)==trim($user_senha))  && trim($cpf)==trim($login))
	    { 
		  header("Location: ../mnnte.php");
		} 

else if  (($ntelogin =="FRO") && (trim($senha)==trim($user_senha))  && trim($cpf)==trim($login))
	    { 
		  header("Location: ../frota/index.php");
		} 

else if  (($ntelogin =="GAC")&& (trim($senha)==trim($user_senha))  && (trim($nte)==trim($nte_bd))   && trim($cpf)==trim($login))
	    { 
		  header("Location: ../gaca/mngaca.php");
		} 
else if  (($ntelogin =="NAM") && (trim($senha)==trim($user_senha))  && (trim($nte)==trim($nte_bd))   && trim($cpf)==trim($login))
	    { 
		  header("Location: ../nam/mnnam.php");
		} 

else if  (($ntelogin =="LOT")&& (trim($senha)==trim($user_senha)) && (trim($nte)==trim($nte_bd))  && trim($cpf)==trim($login))
  {

       if (trim($inep)!='')
         {
           $re = mysql_query("select count(*) as total from escola where inep  = '$inep'");
           $total = mysql_result($re, 0, "total");
           if ($total==0)
            {
         	echo "<html><head><title>Resposta !!!</title></head>";
        	echo "<body background=\"background_mensagens.jpg\" style=\"background-attachment:fixed; background-repeat:no-repeat\">";
        	echo "<br><br><br>";
        	echo "<center><img src=\"faleconosco/atencao.gif\" alt=\"\"><p><font color=\"#ff6600\" face=\"Verdana\" size=\"4\">Usu�rio Informe o INEP da Sua Escola!!!! <b></b></font></center>";
        	echo "<br><br><center><a href=\"../login.php\"><img src=\"faleconosco/button_voltar2_.gif\" alt=\"Voltar\" border=\"0\" /></a></center>";
              echo "</body></html>";
           exit;
	       }
		   else
		     {
      		  header("Location: ../escola/mnadmescola.php");
		     }
        }
       else
        {
             header("Location: nam/mnlotacao.php");
	    }
	 }

else if  (($ntelogin =="NRH")&& (trim($senha)==trim($user_senha)) && (trim($nte)==trim($nte_bd)) && trim($cpf)==trim($login))
	    { 
		  header("Location: nam/mnrh.php");
		} 


else if  (($ntelogin =="1")&& (trim($senha)==trim($user_senha)) && (trim($nte)==trim($nte_bd)) && trim($cpf)==trim($login))
	    {

       if (trim($inep)!='')
         {
           $re = mysql_query("select count(*) as total from escola where inep  = '$inep'");
           $total = mysql_result($re, 0, "total");
           if ($total==0)
            {
         	echo "<html><head><title>Resposta !!!</title></head>";
        	echo "<body background=\"background_mensagens.jpg\" style=\"background-attachment:fixed; background-repeat:no-repeat\">";
        	echo "<br><br><br>";
        	echo "<center><img src=\"faleconosco/atencao.gif\" alt=\"\"><p><font color=\"#ff6600\" face=\"Verdana\" size=\"4\">Usu�rio Informe o INEP da Sua Escola!!!! <b></b></font></center>";
        	echo "<br><br><center><a href=\"../login.php\"><img src=\"faleconosco/button_voltar2_.gif\" alt=\"Voltar\" border=\"0\" /></a></center>";
            echo "</body></html>";
           exit;
	       }
		   else
		     {
      		  header("Location: ../escola/mnadmescola.php");
		     }
        }
       else
        {
		  header("Location: ../cre/mnadrem.php");
	    }

  }

else if  (($ntelogin =="2")&& (trim($senha)==trim($user_senha)) && (trim($nte)==trim($nte_bd)) && trim($cpf)==trim($login))
	    {
       if (trim($inep)!='')
         {
           $re = mysql_query("select count(*) as total from escola where inep  = '$inep'");
           $total = mysql_result($re, 0, "total");
           if ($total==0)
            {
         	echo "<html><head><title>Resposta !!!</title></head>";
        	echo "<body background=\"background_mensagens.jpg\" style=\"background-attachment:fixed; background-repeat:no-repeat\">";
        	echo "<br><br><br>";
        	echo "<center><img src=\"faleconosco/atencao.gif\" alt=\"\"><p><font color=\"#ff6600\" face=\"Verdana\" size=\"4\">Usu�rio Informe o INEP da Sua Escola!!!! <b></b></font></center>";
        	echo "<br><br><center><a href=\"../login.php\"><img src=\"faleconosco/button_voltar2_.gif\" alt=\"Voltar\" border=\"0\" /></a></center>";
            echo "</body></html>";
	                  exit;
              }
		   else
		     {
      		  header("Location: ../escola/mnadmescola.php");
		     }
        }
       else
        {
		  header("Location: cre/mnadrem.php");
	    }

		}

else if  (($ntelogin =="6")&& (trim($senha)==trim($user_senha)) && (trim($nte)==trim($nte_bd)) && trim($cpf)==trim($login))
	    {
       if (trim($inep)!='')
         {
           $re = mysql_query("select count(*) as total from escola where inep  = '$inep'");
           $total = mysql_result($re, 0, "total");
           if ($total==0)
            {
         	echo "<html><head><title>Resposta !!!</title></head>";
        	echo "<body background=\"background_mensagens.jpg\" style=\"background-attachment:fixed; background-repeat:no-repeat\">";
        	echo "<br><br><br>";
        	echo "<center><img src=\"faleconosco/atencao.gif\" alt=\"\"><p><font color=\"#ff6600\" face=\"Verdana\" size=\"4\">Usu�rio Informe o INEP da Sua Escola!!!! <b></b></font></center>";
        	echo "<br><br><center><a href=\"login.php\"><img src=\"faleconosco/button_voltar2_.gif\" alt=\"Voltar\" border=\"0\" /></a></center>";
            echo "</body></html>";
           exit;
	       }
		   else
		     {
      		  header("Location: ../escola/mnadmescola.php");
		     }
        }
       else
        {
		  header("Location: ../cre/mnadrem.php");
	    }

		}

else if  (($ntelogin =="13")&& (trim($senha)==trim($user_senha)) && (trim($nte)==trim($nte_bd)) && trim($cpf)==trim($login))
	    {
       if (trim($inep)!='')
         {
           $re = mysql_query("select count(*) as total from escola where inep  = '$inep'");
           $total = mysql_result($re, 0, "total");
           if ($total==0)
            {
         	echo "<html><head><title>Resposta !!!</title></head>";
        	echo "<body background=\"background_mensagens.jpg\" style=\"background-attachment:fixed; background-repeat:no-repeat\">";
        	echo "<br><br><br>";
        	echo "<center><img src=\"faleconosco/atencao.gif\" alt=\"\"><p><font color=\"#ff6600\" face=\"Verdana\" size=\"4\">Usu�rio Informe o INEP da Sua Escola!!!! <b></b></font></center>";
        	echo "<br><br><center><a href=\"login.php\"><img src=\"faleconosco/button_voltar2_.gif\" alt=\"Voltar\" border=\"0\" /></a></center>";
            echo "</body></html>";
           exit;
	       }
		   else
		     {
      		  header("Location: ../escola/mnadmescola.php");
		     }
        }
       else
        {
		  header("Location: ../cre/mnadrem.php");
	    }

		}

else if  (($ntelogin =="12")&& (trim($senha)==trim($user_senha)) && (trim($nte)==trim($nte_bd)) && trim($cpf)==trim($login))
	    {
       if (trim($inep)!='')
         {
           $re = mysql_query("select count(*) as total from escola where inep  = '$inep'");
           $total = mysql_result($re, 0, "total");
           if ($total==0)
            {
         	echo "<html><head><title>Resposta !!!</title></head>";
        	echo "<body background=\"background_mensagens.jpg\" style=\"background-attachment:fixed; background-repeat:no-repeat\">";
        	echo "<br><br><br>";
        	echo "<center><img src=\"faleconosco/atencao.gif\" alt=\"\"><p><font color=\"#ff6600\" face=\"Verdana\" size=\"4\">Usu�rio Informe o INEP da Sua Escola!!!! <b></b></font></center>";
        	echo "<br><br><center><a href=\"login.php\"><img src=\"faleconosco/button_voltar2_.gif\" alt=\"Voltar\" border=\"0\" /></a></center>";
            echo "</body></html>";
           exit;
	       }
		   else
		     {
      		  header("Location: ../escola/mnadmescola.php");
		     }
        }
       else
        {
		  header("Location: ../cre/mnadrem.php");
	    }

		}


else if  (($ntelogin =="11")&& (trim($senha)==trim($user_senha)) && (trim($nte)==trim($nte_bd)) && trim($cpf)==trim($login))
	    {
       if (trim($inep)!='')
         {
           $re = mysql_query("select count(*) as total from escola where inep  = '$inep'");
           $total = mysql_result($re, 0, "total");
           if ($total==0)
            {
         	echo "<html><head><title>Resposta !!!</title></head>";
        	echo "<body background=\"background_mensagens.jpg\" style=\"background-attachment:fixed; background-repeat:no-repeat\">";
        	echo "<br><br><br>";
        	echo "<center><img src=\"faleconosco/atencao.gif\" alt=\"\"><p><font color=\"#ff6600\" face=\"Verdana\" size=\"4\">Usu�rio Informe o INEP da Sua Escola!!!! <b></b></font></center>";
        	echo "<br><br><center><a href=\"../login.php\"><img src=\"faleconosco/button_voltar2_.gif\" alt=\"Voltar\" border=\"0\" /></a></center>";
            echo "</body></html>";
           exit;
	       }
		   else
		     {
      		  header("Location: ../escola/mnadmescola.php");
		     }
        }
       else
        {
		  header("Location: ../cre/mnadrem.php");
	    }

		}
else if  (($ntelogin =="3")&& (trim($senha)==trim($user_senha)) && (trim($nte)==trim($nte_bd)) && trim($cpf)==trim($login))
	    {
       if (trim($inep)!='')
         {
           $re = mysql_query("select count(*) as total from escola where inep  = '$inep'");
           $total = mysql_result($re, 0, "total");
           if ($total==0)
            {
         	echo "<html><head><title>Resposta !!!</title></head>";
        	echo "<body background=\"background_mensagens.jpg\" style=\"background-attachment:fixed; background-repeat:no-repeat\">";
        	echo "<br><br><br>";
        	echo "<center><img src=\"faleconosco/atencao.gif\" alt=\"\"><p><font color=\"#ff6600\" face=\"Verdana\" size=\"4\">Usu�rio Informe o INEP da Sua Escola!!!! <b></b></font></center>";
        	echo "<br><br><center><a href=\"../login.php\"><img src=\"faleconosco/button_voltar2_.gif\" alt=\"Voltar\" border=\"0\" /></a></center>";
            echo "</body></html>";
           exit;
	       }
		   else
		     {
      		  header("Location: ../escola/mnadmescola.php");
		     }
        }
       else
        {
		  header("Location: ../cre/mnadrem.php");
	    }

		}
else if  (($ntelogin =="4")&& (trim($senha)==trim($user_senha)) && (trim($nte)==trim($nte_bd)) && trim($cpf)==trim($login))
	    {
       if (trim($inep)!='')
         {
           $re = mysql_query("select count(*) as total from escola where inep  = '$inep'");
           $total = mysql_result($re, 0, "total");
           if ($total==0)
            {
         	echo "<html><head><title>Resposta !!!</title></head>";
        	echo "<body background=\"background_mensagens.jpg\" style=\"background-attachment:fixed; background-repeat:no-repeat\">";
        	echo "<br><br><br>";
        	echo "<center><img src=\"faleconosco/atencao.gif\" alt=\"\"><p><font color=\"#ff6600\" face=\"Verdana\" size=\"4\">Usu�rio Informe o INEP da Sua Escola!!!! <b></b></font></center>";
        	echo "<br><br><center><a href=\"../login.php\"><img src=\"faleconosco/button_voltar2_.gif\" alt=\"Voltar\" border=\"0\" /></a></center>";
            echo "</body></html>";
           exit;
	       }
		   else
		     {
      		  header("Location: ../escola/mnadmescola.php");
		     }
        }
       else
        {
		  header("Location: ../cre/mnadrem.php");
	    }

		}


else if  (($ntelogin =="5")&& (trim($senha)==trim($user_senha)) && (trim($nte)==trim($nte_bd)) && trim($cpf)==trim($login))
	    {
       if (trim($inep)!='')
         {
           $re = mysql_query("select count(*) as total from escola where inep  = '$inep'");
           $total = mysql_result($re, 0, "total");
           if ($total==0)
            {
         	echo "<html><head><title>Resposta !!!</title></head>";
        	echo "<body background=\"background_mensagens.jpg\" style=\"background-attachment:fixed; background-repeat:no-repeat\">";
        	echo "<br><br><br>";
        	echo "<center><img src=\"faleconosco/atencao.gif\" alt=\"\"><p><font color=\"#ff6600\" face=\"Verdana\" size=\"4\">Usu�rio Informe o INEP da Sua Escola!!!! <b></b></font></center>";
        	echo "<br><br><center><a href=\"../login.php\"><img src=\"faleconosco/button_voltar2_.gif\" alt=\"Voltar\" border=\"0\" /></a></center>";
            echo "</body></html>";
           exit;
	       }
		   else
		     {
      		  header("Location: ../escola/mnadmescola.php");
		     }
        }
       else
        {
		  header("Location: ../cre/mnadrem.php");
	    }

		}

else if  (($ntelogin =="7")&& (trim($senha)==trim($user_senha)) && (trim($nte)==trim($nte_bd)) && trim($cpf)==trim($login))
	    {
       if (trim($inep)!='')
         {
           $re = mysql_query("select count(*) as total from escola where inep  = '$inep'");
           $total = mysql_result($re, 0, "total");
           if ($total==0)
            {
         	echo "<html><head><title>Resposta !!!</title></head>";
        	echo "<body background=\"background_mensagens.jpg\" style=\"background-attachment:fixed; background-repeat:no-repeat\">";
        	echo "<br><br><br>";
        	echo "<center><img src=\"faleconosco/atencao.gif\" alt=\"\"><p><font color=\"#ff6600\" face=\"Verdana\" size=\"4\">Usu�rio Informe o INEP da Sua Escola!!!! <b></b></font></center>";
        	echo "<br><br><center><a href=\"../login.php\"><img src=\"faleconosco/button_voltar2_.gif\" alt=\"Voltar\" border=\"0\" /></a></center>";
            echo "</body></html>";
           exit;
	       }
		   else
		     {
      		  header("Location: ../escola/mnadmescola.php");
		     }
        }
       else
        {
		  header("Location: ../cre/mnadrem.php");
	    }

		}

else if  (($ntelogin =="8")&& (trim($senha)==trim($user_senha)) && (trim($nte)==trim($nte_bd)) && trim($cpf)==trim($login))
	    {
       if (trim($inep)!='')
         {
           $re = mysql_query("select count(*) as total from escola where inep  = '$inep'");
           $total = mysql_result($re, 0, "total");
           if ($total==0)
            {
         	echo "<html><head><title>Resposta !!!</title></head>";
        	echo "<body background=\"background_mensagens.jpg\" style=\"background-attachment:fixed; background-repeat:no-repeat\">";
        	echo "<br><br><br>";
        	echo "<center><img src=\"faleconosco/atencao.gif\" alt=\"\"><p><font color=\"#ff6600\" face=\"Verdana\" size=\"4\">Usu�rio Informe o INEP da Sua Escola!!!! <b></b></font></center>";
        	echo "<br><br><center><a href=\"../login.php\"><img src=\"faleconosco/button_voltar2_.gif\" alt=\"Voltar\" border=\"0\" /></a></center>";
            echo "</body></html>";
           exit;
	       }
		   else
		     {
      		  header("Location: ../escola/mnadmescola.php");
		     }
        }
       else
        {
		  header("Location: ../cre/mnadrem.php");
	    }

		}


else if  (($ntelogin =="10")&& (trim($senha)==trim($user_senha)) && (trim($nte)==trim($nte_bd)) && trim($cpf)==trim($login))
	    {
       if (trim($inep)!='')
         {
           $re = mysql_query("select count(*) as total from escola where inep  = '$inep'");
           $total = mysql_result($re, 0, "total");
           if ($total==0)
            {
         	echo "<html><head><title>Resposta !!!</title></head>";
        	echo "<body background=\"background_mensagens.jpg\" style=\"background-attachment:fixed; background-repeat:no-repeat\">";
        	echo "<br><br><br>";
        	echo "<center><img src=\"faleconosco/atencao.gif\" alt=\"\"><p><font color=\"#ff6600\" face=\"Verdana\" size=\"4\">Usu�rio Informe o INEP da Sua Escola!!!! <b></b></font></center>";
        	echo "<br><br><center><a href=\"../login.php\"><img src=\"faleconosco/button_voltar2_.gif\" alt=\"Voltar\" border=\"0\" /></a></center>";
              echo "</body></html>";
              exit;
	       }
		   else
		     {
      		  header("Location: ../escola/mnadmescola.php");
		     }
        }
       else
        {
		  header("Location: ../cre/mnadrem.php");
	    }

		}
else if  (($ntelogin =="9")&& (trim($senha)==trim($user_senha)) && (trim($nte)==trim($nte_bd)) && trim($cpf)==trim($login))
	    {
       if (trim($inep)!='')
         {
           $re = mysql_query("select count(*) as total from escola where inep  = '$inep'");
           $total = mysql_result($re, 0, "total");
           if ($total==0)
            {
         	echo "<html><head><title>Resposta !!!</title></head>";
        	echo "<body background=\"background_mensagens.jpg\" style=\"background-attachment:fixed; background-repeat:no-repeat\">";
        	echo "<br><br><br>";
        	echo "<center><img src=\"faleconosco/atencao.gif\" alt=\"\"><p><font color=\"#ff6600\" face=\"Verdana\" size=\"4\">Usu�rio Informe o INEP da Sua Escola!!!! <b></b></font></center>";
        	echo "<br><br><center><a href=\"../login.php\"><img src=\"faleconosco/button_voltar2_.gif\" alt=\"Voltar\" border=\"0\" /></a></center>";
             echo "</body></html>";
             exit;
	       }
		   else
		     {
      		  header("Location: ../escola/mnadmescola.php");
		     }
        }
       else
        {
		  header("Location: ../cre/mnadrem.php");
	    }

		}

else
  		{ 
         	echo "<html><head><title>Resposta !!!</title></head>";
        	echo "<body background=\"background_mensagens.jpg\" style=\"background-attachment:fixed; background-repeat:no-repeat\">";
        	echo "<br><br><br>";
        	echo "<center><img src=\"faleconosco/atencao.gif\" alt=\"\"><p><font color=\"#ff6600\" face=\"Verdana\" size=\"4\">Usu�rio Nao Cadastrado Para o Ambiente Selecionado!!!! <b></b></font></center>";
        	echo "<br><br><center><a href=\"login.php\"><img src=\"faleconosco/button_voltar2_.gif\" alt=\"Voltar\" border=\"0\" /></a></center>";
              echo "</body></html>";
              exit;
		}
	}
}
mysql_close();

/**********Tramento de Log*/
// Abre ou cria o arquivo bloco1.txt
// "a" representa que o arquivo � aberto para ser escrito
/*
$datalog=date("d-m-Y-H:i:s");

$fp = fopen("log/logs.txt", "a",0);

// Escreve "exemplo de escrita" no bloco1.txt
$escreve = fwrite($fp, "$login,$inep,$nte,$ntelogin,$datalog\n");

// Fecha o arquivo
fclose($abre);
*/

?>
