<?php
require_once '../../start.php';
$pdo = new Conexao;

$title = 'Matriz curricular ' . $_SESSION['txtano'];

$ensinos = Ensino::getAll();
$modalidades = Modalidade::getAll();
$disciplinas = Disciplina::getAll();

$series = array();
if (isset($_GET['modalidade']) && !empty($_GET['modalidade'])) {
    $sql = "SELECT id, turmas AS descricao FROM serie
            WHERE modalidade = :modalidade;";
    $sth = $pdo->prepare($sql);
    $sth->bindParam(':modalidade', $_GET['modalidade']);
    $series = $sth->execute() ? $sth->fetchAll() : array();
}

$sql = "SELECT g.id_modalidade, m.descricao AS modalidade, g.id_ensino, e.descricao AS ensino, g.id_serie, s.turmas AS serie, COUNT(g.id_disciplina) AS disciplinas
        FROM grade_curricular g
          JOIN serie s ON g.id_serie = s.id
          JOIN modalidadeensino m ON g.id_modalidade = m.id
          JOIN habilitacao h ON g.id_disciplina = h.codigo
          JOIN ensino e ON g.id_ensino = e.id
        WHERE g.inep = :inep AND g.ano = :ano
        GROUP BY g.id_ensino, g.id_modalidade, g.id_serie
        ORDER BY e.descricao, m.descricao, s.turmas";
$sth = $pdo->prepare($sql);
$sth->bindParam(':inep', $_SESSION['escola']['inep']);
$sth->bindParam(':ano', $_SESSION['txtano']);
$agrupamentos = $sth->execute() ? $sth->fetchAll() : null;

if (isset($_GET['ensino']) && isset($_GET['modalidade']) && isset($_GET['serie'])) {
    $sql = "SELECT g.id, g.id_modalidade, g.id_serie, g.id_ensino, h.descricao AS disciplina,g.ano,g.ch,g.ch_noite,g.usuario,g.reprova,g.opcional
            FROM grade_curricular g
              JOIN serie s ON g.id_serie = s.id
              JOIN modalidadeensino m ON g.id_modalidade = m.id
              JOIN habilitacao h ON h.codigo = g.id_disciplina
              JOIN ensino e ON e.id = g.id_ensino
            WHERE g.inep = :inep
              AND g.ano = :ano
              AND g.id_serie = :id_serie
              AND g.id_ensino = :id_ensino
              AND g.id_modalidade = :id_modalidade
            ORDER BY m.descricao, s.turmas, h.impressao";
    $sth = $pdo->prepare($sql);
    $sth->bindParam(':id_serie', $_GET['serie']);
    $sth->bindParam(':id_ensino', $_GET['ensino']);
    $sth->bindParam(':id_modalidade', $_GET['modalidade']);
    $sth->bindParam(':inep', $_SESSION['escola']['inep']);
    $sth->bindParam(':ano', $_SESSION['txtano']);

    $gradeCurricular = $sth->execute() ? $sth->fetchAll() : null;
}

?><!DOCTYPE HTML>
<html>
<head>
    <?php require_once page_head(); ?>
</head>
<body>
<?php require_once page_header(); ?>
<div class="container">
    <form action="matriz_salvar.php" method="POST" class="well well-sm submit-wait">
        <div class="row">
            <div class="col-md-4">
                <div class="form-group">
                    <label for="id_ensino">Ensino</label>
                    <select autofocus name="id_ensino" id="id_ensino" class="form-control chosen" required>
                        <option value=""></option>
                        <?php foreach ($ensinos as $en): ?>
                            <option value="<?php echo $en['id'] ?>" <?php selected(isset($_GET['ensino']) && $_GET['ensino'] == $en['id']) ?>><?php echo $en['descricao'] ?></option>
                        <?php endforeach ?>
                    </select>
                </div>
            </div>

            <div class="col-md-4">
                <div class="form-group">
                    <label for="id_modalidade">Modalidade</label>
                    <select name="id_modalidade" id="id_modalidade" class="form-control chosen" required>
                        <option value=""></option>
                        <?php foreach ($modalidades as $mo): ?>
                            <option value="<?php echo $mo['id'] ?>" <?php selected(isset($_GET['modalidade']) && $_GET['modalidade'] == $mo['id']) ?>><?php echo $mo['descricao'] ?></option>
                        <?php endforeach ?>
                    </select>
                </div>
            </div>

            <div class="col-md-4">
                <div class="form-group">
                    <label for="id_serie">Ano Escolar</label>
                    <select name="id_serie" id="id_serie" class="form-control chosen" required>
                        <option value="">Selecione a modalidade</option>
                        <?php foreach ($series as $se): ?>
                            <option value="<?php echo $se['id'] ?>" <?php selected(isset($_GET['serie']) && $_GET['serie'] == $se['id']) ?>><?php echo $se['descricao'] ?></option>
                        <?php endforeach ?>
                    </select>
                </div>
            </div>
        </div>

        <div class="row">
            <div class="col-md-4">
                <div class="form-group">
                    <label for="id_disciplina">Componente Curricular</label>
                    <select name="id_disciplina" id="id_disciplina" class="form-control chosen" required>
                        <option value=""></option>
                        <?php foreach ($disciplinas as $di): ?>
                            <option value="<?php echo $di['id'] ?>"><?php echo $di['descricao'] ?></option>
                        <?php endforeach ?>
                    </select>
                </div>
            </div>

            <div class="col-md-2">
                <div class="form-group">
                    <label for="carga_horaria">C.H. Diurno</label>
                    <input type="number" name="carga_horaria" class="form-control" placeholder="Diurno" maxlength="3" id="carga_horaria" onKeyPress="return Enum(event)">
                </div>
            </div>

            <div class="col-md-2">
                <div class="form-group">
                    <label for="carga_horaria_noite">C.H. Noturno</label>
                    <input type="number" name="carga_horaria_noite" class="form-control" placeholder="Noturno" <?php disabled($txtano < 2016) ?> maxlength="3" id="carga_horaria_noite" onKeyPress="return Enum(event)">
                </div>
            </div>

            <div class="col-md-2">
                <div class="form-group">
                    <label for="reprova">Reprova?</label>
                    <select id="reprova" name="reprova" class="form-control">
                        <option value="S">SIM</option>
                        <option value="N">N�O</option>
                    </select>
                </div>
            </div>

            <div class="col-md-2">
                <div class="form-group">
                    <label for="opcional">
                        Opcional ?
                        <span title="Disciplina opcional n�o calcula a carga hor�ria para reprovar o aluno por falta." class="text-muted">
									<i class="fa fa-info-circle"></i>
								</span>
                    </label>
                    <select id="opcional" name="opcional" class="form-control">
                        <option value="0">N�O</option>
                        <option value="1">SIM</option>
                    </select>
                </div>
            </div>
        </div>

        <p id="finish">
            <button type="submit" class="btn btn-primary btn-submit-wait">ADICIONAR COMPONENTE</button>
            <a class="btn btn-default pull-right" href="<?php url('adme/escola/matriz.php') ?>">Voltar</a>
        </p>
    </form>

    <hr>

    <div class="table-responsive">
        <table class="table table-striped table-bordered table-condensed table-hover">
            <thead>
            <tr>
                <th>Ensino</th>
                <th>Modalidade</th>
                <th>Ano Escolar</th>
                <th width="10">Componentes</th>
                <th width="10"></th>
            </tr>
            </thead>
            <tbody>
            <?php foreach ($agrupamentos as $agru): ?>
                <tr>
                    <td><?php echo $agru["ensino"]; ?></td>
                    <td><?php echo $agru["modalidade"]; ?></td>
                    <td><?php echo $agru["serie"]; ?></td>
                    <td class="text-center"><?php echo $agru["disciplinas"]; ?></td>
                    <td>
                        <a class="btn btn-xs btn-block btn-primary" href="?ensino=<?php echo $agru['id_ensino'] ?>&modalidade=<?php echo $agru['id_modalidade'] ?>&serie=<?php echo $agru['id_serie'] ?>">EXIBIR</a>
                    </td>
                </tr>
                <?php if (isset($gradeCurricular) && sizeof($gradeCurricular) > 0 && $gradeCurricular[0]['id_ensino'] == $agru['id_ensino'] && $gradeCurricular[0]['id_modalidade'] == $agru['id_modalidade'] && $gradeCurricular[0]['id_serie'] == $agru['id_serie']): ?>
                    <tr class="info">
                        <td></td>
                        <td colspan="3">
                            <div class="table-responsive">
                                <table class="table table-striped table-bordered table-condensed table-hover">
                                    <thead>
                                    <tr>
                                        <th>Componente Curricular</th>
                                        <th width="100" class="text-center" title="Carga Hor�ria Diurno">C.H. Diurno</td>
                                        <th width="100" class="text-center" title="Carga Hor�ria Noturno">C.H. Noturno</td>
                                        <th width="20" class="text-center">Reprova</th>
                                        <th width="20" class="text-center">Opcional</th>
                                        <th width="20">
                                             
                                        </th>
                                    </tr>
                                    </thead>
                                    <tbody>
                                    <?php foreach ($gradeCurricular as $gra): ?>
                                        <tr title="Gravado por Usu�rio <?php echo $gra["usuario"]; ?>">
                                            <td><?php echo $gra["disciplina"]; ?></td>
                                            <td class="text-center"><?php echo empty($gra["ch"]) ? '-' : $gra["ch"]; ?></td>
                                            <td class="text-center"><?php echo empty($gra["ch_noite"]) ? '-' : $gra["ch_noite"]; ?></td>
                                            <td class="text-center text-<?php echo $gra["reprova"]=='S' ? 'success' : 'danger'; ?>">
                                                <?php echo $gra["reprova"]=='S' ? 'SIM' : 'N�O'; ?>
                                            </td>
                                            <td class="text-center text-<?php echo $gra["opcional"]==1 ? 'success' : 'danger'; ?>">
                                                <?php echo $gra["opcional"]==1 ? 'SIM' : 'N�O'; ?>
                                            </td>
                                            <td align="center">
                                                <a href="<?php url("escola/turma/exclui_grade_curricular.php?codigo={$gra["id"]}") ?>" onclick="return confirm('Confirma excluir componente da grade curricular?');" class="btn btn-xs btn-danger">
                                                    EXCLUIR
                                                </a>
                                            </td>
                                        </tr>
                                    <?php endforeach ?>
                                    </tbody>
                                </table>
                            </div>
                        </td>
                    </tr>
                <?php endif ?>
            <?php endforeach ?>
            </tbody>
        </table>
    </div>

    <div class="row">
        <div class="col-md-3 col-md-offset-4">
            <table class="table table-bordered">
                <tr>
                    <th>Total de Matrizes Curriculares</th>
                    <td><?php echo sizeof($agrupamentos) ?></td>
                </tr>
            </table>
        </div>
    </div>

</div>
<?php require_once page_footer(); ?>
<script type="text/javascript">
    $(function () {
        $('#id_modalidade').change(function () {
            var modalidade = $(this).val();
            if (modalidade) {
                $.getJSON(URL_HOST + '/ajax/series_por_modalidade.php', { modalidade: modalidade }, function (j) {
                    var options = '<option value=""></option>';
                    for (var i = 0; i < j.length; i++) {
                        options += '<option value="' + j[i].id + '">' + j[i]['turmas'] + '</option>';
                    }
                    $('#id_serie').html(options).trigger('chosen:updated');
                });
            } else {
                $('#id_serie').html('<option value=""></option>').trigger('chosen:updated');
            }
        });
    });
</script>
</body>
</html>