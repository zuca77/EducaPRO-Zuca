<?php
    $segmentos = [
        'PAI',
        'ALUNO',
        'PROFESSOR',
        'FUNCION�RIO'
    ];

    function allSegmentsLess($less = [])  {
        global $segmentos;

        return array_filter($segmentos, function ($item) use ($less) {
            return !in_array($item, $less);
        });
    }
?>

<div role="tabpanel" class="tab-pane" id="conselho">
    <div class="row">
        <div class="col-md-2">
            <div class="form-group">
                <label for="CNPJ">CNPJ <small class="text-muted">(Apenas n�meros)</small></label>
                <input name="conselho[CNPJ]" type="text" id="CNPJ" class="form-control" MAXLENGTH="14" value= "<?= $conselho['CNPJ']; ?>">
            </div>
        </div>
        <div class="col-md-2">
            <div class="form-group">
                <label for="DTREGISTRO">Data de Registro</label>
                <input type="text" name="conselho[DTREGISTRO]" class="form-control mask-data" id="DTREGISTRO" value="<?= formataData($conselho['DTREGISTRO']); ?>">
            </div>
        </div>
        <div class="col-md-2">
            <div class="form-group">
                <label for="TPELEICAO">Tipo de Elei��o</label>
                <select name="conselho[TPELEICAO]" id="TPELEICAO" class="form-control">
                    <option value=""></option>
                    <?php foreach($tiposEleicao as $te): ?>
                    <option value="<?= $te['id'] ?>" <?= ($te['id']==$conselho["TPELEICAO"]) ? "selected" : '' ?>>
                        <?= $te['descricao']; ?>
                        <?php endforeach ?>
                </select>
            </div>
        </div>
        <div class="col-md-3">
            <div class="form-group">
                <label for="DTINICIO">Data de In�cio de Mandato</label>
                <input type="text" name="conselho[DTINICIO]" id="DTINICIO" class="form-control mask-data" value="<?= formataData($conselho['DTINICIO']); ?>">
            </div>
        </div>
        <div class="col-md-2">
            <div class="form-group">
                <label for="DTFIM">Data de Fim de Mandato</label>
                <input type="text" name="conselho[DTFIM]" id="DTFIM"  class="form-control mask-data" value="<?= formataData($conselho['DTFIM']); ?>" >
            </div>
        </div>
    </div>

    <hr>

    <fieldset class="well well-sm">
        <legend>
            <i class="fa fa-users text-muted"></i>
            Membros da composi��o atual
        </legend>

        <!-- Nav tabs -->
        <ul class="nav nav-tabs" role="tablist">
            <li role="presentation" class="active"><a href="#diretoria-executiva" aria-controls="diretoria-executiva" role="tab" data-toggle="tab">Diretoria Executiva</a></li>
            <li role="presentation"><a href="#articulacao-pedagogica-financeira" aria-controls="articulacao_pedagogica_financeira" role="tab" data-toggle="tab">Comiss�o de Articula��o Pedag�gica e Financeira</a></li>
            <li role="presentation"><a href="#conselho-fiscal" aria-controls="conselho-fiscal" role="tab" data-toggle="tab">Conselho Fiscal</a></li>
        </ul>

        <br>

        <div class="tab-content">
<!--            Diretoria executiva-->
            <div role="tabpanel" class="tab-pane active" id="diretoria-executiva">
<!--                Presidente e vice -->
                <div class="row">
                    <div class="col-md-6">
                        <div class="form-group">
                            <label for="presidente">Presidente</label>
                            <input name="conselho[de_presidente]" type="text" id="presidente" class="form-control text-uppercase" MAXLENGTH="60" value= "<?= $conselho['de_presidente']; ?>">
                        </div>
                    </div>
                    <div class="col-md-6">
                        <div class="form-group">
                            <label for="de_vice_presidente">Vice Presidente</label>
                            <input name="conselho[de_vice_presidente]" type="text" id="de_vice_presidente" class="form-control text-uppercase" MAXLENGTH="60" value= "<?= $conselho['de_vice_presidente']; ?>">
                        </div>
                    </div>
                </div>

<!--                Secret�rio e suplente -->
                <div class="row">
                    <div class="col-md-2">
                        <div class="form-group">
                            <label for="de_secretario_segmento">Segmento</label>
                            <select name="conselho[de_secretario_segmento]" id="de_secretario_segmento" class="form-control">
                                <option value="">Selecione</option>

                                <?php foreach ($segmentos as $segmento): ?>
                                    <option value="<?= $segmento ?>" <?= ($conselho['de_secretario_segmento'] == $segmento) ?  'selected' : '' ?>>
                                        <?= $segmento ?>
                                    </option>
                                <?php endforeach; ?>
                            </select>
                        </div>
                    </div>
                    <div class="col-md-4">
                        <div class="form-group">
                            <label for="de_secretario">Secret�rio</label>
                            <input name="conselho[de_secretario]" type="text" id="de_secretario" class="form-control text-uppercase" MAXLENGTH="60" value= "<?= $conselho['de_secretario']; ?>">
                        </div>
                    </div>
                    <div class="col-md-6">
                        <div class="form-group">
                            <label for="de_secretario_suplente">Suplente</label>
                            <input name="conselho[de_secretario_suplente]" type="text" id="de_secretario_suplente" class="form-control text-uppercase" MAXLENGTH="60" value= "<?= $conselho['de_secretario_suplente']; ?>">
                        </div>
                    </div>
                </div>

<!--                Tesoureiro e suplente -->
                <div class="row">
                    <div class="col-md-2">
                        <div class="form-group">
                            <label for="de_tesoureiro_segmento">Segmento</label>
                            <select name="conselho[de_tesoureiro_segmento]" id="de_tesoureiro_segmento" class="form-control">
                                <option value="">Segmento</option>

                                <?php foreach ($segmentos as $segmento): ?>
                                    <option value="<?= $segmento ?>" <?= ($conselho['de_tesoureiro_segmento'] == $segmento) ?  'selected' : '' ?>>
                                        <?= $segmento ?>
                                    </option>
                                <?php endforeach; ?>
                            </select>
                        </div>
                    </div>
                    <div class="col-md-4">
                        <div class="form-group">
                            <label for="de_tesoureiro">Tesoureiro</label>
                            <input name="conselho[de_tesoureiro]" type="text" id="de_tesoureiro" class="form-control text-uppercase" MAXLENGTH="40" value= "<?= $conselho['de_tesoureiro']; ?>">
                        </div>
                    </div>
                    <div class="col-md-6">
                        <div class="form-group">
                            <label for="de_tesoureiro_suplente">Suplente</label>
                            <input name="conselho[de_tesoureiro_suplente]" type="text" id="de_tesoureiro_suplente" class="form-control text-uppercase" MAXLENGTH="40" value= "<?= $conselho['de_tesoureiro_suplente']; ?>">
                        </div>
                    </div>
                </div>
            </div>

<!--            Articula��o pedag�gica e financeira -->
            <div role="tabpanel" class="tab-pane" id="articulacao-pedagogica-financeira">

<!--                Secret�rio e suplente -->
                <div class="row">
                    <div class="col-md-2">
                        <div class="form-group">
                            <label for="apf_representante_1_segmento">Segmento</label>
                            <select name="conselho[apf_representante_1_segmento]" id="apf_representante_1_segmento" class="form-control">
                                <option value="">Selecione</option>
                                <?php
                                    foreach (allSegmentsLess(['PAI', 'ALUNO']) as $segmento): ?>
                                    <option value="<?= $segmento ?>" <?= ($conselho['apf_representante_1_segmento'] == $segmento) ?  'selected' : '' ?>>
                                        <?= $segmento ?>
                                    </option>
                                <?php endforeach; ?>
                            </select>
                        </div>
                    </div>
                    <div class="col-md-4">
                        <div class="form-group">
                            <label for="apf_representante_1">Representante 1</label>
                            <input name="conselho[apf_representante_1]" type="text" id="apf_representante_1" class="form-control text-uppercase" MAXLENGTH="60" value= "<?= $conselho['apf_representante_1']; ?>">
                        </div>
                    </div>
                    <div class="col-md-6">
                        <div class="form-group">
                            <label for="de_representante_1_suplente">Suplente</label>
                            <input name="conselho[apf_representante_1_suplente]" type="text" id="apf_representante_1_suplente" class="form-control text-uppercase" MAXLENGTH="60" value= "<?= $conselho['apf_representante_1_suplente']; ?>">
                        </div>
                    </div>
                </div>

<!--                Secret�rio e suplente -->
                <div class="row">
                    <div class="col-md-2">
                        <div class="form-group">
                            <label for="apf_representante_2_segmento">Segmento</label>
                            <select name="conselho[apf_representante_2_segmento]" id="apf_representante_2_segmento" class="form-control">
                                <option value="">Selecione</option>
                                <?php
                                foreach (allSegmentsLess(['PROFESSOR', 'FUNCION�RIO']) as $segmento): ?>
                                    <option value="<?= $segmento ?>" <?= ($conselho['apf_representante_2_segmento'] == $segmento) ?  'selected' : '' ?>>
                                        <?= $segmento ?>
                                    </option>
                                <?php endforeach; ?>
                            </select>
                        </div>
                    </div>
                    <div class="col-md-4">
                        <div class="form-group">
                            <label for="apf_representante_2">Representante 2</label>
                            <input name="conselho[apf_representante_2]" type="text" id="apf_representante_2" class="form-control text-uppercase" MAXLENGTH="60" value= "<?= $conselho['apf_representante_2']; ?>">
                        </div>
                    </div>
                    <div class="col-md-6">
                        <div class="form-group">
                            <label for="de_representante_2_suplente">Suplente</label>
                            <input name="conselho[apf_representante_2_suplente]" type="text" id="apf_representante_2_suplente" class="form-control text-uppercase" MAXLENGTH="60" value= "<?= $conselho['apf_representante_2_suplente']; ?>">
                        </div>
                    </div>
                </div>

                <div class="row">
                    <div class="col-md-2">
                        <div class="form-group">
                            <label for="apf_representante_3_segmento">Segmento</label>
                            <select name="conselho[apf_representante_3_segmento]" id="apf_representante_3_segmento" class="form-control">
                                <option value="">Selecione</option>
                                <?php
                                foreach (allSegmentsLess(['PROFESSOR', 'FUNCION�RIO']) as $segmento): ?>
                                    <option value="<?= $segmento ?>" <?= ($conselho['apf_representante_3_segmento'] == $segmento) ?  'selected' : '' ?>>
                                        <?= $segmento ?>
                                    </option>
                                <?php endforeach; ?>
                            </select>
                        </div>
                    </div>
                    <div class="col-md-4">
                        <div class="form-group">
                            <label for="apf_representante_3">Representante 3</label>
                            <input name="conselho[apf_representante_3]" type="text" id="apf_representante_3" class="form-control text-uppercase" MAXLENGTH="60" value= "<?= $conselho['apf_representante_3']; ?>">
                        </div>
                    </div>
                    <div class="col-md-6">
                        <div class="form-group">
                            <label for="de_representante_3_suplente">Suplente</label>
                            <input name="conselho[apf_representante_3_suplente]" type="text" id="apf_representante_3_suplente" class="form-control text-uppercase" MAXLENGTH="60" value= "<?= $conselho['apf_representante_3_suplente']; ?>">
                        </div>
                    </div>
                </div>
            </div>

<!--            Conselho fiscal -->
            <div role="tabpanel" class="tab-pane" id="conselho-fiscal">

                <!--                Secret�rio e suplente -->
                <div class="row">
                    <div class="col-md-2">
                        <div class="form-group">
                            <label for="cf_representante_1_segmento">Segmento</label>
                            <select name="conselho[cf_representante_1_segmento]" id="cf_representante_1_segmento" class="form-control">
                                <option value="">Selecione</option>
                                <?php
                                foreach (allSegmentsLess(['PAI', 'ALUNO']) as $segmento): ?>
                                    <option value="<?= $segmento ?>" <?= ($conselho['cf_representante_1_segmento'] == $segmento) ?  'selected' : '' ?>>
                                        <?= $segmento ?>
                                    </option>
                                <?php endforeach; ?>
                            </select>
                        </div>
                    </div>
                    <div class="col-md-4">
                        <div class="form-group">
                            <label for="cf_representante_1">Representante 1</label>
                            <input name="conselho[cf_representante_1]" type="text" id="cf_representante_1" class="form-control text-uppercase" MAXLENGTH="60" value= "<?= $conselho['cf_representante_1']; ?>">
                        </div>
                    </div>
                    <div class="col-md-6">
                        <div class="form-group">
                            <label for="de_representante_1_suplente">Suplente</label>
                            <input name="conselho[cf_representante_1_suplente]" type="text" id="cf_representante_1_suplente" class="form-control text-uppercase" MAXLENGTH="60" value= "<?= $conselho['cf_representante_1_suplente']; ?>">
                        </div>
                    </div>
                </div>

                <!--                Secret�rio e suplente -->
                <div class="row">
                    <div class="col-md-2">
                        <div class="form-group">
                            <label for="cf_representante_2_segmento">Segmento</label>
                            <select name="conselho[cf_representante_2_segmento]" id="cf_representante_2_segmento" class="form-control">
                                <option value="">Selecione</option>
                                <?php
                                foreach (allSegmentsLess(['PAI', 'ALUNO']) as $segmento): ?>
                                    <option value="<?= $segmento ?>" <?= ($conselho['cf_representante_2_segmento'] == $segmento) ?  'selected' : '' ?>>
                                        <?= $segmento ?>
                                    </option>
                                <?php endforeach; ?>
                            </select>
                        </div>
                    </div>
                    <div class="col-md-4">
                        <div class="form-group">
                            <label for="cf_representante_2">Representante 2</label>
                            <input name="conselho[cf_representante_2]" type="text" id="cf_representante_2" class="form-control text-uppercase" MAXLENGTH="60" value= "<?= $conselho['cf_representante_2']; ?>">
                        </div>
                    </div>
                    <div class="col-md-6">
                        <div class="form-group">
                            <label for="de_representante_2_suplente">Suplente</label>
                            <input name="conselho[cf_representante_2_suplente]" type="text" id="cf_representante_2_suplente" class="form-control text-uppercase" MAXLENGTH="60" value= "<?= $conselho['cf_representante_2_suplente']; ?>">
                        </div>
                    </div>
                </div>

                <div class="row">
                    <div class="col-md-2">
                        <div class="form-group">
                            <label for="cf_representante_3_segmento">Segmento</label>
                            <select name="conselho[cf_representante_3_segmento]" id="cf_representante_3_segmento" class="form-control">
                                <option value="">Selecione</option>
                                <?php
                                foreach (allSegmentsLess(['PROFESSOR', 'FUNCION�RIO']) as $segmento): ?>
                                    <option value="<?= $segmento ?>" <?= ($conselho['cf_representante_3_segmento'] == $segmento) ?  'selected' : '' ?>>
                                        <?= $segmento ?>
                                    </option>
                                <?php endforeach; ?>
                            </select>
                        </div>
                    </div>
                    <div class="col-md-4">
                        <div class="form-group">
                            <label for="cf_representante_3">Representante 3</label>
                            <input name="conselho[cf_representante_3]" type="text" id="cf_representante_3" class="form-control text-uppercase" MAXLENGTH="60" value= "<?= $conselho['cf_representante_3']; ?>">
                        </div>
                    </div>
                    <div class="col-md-6">
                        <div class="form-group">
                            <label for="de_representante_3_suplente">Suplente</label>
                            <input name="conselho[cf_representante_3_suplente]" type="text" id="cf_representante_3_suplente" class="form-control text-uppercase" MAXLENGTH="60" value= "<?= $conselho['cf_representante_3_suplente']; ?>">
                        </div>
                    </div>
                </div>
            </div>
        </div>

    </fieldset>
</div>