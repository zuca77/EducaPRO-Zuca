<?php
require_once '../../start.php';
$pdo = new Conexao;

if($_SERVER["REQUEST_METHOD"] != "POST") {
    redirect('adme/escola/index.php');
}

$data = date('Y.m.d');
$_POST['txtdtemissao'] = converteData($_POST['txtdtemissao']);
$_POST['txtdtvalidade'] = converteData($_POST['txtdtvalidade']);

$sql = "UPDATE escola
        SET descricao=:descricao,tipo=:tipo, endereco=:endereco, bairro=:bairro,cep=:cep,fone=:fone,municipio=:cod_municipio,numero=:nr,nprofessores=:nprofessores,secretario=:secretario,
        nalunos=:nalunos,diretor=:diretor,vicediretor=:vicediretor,nemergencial=:nemergencial,nadministrativo=:nadministrativo,portaria=:portaria,regularizada=:regularizada,email=:email,
        situacao=:situacao,dtvalidade=:dtvalidade,modalidade1=:modalidade1,modalidade2=:modalidade2,modalidade3=:modalidade3,modalidade4=:modalidade4,modalidade5=:modalidade5,
        modalidade6=:modalidade6,modalidade7=:modalidade7,qtdasala=:txtqdtasala,sleitura=:selectleitura,lie=:selectlie, quadra=:selectquadra,qcoberta=:selectcoberta,pde=:selectpde,
        ideb=:txtideb,enem=:txtenem,provinha_brasil_portugues=:provinha_brasil_portugues,provinha_brasil_matematica=:provinha_brasil_matematica,prova_brasil_portugues=:prova_brasil_portugues,prova_brasil_matematica=:prova_brasil_matematica,
        dtportaria=:dtportaria, usuario=:usuario,latitude=:latitude,longitude=:longitude,dtaltera=:data
        WHERE inep=:inep";
$sth = $pdo->prepare($sql);
$sth->bindParam(':email', $_POST['email']);
$sth->bindParam(':descricao', $_POST['descricao']);
$sth->bindParam(':tipo', $_POST['tipo']);
$sth->bindParam(':endereco', $_POST['endereco']);
$sth->bindParam(':bairro', $_POST['bairro']);
$sth->bindParam(':cep', $_POST['txtcep']);
$sth->bindParam(':fone', $_POST['fone']);
$sth->bindParam(':cod_municipio', $_POST['cod_municipio']);
$sth->bindParam(':nr', $_POST['nr']);
$sth->bindParam(':nprofessores', $_POST['nprofessores']);
$sth->bindParam(':nalunos', $_POST['nalunos']);
$sth->bindParam(':diretor', $_POST['diretor']);
$sth->bindParam(':vicediretor', $_POST['vicediretor']);
$sth->bindParam(':secretario', $_POST['secretario']);
$sth->bindParam(':nemergencial', $_POST['nemergencial']);
$sth->bindParam(':nadministrativo', $_POST['nadm']);
$sth->bindParam(':portaria', $_POST['txtportaria']);
$sth->bindParam(':regularizada', $_POST['selectregularizacao']);
$sth->bindParam(':situacao', $_POST['selectsituacao']);
$sth->bindParam(':dtportaria', $_POST['txtdtemissao']);
$sth->bindParam(':dtvalidade', $_POST['txtdtvalidade']);
$sth->bindParam(':modalidade1', $_POST['modalidade1']);
$sth->bindParam(':modalidade2', $_POST['modalidade2']);
$sth->bindParam(':modalidade3', $_POST['modalidade3']);
$sth->bindParam(':modalidade4', $_POST['modalidade4']);
$sth->bindParam(':modalidade5', $_POST['modalidade5']);
$sth->bindParam(':modalidade6', $_POST['modalidade6']);
$sth->bindParam(':modalidade7', $_POST['modalidade7']);
$sth->bindParam(':txtqdtasala', $_POST['txtqdtasala']);
$sth->bindParam(':selectleitura', $_POST['selectleitura']);
$sth->bindParam(':selectlie', $_POST['selectlie']);
$sth->bindParam(':selectquadra', $_POST['selectquadra']);
$sth->bindParam(':selectcoberta', $_POST['selectcoberta']);
$sth->bindParam(':selectpde', $_POST['selectpde']);
$sth->bindParam(':txtideb', $_POST['txtideb']);
$sth->bindParam(':txtenem', $_POST['txtenem']);
$sth->bindParam(':provinha_brasil_portugues', $_POST['provinha_brasil_portugues']);
$sth->bindParam(':provinha_brasil_matematica', $_POST['provinha_brasil_matematica']);
$sth->bindParam(':prova_brasil_portugues', $_POST['prova_brasil_portugues']);
$sth->bindParam(':prova_brasil_matematica', $_POST['prova_brasil_matematica']);
$sth->bindParam(':latitude', $_POST['latitude']);
$sth->bindParam(':longitude', $_POST['longitude']);
$sth->bindParam(':usuario', $_SESSION['usuario']['cpf']);
$sth->bindParam(':inep', $_SESSION['escola']['inep']);
$sth->bindParam(':data', $data);

try {
    if (!$sth->execute()) {
        Notification::error('N�o foi poss�vel atualizar dados de escola.');
        redirectBack();
    }

    $sql = "SELECT COUNT(inep) FROM transicao
            WHERE inep = :inep;";
    $sth = $pdo->prepare($sql);
    $sth->bindParam(':inep', $_SESSION['escola']['inep']);
    $temTransicao = $sth->execute() ? $sth->fetchColumn() :  0;

    if ($temTransicao) {
        $sql = "UPDATE transicao
                SET regularizacao=:selectregularizacao,portaria=:txtportaria,dtemissao=:dtemissao,patrimonio=:selectpatrimonio,spatrimonio=:selectstatuspatri,penai=:penai,
                acervo=:selectacervo,qtdasala=:txtqdtasala,situacao=:situacao,dtvalidade=:txtdtvalidade,modalidade1=:modalidade1,modalidade2=:modalidade2,
                modalidade3=:modalidade3,modalidade4= :modalidade4,modalidade5=:modalidade5,modalidade6=:modalidade6,modalidade7=:modalidade7,ano=:ano,
                sleitura=:selectleitura,lie=:selectlie,quadra=:selectquadra,squadra=:selectstatusqd,qcoberta=:selectcoberta,pde=:selectpde,ideb=:txtideb,enem=:txtenem,prova_brasil_portugues=:prova_brasil_portugues,prova_brasil_matematica=:prova_brasil_matematica,
                provinha_brasil_portugues=:provinha_brasil_portugues, provinha_brasil_matematica=:provinha_brasil_matematica,programa=:selectprogramas,qtdaprograma=:txtqdtaprograma,fonter=:selectfonte,cantina=:selectcantina,mais=:selectmais,profipes=:profipes,
                fiscalmuni=:fiscalmuni,fiscalestado=:fiscalestado,fiscalfederal=:fiscalfedera,fiscalfgts=:fiscalfgts,contabil=:contabil,inss=:inss,proafi=:proafi,usuario=:login,refeitorio=:refeitorio,auditorio=:auditorio,sala_professor=:sala_professor,infovia=:infovia, 
                internet_seduc=:internet_seduc, internet_mec=:internet_mec, internet_propria=:internet_propria,lab_ciencias=:lab_ciencias
                WHERE inep=:inep";
    } else {
        $sql = "INSERT INTO transicao (inep,regularizacao,portaria,dtemissao,patrimonio,spatrimonio,acervo,qtdasala,sleitura,lie,quadra,squadra,qcoberta,pde,programa,qtdaprograma,
                ideb,enem,provinha_brasil_portugues, provinha_brasil_matematica, prova_brasil_portugues, prova_brasil_matematica, fonter,cantina,mais,fiscalmuni,fiscalestado,fiscalfederal,fiscalfgts,contabil,inss,proafi,penai,profipes,modalidade1,modalidade2,
                modalidade3,modalidade4,modalidade5,situacao,dtvalidade,modalidade6,modalidade7,usuario,ano,refeitorio,auditorio,sala_professor,infovia,internet_seduc,internet_seduc,internet_propria,lab_ciencias)
                VALUES (:inep,:selectregularizacao,:txtportaria,:dtemissao,:selectpatrimonio,:selectstatuspatri,:selectacervo,:txtqdtasala,:selectleitura,:selectlie,:selectquadra,
                :selectstatusqd,:selectcoberta,:selectpde,:selectprogramas,:txtqdtaprograma,:txtideb,:txtenem,:provinha_brasil_portugues,:provinha_brasil_matematica,:prova_brasil_portugues,:prova_brasil_matematica,:selectfonte,:selectcantina,:selectmais,
                :fiscalmuni,:fiscalestado,:fiscalfedera,:fiscalfgts,:contabil,:inss,:proafi,:penai,:profipes,:modalidade1,:modalidade2,:modalidade3,:modalidade4,:modalidade5,
                :situacao,:txtdtvalidade,:modalidade6,:modalidade7,:login,:ano,:refeitorio,:auditorio,:sala_professor,:infovia,:internet_seduc,:internet_mec,:internet_propria, :lab_ciencias)";
    }

    $sth = $pdo->prepare($sql);
    $sth->bindParam(':selectregularizacao', $_POST['selectregularizacao']);
    $sth->bindParam(':txtportaria', $_POST['txtportaria']);
    $sth->bindParam(':dtemissao', $_POST['txtdtemissao']);
    $sth->bindParam(':selectpatrimonio', $_POST['selectpatrimonio']);
    $sth->bindParam(':selectstatuspatri', $_POST['selectstatuspatri']);
    $sth->bindParam(':penai', $_POST['penai']);
    $sth->bindParam(':selectacervo', $_POST['selectacervo']);
    $sth->bindParam(':situacao', $_POST['situacao']);
    $sth->bindParam(':txtdtvalidade', $_POST['txtdtvalidade']);
    $sth->bindParam(':modalidade1', $_POST['modalidade1']);
    $sth->bindParam(':modalidade2', $_POST['modalidade2']);
    $sth->bindParam(':modalidade3', $_POST['modalidade3']);
    $sth->bindParam(':modalidade4', $_POST['modalidade4']);
    $sth->bindParam(':modalidade5', $_POST['modalidade5']);
    $sth->bindParam(':modalidade6', $_POST['modalidade6']);
    $sth->bindParam(':modalidade7', $_POST['modalidade7']);
    $sth->bindParam(':txtqdtasala', $_POST['txtqdtasala']);
    $sth->bindParam(':selectleitura', $_POST['selectleitura']);
    $sth->bindParam(':selectlie', $_POST['selectlie']);
    $sth->bindParam(':selectquadra', $_POST['selectquadra']);
    $sth->bindParam(':selectstatusqd', $_POST['selectstatusqd']);
    $sth->bindParam(':selectcoberta', $_POST['selectcoberta']);
    $sth->bindParam(':selectpde', $_POST['selectpde']);
    $sth->bindParam(':txtideb', $_POST['txtideb']);
    $sth->bindParam(':txtenem', $_POST['txtenem']);
    $sth->bindParam(':provinha_brasil_matematica', $_POST['provinha_brasil_matematica']);
    $sth->bindParam(':provinha_brasil_portugues', $_POST['provinha_brasil_portugues']);
    $sth->bindParam(':prova_brasil_portugues', $_POST['prova_brasil_portugues']);
    $sth->bindParam(':prova_brasil_matematica', $_POST['prova_brasil_matematica']);
    $sth->bindParam(':selectprogramas', $_POST['selectprogramas']);
    $sth->bindParam(':txtqdtaprograma', $_POST['txtqdtaprograma']);
    $sth->bindParam(':selectfonte', $_POST['selectfonte']);
    $sth->bindParam(':selectcantina', $_POST['selectcantina']);
    $sth->bindParam(':selectmais', $_POST['selectmais']);
    $sth->bindParam(':profipes', $_POST['profipes']);
    $sth->bindParam(':fiscalmuni', $_POST['fiscalmuni']);
    $sth->bindParam(':fiscalestado', $_POST['fiscalestado']);
    $sth->bindParam(':fiscalfedera', $_POST['fiscalfedera']);
    $sth->bindParam(':fiscalfgts', $_POST['fiscalfgts']);
    $sth->bindParam(':contabil', $_POST['contabil']);
    $sth->bindParam(':inss', $_POST['inss']);
    $sth->bindParam(':proafi', $_POST['proafi']);
    $sth->bindParam(':login', $_SESSION['usuario']['cpf']);
    $sth->bindParam(':inep', $_SESSION['escola']['inep']);
    $sth->bindParam(':ano', $_SESSION['txtano']);
    $sth->bindParam(':refeitorio', $_POST['refeitorio']);
    $sth->bindParam(':auditorio', $_POST['auditorio']);
    $sth->bindParam(':sala_professor', $_POST['sala_professor']);
    $sth->bindParam(':infovia', $_POST['infovia']);
    $sth->bindParam(':internet_seduc', $_POST['internet_seduc']);
    $sth->bindParam(':internet_mec', $_POST['internet_mec']);
    $sth->bindParam(':internet_propria', $_POST['internet_propria']);
    $sth->bindParam(':lab_ciencias', $_POST['lab_ciencias']);

    if (!$sth->execute()) {
        Notification::error('N�o foi poss�vel salvar dados de transi��o.');
    }

    $_POST['conselho']['DTREGISTRO'] = converteData($_POST['conselho']['DTREGISTRO']);
    $_POST['conselho']['DTINICIO'] = converteData($_POST['conselho']['DTINICIO']);
    $_POST['conselho']['DTFIM'] = converteData($_POST['conselho']['DTFIM']);

    $sql = "SELECT COUNT(inep) FROM conselhoe
          WHERE inep = :inep;";
    $sth = $pdo->prepare($sql);
    $sth->bindParam(':inep', $inep);
    $temConselho = $sth->execute() ? $sth->fetchColumn() : 0;

    $dadosConselho = $_POST['conselho'];

    if ($temConselho) {
        $sql = "UPDATE conselhoe SET";

        foreach ($dadosConselho as $campo => $valor) {
            $sql .= " $campo=:{$campo}, ";
        }

        $sql = rtrim($sql, ", ");

        $sql .= " WHERE inep=:inep;";
    } else {
        $sql = sprintf(
            'INSERT INTO conselhoe (%s %s) VALUES (%s %s)',
            implode(', ', array_keys($dadosConselho)), ', inep',
            ':' . implode(', :', array_keys($dadosConselho)), ', :inep'
        );
    }

    $query = $pdo->prepare($sql);

    $bind = array();

    foreach ($dadosConselho as $key => $value) {
        $bind[":{$key}"] = $value;
    }

    $bind[":inep"] = $_SESSION['escola']['inep'];

    if (!$query->execute($bind)) {
        Notification::error('N�o foi poss�vel salvar dados de conselho.');
        redirectBack();
    }

    Notification::success('Dados de escola alterados com sucesso.');

} catch (Exception $e) {
    Notification::ex($e);
}

redirectBack();