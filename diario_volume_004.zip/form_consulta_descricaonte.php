<?
session_start();
if (isset($_SESSION["login_usuario"]))
  {
     $login =  $_SESSION["login_usuario"];
     $nte   =  $_SESSION["nivel_usuario"];
     include ("funcoes.php");
     echo  saudacoes()."   ". "$login" ."  -  ". $nte."  ".dataextenso();
  }
 else
  {
     		 header("Location: login.php");
  }  	 
?>

<script language="javascript" src="generic.js"></script>  
<html>
<title>NTE-Porto Velho</title>
 <head> 
  <link rel="stylesheet" href="estilos.css" type="text/css">
  <script language="javascript" src="generic.js"></script>	
</head>
<body>
<center>
<div id="geral">
  <div id="topo">
    <img src= "imagem/cabecalho.jpg"/>
  </div>

<form name ="formdiagnostico" action="altera_escola_diagnostico.php" method="post" >

<div id="corpodiagnostico" class="fontecorpo">

<table border="0">
<br>
<?


$id = $_GET['codigo'];
$sql = "select * from escola where codigo = $id";
$resposta = mysql_query( $sql );
while ( $linha = mysql_fetch_array( $resposta )) 
   {
?>
   <tr>
    <td height="30"></td>
   </tr>
<tr><td>C�digo</td><td><input readonly="true"  name="codigo"  type="text" value="<?echo $id?>"</td></tr>
<tr><td>INEP </td><td><input  name="inep"   readonly="true" size="10" maxlength="10" type="text" value="<?echo $linha["INEP"];?>" onKeyPress="return Enum(event)"></td> </tr>
<tr><td>Descri��o</td><td><input  name="descricao" size="50"  readonly="true" type="text" value="<?echo $linha["DESCRICAO"];?>" onBlur=   "maiusculalteracadescola()"></td></tr>

	<tr> 
     <td>Endere�o</td>
	 <td>
 <input name="endereco" type="text" id="endereco" size="50" MAXLENGTH="40"   readonly="true" value="<?echo $linha["ENDERECO"];?>"    onBlur=   "maiusculalteracadescola()"> </td></tr>
      </td>
	</tr>

	<tr> 
     <td>Bairro</td><td>
       <input name="bairro" type="text" id="bairro" size="25"  readonly="true" MAXLENGTH="25" value="<?echo $linha["BAIRRO"];?>" onBlur=   "maiusculalteracadescola()">
	  N
	   <input name="nr" type="text" id="nr" size="10"  readonly="true" MAXLENGTH="4" value="<?echo $linha["NUMERO"];?>" onKeyPress="return Enum(event)" >
	   </td>	   
	   </tr>
<?
$codmuni=$linha["MUNICIPIO"];
$sqlconulta        = "select codigo,descricao from municipio where codigo = $codmuni";
$respconsulta      = mysql_query( $sqlconulta );
while ( $dado = mysql_fetch_array( $respconsulta )) 
{
 $descricao = $dado["descricao"];
 $codigo    = $dado["codigo"];
}
?>

<tr><td>Munic�pio</td><td>
 <input  name="municodigo" size="8" type="text" readonly="true" value="<?echo "$codigo";?>">
 <input  name="municipio1" size="30" type="text" readonly="true" value="<?echo "$descricao";?>"></td></tr>
 
<tr><td>Zona</td><td>
 <input  name="zona" size="15" type="text" readonly="true" maxlength="15" value="<?echo $linha["TIPO"];?>"></td></tr>
 
   <tr> 
     <td>CEP</td><td>
   	   <input name="cep" type="text" id="cep" size="8" MAXLENGTH="8"  readonly="true" value="<?echo $linha["CEP"];?>" onKeyPress="return Enum(event)">
	  </td>
	 </tr>

	<tr> 
     <td>Fone</td><td>
      <input name="fone" type="text" id="fone" size="30" MAXLENGTH="20"   value="<?echo $linha["FONE"];?>" >
      </td>
	</tr>


<tr><td>Site-Blog</td><td><input  name="siteblog" size="60" maxlength="60"  type="text" onBlur=   "maiusculadiagnostico()"></td></tr>

                    <tr>
                      <td><b>Mod Ensino Regular</b></td>
					  <td>
						
                             Fundamental
				 	       <input name="merf" type="checkbox" id="merf" value="1" />
                            M�dio
   					         <input name="merm" type="checkbox" id="merm" value="1"/>
					   </td>
					 </td>
	   			</tr>	


                    <tr>
                      <td><b>Mod Ensino EJA</b></td>
					  <td>
						
                             Fundamental
				 	       <input name="meef" type="checkbox" id="meef" value="1" />
                            M�dio
   					         <input name="meem" type="checkbox" id="meem" value="1"/>					   </td>
					 </td>
	   			</tr>	



	<tr> 
     <td>N� Alunos</td><td>
         &nbsp <input name="nalunos" type="text" id="nalunos" size="4" MAXLENGTH="4"   value="<?echo $linha["NALUNOS"];?>" onKeyPress="return Enum(event)">
		 
	  &nbsp N� Docentes  <input name="ndocentes" type="text" id="ndocentes" size="4" MAXLENGTH="4" value = "0"  onKeyPress="return Enum(event)">
       &nbsp N� Salas   <input name="nsala" type="text" id="nsala" size="4" MAXLENGTH="4" value = "0" onKeyPress="return Enum(event)">
      </td>
</tr>

	<tr> 
     <td>N� Turmas </td><td>
          Manh�&nbsp <input name="ntmanha" type="text" id="ntmanha" size="4" MAXLENGTH="4"  value = "0" onKeyPress="return Enum(event)">
	  &nbsp Tarde <input name="nttarde" type="text" id="nttarde" size="4" MAXLENGTH="4"    value = "0"  onKeyPress="return Enum(event)">
       &nbsp Noite   <input name="ntnoite" type="text" id="ntnoite" size="4" MAXLENGTH="4" value = "0"  onKeyPress="return Enum(event)">
      </td>
</tr>

	<tr> 
     <td>N� LIE's </td><td>
          <input name="nlies" type="text" id="nlies" size="4" MAXLENGTH="4"  value = "0"  onKeyPress="return Enum(event)">
	  &nbsp;&nbsp N� Telessala <input name="ntelessala" type="text" id="ntelessala" size="4" MAXLENGTH="4"  value = "0"   onKeyPress="return Enum(event)">
            </td>
</tr>
<tr><td>Email Escola</td><td><input  name="emailescola"  id="emailescola" size="60" maxlength="60"   type="text"  onBlur=   "maiusculadiagnostico()"></td></tr>


<tr><td>Diretor(a)</td><td><input  name="nomediretor" id="nomediretor" size="40"  maxlength="40" type="text"  onBlur=   "maiusculadiagnostico()">
Fone <input name="fonediretor" type="text" id="fonediretor" size="15" MAXLENGTH="15"   value="<?echo $linha["FONE"];?>" >

</td></tr>
	
<tr><td>Vice Diretor(a)</td><td><input  name="vicediretor" id="vicediretor" size="40"  maxlength="40" type="text"  onBlur=   "maiusculadiagnostico()">
Fone <input name="fonevice" type="text" id="fonevice" size="15" MAXLENGTH="15">
</td></tr>




               <tr>
                    <td><b>Coordenador(a) LIES</b></td>
					  <td>
                           <input  name="liescoord1"  id="liescoord1" size="50" maxlength="40"   type="text" onBlur=   "maiusculadiagnostico()"> 
						         M<input name="liescoord1m" id="liescoord1m" type="checkbox" id="editar" value="1" />
                 			     T<input name="liescoord1t" id="liescoord1t" type="checkbox" id="editar" value="1" />
                 			     N<input name="liescoord1n" id="liescoord1n" type="checkbox" id="editar" value="1" /><br> 								 
                           <input  name="liescoord2"  id="liescoord2" size="50" maxlength="40"    type="text" onBlur=   "maiusculadiagnostico()">     
						         M<input name="liescoord2m"  id="liescoord2m" type="checkbox" id="editar" value="1" />
                 			     T<input name="liescoord2t" id="liescoord2t" type="checkbox" id="editar" value="1" />
                 			     N<input name="liescoord2n"  id="liescoord2n" type="checkbox" id="editar" value="1" /><br> 								 
                           <input  name="liescoord3" id="liescoord3" size="50" maxlength="40"   type="text"  onBlur=   "maiusculadiagnostico()">     
						         M<input name="liescoord3m"  id="liescoord3m" type="checkbox" id="editar" value="1" />
                 			     T<input name="liescoord3t"  id="liescoord3t" type="checkbox" id="editar" value="1" />
                 			     N<input name="liescoord3n"  id="liescoord3n" type="checkbox" id="editar" value="1" /><br>					</td>
				 </tr>


               <tr>
                    <td><b>Coordenador(a) Telessala</b></td>
					  <td>
                           <input  name="tvecoord1" size="50" maxlength="40"   type="text" onBlur=   "maiusculadiagnostico()">     M<input name="tvecoord1m"  type="checkbox" id="editar" value="1" />
                 			     T<input name="tvecoord1t"  type="checkbox" id="editar" value="1" />
                 			     N<input name="tvecoord1n"   type="checkbox" id="editar" value="1" /><br> 								 
                          
						  
						   <input  name="tvecoord2" size="50" maxlength="40"   type="text"  onBlur=   "maiusculadiagnostico()">     M<input name="tvecoord2m" type="checkbox" id="editar" value="1" />
                 			     T<input name="tvecoord2t" type="checkbox" id="editar" value="1" />
                 			     N<input name="tvecoord2n" type="checkbox" id="editar" value="1" /><br> 								 

                           <input  name="tvecoord3" size="50" maxlength="40"   type="text"  onBlur=   "maiusculadiagnostico()">     
						         M<input name="tvecoord3m" type="checkbox" id="editar" value="1" />
                 			     T<input name="tvecoord3t" type="checkbox" id="editar" value="1" />
                 			     N<input name="tvecoord3n" type="checkbox" id="editar" value="1" /><br>					</td>
				 </tr>



               <tr>
                    <td>Programas</td>
					  <td>
                                 Proinfo<input name="proinfo1" type="checkbox" id="editar" value="1" />
                 			     Oi Tonomundo<input name="tonomundo1" type="checkbox" id="editar" value="1" />
                 			     Alvorada<input name="alvorada1" type="checkbox" id="editar" value="1" /> 								 
                                 Despertar<input name="despertar1" type="checkbox" id="editar" value="1" />
                 			     Promed<input name="promed1" type="checkbox" id="editar" value="1" /><br>
                 			     Proinesp<input name="proinesp1" type="checkbox" id="editar" value="1" />								 
   			     Outros<input  name="prooutros" id ="prooutros" size="35"  maxlength="25"   type="text"  onBlur=   "maiusculadiagnostico()">     

					</td>				 </tr>


<tr bgcolor="#FFFF00"><td><b>Estrutura F�sica LIE</b></td>
</tr>


               <tr>
                    <td></td>
					  <td>
                         Sala LIE M2 &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp
					       <input name="salaliem2" type="text" id="salaliem2" size="4" MAXLENGTH="4"   value = "0" onKeyPress="return Enum(event)"><br>
                         Qtda Ar condicionado
					       &nbsp;&nbsp;&nbsp <input name="qtdaarlie" type="text" id="qtdaarlie" size="4" MAXLENGTH="4" value = "0"  onKeyPress="return Enum(event)"><br>
                         Qtda Central de Ar&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp
					       <input name="qtdacentrallie" type="text" id="qtdacentrallie" size="4" MAXLENGTH="4"  value = "0"   onKeyPress="return Enum(event)"><br>
         			     Condi��es F�sicas &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp <input  name="codifisicalie" size="40"   MAXLENGTH="150" type="text" onBlur=   "maiusculadiagnostico()">        

					</td>
               </tr>


<tr bgcolor="#FFFF00"><td><b>Estrutura Telessala</b></td>
</tr>
               <tr>
                    <td></td>
					  <td>
                         <div align="left">Telessala M2&nbsp;&nbsp;&nbsp&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp
                           <input name="salatvm2" type="text" id="salatvm2" size="4" MAXLENGTH="4"  value = "0" onKeyPress="return Enum(event)">
                           <br>
                           Qtda Ar condicionado
					       &nbsp;&nbsp;&nbsp
                           <input name="qtdaartv" type="text" id="qtdaartv" size="4" MAXLENGTH="4"   value = "0" onKeyPress="return Enum(event)">
                           <br>
                           Qtda Central de Ar&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp
                           <input name="qtdacentraltv" type="text" id="qtdacentraltv" size="4" MAXLENGTH="4" value = "0"  onKeyPress="return Enum(event)">
                           <br>
                           Condi��es F�sicas &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp
                           <input  name="codifisicatv" size="40"   MAXLENGTH="150" type="text"  onBlur=   "maiusculadiagnostico()">     

					</td>
                         </div>
			     </tr>

<tr bgcolor="#FFFF00"><td><b>Mobili�rio LIE</b></td>
</tr>
            <tr>
			<td>
               <tr>
					  <td>Computador</td>
					      <td align="left"> <input name="Computadorlie" type="text" id="Computadorlie" value = "0" size="4" MAXLENGTH="4"    onKeyPress="return Enum(event)"></td>
                </tr>
				<tr> 
					  <td>Arm�rio</td>
					       <td><input name="armariolie" type="text" id="armariolie" size="4" MAXLENGTH="4"  value = "0" onKeyPress="return Enum(event)" >			          </td>
                 </tr>
				 <tr>
					  <td>Cadeira</td>
					       <td><input name="cadeiralie" type="text" id="cadeiralie" size="4" MAXLENGTH="4"  value = "0"  onKeyPress="return Enum(event)" >			          </td>
				</tr>	
					
				<tr>	
					  <td>Bancada</td>
					       <td><input name="bancadalie" type="text" id="bancadalie" size="4" MAXLENGTH="4"  value = "0"  onKeyPress="return Enum(event)" >			          </td>
				</tr>	  
					
				<tr>	
					  <td>Mesa</td>
					       <td><input name="mesalie" type="text" id="mesalie" size="4" MAXLENGTH="4" value = "0"   onKeyPress="return Enum(event)" >			          </td>
				</tr>	  
                <tr>
					  <td>Impressora</td>
					       <td><input name="impressoralie" type="impressoralie" id="nalunos" size="4" MAXLENGTH="4" value = "0"  onKeyPress="return Enum(event)" >			          </td>
				</tr>	  

				<tr> 
					  <td>Quadro Interativo</td>
					       <td><input name="qdinterativolie" type="text" id="qdinterativolie" size="4" MAXLENGTH="4"  value = "0"  onKeyPress="return Enum(event)" >			          </td>
				</tr>	  

				<tr>	
					  <td>Notebook</td>
					       <td><input name="notebooklie" type="text" id="notebooklie" size="4" MAXLENGTH="4" value = "0" onKeyPress="return Enum(event)" >			          </td>
				</tr>	  

			<tr>
					  <td>NoBreak</td>
					       <td><input name="nobreaklie" type="text" id="nobreaklie" size="4" MAXLENGTH="4"   value = "0" onKeyPress="return Enum(event)" >			          </td>
              </tr>
				
			<tr>	
					  <td>Leitor de DVD</td>
					       <td><input name="ledvdlie" type="text" id="ledvdlie" size="4" MAXLENGTH="4"  value = "0"   onKeyPress="return Enum(event)" >			          </td>
            </tr> 
              
			      <tr>
					  <td>Prateleira Fixa</td>
					       <td><input name="pratileiralie" type="text" id="pratileiralie" size="4" MAXLENGTH="4"   value = "0" onKeyPress="return Enum(event)" >			          </td>
				</tr>		   
           </td>
		   </tr>





<tr bgcolor="#FFFF00"><td><b>Mobili�rio TV Escola</b></td>
</tr>
			  
  <tr>
					  <td>Computador</td>
					      <td align="left"> <input name="computadortv" type="text" id="computadortv" size="4" MAXLENGTH="4" value = "0"   onKeyPress="return Enum(event)"></td>
                </tr>
				<tr> 
					  <td>Arm�rio</td>
					       <td><input name="armariotv" type="text" id="armariotv" size="4" MAXLENGTH="4"  value = "0"  onKeyPress="return Enum(event)" >
			          </td>
                 </tr>
				 <tr>
					  <td>Cadeira</td>
					       <td><input name="cadeiratv" type="text" id="cadeiratv" size="4" MAXLENGTH="4"  value = "0"  onKeyPress="return Enum(event)" >
			          </td>
				</tr>	
					
					
				<tr>	
					  <td>Mesa</td>
					       <td><input name="mesatv" type="text" id="mesatv" size="4" MAXLENGTH="4"  value = "0"  onKeyPress="return Enum(event)" >
			          </td>
				</tr>	  
                <tr>
					  <td>TV Analogica</td>
					       <td><input name="tvana" type="text" id="tvana" size="4" MAXLENGTH="4"   value = "0" onKeyPress="return Enum(event)" >
			          </td>
				</tr>	  
                 <tr>
					  <td>M�q Fotografica</td>
					       <td><input name="maqfototv" type="text" id="maqfototv" size="4" MAXLENGTH="4"  value = "0"  onKeyPress="return Enum(event)" >
			          </td>
                 </tr>
				<tr> 
					  <td>Quadro Interativo</td>
					       <td><input name="qdrinterativotv" type="text" id="qdrinterativotv" size="4" MAXLENGTH="4" value = "0"   onKeyPress="return Enum(event)" >
			          </td>
				</tr>	  

				<tr>	
					  <td>Antena</td>
					       <td><input name="antenatv" type="text" id="antenatv" size="4" MAXLENGTH="4" value = "0" onKeyPress="return Enum(event)" >
			          </td>
				</tr>	  

				<tr>	
					  <td>Receptor</td>
					       <td><input name="receotortv" type="text" id="receotortv" size="4" MAXLENGTH="4"  value = "0" onKeyPress="return Enum(event)" >
			          </td>
				</tr>	  


			<tr>
					  <td>TV Por Assinatura</td>
					       <td><input name="tvassina" type="text" id="tvassina" size="4" MAXLENGTH="4"  value = "0" onKeyPress="return Enum(event)" >
			          </td>
              </tr>

			<tr>
					  <td>Aparelho de Som</td>
					       <td><input name="apsomtv" type="text" id="apsomtv" size="4" MAXLENGTH="4"   value = "0" onKeyPress="return Enum(event)" >
			          </td>
              </tr>


			<tr>
					  <td>Caixa de Som</td>
					       <td><input name="cxsomtv" type="text" id="cxsomtv" size="4" MAXLENGTH="4" value = "0"    onKeyPress="return Enum(event)" >
			          </td>
              </tr>

<tr bgcolor="#FFFF00"><td><b>Conex�o Internet</b></td>
</tr>

                    <tr>
                      <td><b></b></td>
					  <td>
						
                             BANDA LARGA
				 	       <input name="bandalarga" type="checkbox" id="editar" value="1" />
                            GESAC
   					         <input name="gesac" type="checkbox" id="relatorios" value="1"/>
                            OI TONOMUNDO
   					         <input name="oitomundo" type="checkbox" id="relatorios" value="1"/>
                            SEDUC
   					         <input name="seduc" type="checkbox" id="relatorios" value="1"/><br>
                            DISCADA
   					         <input name="discada" type="checkbox" id="relatorios" value="1"/>
                            
   					         Circuito<input name="ncicuito" type="text" id="ncicuito" size="35"  MAXLENGTH="20"  onKeyPress="return Enum(event)">					   </td>
					 </td>
	   			</tr>	

<tr bgcolor="#FFFF00"><td><b>Forma��o PROINFO</b></td>
</tr>

                    <tr>
                      <td><b></b></td>
					  <td>
						
                            Introdu��o a Ed Digital 40 H
				 	       <input name="introducao40" type="checkbox" id="introducao40" value="1" /><br>
						    Ensinando e Aprendendo com TIC's 100 H                         
   					        <input name="tic100" type="checkbox" id="tic100" value="1"/><br>
                            Elabora��o de Projetos 40 Hs
   					        <input name="projetos40" type="checkbox" id="projetos40" value="1"/><br>
                            Aluno Integrado
   					         <input name="alunointegrado" type="checkbox" id="alunointegrado" value="1"/><br>
                            UCA
   					         <input name="uca" type="checkbox" id="uca" value="1"/><br>					   </td>
					 </td>
	   			</tr>	

<tr>
<td></td><td><input name="submit"  type="submit"  value="Gravar"  onClick="javascript:return validadiagnostico();" >  </td>
</tr>               

       </td>
      </tr>


   </table>
</form>
<?
  }
mysql_free_result( $resposta );
mysql_close($conexao);
?>
</table>
 </div>

    <div id="menudiagnostico" class="fonte" align="left">
 	    <p>&nbsp; </p>
      <h3 align="center" class="style5" >Escola Diagn�stico</h3>
   	  <ul  class="menu_vertical">
		 <li><a href="mnnte.php" title="Retorna ">Volta</a>
      </ul>			
	</div>

</div>

<div id="rodape" class="fonterodape">
  </div>   
</center>

</body>
</html>
