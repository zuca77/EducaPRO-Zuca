<?
/*session_start();
if (isset($_SESSION["login_usuario"]))
  {
     $login =  $_SESSION["login_usuario"];
     $nte   =  $_SESSION["nivel_usuario"];
     include ("../funcoes.php");
     echo  saudacoes()."   ". "$login" ."  -  ". $nte."  ".dataextenso();
  }
 else
  {
     		 header("Location: ../login.php");
  }
*/

include ("../conexao_mysql.php");

include ("funcoes.php");

$id = $_GET['codigo'];
$sql = "select * from escola where codigo = $id";
$resposta = mysql_query( $sql );
while ( $linha = mysql_fetch_array( $resposta ))
 {
?>



<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01//EN"
	"http://www.w3.org/TR/html4/strict.dtd">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1" />
	<title>SEDUC-RO</title>


	<link rel="stylesheet" href="style/forms.css" type="text/css" />
	<link rel="stylesheet" href="estilo.css" type="text/css" />
	<link rel="stylesheet" href="style/menu.css" type="text/css" />

	<link href="tablecloth/tablecloth.css" rel="stylesheet" type="text/css" media="screen" />


	<script type="text/javascript" src="tablecloth/tablecloth.js"></script>
	<script src="lib/jquery-1.4.2.js" type="text/javascript"></script>
	<script src="lib/validate.js" type="text/javascript"></script>
	<script src="lib/forms.js" type="text/javascript"></script>
    <script src="generic.js"    type="text/javascript"></script>
    <script src="lib/jquery.maskedinput-1.1.1.js" type="text/javascript"></script>




	<link type="text/css" href="jquery-ui-1.8.18.custom/css/ui-lightness/jquery-ui-1.8.18.custom.css" rel="stylesheet" />
	<script type="text/javascript" src="jquery-ui-1.8.18.custom/js/jquery-1.7.1.min.js"></script>
	<script type="text/javascript" src="jquery-ui-1.8.18.custom/js/jquery-ui-1.8.18.custom.min.js"></script>



		<script type="text/javascript">
			$(function(){

				// Accordion
				$("#accordion").accordion({ header: "h3" });

				// Tabs
				$('#tabs').tabs();


				// Dialog
				$('#dialog').dialog({
					autoOpen: false,
					width: 600,
					buttons: {
						"Ok": function() {
							$(this).dialog("close");
						},
						"Cancel": function() {
							$(this).dialog("close");
						}
					}
				});

				// Dialog Link
				$('#dialog_link').click(function(){
					$('#dialog').dialog('open');
					return false;
				});

				// Datepicker
				$('#datepicker').datepicker({
					inline: true
				});

				// Slider
				$('#slider').slider({
					range: true,
					values: [17, 67]
				});

				// Progressbar
				$("#progressbar").progressbar({
					value: 20
				});

				//hover states on the static widgets
				$('#dialog_link, ul#icons li').hover(
					function() { $(this).addClass('ui-state-hover'); },
					function() { $(this).removeClass('ui-state-hover'); }
				);

			});
		</script>






<script src="../script.js"></script>

<script>


	$(function() {
		$( "#txtdtemisao" ).datepicker({
			changeMonth: true,
			changeYear: true
		});
	});

$(function() {
        $("#txtdtemisao").datepicker();
        $('#txtdtemisao').datepicker('option', 'dateFormat', 'dd/mm/yy');
});






	$(function() {
		$( "#txtdtvalidade" ).datepicker({
			changeMonth: true,
			changeYear: true
		});
	});

$(function() {
        $("#txtdtvalidade").datepicker();
        $('#txtdtvalidade').datepicker('option', 'dateFormat', 'dd/mm/yy');
});







</script>



</head>
<body>
	<div id="warpper">
		<div id="header">
		    <img src= "img/seduc_topo.jpg"/>
		</div>

<div id="content">
    <form name ="form" id="form" class="form" action="altera_escola.php" method="post" >


<p>
		<label for="lbldtemissaote">C�digo<img src= "img/check.gif"/></label>
         <input readonly="true"  name="codigo" id="codigo"  type="text" value="<?echo $id?>">
</p>


<p>
		<label for="lbldtemissaote">INEP<img src= "img/check.gif"/></label>
         <input  name="inep"  id="inep" readonly="true" size="10" maxlength="10" type="text" value = "<?echo $linha["INEP"];?>" onKeyPress="return Enum(event)"/>
</p>


 <p>
		<label for="lbldtemissaote">Descri��o<img src= "img/check.gif"/></label>
        <input  name="descricao" id="descricao" size="60" maxlength="60" type="text" value="<?echo $linha["DESCRICAO"];?>" onBlur=   "maiusculalteracadescola()">
</p>

 <p>
 <label for="lbldtemissaote">Endere�o<img src= "img/check.gif"/></label>
 <input name="endereco" type="text" id="endereco" size="60" MAXLENGTH="60"  value="<?echo $linha["ENDERECO"];?>"    onBlur=   "maiusculalteracadescola()">
 </p>


 <p>
 <label for="lbldtemissaote">Bairro<img src= "img/check.gif"/></label>
        <input name="bairro" type="text" id="bairro" size="40" MAXLENGTH="40" value="<?echo $linha["BAIRRO"];?>" onBlur=   "maiusculalteracadescola()">
 <label for="lbldtemissaote">N<img src= "img/check.gif"/></label>
  <input name="nr" type="text" id="nr" size="10" MAXLENGTH="4" value="<?echo $linha["NUMERO"];?>" onKeyPress="return Enum(event)" >

    <label for="txtCEP">CEP<img src= "img/check.gif"/></label>
	<input id="txtcep" name="txtcep" type="text" style="width:90px" maxlength="8" value="<?echo $linha["CEP"];?>" onKeyPress="return Enum(event)"/>


</p>





<p>
 <label for="lbldtemissaote">FONE<img src= "img/check.gif"/></label>
 <input name="fone" type="text" id="fone" size="20" MAXLENGTH="20"

value="<?echo $linha["FONE"];?>" >
</p>

<p>

<?
$codmuni=$linha["MUNICIPIO"];
$sqlconulta        = "select codigo,descricao from municipio where codigo = $codmuni";
$respconsulta      = mysql_query( $sqlconulta );
while ( $dado = mysql_fetch_array( $respconsulta ))
{
   $descricao = $dado["descricao"];
   $codigo    = $dado["codigo"];
}
?>
</p>


  			     	<p>
						<label for="regularizacao">Quantidade Servidores</label>
						<label for="regularizacao">*********************************</label>


     	  			</p>

<P>
 <label for="lbldtemissaote">Prof Estatut�rio<img src="img/check.gif"/></label>
 <input name="nprofessores" type="text" id="nprofessores" size="5" MAXLENGTH="5" value="<?echo $linha["NPROFESSORES"];?>" onKeyPress="return Enum(event)">


<label for="lbldtemissaote">Prof Emerg�ncial<img src=

"img/check.gif"/></label>
 <input name="nemergencial" type="text" id="nemergencial" size="5" MAXLENGTH="5" value="<?echo $linha["NEMERGENCIAL"];?>" onKeyPress="return Enum(event)">


 <label for="lbldtemissaote">T�c Administrativo<img src="img/check.gif"/></label>
 <input name="nadm" type="text" id="nadm" size="5" MAXLENGTH="5" value="<?echo $linha["NADMINISTRATIVO"];?>" onKeyPress="return Enum(event)">

 <label for="lbldtemissaote">Alunos<img src= "img/check.gif"/></label>
  <input name="nalunos" type="text" id="nalunos" size="5" MAXLENGTH="5" value="<?echo $linha["NALUNOS"];?>" onKeyPress="return Enum(event)">

</p>



	   <p>
         <label for="lblcod_cpf">Diretor<img src= "img/check.gif"/></label>
         <input name="diretor" type="text" id="diretor" size="60" MAXLENGTH="60" value= "<?echo $linha["DIRETOR"];?>">
       </p>


	   <p>
         <label for="lblcod_cpf">Vice Diretor<img src= "img/check.gif"/></label>
		 <input name="vicediretor" type="text" id="vicediretor" size="60" maxlength="60" value= "<?echo $linha["VICEDIRETOR"];?>">
       </p>






   <p>
        			 <label for="regularizacao">Regularizada<img src= "img/check.gif"/></label>
 			               <select id="selectregularizacao" name="selectregularizacao" style="width:80px" value= "<?echo $linha["REGULARIZADA"];?>">
              		          <option value="S">Sim</option>
            		          <option value="N">N�o</option>
    		               </select>



						 <label for="regularizacao">Situa��o<img src= "img/check.gif"/></label>
 		               <select id="selectsituacao" name="selectsituacao" style="width:105px" value= "<?echo $linha["SITUACAO"];?>">
							  <option value="A">Autorizada</option>
            		          <option value="R">Reconhecida</option>
							  <option value="I">Irregular</option>
    		               </select>


<label for="lbldtemissaote">Portaria/Decreto<img src= "img/check.gif"/></label>
<input type="text" name="txtportaria" style="width:140px"  id="txtportaria" maxlength="12" size="20" value= "<?echo $linha["PORTARIA"];?>" 	>


       </p>



<P>
<label for="lbldtemissaote">Data Emiss�o<img src= "img/check.gif"/></label>
<input type="text" name="txtdtemisao1" id="txtdtemisao1" readonly="true" value="<? $data = date("d/m/Y",strtotime($linha["DTPORTARIA"]));    if ($data=='31/12/1969')
  {
	$data="";
	echo $data;
  }
else
{
 echo $data;
 }
 ?>">


<label for="lbldtemissaote1">Data Validade<img src= "img/check.gif"/></label>
 <input name= "txtdtvalidade1" type="text" id="txtdtvalidade1" readonly="true" value="<? $data1 = date("d/m/Y",strtotime($linha["DTVALIDADE"]));

 if ($data1=='31/12/1969')
  {
	$data1="";
  }
 else
{
 echo $data1;
 }
 ?>">

</p>	




<P>

<label for="lbldtemissaote">Altera Data Emiss�o<img src= "img/check.gif"/></label>
<input type="text" name="txtdtemisao" id="txtdtemisao" readonly="true"  onChange="alteraportaria(this.value)" >

<label for="lbldtemissaote1">Altera Data Validade<img src= "img/check.gif"/></label>
<input name= "txtdtvalidade" type="text" id="txtdtvalidade" readonly="true"  onChange="alteravalidade(this.value)" >

</p>	




 <p>
 <label for="lbldtemissaote">Munic�pio<img src= "img/check.gif"/></label>
 <input  name="municodigo" size="8" type="text" readonly="true" value="<?echo "$codigo";?>">
 <input  name="municipio1" size="55" type="text" readonly="true" value="<?echo "$descricao";?>">
 </p>



<P>
 <label for="lbldtemissaote">Altera Munic�pio<img src= "img/check.gif"/></label>
       <?=lista_municipio_Altera();?>
</P>



<p>
 <label for="lbldtemissaote">Zona<img src= "img/check.gif"/></label>
  <input  name="zona" size="15" type="text" readonly="true" maxlength="15" value="<?echo $linha["TIPO"];?>">
</p>
<p>
 <label for="lbldtemissaote">Altera Zona<img src= "img/check.gif"/></label>
	          <select name="tipo" onChange="alterazona(this.value)" >
              <option value="">...Selecione Tipo...</option>
              <option value="RURAL">RURAL</option>
              <option value="URBANA">URBANA</option>
            </select>
</p>


<?
}

?>
					<p id="finish">
            <input type="submit" value="Gravar" />
            <input type="reset" value="limpar" />
					</p>
				</form>
			</div>
		</div>
	</div>
</body>
</html>