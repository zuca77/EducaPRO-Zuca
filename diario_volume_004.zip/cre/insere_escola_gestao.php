
<?

//verifico se o aqruvo que eu criei existe

if(file_exists("conexao_mysql.php")) 
{
        require "../conexao_mysql.php"; 
       mysql_query("SET NAMES 'utf8'");		            
} else 
{
        echo "Arquivo conexao_mysql nao foi encontrado";
        exit;
}


/*verifico se os dados estao vindos do formulario, porque se uma pessoa acessar essa pagina diretamente 
poderia dar erro, entao eu testo antes*/
if($_SERVER["REQUEST_METHOD"] == "POST") 
{

/******Dados da escola*********************************************************************************/

$passou1=0;
$passou2=0;






$codigo      = $_POST['codigo'];
$inep        = $_POST['inep'];
$descricao   = trim($_POST['descricao']);
$zona              = $_POST['zona'];
$municodigo  = $_POST['cod_estado'];
$endereco    = trim($_POST['endereco']);
$nr          = trim($_POST['nr']);
$bairro      = trim($_POST['bairro']);
$cep         = $_POST['txtcep'];
$fone        = $_POST['fone'];
$nprofessores= $_POST['nprofessores'];
$nalunos     = $_POST['nalunos'];
$tipo           = $_POST['tipo'];               

$NADMINISTRATIVO= $_POST['nadm'];
$DTVALIDADE     = $_POST['txtdtvalidade'];
$DTPORTARIA     = $_POST['txtdtemissao'];
$PORTARIA       = $_POST['txtportaria'];
$SITUACAO       = $_POST['selectsituacao'];
$REGULARIZADA   = $_POST['selectregularizacao'];
$VICEDIRETOR    = trim($_POST['vicediretor']);
$DIRETOR	    = trim($_POST['diretor']);
$NEMERGENCIAL   = $_POST['nemergencial'];
$modalidade1    = $_POST['modalidade1'];
$modalidade2    = $_POST['modalidade2'];
$modalidade3    = $_POST['modalidade3'];
$modalidade4    = $_POST['modalidade4'];
$modalidade5    = $_POST['modalidade5'];
$modalidade6    = $_POST['modalidade6'];
$modalidade7    = $_POST['modalidade7'];



$txtqdtasala					= $_POST['txtqdtasala'];
$selectleitura                  = $_POST['selectleitura'];
$selectlie                      = $_POST['selectlie'];
$selectquadra                   = $_POST['selectquadra'];
$selectcoberta                  = $_POST['selectcoberta'];
$selectpde                      = $_POST['selectpde'];
$txtideb                        = $_POST['txtideb'];
$txtenem                        = $_POST['txtenem'];
$txtprasil                      = $_POST['txtprasil'];
$txtprovlhabr                   = $_POST['txtprovlhabr'];




$data = trim($DTPORTARIA);
if (strlen($data) != 10)
{
$rs = "";
}
else
{
$arr_data = explode("/",$data);
$data_banco = $arr_data[2]."-".$arr_data[1]."-".$arr_data[0];
$rs = $data_banco;
}
$dataformato =$rs; 







$data1 = trim($DTVALIDADE);
if (strlen($data1) != 10)
{
$rs1 = "";
}
else
{
$arr_data1 = explode("/",$data1);
$data_banco1 = $arr_data1[2]."-".$arr_data1[1]."-".$arr_data1[0];
$rs1 = $data_banco1;
}

$dataformato1 =$rs1; 

$dia = date('d');
$mes = date('m');
$ano = date('Y');
 

$data =$ano.".".$mes.".".$dia;

$sqlconsulta="select * from escola where inep= '$inep'";
$qryconsulta = mysql_query($sqlconsulta);
$linhas=mysql_num_rows($qryconsulta);
if ($linhas > 0)
{	
$sql = "update escola set  descricao='$descricao',tipo='$tipo', endereco='$endereco', bairro='$bairro',cep='$cep',fone=               '$fone',municipio='$municodigo',numero='$nr',nprofessores='$nprofessores',nalunos='$nalunos',diretor='$DIRETOR',vicediretor=       '$VICEDIRETOR',NEMERGENCIAL='$NEMERGENCIAL',NADMINISTRATIVO='$NADMINISTRATIVO',PORTARIA='$PORTARIA',REGULARIZADA='$REGULARIZADA',  SITUACAO='$SITUACAO',DTVALIDADE='$dataformato1',modalidade1='$modalidade1',modalidade2='$modalidade2',modalidade3='$modalidade3',modalidade4= '$modalidade4',modalidade5='$modalidade5',modalidade6='$modalidade6',modalidade7='$modalidade7',qtdasala='$txtqdtasala',SLEITURA     	= '$selectleitura',LIE='$selectlie', QUADRA='$selectquadra',QCOBERTA='$selectcoberta',PDE='$selectpde',IDEB='$txtideb',ENEM            ='$txtenem',PBRASIL='$txtprasil',PROVINHABR='$txtprovlhabr',DTPORTARIA='$dataformato'   where inep='$inep'";
$qry = mysql_query($sql);

if($qry)
{
       //verifiquei acima se deu certo o comando e aqui verifico se foi mesmo gravado o dado no banco
		if(mysql_affected_rows() == 1)
		{
              $passou1 = 1;
			  // echo "Registro efetuado com sucesso<br/>";
        }

}
else
   {
        //verifico se nao estao tentando gravar um dado que ja existe, pois usei UNIQUE na tabela
        if(mysql_errno() == 1062)
		  {
                echo $erros[mysql_errno()];
                exit;
          }
		  else
		  {
                echo "Erro nao foi possivel efetuar o cadastro do dados da escola";
                exit;
          }

     }
  }



//***********************************Transicao*******************************************************/


$cpf                     		= $_POST['cpf1'];
$selectregularizacao    		= $_POST['selectregularizacao'];
$txtportaria            	    = $_POST['txtportaria'];
$txtdtemisao					= $_POST['txtdtemisao'];
$selectpatrimonio				= $_POST['selectpatrimonio'];
$selectstatuspatri				= $_POST['selectstatuspatri'];
$selectacervo					= $_POST['selectacervo'];
$txtqdtasala					= $_POST['txtqdtasala'];
$selectleitura                  = $_POST['selectleitura'];
$selectlie                      = $_POST['selectlie'];
$selectquadra                   = $_POST['selectquadra'];
$selectstatusqd                 = $_POST['selectstatusqd'];
$selectcoberta                  = $_POST['selectcoberta'];
$selectpde                      = $_POST['selectpde'];
$selectprogramas                = $_POST['selectprogramas'];
$txtqdtaprograma                = $_POST['txtqdtaprograma'];
$selectacervo                   = $_POST['selectacervo'];
$selectstatusacervo             = $_POST['selectstatusacervo'];
$txtideb                        = $_POST['txtideb'];
$txtenem                        = $_POST['txtenem'];
$txtprasil                      = $_POST['txtprasil'];
$txtprovlhabr                   = $_POST['txtprovlhabr'];
$selectmodalidade               = $_POST['selectmodalidade'];
$selectfonte                    = $_POST['selectfonte'];
$selectcantina                  = $_POST['selectcantina'];
$selectmais                     = $_POST['selectmais'];
$laudo                          = $_POST['laudo'];



$fiscalmuni                     = $_POST['fiscalmuni'];
$fiscalestado                   = $_POST['fiscalestado'];
$fiscalfedera                   = $_POST['fiscalfedera'];
$fiscalfgts                     = $_POST['fiscalfgts'];
$contabil                       = $_POST['contabil'];
$inss                           = $_POST['inss'];
$proafi                         = $_POST['proafi'];
$penai                          = $_POST['penai'];
$profipes                       = $_POST['profipes'];
$pde                            = $_POST['pde'];

$modalidade1                    = $_POST['modalidade1'];
$modalidade2                    = $_POST['modalidade2'];
$modalidade3                    = $_POST['modalidade3'];
$modalidade4                    = $_POST['modalidade4'];
$modalidade5                    = $_POST['modalidade5'];

$modalidade6                    = $_POST['modalidade6'];
$modalidade7                    = $_POST['modalidade7'];


$selectsituacao                 = $_POST['selectsituacao'];
$txtdtvalidade                  = $_POST['txtdtvalidade'];





$data = trim($DTPORTARIA);
if (strlen($data) != 10)
{
$rs = "";
}
else
{
$arr_data = explode("/",$data);
$data_banco = $arr_data[2]."-".$arr_data[1]."-".$arr_data[0];
$rs = $data_banco;
}
$dataformato =$rs; 







$data1 = trim($DTVALIDADE);
if (strlen($data1) != 10)
{
$rs1 = "";
}
else
{
$arr_data1 = explode("/",$data1);
$data_banco1 = $arr_data1[2]."-".$arr_data1[1]."-".$arr_data1[0];
$rs1 = $data_banco1;
}

$dataformato1 =$rs1; 

$dia = date('d');
$mes = date('m');
$ano = date('Y');


$data =$ano.".".$mes.".".$dia;

$sql="select * from transicao where inep= '$inep'";
$qry = mysql_query($sql);
$linhas=mysql_num_rows($qry );
if ($linhas > 0)
{
$sql = "update transicao set inep='$inep',REGULARIZACAO='$selectregularizacao',PORTARIA='$txtportaria', DTEMISSAO='$dataformato',PATRIMONIO='$selectpatrimonio',SPATRIMONIO='$selectstatuspatri',ACERVO='$selectacervo',QTDASALA='$txtqdtasala',
PORTARIA='$PORTARIA',SITUACAO='$SITUACAO',DTVALIDADE='$dataformato1',modalidade1='$modalidade1',modalidade2='$modalidade2',modalidade3='$modalidade3',modalidade4= '$modalidade4',modalidade5='$modalidade5',modalidade6='$modalidade6',modalidade7='$modalidade7',qtdasala='$txtqdtasala',SLEITURA= '$selectleitura',LIE='$selectlie',QUADRA='$selectquadra',QCOBERTA='$selectcoberta',PDE='$selectpde',IDEB='$txtideb',ENEM='$txtenem',PBRASIL='$txtprasil',PROVINHABR='$txtprovlhabr',PROGRAMA='$selectprogramas',QTDAPROGRAMA='$txtqdtaprograma',FONTER='$selectfonte',CANTINA='$selectcantina',MAIS='$selectmais',FISCALMUNI='$fiscalmuni',FISCALESTADO='$fiscalestado',FISCALFEDERAL='$fiscalfedera',FISCALFGTS='$fiscalfgts',CONTABIL='$contabil',INSS='$inss',PROAFI='$proafi',PENAI='$penai',PROFIPES='$profipes',PDEF='$pde'  where inep='$inep'";

$qry = mysql_query($sql);


if($qry)
{
       //verifiquei acima se deu certo o comando e aqui verifico se foi mesmo gravado o dado no banco
        if(mysql_affected_rows() == 1)
		{
               $passou2 = 1;
			   //echo "Registro Alterado  com sucesso<br/>";

        }

} else
   {
        //verifico se nao estao tentando gravar um dado que ja existe, pois usei UNIQUE na tabela
        if(mysql_errno() == 1062)
		  {
                echo $erros[mysql_errno()];
                exit;
          }
		  else
		  {
                echo "Erro nao foi possivel efetuar a Altera��o dos dados da transicao" ;
                exit;
          }

     }

}
else
{

$sql = "insert into transicao (inep,REGULARIZACAO,PORTARIA,DTEMISSAO,PATRIMONIO,SPATRIMONIO,ACERVO,QTDASALA,SLEITURA,LIE,QUADRA,SQUADRA,QCOBERTA,PDE,PROGRAMA,QTDAPROGRAMA,IDEB,ENEM,PBRASIL,PROVINHABR,FONTER,CANTINA,MAIS,LAUDO,FISCALMUNI,FISCALESTADO,FISCALFEDERAL,FISCALFGTS,CONTABIL,INSS,PROAFI,PENAI,PROFIPES,PDEF,MODALIDADE1,MODALIDADE2,MODALIDADE3,MODALIDADE4,MODALIDADE5,SITUACAO,DTVALIDADE,MODALIDADE6,MODALIDADE7,USUARIO,ANO) values ('$inep','$selectregularizacao','$txtportaria','$dataformato','$selectpatrimonio','$selectstatuspatri','$selectacervo','$txtqdtasala','$selectleitura','$selectlie','$selectquadra','$selectstatusqd','$selectcoberta','$selectpde','$selectprogramas','$txtqdtaprograma','$txtideb','$txtenem','$txtprasil','$txtprovlhabr','$selectfonte','$selectcantina','$selectmais','$laudo','$fiscalmuni','$fiscalestado','$fiscalfedera','$fiscalfgts','$contabil','$inss','$proafi','$penai','$profipes','$pde','$modalidade1','$modalidade2','$modalidade3','$modalidade4','$modalidade5','$selectsituacao','$dataformato1','$modalidade6','$modalidade7','$login','2011')";
$qry = mysql_query($sql);

if($qry)
{
       //verifiquei acima se deu certo o comando e aqui verifico se foi mesmo gravado o dado no banco
        if(mysql_affected_rows() == 1)
		{
               echo "Registro Transicao efetuado com sucesso<br/>";


        }

} else
   {
        //verifico se nao estao tentando gravar um dado que ja existe, pois usei UNIQUE na tabela
        if(mysql_errno() == 1062)
		  {
                echo $erros[mysql_errno()];
                exit;
          }
		  else
		  {
                echo "Erro Transicao nao foi possivel efetuar o cadastro dos dados da transicao" ;
                exit;
          }

     }

}


//******Dados conselho escolar*****************************************************************************************/

$dados="";

$txtcnpj = $_POST['cnpj'];
	
	
		for ($i=0; $i < strlen($txtcnpj); $i++) 
		{
			if (($txtcnpj[$i]!='.') and ($txtcnpj[$i]!='/') and ($txtcnpj[$i]!='-')) 
			    { 
				  $dados =$dados.''. $txtcnpj[$i];
				}
		}
		//retorna o campo formatado

 $txtcnpj = $dados;



$txtdtregistro       = $_POST['txtdtregistro'];
$tipoe               = $_POST['tipoe'];
$txtdtmandatoi       = $_POST['txtdtmandatoi'];
$txtdtmandatof       = $_POST['txtdtmandatof'];
$txtpresidente       = $_POST['txtpresidente'];
$txtsuplente         = $_POST['txtsuplente']; 
$txtsegmento1_de     = $_POST['txtsegmento1_de'];
$txtsecretario1_de   = $_POST['txtsecretario1_de'];
$txtsuplente1_de     = $_POST['txtsuplente1_de'];
$txtsegmento2_de     = $_POST['txtsegmento2_de'];
$txtsecretario2_de   = $_POST['txtsecretario2_de'];
$txtsuplente2_de     = $_POST['txtsuplente2_de'];
$txtconselheiro1_cap = $_POST['txtconselheiro1_cap'];
$txtsuplente1_cap    = $_POST['txtsuplente1_cap'];
$txtconselheiro2_cap = $_POST['txtconselheiro2_cap'];
$txtsuplente2_cap    = $_POST['txtsuplente2_cap'];
$txtconselheiro3_cap = $_POST['txtconselheiro3_cap'];
$txtsuplente3_cap    = $_POST['txtsuplente3_cap'];
$txtconselheiro4_cap = $_POST['txtconselheiro4_cap'];
$txtsuplente4_cap    = $_POST['txtsuplente4_cap'];
$txttesoureiro1_cef  = $_POST['txttesoureiro1_cef'];


$txtsuplentetesouro    = $_POST['txtsuplentetesouro'];



$txtconselheiro1_cef = $_POST['txtconselheiro1_cef'];
$txtsuplente1_cef    = $_POST['txtsuplente1_cef'];
$txtconselheiro2_cef = $_POST['txtconselheiro2_cef'];
$txtsuplente3_cef    = $_POST['txtsuplente3_cef'];
$txtconselheiro3_cef = $_POST['txtconselheiro3_cef'];
$txtsuplente3_cef    = $_POST['txtsuplente3_cef'];


$txtconselheiro1_cf   = $_POST['txtconselheiro1_cf'];
$txtsuplente1_cf     = $_POST['txtsuplente1_cf'];

$txtconselheiro2_cf  = $_POST['txtconselheiro2_cf'];
$txtsuplente2_cf     = $_POST['txtsuplente2_cf'];

$txtconselheiro3_cf  = $_POST['txtconselheiro3_cf'];
$txtsuplente3_cf     = $_POST['txtsuplente3_cf'];
$txtconselheiro4_cf  = $_POST['txtconselheiro4_cf'];



$txtsuplente4_cf     = $_POST['txtsuplente4_cf'];



$data1 = trim($txtdtregistro);
if (strlen($data1) != 10)
{
$rs1 = "";
}
else
{
$arr_data1 = explode("/",$data1);
$data_banco1 = $arr_data1[2]."-".$arr_data1[1]."-".$arr_data1[0];
$rs1 = $data_banco1;
}

$dataformato =$rs1; 


$data1 = trim($txtdtmandatoi);
if (strlen($data1) != 10)
{
$rs1 = "";
}
else
{
$arr_data1 = explode("/",$data1);
$data_banco1 = $arr_data1[2]."-".$arr_data1[1]."-".$arr_data1[0];
$rs1 = $data_banco1;
}

$dataformatoi =$rs1; 


$data1 = trim($txtdtmandatof);
if (strlen($data1) != 10)
{
$rs1 = "";
}
else
{
$arr_data1 = explode("/",$data1);
$data_banco1 = $arr_data1[2]."-".$arr_data1[1]."-".$arr_data1[0];
$rs1 = $data_banco1;
}

$dataformatof =$rs1; 


$sql="select * from conselhoe where inep= '$inep'";
$qry = mysql_query($sql);
$linhas=mysql_num_rows($qry );
if ($linhas <= 0)
{

$sql ="insert into conselhoe (INEP,CNPJ,DTREGISTRO,TPELEICAO,DTINICIO,DTFIM,PRESIDENTE,SUPLENTE_PRES,SEGMENTO1DE,SECRETARIO1DE,SUPLENTE_SECR1,SEGMENTO2DE,SECRETARIO2DE,SUPLENTE_SECR2,CONSELHE1CAP,SUPLENTE1CAP,CONSELHE2CAP,SUPLENTE2CAP,CONSELHE3CAP,SUPLENTE3CAP,CONSELHE4CAP,SUPLENTE4CAP,TESOUREIRO,SUPLENTETESOURO,CONSELHE1CEF,SUPLENTE1CEF,CONSELHE2CEF,SUPLENTE2CEF,CONSELHE3CEF,SUPLENTE3CEF,CONSELHE1CF,SUPLENTE1CF,CONSELHE2CF,SUPLENTE2CF,CONSELHE3CF,SUPLENTE3CF,CONSELHE4CF,SUPLENTE4CF) values ('$inep','$txtcnpj','$dataformato','$tipoe','$dataformatoi','$dataformatof','$txtpresidente','$txtsuplente','$txtsegmento1_de','$txtsecretario1_de','$txtsuplente1_de','$txtsegmento2_de','$txtsecretario2_de','$txtsuplente2_de','$txtconselheiro1_cap','$txtsuplente1_cap','$txtconselheiro2_cap','$txtsuplente2_cap','$txtconselheiro3_cap','$txtsuplente3_cap','$txtconselheiro4_cap','$txtsuplente4_cap','$txttesoureiro1_cef','$txtsuplentetesouro','$txtconselheiro1_cef','$txtsuplente1_cef','$txtconselheiro2_cef','$txtsuplente3_cef','$txtconselheiro3_cef','$txtsuplente3_cef','$txtconselheiro1_cf','$txtsuplente1_cf','$txtconselheiro2_cf','$txtsuplente2_cf','$txtconselheiro3_cf','$txtsuplente3_cf','$txtconselheiro4_cf','$txtsuplente4_cf')";



$qry = mysql_query($sql);


if($qry)
{
       //verifiquei acima se deu certo o comando e aqui verifico se foi mesmo gravado o dado no banco
        if(mysql_affected_rows() == 1)
		{
			
			
echo "<html><head><title>Resposta !!!</title></head>";
echo "<body background=\"background_mensagens.jpg\" style=\"background-attachment:fixed; background-repeat:no-repeat\">";
echo "<br><br><br>";
echo "<center><img src=\"faleconosco/atencao.gif\" alt=\"\"><p><font color=\"#ff6600\" face=\"Verdana\" size=\"4\">Dados Gravado Com Sucesso. <b></b></font></center>";
echo "<br><br><center><a href=\"../mnescola.php\"><img src=\"faleconosco/button_voltar2_.gif\" alt=\"Voltar\" border=\"0\" /></a></center>";
echo "</body></html>";
			
			
			  // echo "Registro Conselho Escolar efetuado com sucesso<br/>";


        }

} else
   {
        //verifico se nao estao tentando gravar um dado que ja existe, pois usei UNIQUE na tabela
        if(mysql_errno() == 1062)
		  {
                echo $erros[mysql_errno()];
                exit;
          }
		  else
		  {
                echo "Erro Conselho Escolar nao foi possivel efetuar o cadastro dos dados " ;
                exit;
          }

     }




}

else
{


$sql = "update conselhoe set inep='$inep',CNPJ='$txtcnpj',DTREGISTRO='$dataformato', TPELEICAO='$tipoe',DTINICIO='$dataformatoi',DTFIM='$dataformatof',PRESIDENTE='$txtpresidente',SUPLENTE_PRES='$txtsuplente',SEGMENTO1DE='$txtsegmento1_de',SECRETARIO1DE='$txtsecretario1_de',SUPLENTE_SECR1='$txtsuplente1_de',SEGMENTO2DE='$txtsegmento2_de',SECRETARIO2DE='$txtsecretario2_de',SUPLENTE_SECR2='$txtsuplente2_de',CONSELHE1CAP='$txtconselheiro1_cap',SUPLENTE1CAP='$txtsuplente1_cap',CONSELHE2CAP='$txtconselheiro2_cap',SUPLENTE2CAP='$txtsuplente2_cap',CONSELHE3CAP='$txtsuplente3_cap',CONSELHE4CAP='$txtconselheiro4_cap',SUPLENTE4CAP='$txtsuplente4_cap',TESOUREIRO='$txttesoureiro1_cef',SUPLENTETESOURO='$txtsuplentetesouro',CONSELHE1CEF='$txtconselheiro1_cef',SUPLENTE1CEF='$txtsuplente1_cef',CONSELHE2CEF='$txtconselheiro2_cef',SUPLENTE2CEF='$txtsuplente2_cf',CONSELHE3CEF='$txtconselheiro3_cf',SUPLENTE3CEF='$txtsuplente3_cf',CONSELHE4CF='$txtconselheiro4_cf',SUPLENTE4CF='$txtsuplente4_cf' where inep='$inep'";

$qry = mysql_query($sql);


if($qry)
{
       //verifiquei acima se deu certo o comando e aqui verifico se foi mesmo gravado o dado no banco
        if(mysql_affected_rows() == 1)
		{
                //    echo "Registro Conselho Escolar alterado com sucesso<br/>";

echo "<html><head><title>Resposta !!!</title></head>";
echo "<body background=\"background_mensagens.jpg\" style=\"background-attachment:fixed; background-repeat:no-repeat\">";
echo "<br><br><br>";
echo "<center><img src=\"faleconosco/atencao.gif\" alt=\"\"><p><font color=\"#ff6600\" face=\"Verdana\" size=\"4\">Dados Gravado Com Sucesso. <b></b></font></center>";
echo "<br><br><center><a href=\"../mnescola.php\"><img src=\"faleconosco/button_voltar2_.gif\" alt=\"Voltar\" border=\"0\" /></a></center>";
echo "</body></html>";


        }

} else
   {
        //verifico se nao estao tentando gravar um dado que ja existe, pois usei UNIQUE na tabela
        if(mysql_errno() == 1062)
		  {
                echo $erros[mysql_errno()];
                exit;
          }
		  else
		  {
                echo "Erro Conselho Escolar nao foi possivel alterar o cadastro dos dados " ;
                exit;
          }

     }






}







@mysql_close($conexao);
}
else// post
{

echo "<html><head><title>Resposta !!!</title></head>";
echo "<body background=\"background_mensagens.jpg\" style=\"background-attachment:fixed; background-repeat:no-repeat\">";
echo "<br><br><br>";
echo "<center><img src=\"faleconosco/atencao.gif\" alt=\"\"><p><font color=\"#ff6600\" face=\"Verdana\" size=\"4\">Dados N�o Repassado.<b></b></font></center>";
echo "<br><br><center><a href=\"../mnescola.php\"><img src=\"faleconosco/button_voltar2_.gif\" alt=\"Voltar\" border=\"0\" /></a></center>";
echo "</body></html>";

}

?>
