<?
/*session_start();
if (isset($_SESSION["login_usuario"]))
  {
     $login =  $_SESSION["login_usuario"];
     $nte   =  $_SESSION["nivel_usuario"];
     include ("../funcoes.php");
     echo  saudacoes()."   ". "$login" ."  -  ". $nte."  ".dataextenso();
  }
 else
  {
     		 header("Location: ../login.php");
  }  	 
*/

  include ("../conexao_mysql.php");
 
 include ("../funcoes.php");
$id = $_GET['codigo'];
$sql = "select * from escola where codigo = $id";
$resposta = mysql_query( $sql );
while ( $linha = mysql_fetch_array( $resposta )) 
 {


?>
  





<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01//EN"
	"http://www.w3.org/TR/html4/strict.dtd">
<head>
	<title>SEDUC-RO</title>


	<link rel="stylesheet" href="style/forms.css" type="text/css" />
	<link rel="stylesheet" href="estilo.css" type="text/css" />
	<link rel="stylesheet" href="style/menu.css" type="text/css" />

	<link href="tablecloth/tablecloth.css" rel="stylesheet" type="text/css" media="screen" />



	<script type="text/javascript" src="tablecloth/tablecloth.js"></script>
	<script src="lib/jquery-1.4.2.js" type="text/javascript"></script>
	<script src="lib/validate.js" type="text/javascript"></script>
	<script src="lib/forms.js" type="text/javascript"></script>
    <script src="generic.js"    type="text/javascript"></script>
    <script src="lib/jquery.maskedinput-1.1.1.js" type="text/javascript"></script>
    



	<link type="text/css" href="jquery-ui-1.8.18.custom/css/ui-lightness/jquery-ui-1.8.18.custom.css" rel="stylesheet" />	
	<script type="text/javascript" src="jquery-ui-1.8.18.custom/js/jquery-1.7.1.min.js"></script>
	<script type="text/javascript" src="jquery-ui-1.8.18.custom/js/jquery-ui-1.8.18.custom.min.js"></script>




	<meta http-equiv="Content-type" content="text/html; charset=utf-8" />









		<script type="text/javascript">
			$(function(){

				// Accordion
				$("#accordion").accordion({ header: "h3" });
	
				// Tabs
				$('#tabs').tabs();
	

				// Dialog			
				$('#dialog').dialog({
					autoOpen: false,
					width: 600,
					buttons: {
						"Ok": function() { 
							$(this).dialog("close"); 
						}, 
						"Cancel": function() { 
							$(this).dialog("close"); 
						} 
					}
				});
				
				// Dialog Link
				$('#dialog_link').click(function(){
					$('#dialog').dialog('open');
					return false;
				});

				// Datepicker
				$('#datepicker').datepicker({
					inline: true
				});
				
				// Slider
				$('#slider').slider({
					range: true,
					values: [17, 67]
				});
				
				// Progressbar
				$("#progressbar").progressbar({
					value: 20 
				});
				
				//hover states on the static widgets
				$('#dialog_link, ul#icons li').hover(
					function() { $(this).addClass('ui-state-hover'); }, 
					function() { $(this).removeClass('ui-state-hover'); }
				);
				
			});
		</script>






<script src="../script.js"></script>

<script>


	$(function() {
		$( "#txtdtemisao" ).datepicker({
			changeMonth: true,
			changeYear: true
		});
	});

$(function() {
        $("#txtdtemisao").datepicker();
        $('#txtdtemisao').datepicker('option', 'dateFormat', 'dd/mm/yy');
});



	


	$(function() {
		$( "#txtdtvalidade" ).datepicker({
			changeMonth: true,
			changeYear: true
		});
	});

$(function() {
        $("#txtdtvalidade").datepicker();
        $('#txtdtvalidade').datepicker('option', 'dateFormat', 'dd/mm/yy');
});







</script>



</head>
<body>
	<div id="warpper">
		<div id="header">
		    <img src= "img/seduc_topo.jpg"/>
		</div>



			<div id="content">


              <form name ="formalteraescola" action="altera_escola.php" method="post" >



<p>
		<label for="lbldtemissaote">Código<img src= "img/check.gif"/></label>
         <input readonly="true"  name="codigo"  type="text" value="<?echo $id?>">
</p>


<p>
		<label for="lbldtemissaote">INEP<img src= "img/check.gif"/></label>
         <input  name="inep"   readonly="true" size="10" maxlength="10" type="text" value = "<?echo $linha["INEP"];?>" onKeyPress="return Enum(event)"/>
</p>


 <p>
		<label for="lbldtemissaote">Descrição<img src= "img/check.gif"/></label>
        <input  name="descricao" size="40" maxlength="60" type="text" value="<?echo $linha["DESCRICAO"];?>" onBlur=   "maiusculalteracadescola()">
</p>		

 <p>
 <label for="lbldtemissaote">Endereço<img src= "img/check.gif"/></label>
 <input name="endereco" type="text" id="endereco" size="40" MAXLENGTH="60"  value="<?echo $linha["ENDERECO"];?>"    onBlur=   "maiusculalteracadescola()"> 
 </p>
 

 <p>
 <label for="lbldtemissaote">Bairro<img src= "img/check.gif"/></label>
        <input name="bairro" type="text" id="bairro" size="40" MAXLENGTH="40" value="<?echo $linha["BAIRRO"];?>" onBlur=   "maiusculalteracadescola()">
 <label for="lbldtemissaote">N<img src= "img/check.gif"/></label>
	   <input name="nr" type="text" id="nr" size="10" MAXLENGTH="4" value="<?echo $linha["NUMERO"];?>" onKeyPress="return Enum(event)" >
</p>



<p>
 <label for="lbldtemissaote">FONE<img src= "img/check.gif"/></label>
 <input name="fone" type="text" id="fone" size="30" MAXLENGTH="20" 

value="<?echo $linha["FONE"];?>" >
</p>
<p>

<?
$codmuni=$linha["MUNICIPIO"];
$sqlconulta        = "select codigo,descricao from municipio where codigo = $codmuni";
$respconsulta      = mysql_query( $sqlconulta );
while ( $dado = mysql_fetch_array( $respconsulta )) 
{
   $descricao = $dado["descricao"];
   $codigo    = $dado["codigo"];
}
?>
</p>



<P>
 <label for="lbldtemissaote">Nr. de Professores<img src= 

"img/check.gif"/></label>
 <input name="nprofessores" type="text" id="nprofessores" size="10" MAXLENGTH="10" value="<?echo $linha["NPROFESSORES"];?>" onKeyPress="return Enum(event)">
</p>


<P>
 <label for="lbldtemissaote">Nr. de Professor Emergêncial<img src= 

"img/check.gif"/></label>
 <input name="nemergencial" type="text" id="nemergencial" size="10" MAXLENGTH="10" value="<?echo $linha["NEMERGENCIAL"];?>" onKeyPress="return Enum(event)">
</p>


<P>
 <label for="lbldtemissaote">Nr. Servidores Adm<img src= 

"img/check.gif"/></label>
 <input name="nadm" type="text" id="nadm" size="10" MAXLENGTH="10" value="<?echo $linha["NEMERGENCIAL"];?>" onKeyPress="return Enum(event)">
</p>




	
<p>
 <label for="lbldtemissaote">Nr. de Alunos<img src= "img/check.gif"/></label>
  <input name="nalunos" type="text" id="nalunos" size="10" MAXLENGTH="10" value="<?echo $linha["NALUNOS"];?>" onKeyPress="return Enum(event)">
</p>      

	   <p>					
         <label for="lblcod_cpf">Diretor<img src= "img/check.gif"/></label>
         <input name="diretor" type="text" id="diretor" size="40" MAXLENGTH="60" value= "<?echo $linha["DIRETOR"];?>">
       </p>


	   <p>					
         <label for="lblcod_cpf">Vice Diretor<img src= "img/check.gif"/></label>
		 <input name="vicediretor" type="text" id="vicediretor" size="40" maxlength="60" value= "<?echo $linha["VICEDIRETOR"];?>">
       </p>


   <p>  
<label for="lbldtemissaote">Portaria/Decreto<img src= "img/check.gif"/></label>
<input type="text" name="txtportaria" style="width:140px"  id="txtportaria" maxlength="12" value= "<?echo $linha["PORTARIA"];?>" 	>
   </P>  




   <p>					
        			 <label for="regularizacao">Regularização<img src= "img/check.gif"/></label>
 			               <select id="selectregularizacao" name="selectregularizacao" style="width:80px">
              		          <option value="S">Sim</option>
            		          <option value="N">Não</option>
    		               </select>


       </p>




		<p>

						 <label for="regularizacao">Situação<img src= "img/check.gif"/></label>
 		               <select id="selectsituacao" name="selectsituacao" style="width:105px" >
              		          <option value=""></option>
							  <option value="A">Autorizada</option>
            		          <option value="R">Reconhecida</option>
    		               </select>


<label for="lbldtemissaote">Portaria/Decreto<img src= "img/check.gif"/></label>
 <input type="text" name="txtportaria" value="" style="width:140px" id="txtportaria" maxlength="12" value= "<?echo $linha["PORTARIA"];?>">
         </P>  





  <P>

<label for="lbldtemissaote">Data Emissão<img src= "img/check.gif"/></label>
<input type="text" name="txtdtemisao" id="txtdtemisao" readonly="true"    value= "<?echo $linha["DTPORTARIA"];?>" />
</p>


<label for="lbldtemissaote">Data Validade<img src= "img/check.gif"/></label>
<input type="text" name="txtdtvalidade"  id="txtdtvalidade" readonly="true" value= "<?echo $linha["DTVALIDADE"];?>" />
</p>






 <p>
 <label for="lbldtemissaote">Municpio<img src= "img/check.gif"/></label>
 <input  name="municodigo" size="8" type="text" readonly="true" value="<?echo "$codigo";?>">
 <input  name="municipio1" size="30" type="text" readonly="true" value="<?echo "$descricao";?>">
 </p>



<P>
 <label for="lbldtemissaote">Altera Município<img src= "img/check.gif"/></label>

       <?=lista_municipio_Altera();?> 
</P>



<p>
 <label for="lbldtemissaote">ZONA<img src= "img/check.gif"/></label>
  <input  name="zona" size="15" type="text" readonly="true" maxlength="15" value="<?echo $linha["TIPO"];?>">
</p> 
<p>
 <label for="lbldtemissaote">Zona<img src= "img/check.gif"/></label>
	          <select name="tipo" onChange="alteraurnoagenda(this.value)" >
              <option value="">...Selecione Tipo...</option>
              <option value="RURAL">RURAL</option>
              <option value="URBANA">URBANA</option>
            </select>
</p>



        <p>		
		   <label for="lbldeficienten">Fundamental Regular 1 a 5 </label>
    	   

		   <label for="lbldeficienten"><input name="modalidade1" type="checkbox"  value ="1"  id="modalidade1"/> Fundamental Regular 6 a 9<input name="modalidade2" type="checkbox"  value ="2"  id="modalidade2" /></label>
 		   

		  <label for="lbldeficienten">Fundamental Regular 1 a 9<input name="modalidade3" type="checkbox"  value ="3"  id="modalidade3"  /></label>
			  

		  <label for="lbldeficienten">Fundamental EJA<input name="modalidade4" type="checkbox"  value ="4"  id="modalidade4" /></label>
		    

      </p>

  
     <p>		
  <label for="lbldeficienten">Ensino Médio Regular</label>
  <label for="lbldeficienten"><input name="modalidade5" type="checkbox"  value ="5"  id="modalidade5" />Ensino Médio EJA<input name="modalidade6" type="checkbox"  value ="6"  id="modalidade6"  ></label>

<label for="lbldeficienten">Educação Especial  <input name="modalidade7" type="checkbox"  value ="7"  id="modalidade7"/ ></label>
  </p>

<?
}

?>

					<p id="finish">
            <input type="submit" value="Gravar" onClick="javascript:return validatransicao();"  />
            <input type="reset" value="limpar" />
					</p>
				</form>
			</div>
		</div>
	</div>
</body>

