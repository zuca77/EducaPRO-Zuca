<?php


session_start();
if (isset($_SESSION["login_usuario"]))
  {
     $login =  $_SESSION["login_usuario"];
     $nte   =  $_SESSION["nivel_usuario"];
     include ("../funcoes.php");
     echo  saudacoes()."   ". "$login" ."  -  ". $nte."  ".dataextenso();
  }
 else
  {
     		 header("Location: ../login.php");
  }


if(file_exists("../conexao_mysql.php")) 
{
        require "../conexao_mysql.php";             
        mysql_query("SET NAMES 'utf8'");
       $ano  = date("Y");		             

} else 
{
        echo "Conexo nao foi encontrado";
        exit;
}

?>

<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01//EN"
	"http://www.w3.org/TR/html4/strict.dtd">
<head>
	<meta http-equiv="Content-type" content="text/html; charset=utf-8" />
	<title>SEDUC-RO</title>
	<link rel="stylesheet" href="style/forms.css" type="text/css" />
	<link rel="stylesheet" href="estilo.css" type="text/css" />
	<link rel="stylesheet" href="style/menu.css" type="text/css" />

	
	<link href="tablecloth/tablecloth.css" rel="stylesheet" type="text/css" media="screen" />
	
	<script type="text/javascript" src="tablecloth/tablecloth.js"></script>
	<script src="lib/jquery-1.4.2.js" type="text/javascript"></script>
	<script src="lib/validate.js" type="text/javascript"></script>
	<script src="lib/forms.js" type="text/javascript"></script>
<!--	<script src="genericlota.js" type="text/javascript"></script>-->
	<script src="generic.js" type="text/javascript"></script>
    <script src="lib/jquery.maskedinput-1.1.1.js" type="text/javascript"></script>


	<link type="text/css" href="jquery-ui-1.8.18.custom/css/ui-lightness/jquery-ui-1.8.18.custom.css" rel="stylesheet" />
<!--	<script type="text/javascript" src="jquery-ui-1.8.18.custom/js/jquery-1.7.1.min.js"></script>-->
	<script type="text/javascript" src="jquery-ui-1.8.18.custom/js/jquery-ui-1.8.18.custom.min.js"></script>





<script type="text/javascript">


$(function() {
		$( "#txtdtlota11" ).datepicker({
			changeMonth: true,
			changeYear: true
		});
	});

$(function() {
        $("#txtdtlota11").datepicker();
        $('#txtdtlota11').datepicker('option', 'dateFormat', 'dd/mm/yy');
});

</script>


</head>
<body>
	<div id="warpper">
		<div id="header">
		    <img src= "../escola/img/seduc_topo.jpg"/>

		</div>
    <div id="container">
			<div id="content">

				<form  name="form" class="form" action="insere_lotacao.php" method="POST">
				 <div id="tema"> 
					   <p><center>Lotacao</center></p>
				  </div>

<?php

$id = $_GET['codigo'];




$sqlmemo="select * from memo where id = $id";
$resultadomemo=mysql_query($sqlmemo) or die (mysql_error());
$linhasmemo=mysql_num_rows($resultadomemo);

if($linhasmemo>0)
{
   while($pegarmemo=mysql_fetch_array($resultadomemo))
   {

      $cpfmemo          =$pegarmemo["CPF"];
      $matricula        =$pegarmemo["MATRICULA"];
      $lotaintcap       =$pegarmemo["LOTAINTCAP"];
      $lotaadmesc       =$pegarmemo["LOTAADMESC"];
      $cod_estado       =$pegarmemo["MUNILOTA"];

   }
}  


if ($lotaintcap=='I')
    $lotaintcap ='INTERIOR';
else	
   $lotaintcap ='CAPITAL';


if ($lotaadmesc=='A')
    $lotaadmesc ='ADM';
else	
   $lotaadmesc ='ESCOLA';


/******************Municipio*************************************************/
	$sqlgerencia = "SELECT codigo, descricao FROM municipio where codigo='$cod_estado'";
    $resultadoger=mysql_query($sqlgerencia) or die (mysql_error());
    $linhas   =mysql_num_rows($resultadoger);

if($linhas>0)
{
   while($pegar=mysql_fetch_array($resultadoger))
	{
    	$munilota    =$pegar["descricao"]; 	
	}
 }	
/*******************************************************************/








$sqldados="select * from servidorrec where cpf = '$cpfmemo'";
$resultadodados=mysql_query($sqldados) or die (mysql_error());
$linhasdados=mysql_num_rows($resultadodados);

if($linhasdados>0)
{
   while($pegardados=mysql_fetch_array($resultadodados))
   {
       $cpf                =$pegardados["cpf"];
	$nome               =$pegardados["nome"];
	$mae                =$pegardados["mae"]; 	
       $pai                =$pegardados["pai"]; 	
	$endereco           =$pegardados["endereco"]; 	
	$bairro             =$pegardados["bairro"]; 	
	$fonesetor          =$pegardados["fonesetor"]; 	
	$fonecontato        =$pegardados["fonecontato"]; 	
	$foneresidencial    =$pegardados["foneresidencial"]; 	
	$celular            =$pegardados["celular"]; 	
	$email              =$pegardados["email"]; 	
	$txtcep             =$pegardados["cep"];
	$txtnr              =$pegardados["numero"];
    }
  }

?>
	
	
					<p>
						<label for="txtCPF">CPF<img src= "img/check.gif"/></label>
						<input type="text" name="cpf" style="width:110px"  maxlength="11" id="cpf"  value= "<?= $cpf; ?>"  readonly="true"/>

					</p>
	

					<p>
						<label for="txtNome">Nome</label>
						<input type="text" name="txtNome" style="width:565px" maxlength="60" value= "<?= $nome; ?>" id="txtNome" readonly="true"/>
					</p>
					
					<p>
						<label for="lblmae">Nome M�e</label>
						<input type="text" name="txtmae" style="width:565px" maxlength="60" value= "<?= $mae; ?>" id="txtmae" readonly="true"/>
					</p>
					<p>
						<label for="lblpai">Nome Pai</label>
						<input type="text" name="txtpai" style="width:565px" maxlength="60" value= "<?= $pai; ?>" id="txtpai"  readonly="true"/>
					</p>


					<p>
						<label for="lblEndereco">Endere�o</label>
						<input type="text" name="txtEndereco" style="width:565px" value= "<?= $endereco; ?>"  maxlength="60" size="60" id="txtEndereco" readonly="true"/>
					</p>

					<p>
						<label for="lblEndereco">Complemento</label>
						<input type="text" name="txtcomplemento" style="width:565px" value= "<?= $bairro; ?>"  maxlength="40" size="60" id="txtcomplemento" readonly="true"/>
					</p>


					<p>
						<label for="lblBairro">Bairro</label>
						<input type="text" name="txtBairro" value= "<?= $bairro; ?>" id="txtBairro"  maxlength="40" readonly="true"/>
						<label for="lblBairro">N.</label>
						<input type="text" name="txtnr" style="width:60px" value= "<?= $txtnr; ?>" id="txtnr" maxlength="5" readonly="true"/>
			                     <label for="txtCEP">CEP</label>
            			<input id="txtcep" name="txtcep" type="text" style="width:90px" value= "<?= $txtcep; ?>" maxlength="8" onKeyPress="return Enum(event)" readonly="true"/>
					</p>
					<p>
						<label for="txtFoneSetor">Telefone Comercial</label>
						<input type="text" name="txtFoneSetor" style="width:90px" value= "<?= $fonesetor; ?>" id="txtFoneSetor"  maxlength="20" readonly="true"/>
						<label for="txtFoneRes">Residencial</label>
						<input type="text" name="txtFoneRes" style="width:90px" value= "<?= $foneresidencial; ?>" id="txtFoneRes" maxlength="20" readonly="true"/>
						<label for="txtCelular">Celular</label>
						<input type="text" name="txtCelular" style="width:90px" value= "<?= $celular; ?>" id="txtCelular" maxlength="20" readonly="true"/>
						<label for="txtCelular">Contato</label>
						<input type="text" name="txtcontato" style="width:90px" value= "<?= $fonecontato; ?>" id="txtcontato" maxlength="25" readonly="true"/>

					</p>
					<p>
						<label for="txtEmail">E-mail</label>
						<input type="text" name="txtEmail" style="width:565px" value= "<?= $email; ?>" id="txtEmail" maxlength="80" readonly="true"/>
					</p>

					<p>
						<label for="txtEmail">Matricula</label>
						<input type="text" name="txtmatricula" style="width:150px" value= "<?= $matricula; ?>" id="txtmatricula" maxlength="80" readonly="true"/>
					</p>
					
					<p>
						<label for="txtEmail">Lota��o</label>
						<input type="text" name="txtlotaintcap" style="width:150px" value= "<?= $lotaintcap; ?>" id="txtlotaintcap" maxlength="80" readonly="true"/>
						<label for="txtEmail">Tipo</label>
						<input type="text" name="txtlotaintcap" style="width:150px" value= "<?= $lotaadmesc; ?>" id="txtlotaintcap" maxlength="80" readonly="true"/>

						<label for="txtEmail">Munic�pio</label>
						<input type="text" name="txtmunilota" style="width:150px" value= "<?= $munilota; ?>" id="txtmunilota" maxlength="80" readonly="true"/>


					</p>

 <p>
	<label for="lblMatricula">Memorando<img src= "img/check.gif"/></label>
    <input name="txtMemo" type="text" id="txtMemo" style="width:120px" title = "Campo Obrigatrio. Informe o número do memrando." MAXLENGTH="10" />
<label for="lblMatricula">Ano</label>
<input type="text" name="txtano" style="width:40px"  maxlength="60" value= "<?= $ano; ?>" id="txtano"  readonly="true"/>
<label for="lblMatricula">ID</label>
    <input name="txtMemor" type="text" id="txtMemor" style="width:120px" title = "Campo Obrigatrio. Informe o número do memrando." MAXLENGTH="10" value= "<?= $id; ?>"  readonly="true"/>

</p>



					   <p>
	  					<label for="lblqtda">Lotado<img src= "img/check.gif"/></label>
 			                <select id="selectlotacao1" name="selectlotacao1" style="width:200px" />	
						    <option value="">...Selecione Lota��o...</option>
              		          <option value="1">ADMINISTRACAO</option>
            		          <option value="2">ESCOLA</option>
    		               </select>
    	       		     </p>

			      <p>
					<label for="lblgerencia">Ger�ncia<img src= "img/check.gif" /></label>
						<select name="txtgerencia" id="txtgerencia"  style="width:400px" disabled="disabled" >
						<option value="">...Selecione Administra��o..</option>
					<?php
            				include ("../conexao_mysql.php");
							$sql = "SELECT codigo, descricao
									FROM gerencia
									ORDER BY descricao";
				     		$res = mysql_query( $sql );
							while ( $row = mysql_fetch_assoc( $res ) ) {
							echo '<option value="'.$row['codigo'].'">'.$row['descricao'].'</option>';
						}
					?>
					</select>

		       </p>
			
			
			<p>
          		<label for="lbldpto">Departamento<img src= "img/check.gif"/></label>
	         	<!--	<span class="carregando">Aguarde, carregando...</span>-->
		          <select name="txtdpto" id="txtdpto" style="width:400px" disabled="disabled">
			           <option value="">-- Escolha Departamento --</option>
            	 </select>
				 
			
	</p>		

           <p>
			  	<label for="selectcontrato3">Escola(s)<img src= "img/check.gif"/></label>
 			    <select id="selectqtdaescola" name="selectqtdaescola" style="width:40px" disabled="disabled">
                   <option value="0">0</option>
                   <option value="1">1</option>
    		     </select>

           </p>

           <p>
				<label for="lblinep1">INEP<img src= "img/check.gif"/></label>
				<input type="text" name="txtinep1" value="" style="width:90px" maxlength="8" id="txtinep1" disabled="disabled" onKeyPress="return Enum(event)"/>


          		   <label for="lbldesescola">Escola</label>
         		   <span class="carregando">Aguarde, carregando...</span>
		             <select name="txtdescescola1" id="txtdescescola1" style="width:350px">
			           <option value="">-- Informe o INEP --</option>
            	    </select>
			</p>


              <p>
						<label for="txtdtlotacao1">Data Lota��o<img src= "img/check.gif"/></label>
						<input type="text" name="txtdtlota11" value="" style="width:70px" id="txtdtlota11" />		



						<label for="selectcontrato1">CH<img src= "img/check.gif"/></label>
 			                <select id="selectch1lota" name="selectch1lota" style="width:40px"  disabled="disabled">
              		          <option value="0">0</option>
              		          <option value="40">40</option>
            		          <option value="25">25</option>
            		          <option value="20">20</option>
    		               </select>

						<label for="lblqtdaaula1">Qtda Aulas<img src= "img/check.gif"/></label>
						<input type="text" name="txtqdtaaulas1" value="0" style="width:30px" id="txtqdtaaulas1" maxlength="2" disabled="disabled"  onKeyPress="return Enum(event)"/>
                  </p>
                  <p>

					<label for="lblareaatuacao1">Area de Atua��o</label>
						<select name="txtautacao1" id="txtautacao1"  style="width:300px" >
						<option value="">Selecione Area de Atua��o</option>
					<?php
							include ("../conexao_mysql.php");
							$sql = "SELECT codigo, descricao
									FROM habilitacao
									ORDER BY descricao";
				     		$res = mysql_query( $sql );
							while ( $row = mysql_fetch_assoc( $res ) ) {
							echo '<option value="'.$row['codigo'].'">'.$row['descricao'].'</option>';
						}
	
					?>
					</select>
			</p>





   <p> 

     		<label for="regularizacao">Obs.<img src= "img/check.gif"/></label>
 			<textarea name = "txtobs"   cols="100" rows = "10" id = "txtobs"  type = "text"  onkeyup="blocTexto(txtobs.value)"></textarea>
  </p> 








					

				<p id="finish">
            <input type="button" value=" Voltar " onclick="history.go(-1);">            
            <input type="submit" value="Gravar" />
            <input type="reset" value="limpar" />
					</p>

<? 


?>


				</form>
			</div>
		</div>



      <script>
     <!--  cor_tabela("tabzebra");-->
    </script>
 </div><!-- Div corpodetalhe-->
</div><!-- Div corpo2-->

<?
  mysql_close($conexao);
?>				
  <div id="rodapeconsulta" class="fonterodape">
</div>
		<div id="footer">
			<p>Todos direitos reservados GTI/SEDUC</p>
		</div>
	</div>
</body>

