
	 /* Autor : Paulo Eduardo
	 * Data  : 30.04.2012 
	 * Analista : Paulo Eduardo
	 * Programador : Paulo Eduardo

*/

$(document).ready(function() {
	$('#toggle').click(function() {
		$('#hidden').toggle(400);
  	return false;
	});

  $(".form").validate({
	          rules:{
              descricao:{required: true,},
			  tipo:{required: true,},
			  endereco:{required: true,},
			  bairro:{required: true,},
			  nr:{required: true,},
			  txtcep:{required: true,},
			  fone:{required: true,},
			  nprofessores:{required: true,},
			  nemergencial:{required: true,},			 
			  nadm:{required: true,},			 
			  nalunos:{required: true,},			 
			  diretor:{required: true,},			 
			  vicediretor:{required: true,},			 
			  selectregularizacao:{required: true,},			 			  
			  selectsituacao:{required: true,},			 			  
			  txtdtemissao: {required: true, dateBR: true},
			  txtdtvalidade: {required: true, dateBR: true},
              cod_estado:{required: true,},			 			       
			  txtdtmandatof: {required: true, dateBR: true},
	     	  txtdtmandatoi: {required: true, dateBR: true},
	     	  txtdtregistro: {required: true, dateBR: true},
              selectstatuspatri:{required: true,},			 			       
			  selectstatusqd: {required: true,},			 			       
	     	  selectcoberta: {required: true,},			 			       
	     	  selectstatus: {required: true,},
			  cnpj:  {cnpj: true},		 			  

	     	  tipoe: {required: true,},
	     	  txtpresidente: {required: true,},
	     	  txtsuplente: {required: true,},
	     	  txtsegmento1_de: {required: true,},
	     	  txtsecretario1_de: {required: true,},
	     	  txtsuplente1_de: {required: true,},
	     	  txtsegmento2_de: {required: true,},			  
	     	  txtsecretario2_de: {required: true,},			  
	     	  txtsuplente2_de: {required: true,},			  
	     	  txtconselheiro1_cap: {required: true,},
	     	  txtsuplente1_cap: {required: true,},
	     	  txtconselheiro2_cap: {required: true,},
	     	  txtsuplente2_cap: {required: true,},
	     	  txtconselheiro3_cap: {required: true,},
	     	  txtsuplente3_cap: {required: true,},
	     	  txtconselheiro4_cap: {required: true,},			  
	     	  txtsuplente4_cap: {required: true,},			  
	     	  txttesoureiro1_cef: {required: true,},			  
	     	  txtsuplentetesouro: {required: true,},
	     	  txtconselheiro1_cef: {required: true,},
	     	  txtsuplente1_cef: {required: true,},
	     	  txtconselheiro2_cef: {required: true,},
	     	  txtsuplente3_cef: {required: true,},
	     	  txtconselheiro3_cef: {required: true,},
	     	  txtsuplente3_cef: {required: true,},			  
	     	  txtconselheiro1_cf: {required: true,},			  
	     	  txtsuplente1_cf: {required: true,},			  


	     	  txtconselheiro2_cf: {required: true,},
	     	  txtsuplente2_cf: {required: true,},
	     	  txtconselheiro3_cf: {required: true,},
	     	  txtsuplente3_cf: {required: true,},
	     	  txtconselheiro4_cf: {required: true,},
	     	  txtsuplente4_cf: {required: true,},


},
  messages:{

			  descricao:{required:"Campo Obrigatorio. Informe o Nome da Escola",},
			  tipo:{required:"Campo Obrigatorio. Informe Se Sua Escola e Urbana ou Rural",},
			  endereco:{required:"Campo Obrigatorio. Informe o Endereço",},
              bairro:{required:"Campo Obrigatorio. Informe o Bairro",},
			  nr:{required:"Campo Obrigatorio. Informe o Numero",},
			  txtcep:{required:"Campo Obrigatorio. Informe CEP",},
			  fone:{required:"Campo Obrigatorio. Informe o Telefone da Escola",},
			  nprofessores:{required:"Campo Obrigatorio. Informe Total de Professores",},
			  nemergencial:{required:"Campo Obrigatorio. Informe Total Servidores Emergênciais",},
			  nadm:{required:"Campo Obrigatorio. Informe o número de Servidores Administrativos",},
			  nalunos:{required:"Campo Obrigatorio. Informe o Total de Alunos Matriculados ",},
			  diretor:{required:"Campo Obrigatorio. Informe o Nome do Diretor",},
			  vicediretor:{required:"Campo Obrigatorio. Informe o do Vice Diretor",},
			  selectregularizacao:{required:"Campo Obrigatorio. Informe a situação da escola",},
			  selectsituacao:{required:"Campo Obrigatorio. Informe a situação da escola",},
		      txtdtemissao: {required: 'Informe a data', dateBR: 'Digite uma data válida'},
			  txtdtvalidade: {required: 'Informe a data', dateBR: 'Digite uma data válida'}, 
			  cod_estado:{required:"Campo Obrigatorio. Informe o Municipio de Sua Escola",},
			  txtdtmandatof: {required: 'Informe a data', dateBR: 'Digite uma data válida'}, 
			  txtdtmandatoi: {required: 'Informe a data', dateBR: 'Digite uma data válida'}, 
			  txtdtregistro: {required: 'Informe a data', dateBR: 'Digite uma data válida'}, 
			  selectsituacao:{required:"Campo Obrigatorio. Informe a situação da escola",},
			  selectstatuspatri:{required:"Campo Obrigatorio. Informe a situação do patrimonio",},
			  selectstatusqd:{required:"Campo Obrigatorio. Informe a situação da quadra",},
			  selectcoberta:{required:"Campo Obrigatorio. Informe se a quadra e coberta ou não",},
			  selectstatus:{required:"Campo Obrigatorio. Informe o status do acervo bibliografico",},			  
	          cnpj: {cnpj: 'CNPJ inválido'},

	     	  tipoe:{required:"Campo Obrigatorio. Informe o tipo de eleicao",},			  
	     	  txtpresidente:{required:"Campo Obrigatorio. Informe o presidente",},			  
	     	  txtsuplente:{required:"Campo Obrigatorio. Informe o suplente",},			  
	     	  txtsegmento1_de:{required:"Campo Obrigatorio. Informe o segmento",},			  
	     	  txtsecretario1_de:{required:"Campo Obrigatorio. Informe o 1 secretario",},			  
	     	  txtsuplente1_de:{required:"Campo Obrigatorio. Informe o 1 suplente",},			  
	     	  txtsegmento2_de:{required:"Campo Obrigatorio. Informe o segmento",},			  
	     	  txtsecretario2_de:{required:"Campo Obrigatorio. Informe o secretario",},			  
	     	  txtsuplente2_de:{required:"Campo Obrigatorio. Informe o suplente",},			  
	     	  txtconselheiro1_cap:{required:"Campo Obrigatorio. Informe o 1 conselheiro",},			  
	     	  txtsuplente1_cap:{required:"Campo Obrigatorio. Informe o suplente",},			  
	     	  txtconselheiro2_cap:{required:"Campo Obrigatorio. Informe o conselheiro",},			  
	     	  txtsuplente2_cap:{required:"Campo Obrigatorio. Informe o suplente",},			  
	     	  txtconselheiro3_cap:{required:"Campo Obrigatorio. Informe o conselheiro",},			  
	     	  txtsuplente3_cap:{required:"Campo Obrigatorio. Informe o suplente",},			  
	     	  txtconselheiro4_cap:{required:"Campo Obrigatorio. Informe o conselheiro",},			  
	     	  txtsuplente4_cap:{required:"Campo Obrigatorio. Informe o suplemte",},			  
	     	  txttesoureiro1_cef:{required:"Campo Obrigatorio. Informe o tesoureiro",},			  
	     	  txtsuplentetesouro:{required:"Campo Obrigatorio. Informe o suplente",},			  
	     	  txtconselheiro1_cef:{required:"Campo Obrigatorio. Informe o conselheiro",},			  
	     	  txtsuplente1_cef:{required:"Campo Obrigatorio. Informe o suplente",},			  
	     	  txtconselheiro2_cef:{required:"Campo Obrigatorio. Informe o conselheiro",},			  
	     	  txtsuplente3_cef:{required:"Campo Obrigatorio. Informe o suplente",},			  
	     	  txtconselheiro3_cef:{required:"Campo Obrigatorio. Informe o conselheiro",},			  
	     	  txtsuplente3_cef:{required:"Campo Obrigatorio. Informe o suplente",},			  
	     	  txtconselheiro1_cf:{required:"Campo Obrigatorio. Informe o conselheiro",},			  
	     	  txtsuplente1_cf:{required:"Campo Obrigatorio. Informe o suplente",},			  
	     	  txtconselheiro2_cf: {required:"Campo Obrigatorio. Informe o conselheiro",},			  
	     	  txtsuplente2_cf: {required:"Campo Obrigatorio. Informe o suplente",},			  
	     	  txtconselheiro3_cf: {required:"Campo Obrigatorio. Informe o conselheiro",},			  
	     	  txtsuplente3_cf: {required:"Campo Obrigatorio. Informe o suplente",},			  
	     	  txtconselheiro4_cf: {required:"Campo Obrigatorio. Informe o conselheiro",},			  
	     	  txtsuplente4_cf: {required:"Campo Obrigatorio. Informe o suplente",},

		}
 });
 });


/*maiuscula*/
$(document).ready(function() {
  $("input").keyup(function(){
    $(this).val($(this).val().toUpperCase());
     })
}) 




function Enum(num){  

 var tecla = num.which;
//alert(tecla);
if (document.all)
    var tecla = event.keyCode;
else if(document.layers)
  var tecla = num.which;
		
 //alert(tecla);
if (((tecla > 47) && (tecla < 58)) || (tecla == 0) || (tecla == 46))  {
   return true;
  }
else
 {
   if (tecla == 8)
    	 return true
   if (tecla != 8)
    	 return false
   else
    	 return false;
  }
}




jQuery(function($){
   $("#txtdtvalidade").mask("99/99/9999");
   $("#fone").mask("(99) 9999-9999");
   $("#txtdtemissao").mask("99/99/9999"); 

   $("#txtdtmandatof").mask("99/99/9999"); 
   $("#txtdtmandatoi").mask("99/99/9999"); 
   $("#txtdtregistro").mask("99/99/9999"); 
   $("#cnpj").mask("99.999.999/9999-99"); 
});




			$(function(){

				// Accordion
				$("#accordion").accordion({ header: "h3" });
	
				// Tabs
				$('#tabs').tabs();
	

				// Dialog			
				$('#dialog').dialog({
					autoOpen: false,
					width: 600,
					buttons: {
						"Ok": function() { 
							$(this).dialog("close"); 
						}, 
						"Cancel": function() { 
							$(this).dialog("close"); 
						} 
					}
				});
				
				// Dialog Link
				$('#dialog_link').click(function(){
					$('#dialog').dialog('open');
					return false;
				});

				// Datepicker
				$('#datepicker').datepicker({
					inline: true
				});
				
				// Slider
				$('#slider').slider({
					range: true,
					values: [17, 67]
				});
				
				// Progressbar
				$("#progressbar").progressbar({
					value: 20 
				});
				
				//hover states on the static widgets
				$('#dialog_link, ul#icons li').hover(
					function() { $(this).addClass('ui-state-hover'); }, 
					function() { $(this).removeClass('ui-state-hover'); }
				);
				
			});







	$(function() {
		$( "#txtdtemissao" ).datepicker({
			changeMonth: true,
			changeYear: true
		});
	});

$(function() {
        $("#txtdtemissao").datepicker();
        $('#txtdtemissao').datepicker('option', 'dateFormat', 'dd/mm/yy');
});




$(function() {
		$( "#txtdtmandatof" ).datepicker({
			changeMonth: true,
			changeYear: true
		});
	});

$(function() {
        $("#txtdtmandatof").datepicker();
        $('#txtdtmandatof').datepicker('option', 'dateFormat', 'dd/mm/yy');
});




$(function() {
		$( "#txtdtmandatoi" ).datepicker({
			changeMonth: true,
			changeYear: true
		});
	});

$(function() {
        $("#txtdtmandatoi").datepicker();
        $('#txtdtmandatoi').datepicker('option', 'dateFormat', 'dd/mm/yy');
});


$(function() {
		$( "#txtdtregistro" ).datepicker({
			changeMonth: true,
			changeYear: true
		});
	});

$(function() {
        $("#txtdtregistro").datepicker();
        $('#txtdtregistro').datepicker('option', 'dateFormat', 'dd/mm/yy');
});













jQuery.validator.addMethod("cnpj", function(cnpj, element) {

	
	
	cnpj = jQuery.trim(cnpj);// retira espaços em branco
    // DEIXA APENAS OS NÚMEROS

	cnpj = cnpj.replace('/','');
    cnpj = cnpj.replace('.','');
    cnpj = cnpj.replace('.','');
    cnpj = cnpj.replace('-','');
  
    var numeros, digitos, soma, i, resultado, pos, tamanho, digitos_iguais;
    digitos_iguais = 1;
 
   if (cnpj.length < 14 && cnpj.length < 15){
      return false;
   }
   for (i = 0; i < cnpj.length - 1; i++){
      if (cnpj.charAt(i) != cnpj.charAt(i + 1)){
         digitos_iguais = 0;
         break;
      }
   }
 
   if (!digitos_iguais){
      tamanho = cnpj.length - 2
      numeros = cnpj.substring(0,tamanho);
      digitos = cnpj.substring(tamanho);
      soma = 0;
      pos = tamanho - 7;
 
      for (i = tamanho; i >= 1; i--){
         soma += numeros.charAt(tamanho - i) * pos--;
         if (pos < 2){
            pos = 9;
         }
      }
      resultado = soma % 11 < 2 ? 0 : 11 - soma % 11;
      if (resultado != digitos.charAt(0)){
         return false;
      }
      tamanho = tamanho + 1;
      numeros = cnpj.substring(0,tamanho);
      soma = 0;
      pos = tamanho - 7;
      for (i = tamanho; i >= 1; i--){
         soma += numeros.charAt(tamanho - i) * pos--;
         if (pos < 2){
            pos = 9;
         }
      }
      resultado = soma % 11 < 2 ? 0 : 11 - soma % 11;
      if (resultado != digitos.charAt(1)){
         return false;
      }
      return true;
   }else{
      return false;
   }
}, "Informe um CNPJ válido."); // Mensagem padrão 






/*

 
 
 
 
 
 
 
/* $(document).ready(function(){
 
   // CONFIGURA A VALIDACAO DO FORMULARIO
 /* 
 
 $("#form").validate({
      rules: {
         cnpj: {cnpj: true}
      },
      messages: {
         cnpj: { cnpj: 'CNPJ inválido'}
      }
      ,submitHandler:function(form) {
         alert('ok');
      }
   });
   $('#result').html('jQuery Validate com novos métodos: cpf, cnpj, dateBR e dateTimeBR');
});
 

 jQuery.validator.addMethod("cnpj", function(cnpj, element) {
    cnpj = jQuery.trim(cnpj);// retira espaços em branco
    // DEIXA APENAS OS NÚMEROS
    cnpj = cnpj.replace('/','');
    cnpj = cnpj.replace('.','');
    cnpj = cnpj.replace('.','');
    cnpj = cnpj.replace('-','');
  
    var numeros, digitos, soma, i, resultado, pos, tamanho, digitos_iguais;
    digitos_iguais = 1;
 
   if (cnpj.length < 14 && cnpj.length < 15){
      return false;
   }
   for (i = 0; i < cnpj.length - 1; i++){
      if (cnpj.charAt(i) != cnpj.charAt(i + 1)){
         digitos_iguais = 0;
         break;
      }
   }
 
   if (!digitos_iguais){
      tamanho = cnpj.length - 2
      numeros = cnpj.substring(0,tamanho);
      digitos = cnpj.substring(tamanho);
      soma = 0;
      pos = tamanho - 7;
 
      for (i = tamanho; i >= 1; i--){
         soma += numeros.charAt(tamanho - i) * pos--;
         if (pos < 2){
            pos = 9;
         }
      }
      resultado = soma % 11 < 2 ? 0 : 11 - soma % 11;
      if (resultado != digitos.charAt(0)){
         return false;
      }
      tamanho = tamanho + 1;
      numeros = cnpj.substring(0,tamanho);
      soma = 0;
      pos = tamanho - 7;
      for (i = tamanho; i >= 1; i--){
         soma += numeros.charAt(tamanho - i) * pos--;
         if (pos < 2){
            pos = 9;
         }
      }
      resultado = soma % 11 < 2 ? 0 : 11 - soma % 11;
      if (resultado != digitos.charAt(1)){
         return false;
      }
      return true;
   }else{
      return false;
   }
}, "Informe um CNPJ válido."); // Mensagem padrão 
*/