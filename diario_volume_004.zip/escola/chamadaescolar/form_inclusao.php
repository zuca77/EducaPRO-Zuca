<?php
/*session_start();
if (isset($_SESSION['cpf']))
  {
     $login =  $_SESSION['cpf'];
     $nome   =  $_SESSION['nome'];
     $unidade   =   $_SESSION['unidade'];
     include ("../funcoes.php");

     echo  saudacoes()."   ". "$login" ."  -  ". $nome."  ".dataextenso()." - ".$unidade;
  }
 else
  {
     		 header("Location: ../../login.php");
  }
  */

include ("../../conexao_mysql.php");

if(file_exists("../../conexao_mysql.php"))
{
        require "../../conexao_mysql.php";

} else
{
        echo "Conex�o nao foi encontrado";
        exit;
}

     include ("../funcoes.php");
?>

<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01//EN"
	"http://www.w3.org/TR/html4/strict.dtd"><head>

    <meta http-equiv="content-type" content="text/html; charset=ISO-8859-1" />

	<title>Gerencia de Tecnologia da Informa��o</title>
	
	
	
	<link rel="stylesheet" href="style/forms.css" type="text/css" />
	<link rel="stylesheet" href="estilo.css" type="text/css" />
	<link rel="stylesheet" href="style/menu.css" type="text/css" />
	<link href="tablecloth/tablecloth.css" rel="stylesheet" type="text/css" media="screen" />


	
	<script type="text/javascript" src="tablecloth/tablecloth.js"></script>
	<script src="lib/jquery-1.4.2.js" type="text/javascript"></script>
	<script src="lib/validate.js" type="text/javascript"></script>
	<script src="lib/forms.js" type="text/javascript"></script>
	<script src="generic1.js" type="text/javascript"></script>
    <script src="lib/jquery.maskedinput-1.1.1.js" type="text/javascript"></script>



 	<link type="text/css" href="jquery-ui-1.8.18.custom/css/ui-lightness/jquery-ui-1.8.18.custom.css" rel="stylesheet" />
	<script type="text/javascript" src="jquery-ui-1.8.18.custom/js/jquery-ui-1.8.18.custom.min.js"></script>


<script src="script.js"></script>

<script>
function pesquisa(form)
{

  var valor = document.form.txtturma.value;
  url="busca_kit.php?valor="+valor;
  ajax(url);
}
</script>



<script>
	$(function() {
		$( "#txtdtnascimento" ).datepicker({
			changeMonth: true,
			changeYear: true
		});
	});

$(function() {
        $("#txtdtnascimento").datepicker();
        $('#txtdtnascimento').datepicker('option', 'dateFormat', 'dd/mm/yy');
});




$(function() {
		$( "#txtdtemissaorgpai" ).datepicker({
			changeMonth: true,
			changeYear: true
		});
	});

$(function() {
        $("#txtdtemissaorgpai").datepicker();
        $('#txtdtemissaorgpai').datepicker('option', 'dateFormat', 'dd/mm/yy');
});



$(function() {
		$( "#txtdtemissaorgmae" ).datepicker({
			changeMonth: true,
			changeYear: true
		});
	});

$(function() {
        $("#txtdtemissaorgmae").datepicker();
        $('#txtdtemissaorgmae').datepicker('option', 'dateFormat', 'dd/mm/yy');
});









</script>




</head>
<body>
	<div id="warpper">
		<div id="header">
            <center>
           <img src= "../img/chamadaescolar.jpg"/>
            </center>
		</div>
    <div id="container">
			<div id="content">

				<form  name="form" class="form" action="insere_dados.php" method="POST">
				 <div id="tema"> 
					   <p><center>Chamada Escolar - 2013</center></p>
				  </div>

			

					<p>
						<label for="lblpai">Nome do Aluno<img src= "../img/check.gif"/></label>
						<input type="text" name="txtnaluno" style="width:565px" maxlength="100" value="" id="txtnaluno" />
					</p>

					<p>
						<label for="lbldtnascimento">Data Nascimento<img src= "../img/check.gif"/></label>
						<input type="text" name="txtdtnascimento" value="" style="width:70px" maxlength="10" id="txtdtnascimento" />


						<label for="selectsexo">Sexo<img src= "../img/check.gif"/></label>
 			               <select id="selectsexo" name="selectsexo" style="width:140px">
              		          <option value="">-Selecione o Sexo-</option>
              		          <option value="M">Masculino</option>
            		          <option value="F">Feminino</option>
    		               </select>
					</p>



 				 	<p>
						<label for="lblBairro">N da Certid�o Nascimento<img src= "../img/check.gif"/></label>
						<input type="text" name="txtcertidao" value="" id="txtcertidao" maxlength="25"/>
						<label for="lblBairro">Folha n<img src= "../img/check.gif"/></label>
						<input type="text" name="txtfolha" style="width:60px" value="" id="txtfolha"  maxlength="5"/>
			            <label for="txtCEP">Livro n<img src= "../img/check.gif"/></label>
            			<input id="txtlivro" name="txtlivro" type="text" style="width:90px" maxlength="8" onKeyPress="return Enum(event)"/>
					</p>
                    					<p>

					<label for="cod_estados">Naturalidade - Estado:<img src= "../img/check.gif"/></label>
						<select name="cod_estado" id="cod_estado">
						<option value=""></option>
					<?php
							$sql = "SELECT cod_estados, sigla
									FROM estados
									ORDER BY sigla";
				     		$res = mysql_query( $sql );
							while ( $row = mysql_fetch_assoc( $res ) ) {
							echo '<option value="'.$row['cod_estados'].'">'.$row['sigla'].'</option>';
						}

					?>
					</select>
          		<label for="cod_cidades">Cidade:<img src= "../img/check.gif"/></label>
          		        <select name="cod_cidades" id="cod_cidades">
			           <option value="">-- Escolha um estado --</option>
            	 </select>


		</p>




   					<p>

					<label for="cod_estados" style="width:200px">Selecione a Turma:<img src= "../img/check.gif"/></label>
						<select name="txtturma" id="txtturma" style="width:450px" onBlur = pesquisa(form)>
						<option value=""></option>
					<?php
							$sql = "SELECT id, descricao
									FROM turma
									ORDER BY id";
				     		$res = mysql_query( $sql );
							while ( $row = mysql_fetch_assoc( $res ) ) {
							echo '<option value="'.$row['id'].'">'.$row['descricao'].'</option>';
						}

					?>
					</select>
             		</p>


      	     <!-- AQUI SER� APRESENTADO O RESULTADO DA BUSCA DIN�MICA.. OU SEJA OS NOMES -->
					<p>
                        <div id="pagina">
                        </div>
             		</p>







					<p>
						<label for="lblpai">Nome Pai</label>
						<input type="text" name="txtpai" style="width:565px" maxlength="60" value="" id="txtpai" />
					</p>



					<p>
						<label for="txtRG">RG</label>
						<input type="text" name="txtRGpai" style="width:110px" value="" id="txtRGpai"  maxlength="20"/>
						<label for="txtOrgaoExp" >Org�o Exp</label>
						<input type="text" name="txtOrgaoExppai" value="" style="width:70px" id="txtOrgaoExppai"  maxlength="6"/>
						<label for="lblDataEmissao">Data Emiss�o</label>
						<input type="text" name="txtdtemissaorgpai" value="" style="width:70px" id="txtdtemissaorgpai" maxlength="10" />

                    </p>
					<p>
						<label for="txtCPF">CPF</label>
						<input type="text" name="cpfpai" style="width:110px" value="" maxlength="11" id="cpfpai"  onKeyPress="return Enum(event)"/>
					</p>



					<p>
						<label for="lblmae">Nome M�e<img src= "../img/check.gif"/></label>
						<input type="text" name="txtmae" style="width:565px" maxlength="60" value="" id="txtmae" />
					</p>

					<p>
						<label for="txtRG">RG<img src= "../img/check.gif"/></label>
						<input type="text" name="txtRGmae" style="width:110px" value="" id="txtRGmae"  maxlength="20"/>
						<label for="txtOrgaoExp" >Org�o Exp<img src= "../img/check.gif"/></label>
						<input type="text" name="txtOrgaoExpmae" value="" style="width:70px" id="txtOrgaoExpmae"  maxlength="6"/>
						<label for="lblDataEmissao">Data Emiss�o<img src= "../img/check.gif"/></label>
						<input type="text" name="txtdtemissaorgmae" value="" style="width:70px" id="txtdtemissaorgmae" maxlength="10" />
					<p>
						<label for="txtCPF">CPF<img src= "../img/check.gif"/></label>
						<input type="text" name="cpf" style="width:110px" value="" maxlength="11" id="cpf"  onKeyPress="return Enum(event)"/>

					</p>



					<p>
						<label for="lblEndereco">Endere�o(Rua/Avenida)<img src= "../img/check.gif"/></label>
						<input type="text" name="txtEndereco" style="width:565px" value=""  maxlength="40" size="40" id="txtEndereco" />
					</p>
					<p>
						<label for="lblBairro">Bairro<img src= "../img/check.gif"/></label>
						<input type="text" name="txtBairro" value="" id="txtBairro" maxlength="25"/>
						<label for="lblBairro">Nr<img src= "../img/check.gif"/></label>
						<input type="text" name="txtnr" style="width:60px" value="" id="txtnr"  maxlength="5"/>
			            <label for="txtCEP">CEP<img src= "../img/check.gif"/></label>
            			<input id="txtcep" name="txtcep" type="text" style="width:90px" maxlength="8" onKeyPress="return Enum(event)"/>
					</p>




					<p>
						<label for="lblcomplemento">Complemento</label>
						<input type="text" name="txtcomplemento" style="width:298px" value=""  maxlength="40" size="60" id="txtcomplemento"/>
					</p>
                 <p>
					<label for="lblcod_estados">Municipio<img src= "../img/check.gif"/></label>
					   <select name="cod_muni" id="cod_muni" >
					   <option value=""></option>
  					  <?php
						   $sql = "select codigo, descricao FROM municipio order by descricao";
						   $res = mysql_query($sql);
						   if($res)
							  {
								while($row = mysql_fetch_array($res)){
							    ?>
  			                    <option value="<?php echo $row['codigo']?>"
						        <?php if($row['codigo'] == $muni){ echo "selected";}?>>
								<?php echo $row['descricao'];?>
								<?php
							      } }
						        ?>
					   </select>
					</p>


					<p>
						<label for="txtFoneSetor">Telefone Para Contato<img src= "../img/check.gif"/></label>
						<input type="text" name="txtcontato" style="width:110px" value="" id="txtcontato" />
						<label for="txtCelular">Celular<img src= "../img/check.gif"/></label>
						<input type="text" name="txtCelular" style="width:90px" value="" id="txtCelular" maxlength="20"/>
					</p>
					<p>
						<label for="txtEmail1">E-mail</label>
						<input type="text" name="txtEmail" style="width:565px" value="" id="txtEmail" maxlength="60"/>
						
					</p>


   	    <p>
            <label for="lblcod_cpf">Obs.:</label>
 			<textarea name = "txtobs"  maxlength= "200" cols="80" rows = "10" id = "txtobs"  type = "text"  onkeyup="blocTexto(txtdescvolume.value)"></textarea>
       </p>


	<p id="finish">

            <input type="submit" value="Gravar" />
            <input type="button" value=" Voltar " onclick="location.href='../mnadmescola.php';">
					</p>
				</form>
			</div>
		</div>
		<div id="footer">
			<p>Todos direitos reservados SEDUC/GTI-RO</p>
		</div>
	</div>
</body>

