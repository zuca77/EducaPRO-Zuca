<?php
require_once '../../start.php';
$pdo = new Conexao;

$title = 'Matr�cula Online';

$subtitle = 'Vagas reservadas';

$sql = "SELECT id, descricao FROM vagaschamadaescolar WHERE inep = {$inep} AND ano = {$txtano} ORDER BY descricao";
$vagas = $pdo->query($sql)->fetchAll();

$sql = "SELECT DISTINCT v.ano FROM reserva_matricula r 
        JOIN vagaschamadaescolar v ON v.id = r.vaga_id 
        WHERE v.inep = {$inep} 
        ORDER BY v.ano";
$anos = $pdo->query($sql)->fetchAll();

$sql = "SELECT id, descricao FROM reserva_status ORDER BY descricao";
$situacoes = $pdo->query($sql)->fetchAll();

/** Lista as Reservas existentes pra escola **/
$sql = "SELECT s.descricao AS situacao, r.protocolo, r.nome_solicitante, r.cpf_solicitante, r.created_at, r.uuid, a.nome, r.aluno_id, v.descricao AS vaga,v.id, v.ano as ano,v.t_vagas, v.inep, a.dt_nascimento
        FROM  reserva_matricula r
          JOIN aluno a ON r.aluno_id = a.id
          JOIN vagaschamadaescolar v ON r.vaga_id = v.id
          JOIN reserva_status s ON r.status_id = s.id
        WHERE v.inep = '{$inep}'";

if(isset($_GET['vagaFiltro']) && !empty($_GET['vagaFiltro']))
{
    $sql = $sql." AND r.vaga_id = :vagaFiltro ";
}  

if(isset($_GET['anoFiltro']) && !empty($_GET['anoFiltro']))
{
    $sql = $sql." AND v.ano = :anoFiltro ";
}  

if(isset($_GET['situacaoFiltro']) && !empty($_GET['situacaoFiltro']))
{
    $sql = $sql." AND r.status_id = :situacaoFiltro ";
}  

if(isset($_GET['protocoloFiltro']) && !empty($_GET['protocoloFiltro']))
{
    $sql = $sql." AND r.protocolo = :protocoloFiltro ";
}  

if(isset($_GET['nomeFiltro']) && !empty($_GET['nomeFiltro']))
{
    $sql = $sql." AND a.nome LIKE :nomeFiltro ";
}

if(isset($_GET['aluno_idFiltro']) && !empty($_GET['aluno_idFiltro']))
{
    $sql = $sql." AND r.aluno_id = :aluno_idFiltro ";
}

$sql = $sql . " GROUP BY r.id
               ORDER BY r.created_at;";

$sth = $pdo->prepare($sql);

if(isset($_GET['protocoloFiltro']) && !empty($_GET['protocoloFiltro']))
{
  $sth->bindParam(':protocoloFiltro', $_GET['protocoloFiltro']);
}

if(isset($_GET['nomeFiltro']) && !empty($_GET['nomeFiltro']))
{
  $nomeFiltro = '%'.$_GET['nomeFiltro'].'%';
  $sth->bindParam(':nomeFiltro',$nomeFiltro);
}

if(isset($_GET['vagaFiltro']) && !empty($_GET['vagaFiltro']))
{
  $sth->bindParam(':vagaFiltro', $_GET['vagaFiltro']);
}

if(isset($_GET['anoFiltro']) && !empty($_GET['anoFiltro']))
{
  $sth->bindParam(':anoFiltro', $_GET['anoFiltro']);
}

if(isset($_GET['situacaoFiltro']) && !empty($_GET['situacaoFiltro'])) 
{
  $sth->bindParam(':situacaoFiltro', $_GET['situacaoFiltro']);
}

if(isset($_GET['aluno_idFiltro']) && !empty($_GET['aluno_idFiltro'])) 
{
  $sth->bindParam(':aluno_idFiltro', $_GET['aluno_idFiltro']);
}

$reservas = $sth->execute() ? $sth->fetchAll() : null;

/** Permite alterar o status de uma reserva selecionada **/
if(isset($_GET['editar'])) {

  $uuid = $_GET['editar'];

  $sqlEditar = "SELECT r.uuid, r.protocolo, r.nome_solicitante, r.cpf_solicitante, r.protocolo, a.nome, a.dt_nascimento, v.t_vagas, v.descricao AS vaga, s.descricao AS situacao, r.observacoes, r.updated_by, r.aluno_id        
          FROM  reserva_matricula r
            JOIN aluno a ON r.aluno_id = a.id
            JOIN vagaschamadaescolar v ON r.vaga_id = v.id
            JOIN reserva_status s ON r.status_id = s.id
          WHERE v.inep = '{$inep}'
            AND r.uuid = :uuid ;";

  $sth = $pdo->prepare($sqlEditar);
  $sth->bindParam(':uuid', $uuid);
  $reservaEditar = $sth->execute() ? $sth->fetch() : null;

  $data_nascimento = \DateTime::createFromFormat('Y-m-d',$reservaEditar['dt_nascimento'])
                              ->format('d/m/Y');

  if($reservaEditar['situacao'] == 'RESERVADA')
  {
      $sqlStatus = "SELECT id, descricao 
              FROM reserva_status 
              WHERE descricao != 'RESERVADA'
                AND descricao != 'EXPIRADA'
                AND descricao != 'CANCELADA'
              ORDER BY descricao";
      $status = $pdo->query($sqlStatus)->fetchAll();
  }

}
  
?><!DOCTYPE HTML>
<html>
  <head>
    <?php require_once page_head() ?>
	</head>
  <body>
  	<?php require_once page_header() ?>
    <div class="container">
    <div class="row">
      <form id="form" class="submit-wait" method="get">
        <div class="col-md-2">
          <p class="form-group">
                <label for="protocoloFiltro">Protocolo</label>
                <input name="protocoloFiltro" id="protocoloFiltro" class="form-control mask-protocolo" type="text" 
                value= "<?php echo isset($_GET['protocoloFiltro']) ? $_GET['protocoloFiltro'] : ''?>"> 
          </p>
        </div>
        <div class="col-md-1">
        <p class="form-group">
              <label for="aluno_idFiltro">ID</label>
             <input name="aluno_idFiltro" id="aluno_idFiltro" class="form-control" type="text" 
              value="<?php echo isset($_GET['aluno_idFiltro']) ? $_GET['aluno_idFiltro'] : ''?>"> 
          </p>
        </div>  
        <div class="col-md-3">
          <p class="form-group">
            <label for="aluno_idFiltro">Estudante</label>
              <input class="form-control" name="nomeFiltro" id="nomeFiltro" type="text" 
              value="<?php echo isset($_GET['nomeFiltro']) ? $_GET['nomeFiltro'] : ''?>">    
          </p>
        </div>  
        <div class="col-md-3">
          <p class="form-group">
            <label for="vagaFiltro">Vaga</label>
            <select name="vagaFiltro" id="vagaFiltro" class="form-control chosen-deselect" type="text" value="<?php echo isset($_GET['vagaFiltro']) ? $_GET['vagaFiltro'] : ''?>">
                <option value=""></option>
                <?php foreach ($vagas as $v): ?>
                  <option value="<?php echo $v['id'] ?>" <?php selected(isset($_GET['vagaFiltro']) && $v['id']== $_GET['vagaFiltro'])?> >
                    <?php echo $v['descricao'] ?>
                  </option>
                <?php endforeach ?> 
              </select>
          </p>
        </div>

         <div class="col-md-2">
          <p class="form-group">
            <label for="situacaoFiltro">Situa��o Reserva</label>
             <select name="situacaoFiltro" id="situacaoFiltro" class="form-control chosen-deselect" type="text" 
               value="<?php echo isset($_GET['situacaoFiltro']) ? $_GET['situacaoFiltro'] : ''?>">
                <option value=""></option>
                <?php foreach ($situacoes as $s): ?>
                  <option value="<?php echo $s['id'] ?>" <?php selected(isset($_GET['situacaoFiltro']) && $s['id']== $_GET['situacaoFiltro'])?> >
                    <?php echo $s['descricao'] ?>
                  </option>
                <?php endforeach ?>
              </select>
          </p>
        </div>
        <div class="col-md-1">
          <p class="form-group">
            <button type="submit" class="btn btn-sm btn-primary" style="margin-top:25px" >FILTRAR</button>
          </p>
        </div>
     </form>
    </div>
<br>


   <?php if(isset($reservaEditar)) { ?>
   <form action="altera_matricula_online.php" method="post">
      <input name="uuid" type="hidden" value="<?php echo $reservaEditar['uuid']; ?>" > 
        <table class="table table-bordered table-condensed text-table">
          <tr>
            <th width="20">
              Solicitante
            </th>
            <td class="text-left" >
              <?php echo $reservaEditar['cpf_solicitante']; ?>
              <?php echo $reservaEditar['nome_solicitante']; ?>
            </td>
            <th width="20">
              Protocolo 
            </th>
            <td class="text-right" width="180">
              <?php echo $reservaEditar['protocolo']; ?>
            </td>
          </tr>
          <tr>
            <th width="70">
              Vaga
            </th>
            <td class="text-left" >
              <?php echo $reservaEditar['vaga']; ?>
            </td>
            <th>
              Situa��o
            </th>
            <td class="text-right">
                <?php if ($reservaEditar['situacao'] == 'RESERVADA') : ?>
                  <select name="situacao" id="situacao" class="form-control chosen" required>
                    <option value="1"><?php echo $reservaEditar['situacao']; ?></option>
                    <?php foreach($status as $situacao): ?>
                    <option value="<?php echo $situacao['id'] ?>"><?php echo $situacao['descricao'] ?></option>
                    <?php endforeach ?>
                  </select>
                <?php 
                  else : 
                    echo $reservaEditar['situacao']; 
                  endif ?>
            </td>
          </tr>
          <tr>
            <th width="20" >
             Aluno 
            </th>
            <td class="text-left" >
              <input name="aluno_id" type="hidden" value="<?php echo $reservaEditar['aluno_id']; ?>" > 
              <?php echo $reservaEditar['aluno_id']; ?>
              <?php echo $reservaEditar['nome']; ?>
            </td>
            <th width="40">
              Nascimento
            </th>
            <td class="text-right" width="100">
              <?php echo $data_nascimento; ?>
            </td>
          </tr>
          <tr>
            <th>Observa��es</th> 
            <td>
               <?php if ($reservaEditar['observacoes']): 
                    echo $reservaEditar['observacoes']; 
                  else : ?>
                    <input name="observacoes" id="observacoes" class="form-control" type="textarea" 
                    placeholder="Caso invalide esta reserva, informe aqui a justificativa para o ato." value=""> 
                <?php  endif ?>
            </td>
            <th>Atendente</th>
            <td class="text-right"><?php echo $reservaEditar['updated_by']; ?></td>
          </tr>
        </table>
        <?php if ($reservaEditar['situacao'] == 'RESERVADA') : ?>
        <div class="well well-sm">
          <input type="submit" class="btn btn-primary" value="Salvar"  onClick="return confirm('Confirma a grava��o?')"/>
          <input type="button" class="btn btn-default btn-back pull-right" value="Voltar">
        </div>  
        <?php endif ?>
      </form>
   <?php } ?>
      
      <br>
      <!-- <div class="alert alert-info hidden-print">
        Os alunos destacados em amarelo s�o os que estiveram em uma turma em 2016, em uma escola (seja estadual ou municipalizada) que utilizava o di�rio eletr�nico. <strong>Avalie com a CRE como ficar� a situa��o deles. Pois cada caso, � um caso.</strong>
      </div> -->

      <?php if (sizeof($reservas) == 0): ?>
      <div class="alert alert-info">Nenhuma reserva realizada para este ano.</div>
      <?php endif ?>
  
      <p><?php echo count($reservas)?> reservas encontradas </p>  

      <table class="table table-bordered table-condensed table-striped ">
        <tr>
          <th width="20"></th>
          <th width="170">Protocolo</th>
          <th width="70">ID</th>
          <th width="100">Ano Vaga</th>
          <th width="100">Nascimento</th>
          <th>Estudante</th>
          <th>Vaga</th>
          <th width="20">Data de Reserva</th>
          <th width="150">Situa��o</th>
          <th width="60"></th>
        </tr>
      <?php foreach ($reservas as $reserva) :?>
      <tr class="<?php echo (ReservaMatricula::turmaAlunoAnoPassado($reserva["aluno_id"])) ? 'warning' : '' ?>">
        <td>
          <a class="btn btn-xs btn-default" href="<?php url("escola/chamadaescolar/reserva_matricula_online.php?reserva={$reserva['uuid']}") ?>">VER</a> 
        </td>
        <td><?php echo $reserva["protocolo"];?></td>
        <td><?php echo $reserva["aluno_id"];?></td>
        <td><?php echo $reserva["ano"];?></td>
        <td><?php echo formataData($reserva["dt_nascimento"]);?></td>
        <td><?php echo $reserva["nome"];?></td>
        <td><?php echo $reserva["vaga"];?></td>
        <td><?php echo formataData($reserva["created_at"]);?></td>
     	  <td><?php echo $reserva['situacao'];?></td>
        <td>
          <?php if($reserva['situacao'] == 'RESERVADA') : ?>
            <a class="btn btn-xs btn-primary" href="<?php url("escola/chamadaescolar/form_matricula_online.php?editar={$reserva['uuid']}") ?>">EDITAR</a> 
          <?php elseif ($reserva['situacao'] == 'INV�LIDA') : ?>
            <a class="btn btn-xs btn-default" href="<?php url("escola/chamadaescolar/form_matricula_online.php?editar={$reserva['uuid']}") ?>">MOTIVO</a> 
          <?php endif ?>
        </td>
      </tr>
      <?php endforeach ?>
      </table>

      <p class="well well-sm">
        <a class="btn btn-default" href="<?php url('escola/mnadmescola.php') ?>">Voltar</a>
      </p>
    </div>

    <?php require_once page_footer() ?>
  </body>
</html>

<script type="text/javascript">

$(document).ready(function(){

  var $situacao = $('#situacao');
  var $observacoes = $('#observacoes');

  function setSituacao() {

      var itemSelecionado = $situacao.val();
      console.log(itemSelecionado);

      if(itemSelecionado == '4')
      {
          $observacoes.attr('required',true);
          $observacoes.focus();
      }
      else
      {
          $observacoes.attr('required',false).val('');
      } 
  }

  $situacao.on('change',function(){
      setSituacao();
  });

  setSituacao();

});

</script>