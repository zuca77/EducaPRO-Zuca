<?
session_start();
if (isset($_SESSION["login_usuario"]))
  {
   // session_cache_expire(1);
	 $login     =  $_SESSION["login_usuario"];
     $nte       =  $_SESSION["nivel_usuario"];
	 $inep      =  $_SESSION["inep_usuario"] ;
     $ntelogin  =  $_SESSION["nte_login"];
     $cpf_usuario  = $_SESSION["cpf_usuario"];

	 include ("../funcoes.php");
     echo  saudacoes()."   ". "$login" ."  -  ". $nte."  ".dataextenso()." ".$inep;

  }
 else
  {
     		 header("../../Location: login.php");
  }



if(file_exists("../../conexao_mysql.php"))
{
        require "../../conexao_mysql.php";

} else
{
        echo "Conex�o nao foi encontrado";
        exit;
}


include ("../../conexao_mysql.php");

if(file_exists("../../conexao_mysql.php"))
{
        require "../../conexao_mysql.php";

} else
{
        echo "Conex�o nao foi encontrado";
        exit;
}





$sqlgerencia = "select e.inep,e.descricao as descescola,e.fone,e.regularizada, e.endereco,e.bairro,e.numero,m.descricao as descmuni from escola e , municipio m  where inep ='$inep' and e.municipio = m.codigo";
$resultadoger=mysql_query($sqlgerencia) or die (mysql_error());
$linhas   =mysql_num_rows($resultadoger);
if($linhas>0)
{
   while($pegar=mysql_fetch_array($resultadoger))
	{

    	$descescola    =$pegar["descescola"];
    	$descmunici    =$pegar["descmuni"];

    	$endereco      =$pegar["endereco"];
    	$bairro        =$pegar["bairro"];
    	$numero        =$pegar["numero"];

    	$fone         =$pegar["fone"];
    	$regularizada        =$pegar["regularizada"];



    }
 }








//if ($_POST['cadastrar'])
if($_SERVER["REQUEST_METHOD"] == "POST")
{

$cod_estado          = $_POST['cod_estado'];
$cod_cidades         = $_POST['cod_cidades'];
$cod_muni            = $_POST['cod_muni'];
$cpfpai              = $_POST['cpfpai'];
$cpf                 = $_POST['cpf'];
$selectsexo	         = $_POST['selectsexo'];
$txtBairro           = addslashes($_POST['txtBairro']);
$txtCelular          = $_POST['txtCelular'];
$txtEmail            = $_POST['txtEmail'];
$txtEndereco         = addslashes($_POST['txtEndereco']);
$txtOrgaoExpmae      = $_POST['txtOrgaoExpmae'];
$txtOrgaoExppai      = $_POST['txtOrgaoExppai'];
$txtRGpai            = $_POST['txtRGpai'];
$txtRGmae            = $_POST['txtRGmae'];
$txtcep              = $_POST['txtcep'];
$txtcertidaonovo    = $_POST['txtcertidaonovo'];
$txtcertidao         = $_POST['txtcertidao'];
$txtcomplemento      = addslashes($_POST['txtcomplemento']);
$txtcontato          = addslashes($_POST['txtcontato']);
$txtfolha            = $_POST['txtfolha'];
$txtlivro            = $_POST['txtlivro'];
$txtnaluno           = $_POST['txtnaluno'];
$txtnr             = $_POST['txtnr'];
$txtobs            = $_POST['txtobs'];
$txtturma	         = $_POST['txtturma'];
$txtdtnascimento     = $_POST['txtdtnascimento'];
$txtmae              = $_POST['txtmae'];
$txtpai              = $_POST['txtpai'];
$txtdtemissaorgpai   = $_POST['txtdtemissaorgpai'];

$dtemissao_certidao  = $_POST['dtemissao_certidao'];
$txtdtemissaorgmae   = $_POST['txtdtemissaorgmae'];

$txtdtnascimentoi     = $_POST['txtdtnascimento'];


$txtresponsavel         = $_POST['txtresponsavel'];
$selectgrauparente      = $_POST['selectgrauparente'];
$txtRGresp              = $_POST['txtRGresp'];
$txtOrgaoExpresp        = $_POST['txtOrgaoExpresp'];
$txtdtemissaorgresp     = $_POST['txtdtemissaorgresp'];
$cpfresp                = $_POST['cpf'];


$selectbosaf             = $_POST['selectbosaf'];
$selecttipo_necessidade  = $_POST['selecttipo_necessidade'];
$selectdeficiente         = $_POST['selectdeficiente'];



$selectcorraca            = $_POST['selectcorraca'];
$nbolsa                   = $_POST['nbolsa'];
$filiacao                 = $_POST['filiacao'];
$idnacional              = $_POST['idnacional'];

$nsus                          = $_POST['nsus'];
$selecttransporte              = $_POST['selecttransporte'];
$selectacesso                   = $_POST['selectacesso'];




/**************turma selecionada*******************************************************/
$txtturma                         = $_POST['txtturma'];
$sql="SELECT * FROM vagaschamadaescolar where id = '$txtturma' and t_vagas > 0";
$resultado=mysql_query($sql) or die (mysql_error());
$linhas = mysql_num_rows($resultado);
if($linhas>0)
{
   while($pegar=mysql_fetch_array($resultado))
	{
    	$desc_turma_chamada    =$pegar["DESCRICAO"];
    	
    }










mysql_query ( "START TRANSACTION" );
$sql = "update vagaschamadaescolar set
		t_vagas          =t_vagas -'1'
        where   id       = '$txtturma'";



if(@mysql_query($sql))
  {

      mysql_query ( "COMMIT" );
      $success = mysql_affected_rows();

     if($success ==true)
		{
         /*alterado com sucesso*/
        }
  }
 else
   {
        //verifico se nao estao tentando gravar um dado que ja existe, pois usei UNIQUE na tabela
        if(mysql_errno() == 1062)
		  {
                echo $erros[mysql_errno()];
                exit;
          }
		  else
		  {
                echo "Erro nao foi possivel efetuar o cadastro";
                exit;
          }
        @mysql_close();
     }
}
else
{
    echo "<html><head><title>Resposta !!!</title></head>";
    echo "<body background=\"background_mensagens.jpg\" style=\"background-attachment:fixed; background-repeat:no-repeat\">";
    echo "<br><br><br>";
    echo "<center><img src=\"faleconosco/atencao.gif\" alt=\"\"><p><font color=\"#FF0000\" face=\"Verdana\" size=\"4\"><blink>Turma sem Saldo.!</blink> <b></b></font></center>";
    echo "<br><br><center><a href=\"form_pesquisa_aluno.php\"><img src=\"faleconosco/button_voltar2_.gif\" alt=\"Voltar\" border=\"0\" /></a></center>";
    echo "</body></html>";
    exit;

}



/*********************************************************************/




$foto           = $_FILES["imagem"];
/*Tratamento  Foto*/
$arquivo_g = isset($_FILES["imagem"]) ? $_FILES["imagem"] : FALSE;if($_FILES["imagem"]==''){echo '<script>confirm("Noticia sem imagem?")</script>';}

$arquivo_g = isset($_FILES["imagem"]) ? $_FILES["imagem"] : FALSE;if($_FILES["imagem"]=='')
   {echo '<script>confirm("Noticia sem imagem?")</script>';}
	if ($arquivo_g['name'] == '')
    {
		$imagem_g = 'null';
 	}
			else
	{
			$largura=370;$altura=260;
			$imagem_g = upImagemBig("g",$arquivo_g,370,260);
	}








/*tratamento das datas*/


$diai = substr($txtdtemissaorgresp, 0,2);
$anoi = substr($txtdtemissaorgresp, -4);
$mesi = substr($txtdtemissaorgresp, -7,2);
$txtdtemissaorgresp=$anoi.".".$mesi.".".$diai;


$diai = substr($dtemissao_certidao, 0,2);
$anoi = substr($dtemissao_certidao, -4);
$mesi = substr($dtemissao_certidao, -7,2);
$dtemissao_certidao=$anoi.".".$mesi.".".$diai;



$diai = substr($txtdtnascimento, 0,2);
$anoi = substr($txtdtnascimento, -4);
$mesi = substr($txtdtnascimento, -7,2);
$txtdtnascimento=$anoi.".".$mesi.".".$diai;



$diaf = substr($txtdtemissaorgpai, 0,2);
$anof = substr($txtdtemissaorgpai, -4);
$mesf = substr($txtdtemissaorgpai, -7,2);
$txtdtemissaorgpai=$anof.".".$mesf.".".$diaf;




$diaret = substr($txtdtemissaorgmae, 0,2);
$anoret = substr($txtdtemissaorgmae, -4);
$mesret = substr($txtdtemissaorgmae, -7,2);
$txtdtemissaorgmae=$anoret.".".$mesret.".".$diaret;

$dia = date('d');
$mes = date('m');
$ano = date('Y');
$data =$dia.".".$mes.".".$ano;
$data1 =$dia.".".$mes.".".$ano;

$datacad =$ano.".".$mes.".".$dia;


/*****************************************************************/
$sql="select * from  aluno where nome = '$txtnaluno' and NOME_PAI='$txtpai' and NOME_MAE = '$txtmae' and responsavel =  '$txtresponsavel'";$resultado=mysql_query($sql) or die (mysql_error());
$linhas=mysql_num_rows($resultado);
if ($linhas>0)
 {

    echo "<html><head><title>Resposta !!!</title></head>";
    echo "<body background=\"background_mensagens.jpg\" style=\"background-attachment:fixed; background-repeat:no-repeat\">";
    echo "<br><br><br>";
    echo "<center><img src=\"faleconosco/atencao.gif\" alt=\"\"><p><font color=\"#FF0000\" face=\"Verdana\" size=\"4\"><blink>Aluno j� Cadastrado - Click em Voltar.!</blink> <b></b></font></center>";
    echo "<br><br><center><a href=\"form_pesquisa_aluno.php\"><img src=\"faleconosco/button_voltar2_.gif\" alt=\"Voltar\" border=\"0\" /></a></center>";
    echo "</body></html>";
    exit;
 }






$sql = "insert into aluno(nome,dt_nascimento,SEXO,termo_certidao,folha_certidao,livro_certidao,uf_nascimento,muni_nascimento,nome_pai,
RG_PAI,ORGEXPRG_PAI,DTRG_PAI,CPF,nome_mae,RG_MAE,ORGEXPRG_MAE,DTRG_MAE,CPF_MAE,endereco,bairro,numero,cep,complemento,cidade,FONECONTATO,
FONECELULAR,EMAIL,OBS,n_certidao_novo,dtemissao_certidao,foto,inep,usuario,responsavel,grau_parentesco,rgresponsavel,orgaoexpresp,
dtemissaorgresp,cpfresp,status,tipo_necessidade,bolsa_familia,deficiente,car_raca,n_bolsa_fam,filiacao,id_nacional,sus,transporte,acesso_portal)

values ('$txtnaluno','$txtdtnascimento','$selectsexo','$txtcertidao','$txtfolha','$txtlivro','$cod_estado','$cod_cidades','$txtpai','$txtRGpai',
'$txtOrgaoExppai','$txtdtemissaorgpai','$cpfpai','$txtmae','$txtRGmae','$txtOrgaoExpmae','$txtdtemissaorgmae','$cpfmae', '$txtEndereco',
'$txtBairro','$txtnr','$txtcep','$txtcomplemento','$cod_muni','$txtcontato','$txtCelular','$txtEmail','$txtobs','$txtcertidaonovo',
'$dtemissao_certidao','$imagem_g','$inep','$cpf', '$txtresponsavel','$selectgrauparente','$txtRGresp','$txtOrgaoExpresp','$txtdtemissaorgresp',
'$cpfresp','1','$selecttipo_necessidade','$selectbosaf','$selectdeficiente','$selectcorraca','$nbolsa','$filiacao','$idnacional','$nsus','$selecttransporte','$selectacesso')";





if(@mysql_query($sql))
{


  if(mysql_affected_rows() == 1)
   {
       $sql = "select last_insert_id()";
       $resp= mysql_query($sql);
       $id_aluno  = mysql_fetch_array($resp);

       $datahora = date('Y.m.d H:i:s');




       $sql = "insert into aluno_chamadaescolar(id_aluno,id_cha_escolar,ano,distorcao,usuario,inep,dt_matricula,datahora)
        values ('$id_aluno[0]','$txtturma','$ano','N','$cpf_usuario','$inep','$datacad', '$datahora')";

        if(@mysql_query($sql))
        {

            $success = mysql_affected_rows();

            if($success ==true)
	     	  {
                     $sql = "select last_insert_id()";
                     $resp= mysql_query($sql);
                     $id_chamda_esc  = mysql_fetch_array($resp);

             }
         }
         else
         {
         //verifico se nao estao tentando gravar um dado que ja existe, pois usei UNIQUE na tabela
          if(mysql_errno() == 1062)
		     {
                echo $erros[mysql_errno()];
                exit;
             }
		  else
		     {
                echo "Erro nao foi possivel efetuar o cadastro";
                exit;
             }
        }
    }






/**********************************************************************************************************************************************/
  ?>
  

<html>
<head>

<title>:: DIARIO ELETRONCIO ::</title>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1">
<link href="../biblioteca/menu/menu.css" rel="stylesheet" type="text/css">
<script language="JavaScript" src="../biblioteca/menu/JSCookMenu.js" type="text/javascript"></script>
<script language="JavaScript" src="../biblioteca/menu/theme.js" type="text/javascript"></script>
<link rel="stylesheet" type="text/css" href="../biblioteca/padraoestilo.css">

<script type="text/javascript" src="../biblioteca/sortabletable.js"></script>
<link type="text/css" rel="StyleSheet" href="../biblioteca/sortabletable.css" />
</head>

<style>
.titulopagina
{
    font-size: 11px;
    color:    #000099;
	background-color:#E8E8E8;
	height:25px;
    font-family: verdana , arial
}

table.bordasimples {border-collapse: collapse;}

table.bordasimples tr td {border:1px solid #CCCCCC;}

.subtitulo
{
	font-family: verdana ;
	font-size: 10pt;
    color: #22408f;
	font-weight: bold;
}

.nomecampo
{
    font-size: 10px;
    color: midnightblue;
    font-family: verdana, arial;
	font-weight: bold;
}
.escrita
{
    font-size: 10px;
    color: #000000;
    font-family: verdana, arial
}
.escritanormal
{
    font-size: 10px;
    color: #000000;
    font-family: verdana, arial;
	font-weight: normal;
}



</style>
<script language="javascript">
function DoPrinting() {
    if (!window.print) {
        alert("Netscape, Internet Explorer 4.0 ou superior!")
        return
    }
    window.print();
}
</script>

</head>
<table width="100%">
<tr>


      <td class="nomecampo" align="center"><b><img src= "../img/brasao.jpg" /></b></td>


</tr>
<tr>
<td>

<table width="100%">
<tr>
<td>&nbsp;  </td>
</tr>
<tr>
<td>
<table border="0"  class="bordasimples" cellspacing="0"  align="center" width="100%" bgcolor=#ffffff>

<tr>
	<td colspan="6"  bgcolor="#EAEAEA"  class="subtitulo" align="center"><b>GOVERNO DO ESTADO DE ROND�NIA</b></td>
</tr>

<tr>
	<td colspan="6"  bgcolor="#EAEAEA"  class="subtitulo" align="center"><b>SECRETARIA DE ESTADO DA EDUCA��O</b></td>
</tr>

<tr>
	<td colspan="6"  bgcolor="#EAEAEA"  class="subtitulo" align="center"><b>GER�NCIA DE TECNOLOGIA DA INFORMA��O</b></td>
</tr>

<tr>
	<td colspan="6"  bgcolor="#EAEAEA"  class="subtitulo" align="center"><b>CHAMADA ESCOLAR / 2014</b></td>
</tr>

<tr>
	<td colspan="6"  bgcolor="#EAEAEA"  class="subtitulo" align="center"><b>Dados da Escola</b></td>
</tr>



<tr>
	<td class="nomecampo"><b>C�digo INEP:</b></td>
	<td>&nbsp;<?echo $inep;?></td>
	<td class="nomecampo"><b>Raz�o Social:</b></td>
	<td class = "escrita">&nbsp;<?echo $descescola;?></td>
	<td class="nomecampo"><b>Zona:</b></td>
	<td>&nbsp;Urbana</td>

</tr>



<tr>
	<td class="nomecampo"><b>Endere�o:</b></td>
	<td class = "escrita">&nbsp;<?echo $endereco;?></td>
	<td class="nomecampo"><b>N�:</b></td>
	<td>&nbsp;<?echo $numero;?></td>
	<td class="nomecampo"><b>Bairro</b></td>
	<td class = "escrita">&nbsp;<?echo $bairro;?></td>

</tr>
<tr>
	<td class="nomecampo"><b>UF:</b></td>
    <td>&nbsp;RO</td>
	<td class="nomecampo"><b>Munic�pio:</b></td>
	<td class = "escrita">&nbsp;<?echo $descmunici;?></td>
	<td class="nomecampo"><b>Regularizada:</b></td>
	<td>&nbsp;<?echo $regularizada;?></td>

  </tr>

 <tr>

	<td class="nomecampo"><b>Telefone:</b></td>
	<td>&nbsp;<?echo $fone;?></td>
	<td class="nomecampo"><b>Dep. administrativa:</b></td>
	<td colspan="3">&nbsp;Estadual</td>
</tr>












<table width="100%">
<tr>
<td>&nbsp;  </td>
</tr>
<tr>
<td>
<table border="0"  class="bordasimples" cellspacing="0"  align="center" width="100%" bgcolor=#ffffff>

<tr>
	<td colspan="18"  bgcolor="#EAEAEA"  class="subtitulo" align="center"><b>Dados do Aluno(a)</b></td>
</tr>



<tr>
	<td class="nomecampo"><b>ID Estadual:</b></td>
	<td class = "escrita">&nbsp;<?echo  $id_aluno[0];?></td>

	<td class="nomecampo"><b>ID Chamda Escolar:</b></td>
	<td class = "escrita">&nbsp;<?echo  $id_chamda_esc[0];?></td>

	<td class="nomecampo"><b>ANO:</b></td>
	<td class = "escrita">&nbsp2014</td>

	<td class="nomecampo"><b>Sexo:</b></td>
	<td   colspan="18"  class = "escrita">&nbsp;<?   if ($selectsexo == '1')
         {
           echo 'M';
         }
         else
          {
           echo 'F';
          }
          ;?></td>


</tr>
<tr>
	<td class="nomecampo"><b>Nome:</b></td>
	<td class = "escrita" colspan="9">&nbsp;<?echo $txtnaluno;?></td>
	<td class="nomecampo"><b>Nascimento:</b></td>
	<td colspan="18" class = "escrita">&nbsp;<?echo $txtdtnascimentoi;?></td>
</tr>



<tr>
	<td class="nomecampo"><b>Certid�o Modelo Novo:</b></td>
	<td class = "escrita">&nbsp;<?echo  $txtcertidao;?></td>
	<td class="nomecampo"><b>Certid�o Modelo Antigo:</b></td>
	<td class = "escrita">&nbsp;<?echo $txtcertidao;?></td>
	<td class="nomecampo"><b>Livro:</b></td>
	<td class = "escrita">&nbsp;<?echo $txtlivro;?></td>
	<td class="nomecampo"><b>Folha:</b></td>
	<td colspan="18" class = "escrita">&nbsp;<?echo $txtfolha;?></td>


</tr>



<tr>
	<td class="nomecampo"><b>Pai</b></td>
	<td class = "escrita" colspan="9">&nbsp;<?echo $txtpai;?></td>
	<td class="nomecampo"><b>M�e</b></td>
	<td class = "escrita" colspan="9">&nbsp;<?echo $txtmae;?></td>
</tr>


<tr>
	<td colspan="18"  bgcolor="#EAEAEA"  class="subtitulo" align="center"><b>Endere�o</b></td>
</tr>


<tr>
	<td class="nomecampo"><b>Endere�o</b></td>
	<td class = "escrita">&nbsp;<?echo $txtEndereco;?></td>
	<td class="nomecampo"><b>Bairro</b></td>
	<td class = "escrita">&nbsp;<?echo $txtBairro;?></td>
	<td class="nomecampo"><b>N�</b></td>
	<td class = "escrita" colspan="5" >&nbsp;<?echo $txtnr;?></td>
	<td class="nomecampo"><b>CEP</b></td>
	<td class = "escrita" colspan="5" >&nbsp;<?echo $txtcep;?></td>
	<td class="nomecampo"><b>Contato</b></td>
	<td class = "escrita" colspan="5" >&nbsp;<?echo $txtcontato;?></td>

</tr>

<tr>
	<td colspan="18"  bgcolor="#EAEAEA"  class="subtitulo" align="center"><b>Vaga Reservada</b></td>
</tr>


<tr>
	<td class="nomecampo"><b>Turma</b></td>
	<td class = "escrita"  colspan="18">&nbsp;<?echo $desc_turma_chamada;?></td>

</tr>

</table>


<table width="100%">
<tr>
<td>&nbsp;  </td>
</tr>
<tr>
<td>
<table border="0"  class="bordasimples" cellspacing="0"  align="center" width="100%" bgcolor=#ffffff>
<tr>
	<td class="nomecampo"><b><img src= "../../imagem/impressora.jpg" onClick="DoPrinting()" title = "Click para imprimir."/></b></td>
</tr>
</table>
</body>
</html>


 <?
/**********************************************************************************************************************************************/
exit;
   }
else
   {
        //verifico se nao estao tentando gravar um dado que ja existe, pois usei UNIQUE na tabela
        if(mysql_errno() == 1062)
		  {
                echo $erros[mysql_errno()];
                exit;
          }
		  else
		  {
                echo "Erro nao foi possivel incluir o pedido";
                exit;
          }
        @mysql_close();
     }

 //}//select kit

}//post



/********************************************************************************/





function upImagemBig($tam,$arquivo,$largura,$altura_crop){
	$dir = "fotos/";

	// ler extensão de arquivo
	preg_match("/\.(gif|png|jpg|jpeg|JPG|JPEG){1}$/i", $arquivo["name"], $ext);

	if(eregi("png|jpg|jpeg|JPG|JPEG",$ext[1])){
		// Renomear arquivo para evitar quebras
		$file_nome = md5(uniqid(time())) ."-".$tam. "." . $ext[1];

		$imagem=$dir.$file_nome;
		//caminho com nome da imagem e local para guardar

		if(move_uploaded_file($_FILES['imagem']['tmp_name'],$imagem))//copy(,$imagem))
		//aqui nada especial so movo a tmp_name dando caminho

		redCropImagemBig($tam,$arquivo,$largura,$altura_crop,$imagem,$file_nome,$ext[1]);

		return $file_nome;
					}
		else
		{
		echo "G. Formato de imagem n&atilde;o suportado!"; exit();
			}
}



function redCropImagemBig($tam,$arquivo,$largura,$altura_crop,$imagem,$file_nome,$ext){
	// Pega as dimensões
	$imagesize = getimagesize($imagem);

	//regra de 3
	$largura_original = $imagesize[0]; // 0 será a largura.
	$altura_original = $imagesize[1]; // 1 será a altura.

	if($tam=='g'){$altura = ($altura_original*$largura)/$largura_original;}
	if($tam=='t'){$altura=$altura_crop;}
	if($tam=='in'){$altura=$altura_crop;}

	//criamos uma nova imagem ( que vai ser a redimensionada) a partir da imagem original
	//$imagem_orig = imagecreatefromjpeg($imagem);
	if($ext == "jpg" || $ext == "jpeg" || $ext == "JPEG" || $ext == "JPG") {
		$imagem_orig = imagecreatefromjpeg($imagem);
		}
	elseif ($ext == "png") {
		$imagem_orig = imagecreatefrompng($imagem);
		}
	if(!$imagem_orig) {
		echo("Erro ao carregar a imagem, talvez formato nao suportado");
		return false;
		exit;
	}

	//pegamos a altura e a largura da imagem original
	$pontox = imagesx($imagem_orig);
	$pontoy = imagesy($imagem_orig);

	//criamos a imagem redimensionada com a funcao imagecreatetruecolor para suportar um grande numero de cores
	$imagem_fin = imagecreatetruecolor($largura, $altura);

	//copiamos o conteudo da imagem original e passamos para o espaco reservado a redimencao
	imagecopyresampled($imagem_fin, $imagem_orig, 0, 0, 0, 0, $largura+1, $altura+1, $pontox, $pontoy);

	//salva a imagem
	//imagejpeg($imagem_fin, $imagem,100);
	if($ext == "jpg" || $ext == "jpeg" || $ext == "JPEG" || $ext == "JPG") {
		imagejpeg($imagem_fin, $imagem,100);
		return true;
		}
	elseif ($ext == "png") {
		imagepng($imagem_fin, $imagem);
		return true;
		}
	else {
		echo("Formato de arquivo nao suportado");
		return false;
	}

	#crop
	$LIMG=$largura;
	$AIMG=$altura_crop;
	$g_srcfile=$imagem;

	if(file_exists($g_srcfile)) {

	   $g_is = getimagesize($g_srcfile);

		$g_ih=$AIMG;
		$g_iw=($g_ih/$g_is[1])*$g_is[0];

		if($LIMG>$g_iw){
		   $g_iw=$LIMG;
		  $g_ih=($LIMG/$g_is[0])*$g_is[1];
		}

		// se a largura redimensionada($g_iw)  for
		// maior ou igual a altura redimensionada($g_ih)
		if($g_iw>=$g_ih){
		   $scr_x=0;
		   $src_y=0;
		}else{
		   $scr_x=0;
		   $src_y=0;
		}

	   $img_src=imagecreatefromjpeg($g_srcfile);
	   $img_dst=imagecreatetruecolor($LIMG, $AIMG);
	   imagecopyresampled($img_dst, $img_src, 0, 0, $scr_x, $src_y, $g_iw, $g_ih, $g_is[0], $g_is[1]);

	   //imagejpeg($img_dst,$imagem);
	    if($ext == "jpg" || $ext == "jpeg" || $ext == "JPEG" || $ext == "JPG") {
		imagejpeg($img_dst,$imagem,100);
		return true;
		}
		elseif ($ext == "gif") {
			imagepng($img_dst,$imagem);
			return true;
			}
		elseif ($ext == "png") {
			imagepng($img_dst,$imagem);
			return true;
			}
		else {
			echo("Formato de arquivo nao suportado");
			return false;
		}
	   imagedestroy($img_dst);
	   //libera a memoria
		imagedestroy ($imagem_orig);
		imagedestroy ($imagem_fin);

	}
}

function redCropImagemT($tam,$arquivo,$largura,$altura_crop,$imagem,$file_nome,$ext){


	#crop
	$LIMG=$largura;
	$AIMG=$altura_crop;
	$g_srcfile=$imagem;

	if(file_exists($g_srcfile)) {

	   $g_is = getimagesize($g_srcfile);

		$g_ih=$AIMG;
		$g_iw=($g_ih/$g_is[1])*$g_is[0];

		if($LIMG>$g_iw){
		   $g_iw=$LIMG;
		  $g_ih=($LIMG/$g_is[0])*$g_is[1];
		}

		// se a largura redimensionada($g_iw)  for
		// maior ou igual a altura redimensionada($g_ih)
		if($g_iw>=$g_ih){
		   $scr_x=0;
		   $src_y=0;
		}else{
		   $scr_x=0;
		   $src_y=0;
		}

	   $img_src=imagecreatefromjpeg($g_srcfile);
	   $img_dst=imagecreatetruecolor($LIMG, $AIMG);
	   imagecopyresampled($img_dst, $img_src, 0, 0, $scr_x, $src_y, $g_iw, $g_ih, $g_is[0], $g_is[1]);

	   //imagejpeg($img_dst,$imagem);
	    if($ext == "jpg" || $ext == "jpeg" || $ext == "JPEG" || $ext == "JPG") {
		imagejpeg($img_dst,$imagem,100);
		return true;
		}
		elseif ($ext == "gif") {
			imagepng($img_dst,$imagem);
			return true;
			}
		elseif ($ext == "png") {
			imagepng($img_dst,$imagem);
			return true;
			}
		else {
			echo("Formato de arquivo nao suportado");
			return false;
		}
	   imagedestroy($img_dst);
	   //libera a memoria
		imagedestroy ($imagem_orig);
		imagedestroy ($imagem_fin);

	}
}







?>
