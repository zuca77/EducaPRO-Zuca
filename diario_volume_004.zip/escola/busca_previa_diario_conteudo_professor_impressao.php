<?php
session_start();

if (isset($_SESSION["login_usuario"]))
  {
   // session_cache_expire(1);
	 $login     =  $_SESSION["login_usuario"];
     $nte       =  $_SESSION["nivel_usuario"];
	 $inep      =  $_SESSION["inep_usuario"] ;
     $ntelogin  =  $_SESSION["nte_login"];
     $cpf1       = $_SESSION["cpf_usuario"];

	 include ("../funcoes.php");

  }
 else
  {
     		 header("../../Location: login.php");
  }


include ("../../conexao_mysql.php");

if(file_exists("../../conexao_mysql.php"))
{
        require "../../conexao_mysql.php";

} else
{
        echo "Conex�o nao foi encontrado";
        exit;
}


$id=$_GET["valor"];


 $totalcaracter       = strlen($id);
 $posicao1            = strpos($id, '*');
 $posicao2            = strpos($id, '-');
 $idturmaprofessor    = substr($id, 0, $posicao1);
 $id_etapa            = substr($id, $posicao1+1,  $posicao2 - ($posicao1)-1);
 $id_tp_rel           = substr($id, $posicao2+1,  $totalcaracter-$posicao2-1);


//********* Turma di�rio criado para calculo de horas****************************
 $turmadiario =$idturmaprofessor;

//*********Caso relatorio seja mensal****************************
 $data =    $id_etapa;


//echo "etapa $id_etapa";
//echo "turma $idturmaprofessor";
//echo "tp rel $id_tp_rel";


$sql="SELECT ano, situacao FROM ano where situacao = 'A' and inep = '$inep'";
$resultado=mysql_query($sql) or die (mysql_error());
$linhas=mysql_num_rows($resultado);
if ($linhas>0)
 {
    while($pegar=mysql_fetch_array($resultado))
   {
         $txtano       = $pegar["ano"];
   }
 }


$sqlturmaprof="SELECT id_turma,cpf,id_disciplina FROM turmaprofessor where id = '$idturmaprofessor'";
$resultadoturmaprof=mysql_query($sqlturmaprof) or die (mysql_error());
$linhasturmaprof=mysql_num_rows($resultadoturmaprof);
if ($linhasturmaprof > 0)
 {
    while($pegarturmaprof=mysql_fetch_array($resultadoturmaprof))
   {
         $txtturma_prof                 = $pegarturmaprof["id_turma"];
         $cpf_prof                      = $pegarturmaprof["cpf"];
         $id_disciplina_prof            = $pegarturmaprof["id_disciplina"];
         $idurma = $txtturma_prof; // variavel usada la embaixo
   }
 }




$sqlturma="SELECT modalidade,semestre FROM turma where inep = '$inep' and id = '$txtturma_prof'";
$resultadoturma=mysql_query($sqlturma) or die (mysql_error());
$linhasturma=mysql_num_rows($resultadoturma);
if ($linhasturma>0)
 {
    while($pegarturma=mysql_fetch_array($resultadoturma))
   {
         $txtmodalidade       = $pegarturma["modalidade"];
         $id_semestre         = $pegarturma["semestre"];
   }
 }


/*******************************Verificando se as etapas estao definidas ou nao*********************************************************************/


if($id_tp_rel=="E")
{

if (($txtmodalidade=='1') || ($txtmodalidade =='3'))
{
               $sqlgerencia = "select * from  etapa_liberacao
               where inep  = '$inep'
               and   ano= '$txtano'
               and id_modalidade = '$txtmodalidade'
               and id_etapa = '$id_etapa'";


               $resultadoger=mysql_query($sqlgerencia) or die (mysql_error());
               $linhas   =mysql_num_rows($resultadoger);
               if($linhas<=0)
                  {
                      echo "<html><head><title>Resposta !!!</title></head>";
                      echo "<body background=\"background_mensagens.jpg\" style=\"background-attachment:fixed; background-repeat:no-repeat\">";
                      echo "<br><br><br>";
                      echo "<center><img src=\"faleconosco/atencao.gif\" alt=\"\"><p><font color=\"#FF0000\" face=\"Verdana\" size=\"4\"><b>Per�odo n�o definido.</b></font></center>";
                      echo "</body></html>";
                      exit;
                   }
 }
else
{
               $sqlgerencia = "select * from  etapa_liberacao where inep  = '$inep'
               and ano= '$txtano'
               and id_modalidade = '$txtmodalidade'
               and semestre  = '$id_semestre'
               and id_etapa = '$id_etapa'";
               $resultadoger=mysql_query($sqlgerencia) or die (mysql_error());
               $linhas   =mysql_num_rows($resultadoger);
               if($linhas<=0)
                   {
                      echo "<html><head><title>Resposta !!!</title></head>";
                      echo "<body background=\"background_mensagens.jpg\" style=\"background-attachment:fixed; background-repeat:no-repeat\">";
                      echo "<br><br><br>";
                      echo "<center><img src=\"faleconosco/atencao.gif\" alt=\"\"><p><font color=\"#FF0000\" face=\"Verdana\" size=\"4\"><b>Per�odo n�o definido ou j� fechado.</b></font></center>";
                      echo "</body></html>";
                      exit;
                   }
  }
}



if($id_tp_rel=="E")
{

if (($txtmodalidade=='1') || ($txtmodalidade=='3'))
{
$sqlgerencia = "select * from  etapa_liberacao where inep  = '$inep'
               and ano= '$txtano'
               and id_modalidade = '$txtmodalidade'
               and id_etapa  = '$id_etapa'";
	$resultadoger=mysql_query($sqlgerencia) or die (mysql_error());
	$linhas   =mysql_num_rows($resultadoger);
	if($linhas>0)
	{
	     while ( $pega_dados = mysql_fetch_array( $resultadoger ))
              {
            $dt_inicio   = $pega_dados["dt_inicio"];
            $dt_fim       = $pega_dados["dt_fim"];




               }
	}
}
else
{
              $sqlgerencia = "select * from  etapa_liberacao where inep  = '$inep'
               and ano= '$txtano'
               and id_modalidade = '$txtmodalidade'
               and semestre  = '$id_semestre'
               and id_etapa  = '$id_etapa'";
	$resultadoger=mysql_query($sqlgerencia) or die (mysql_error());
	$linhas   =mysql_num_rows($resultadoger);
	if($linhas>0)
	{
	     while ( $pega_dados = mysql_fetch_array( $resultadoger ))
              {
            $dt_inicio   = $pega_dados["dt_inicio"];
            $dt_fim       = $pega_dados["dt_fim"];
               }
	}


}
}



/**********************************************************************************************************************************************/


if(!empty($_GET["valor"]))
 {

$sql="SELECT t.id, h.descricao AS descdisciplina, tu.descricao AS descturma, s.nome, h.codigo as disciplina,
t.id as idturma, s.cpf, tu.id AS idturma
FROM turmaprofessor t, habilitacao h, turma tu, servidorrec s
WHERE t.id_disciplina = h.codigo
AND tu.id = t.id_turma
AND s.cpf = t.cpf
AND t.id = '$turmadiario'";




  $resultado=mysql_query($sql) or die (mysql_error());
  $linhas=mysql_num_rows($resultado);
  if($linhas>0)
 {
?>
<html>
<head>
    <meta http-equiv="content-type" content="text/html; charset=ISO-8859-1" />
     <script language="javascript" src="alteracao.js"></script>	
	
	<link rel="stylesheet" href="style/forms.css" type="text/css" />
	<link rel="stylesheet" href="estilo.css" type="text/css" />
	<link rel="stylesheet" href="style/menu.css" type="text/css" />
	<link href="tablecloth/tablecloth.css" rel="stylesheet" type="text/css" media="screen" />
    <link rel="stylesheet" href="css/bootstrap.min.css" type="text/css" />
<script language="JavaScript" type="text/javascript">

function teclas(event){
if(((event.keyCode < 96) || (event.keyCode > 105)) && ((event.keyCode < 48) || (event.keyCode > 57)) ) {
campo.value = campo.value.replace(String.fromCharCode(event.keyCode).toLowerCase(),"");
}
}


</script>






<style type="text/css">
<!--
.style4 {color: #000000; font-weight: bold; }
.style10 {color: #000033; font-weight: bold; }
.style14 {color: #000033}
-->
</style>
</head>
<body>
<form  name="form_busca_produto" class="form" action="insere_dados.php" method="POST">
<table border="0" width="100%" class="table table-striped">


<?
while($pegar=mysql_fetch_array($resultado))
  {

  $iddisciplina  = $pegar["disciplina"];
  $idturma               = $pegar["idturma"];
  $cpfprofessor           = $pegar["cpf"];
?>
 	 



<tr>
    <td><span class="style4">Data</span></td>
   <td><span class="style4">Conteudo</span></td>
</tr>

<?

  }



     if($id_tp_rel=="M")
            {

          $sql_conteudo="select id,id_professor,id_turma,inep,assunto,id_disciplina,data_chamada
          from frequencia_cabeca
          where  id_professor = '$cpfprofessor'   and id_turma = '$idturma' and  inep= '$inep'  and id_disciplina= '$iddisciplina'
          and  Month(data_chamada) = '$data'
          order by data_chamada ";
       }
     else // etapa
       {

//echo "* $dt_inicio";
//echo "* $dt_fim";


         $sql_conteudo="select id,id_professor,id_turma,inep,assunto,id_disciplina,data_chamada
         from frequencia_cabeca
         where  id_professor = '$cpfprofessor'   and id_turma = '$idturma' and  inep= '$inep'
          and id_disciplina= '$iddisciplina' and  data_chamada >= '$dt_inicio' and  data_chamada<= '$dt_fim' order by data_chamada ";

       }


      $resultado_conteudo=mysql_query($sql_conteudo) or die (mysql_error());
      $linhas_conteudo=mysql_num_rows($resultado_conteudo);
      if($linhas_conteudo>0)
         {
           while($pegar_conteudo=mysql_fetch_array($resultado_conteudo))
          {

             $data_chamada      = date("d/m/Y",strtotime($pegar_conteudo["data_chamada"]));
             $assunto          = $pegar_conteudo["assunto"];

    ?>
            <tr>
                <td> <?echo $data_chamada;?> </td>
	          <td> <?echo $assunto;?></td>
 	      </tr>


     <?

      }
     }
     else
         {




                                                                                                                                                 	echo "<center><p><bl <font color=\"#ff6600\" face=\"Verdana\" size=\"3\"><b><blink>Nao existe lancamento de registro Conteudo! </blink><b></b></font></center>";

            exit;

         }




 }
else
 {
	echo "<center><p><bl <font color=\"#ff6600\" face=\"Verdana\" size=\"3\"><b><blink>Turma n�o Localizado!!!! </blink><b></b></font></center>";
 }
}
 
?>
</table> 

<?



if($id_tp_rel=="M")
 {
 $sql = "select count(*) as total from dias_diario d,tipo_aula t where id_turmaprofessor = '$turmadiario' and  t.id = d.tipo_aula and d.tipo_aula in(1,2 ) and  Month(data) = '$data'";
 $resultado=mysql_query($sql) or die (mysql_error());
 $linhas=mysql_num_rows($resultado);
 while($pegar=mysql_fetch_array($resultado))
   {
     $total = $pegar["total"];
   }

 $sql = "select count(*) as total from dias_diario d,tipo_aula t where id_turmaprofessor = '$turmadiario' and t.id = d.tipo_aula and d.registrado = 'S'
 and t.id = d.tipo_aula and d.tipo_aula in(1,2 ) and  Month(data) = '$data'";

 $resultado=mysql_query($sql) or die (mysql_error());
 $linhas=mysql_num_rows($resultado);
 while($pegar=mysql_fetch_array($resultado))
   {
     $totalregistrada = $pegar["total"];
   }


 $sql = "select count(*) as total from dias_diario d,tipo_aula t where id_turmaprofessor = '$turmadiario' and t.id = d.tipo_aula and d.registrado = 'N'
  and t.id = d.tipo_aula and d.tipo_aula in(1,2 ) and  Month(data) = '$data'";

 $resultado=mysql_query($sql) or die (mysql_error());
 $linhas=mysql_num_rows($resultado);
 while($pegar=mysql_fetch_array($resultado))
   {
     $totalnregistrada = $pegar["total"];
   }




 /*AULA DE RECUPERA��O*/
 $sql = "select count(*) as total from dias_diario d,tipo_aula t where id_turmaprofessor = '$turmadiario' and  t.id = d.tipo_aula and d.tipo_aula in(3) and  Month(data) = '$data'";
 $resultado=mysql_query($sql) or die (mysql_error());
 $linhas=mysql_num_rows($resultado);
 while($pegar=mysql_fetch_array($resultado))
   {
     $totalrec = $pegar["total"];
   }


 $sql = "select count(*) as total from dias_diario d,tipo_aula t where id_turmaprofessor = '$turmadiario' and t.id = d.tipo_aula and d.registrado = 'S'
 and t.id = d.tipo_aula and d.tipo_aula in(3) and  Month(data) = '$data'";

 $resultado=mysql_query($sql) or die (mysql_error());
 $linhas=mysql_num_rows($resultado);
 while($pegar=mysql_fetch_array($resultado))
   {
     $totalrecregistrada = $pegar["total"];
   }



  $sql = "select count(*) as total from dias_diario d,tipo_aula t where id_turmaprofessor = '$turmadiario' and t.id = d.tipo_aula and d.registrado = 'N'
  and t.id = d.tipo_aula and d.tipo_aula in(3 ) and  Month(data) = '$data'";

 $resultado=mysql_query($sql) or die (mysql_error());
 $linhas=mysql_num_rows($resultado);
 while($pegar=mysql_fetch_array($resultado))
   {
     $totalrecnregistrada = $pegar["total"];
   }

}

else   /*Etapa*/
{


 $sql = "select count(*) as total from dias_diario d,tipo_aula t where id_turmaprofessor = '$turmadiario'
 and  t.id = d.tipo_aula
 and  d.tipo_aula in(1,2)
 and  data >= '$dt_inicio'
 and  data <= '$dt_fim'";
 $resultado=mysql_query($sql) or die (mysql_error());
 $linhas=mysql_num_rows($resultado);
 while($pegar=mysql_fetch_array($resultado))
   {
     $total = $pegar["total"];
   }

 $sql = "select count(*) as total from dias_diario d,tipo_aula t where id_turmaprofessor = '$turmadiario'
 and t.id = d.tipo_aula
 and d.registrado = 'S'
 and t.id = d.tipo_aula
 and d.tipo_aula in(1,2)
 and  data >= '$dt_inicio'
 and  data <= '$dt_fim'";

 $resultado=mysql_query($sql) or die (mysql_error());
 $linhas=mysql_num_rows($resultado);
 while($pegar=mysql_fetch_array($resultado))
   {
     $totalregistrada = $pegar["total"];
   }


 $sql = "select count(*) as total from dias_diario d,tipo_aula t where id_turmaprofessor = '$turmadiario'
  and t.id = d.tipo_aula
  and d.registrado = 'N'
  and t.id = d.tipo_aula
  and d.tipo_aula in(1,2)
  and  data >= '$dt_inicio'
  and  data <= '$dt_fim'";
  $resultado=mysql_query($sql) or die (mysql_error());
 $linhas=mysql_num_rows($resultado);
 while($pegar=mysql_fetch_array($resultado))
   {
     $totalnregistrada = $pegar["total"];
   }




 /*AULA DE RECUPERA��O*/
 $sql = "select count(*) as total from dias_diario d,tipo_aula t where id_turmaprofessor = '$turmadiario'
 and  t.id = d.tipo_aula and d.tipo_aula in(3)
 and  data >= '$dt_inicio'
 and  data<= '$dt_fim'";
 $resultado=mysql_query($sql) or die (mysql_error());
 $linhas=mysql_num_rows($resultado);
 while($pegar=mysql_fetch_array($resultado))
   {
     $totalrec = $pegar["total"];
   }


 $sql = "select count(*) as total from dias_diario d,tipo_aula t where id_turmaprofessor = '$turmadiario'
 and t.id = d.tipo_aula
 and d.registrado = 'S'
 and t.id = d.tipo_aula
 and d.tipo_aula in(3)
 and  data >= '$dt_inicio' and  data <= '$dt_fim'";
 $resultado=mysql_query($sql) or die (mysql_error());
 $linhas=mysql_num_rows($resultado);
 while($pegar=mysql_fetch_array($resultado))
   {
     $totalrecregistrada = $pegar["total"];
   }



  $sql = "select count(*) as total from dias_diario d,tipo_aula t where id_turmaprofessor = '$turmadiario'
  and t.id = d.tipo_aula
  and d.registrado = 'N'
  and t.id = d.tipo_aula
  and d.tipo_aula in(3)
  and data >= '$dt_inicio' and  data <= '$dt_fim'";

 $resultado=mysql_query($sql) or die (mysql_error());
 $linhas=mysql_num_rows($resultado);
 while($pegar=mysql_fetch_array($resultado))
   {
     $totalrecnregistrada = $pegar["total"];
   }


}





















if ($total>0)
  {
?>


<table border="0" width="100%" class="table table-striped">
  <tr><td><font size="2"> <center>
    <b><span class="style14">Aula = Normal + Reposi��o</span>        </b>
  </center></td><td>******* </td>
  </tr>

  <tr><td class="style10">Total aula(s) prevista(s) Tipo (N+R)</td>
  <td><font size="2"> <?echo $total;?>  </tr>

  <tr><td><span class="style10">Total de Aula(s) Registrada(s)</span></td>
    	  <td><font size="2"> <?echo  $totalregistrada;?>
  </tr>

  <tr><td><span class="style10">Total de Aula(s) N�o Registrada(s)</span></td>
    	  <td><font size="2"> <?echo  $totalnregistrada;?>
  </tr>

  <tr><td><font size="2"> <center>
    <b><span class="style14">Aula = Recupera��o</span>        </b>
  </center></td><td>******* </td>
  </tr>

  <tr><td><span class="style14"><strong>Total Aula Prevista de Recupera��o</strong></span></td>
    	  <td><font size="2"> <?echo  $totalrec;?>
  </tr>


  <tr><td><span class="style10">Total Aula de Recupera��o Registrada</span></td>
    	  <td><font size="2"> <?echo  $totalrecregistrada;?>
  </tr>


  <tr><td><span class="style10">Total Aula de Recupera��o N�o Registrada</span></td>
    	  <td><font size="2"> <?echo  $totalrecnregistrada;?>
  </tr>




<?
}
?>
</table>
</body>
</html>
