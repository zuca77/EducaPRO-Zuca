<?
session_start();
if (isset($_SESSION["login_usuario"]))
  {
   // session_cache_expire(1);
	 $login     =  $_SESSION["login_usuario"];
     $nte       =  $_SESSION["nivel_usuario"];
	 $inep      =  $_SESSION["inep_usuario"] ;
     $ntelogin  =  $_SESSION["nte_login"];
	 include ("funcoes.php");
     echo  saudacoes()."   ". "$login" ."  -  ". $nte."  ".dataextenso() ." - ".$inep;

  }
 else
  {
     		 header("Location: ../login.php");
  }








?>

<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">

<head>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1" />
<title>GTI/SEDUC-RO</title>
  <link rel="stylesheet" href="../estilos.css" type="text/css">
  <link rel="stylesheet" href="css/bootstrap.min.css" type="text/css" />

<style>
		<style text="text/css">
			li:hover ul ul, li.over ul ul { 
			display:none; 
			}

			li:hover ul, li li:hover ul, li.over ul, 
			li li.over ul { 
			display: block; 
			}
			li:hover ul, li.over ul { 
			display: block; 
			}
			ul,
			ul ul {
				margin: 0;
				padding: 0;
				width: 148px;
				/*border-bottom: 1px solid #ccc;*/
		    	background: #008080; /* IE6 Bug cor de fundo #006699*/
				font-size: 100%;
				}

			ul li {
				position: relative;
				list-style: none;
				}

			ul li a {
				display: block;
				text-decoration: none;
				color: #FF0000;/**/
				padding: 1px; /*reduz  a largura da tabela*/
			/*	border: 1px solid #333333*/ /   * largura de borda  grade das tabelas  cor da borda*/;
				border-bottom: 0;
				}

			/* Hack para IE \*/
			* html ul li { float: left; height: 1%; }
			* html ul li a { height: 1%; }
			/* End */

			ul ul {
				position: absolute;
				display: none;
				left: 142px; 
				top: 0;
				}
			ul li ul li a { padding: 2px 5px; }

			ul li:hover ul ul,
			ul li:hover ul ul ul,
			ul li.over ul ul,
			ul li.over ul ul ul { display: none; }

			ul li:hover ul,
			ul li li:hover ul,
			ul li li li:hover ul,
			ul li.over ul,
			ul li li.over ul,
			ul li li li.over ul { display: block; }

			ul li.menupai { background: transparent url(arrow.gif) right center no-repeat; }

			ul li.menupai:hover,
			ul li.over { background-color: #FF0000; }/*cor do prompt */

			ul li a:hover { color: #FFFF00; } /* ao passar ao mouse cor da letra*/

		.style1 {color: #0000FF}
</style>

</style>

 <script language="javascript" src="../generic.js"></script>	

</head>

<body>
<center>	
    <table>
      <tr>
        <td height="0"></td>
      </tr>
    </table>

    <div id="geral">

          <div id="topo">
            <img src= "img/seduc_topo2via.jpg"/>
         </div>


    <div id="corpo">
           <br/><br/><br/><br/><br/><br/><br/><br/>
           <center><img src= "img/gestao.jpg"/></center>

    </div>

	
	
    <div id="menu" class="fonte" align="left">
	    <p>&nbsp; </p>
	    <h3 align="center"><strong>ADM ESCOLAR</strong></h3>

   	  <ul  class="menu_vertical">

       	<li class="menupai"><a href="#">Escola</a>
		            <ul class="inline">

              <li><a href="form_altera_escola_gestao.php"  title="Permite Atualizar dados ">Cadastro</a></li>
              <li><a href="turma/form_inclusao_tp_recuperacao.php"  title="Permite Definir tipo de recupera��o">Tipo de Recupera��o</a></li>
               <li><a href="turma/form_inclusao_gradecurricular.php"  title="Permite a cria��o de turma">Grade Curricular</a></li>
                  </ul>
		</li>






                          <li class="menupai"><a href="#">Reposit�rio</a>
		                           <ul>
                                       <li class="menupai"><a href="#" title = "Acessa Turmas que Foram Fechadas Durante  Ano Corrente">Turmas Encerradas</a>
                                         <ul>
                                             <li><a href="nota/form_imprimi_fichaindividual_turmas_encerradas.php"  title="Pesquisa geral de alunos..">Ficha Individual</a></li>
                                             <li><a href="nota/form_turma_atafina_eja_turma_encerrada.php"  title="Pesquisa ATA Final Modalidade EJA">Ata Final EJA</a></li>
						   <li><a href="nota/form_turma_atafina_ef_turmas_encerradas.php"  title="Pesquisa ATA Final Modalidade ER">Ata Final ER</a></li>

                                             <li><a href="turma/form_reabertura_turmas_encerradas.php"  title="Permite abrir turma fechada no mesmo ano.">Reabertura</a></li>
    	                                  </ul>
                                       <li class="menupai"><a href="#" title = "Acessa Turmas fechadas nos anos anteriores ">Ano Letivo Fechado</a>
                                           <ul>
                                              <li><a href="#"  title="Pesquisa geral de alunos.">Ficha Individual</a></li>
                   			        



                                          </ul>

     			                </ul>
	                     	</li>



                          <li class="menupai"><a href="#">Elimina��o de Componente</a>
		                           <ul>
                                       <li class="menupai"><a href="#">Avalia��o Especial</a>
                                         <ul>
                                              <li><a href="nota/form_lanca_nota_eliminacao_componente.php"  title="Permite incluir componente elimindado.">Inclus�o</a></li>
                                              <li><a href="nota/form_consulta_aluno_eliminacao.php"  title="Permite realizar consulta de aluno e componente eliminado.">Consulta</a></li>
   			                         

    </ul>

                                       <li class="menupai"><a href="#">Conselho de Professores</a>
                                           <ul>
                                              <li><a href="nota/form_lanca_nota_eliminacao_componente_ce.php"  title="Permite incluir componente elimindado.">Inclus�o</a></li>
                                              <li><a href="nota/form_consulta_aluno_eliminacao_cp.php"  title="Permite realizar consulta de aluno e componente eliminado.">Consulta</a></li>
                   		               </ul>

                                       <li class="menupai"><a href="#">ENEM/ENCEJA</a>
                                           <ul>
                                              <li><a href="nota/form_lanca_nota_eliminacao_componente_enem.php"  title="Permite incluir componente eliminado pelo ENEM.">Inclus�o</a></li>
                                              <li><a href="nota/form_consulta_aluno_eliminacao_enem.php"  title="Permite realizar consulta  e cancelamento componente eliminado pelo ENEM .">Consulta</a></li>
                   		               </ul>
     			               

                                       <li class="menupai"><a href="#">Prenchimento de  Lacuna</a>
                                         <ul>
                                              <li><a href="aluno/form_pesquisa_aluno_lacuna.php"  title="Permite incluir nota para preenchimento de lacuna.">Inclus�o</a></li>
                                              <li><a href="nota/form_consulta_aluno_eliminacao_lacuna.php"  title="Permite realizar consulta de aluno lacunado.">Consulta</a></li>
   			                             </ul>





       	<li class="menupai"><a href="#">Avalia��es Recebida de Escolas Fora da Rede</a>
		            <ul>
              <li><a href="nota/form_tp_avaliacao_alunos_recebidos.php"  title="Permite alunos com avalia��es de escolas fora da rede.">Inclus�o</a></li>
              <li><a href="nota/form_consulta_ava_fora_rede.php"  title="Permite realizar consulta de aluno e componente eliminado.">Consulta</a></li>
   			    </ul>
		</li>



                                       </ul>
	                     	</li>



       	<li class="menupai"><a href="#">Justificativa de Faltas</a>

		                 <ul>
                           <li><a href="nota/form_lanca_falta_eliminacao_componente.php"  title="Permite incluir justificativa de faltas.">Inclus�o</a></li>
                           <li><a href="nota/form_consulta_abono_faltas.php"  title="Permite consultar alunos com justificativa de faltas.">Consulta</a></li>
   			             </ul>

		</li>






       	<li class="menupai"><a href="#">Chamada Escolar</a>
		          <ul>
				<li><a href="chamadaescolar/form_inclusao_saldo.php"  title="Permite o cadastro de saldo de vagas"><blink>Inclus�o de Vagas</blink></a></li>
                            <li><a href="chamadaescolar/form_pesquisa_aluno.php"  title="Permite incluir o aluno na chamada escolar"><blink>Matricula</blink></a></li>
                            <li><a href="chamadaescolar/form_rel_vagaschamadaescolar.php"  title="Permite Verificar vagas em outras escolas">Consulta Vagas</a></li>

                        <li class="menupai"><a href="#">Relatorios</a>
	       	                <ul>
                                      <li><a href="chamadaescolar/rel_alunos.php"  title="Visualiza alunos matriculados na chamada escolar">Anal�tico</a></li>
                                     <li><a href="chamadaescolar/rel_sintetico.php"  title="Visualiza vagas disponibilizadas na chamada escolar">Sint�tico</a></li>
    		                    	  </ul>
                          	</li>





			  </ul>
		</li>


       	<li class="menupai"><a href="#">Aluno</a>
 		            <ul>
                        	<li><a href="aluno/form_pesquisa_aluno_turma.php"    title="Matricula aluno individual">Pesquisa Aluno</a></li>
                         	<li><a href="aluno/form_pesquisa_aluno.php"     title="Matricula aluno individual">Matricula Individual</a></li>
                            <li><a href="aluno/busca_aluno_importacao.php"  title="Permite matricular um grupo de alunos">Matricula Grupo</a></li>
	    		    </ul>



		</li>

      	<li><a href="aluno/form_pesquisa_aluno_turma.php"    title="Matricula aluno individual">Pesquisa Aluno</a></li>


 


       	<li class="menupai"><a href="#">Servidor</a>
           <ul>

           		<li><a href="formealtera.php"           title="Permite realizar altera��o de dados pessoais." >Altera Dados Servidor</a></li>
                <li><a href="form_consulta_memo.php"           title="Permite gerar recep��o de Servidor." >Recep��o de Servidor</a></li>
              	<li class="menupai"><a href="#">Devolu��o Servidor</a>
			    <ul>
			 	<li><a href="relatorios/professoresdev.php"      title="Relat�rio de servidores lotado em sala de aula">Professores</a></li>
                <li><a href="relatorios/administrativodev.php"   title="Servidores lotado em ambiente administrativo">Administrativo</a></li>
			  </ul>
		</li>

       	<li class="menupai"><a href="#">Enquadramento Servidor</a>
			  <ul>
				<li><a href="relatorios/professoresenquadra.php"      title="Relat�rio de servidores lotado em sala de aula">Professores</a></li>
                <li><a href="relatorios/administrativoenquadra.php"   title="Servidores lotado em ambiente administrativo">Administrativo</a></li>
			  </ul>
           </ul>
		</li>










       	<li class="menupai"><a href="#">Associar</a>
   		           <ul>
				     <li><a href="matricula/form_assoc_aluno_tuma.php"  title="Permite alocar aluno em turmas.">Turma x Aluno</a></li>
		     	  </ul>


		</li>


       	<li class="menupai"><a href="#">Turma</a>

             <ul>

   		                <li><a href="turma/form_inclusao_turma.php"  title="Permite criar ou fechar novas turmas">Criar/Fechar</a></li>
     			        <li><a href="turmamanutencao/form_consulta_aluno_nchamada.php"  title="Permite Incluir N�mero de Chamda">N� Di�rio</a></li>
    			        <li><a href="turmamanutencao/form_consulta_turmaaluno.php"  title="Permite realizar movimenta��o de aluno">Movimentar Aluno</a></li>
  	    		        <li><a href="turmamanutencao/form_imprimi_turma_aluno.php"  title="Consulta Turma x Aluno - seus status">Espelho Turma</a></li>
  	    		        <li><a href="turmamanutencao/form_turma_aluno_dependencia.php"  title="Vincula Aluno x Disciplina">Depend�ncia</a></li>


		   </ul>
	      </li>




       <li><a href="chamada/form_fechamento_faltas_sec.php"  title="Permite Registrar total de frequ�ncia no boletim e ficha individual">Totalizador de Faltas</a></li>


       	           <li class="menupai"><a href="#">Supervis�o</a>
		              <ul>
                              <li><a href="supervisao/form_inclusao_prof_disc.php"        title="Permite associar aluno x disciplina x turma">Prof x Disciplina</a></li>
                              <li><a href="supervisao/form_inclusao_prof_turma.php"       title="Permite associar aluno x disciplina x turma">Prof x Turma</a></li>
                            
                               <li><a href="calendario/form_inclusao_calendario.php"       title="Resgistra calend�rio letivo para liberar di�rio eletr�nico">Calend�rio Letivo</a></li>                            
				  <!--<li><a href="supervisao/form_inclusao_prof_disc.php"    title="Permite associar aluno x disciplina x turma">Capa Di�rio</a></li>-->
                              <li><a href="calendario/form_pesquisa_professor.php"       title="Permite associar os dias letivos para cada professor">Previs�o Dias Di�rio</a></li>
                             
                              <li><a href="calendario/form_pesquisa_professor_dia_dairio.php"         title="Permite visualizar dias letivos alocados por turma">Dias Di�rio Por Turma</a></li>
                              

                               <li><a href="calendario/form_pesquisa_professor_conteudo.php"       title="Permite Pr�via Di�rio Conte�do.">Pr�via Di�rio Conte�do</a></li>

                              <li><a href="supervisao/form_liberacao_bim.php"  title="Consulta Turma x Aluno">Libera��o de Etapas</a></li>
                              <li><a href="supervisao/busca_professor_senha.php"  title="Permite liberar acesso ao di�rio eletr�nico">Libera��o de Acesso</a></li>

                              
                              <li><a href="calendario/form_pesquisa_professor_frequencia.php"       title="Permite Pr�via Di�rio Conte�do.">Frequ�ncia Escolar</a></li> 

			       </ul>
		           </li>









       	   <li class="menupai"><a href="#">Lan�amento Nota</a>
		                  <ul>
                                         <li class="menupai"><a href="#">Inclus�o Nota Bimestral</a>
                                               <ul>
                                                <li><a href="nota/form_lanca_notabimsecret.php"  title="Permite Lan�armento de Nota">1� Bim</a></li>
                                                <li><a href="nota/form_lanca_notabim2secret.php"  title="Permite Lan�armento de Nota">2� Bim</a></li>
                                                <li><a href="nota/form_lanca_notabim3secret.php"  title="Permite Lan�armento de Nota">3� Bim</a></li>
                                                <li><a href="nota/form_lanca_notabim4secret.php"  title="Permite Lan�armento de Nota">4� Bim</a></li>
                                               <!-- <li><a href="#"  title="Permite Lan�armento de Nota Individual">Manuten��o</a></li>-->
                                                <li><a href="nota/form_lanca_nota_individual.php"  title="Permite Lan�armento de Nota Individual">Individual</a></li>

                                              </ul>
                                         </li>




                                         <li class="menupai"><a href="#">Altera��o Nota Bimestral</a>
                                               <ul>
                                                <li><a href="nota/form_lanca_nota_alterabimsecret.php"  title="Permite Altera��o de Nota">1� Bim</a></li>
     		                                  <li><a href="nota/form_lanca_nota_altera2bimsecret.php"  title="Permite Lan�armento de Nota">2� Bim</a></li>
                                                <li><a href="nota/form_lanca_nota_altera3bimsecret.php"  title="Permite Lan�armento de Nota">3� Bim</a></li>
                                                <li><a href="nota/form_lanca_nota_altera4bimsecret.php"  title="Permite Lan�armento de Nota">4� Bim</a></li>
                                              </ul>
                                         </li>



                                         <li class="menupai"><a href="#">Inclus�o Nota Recupera��o</a>
                                               <ul>
                                                <li><a href="nota/form_lanca_notasecretrec1.php"  title="Permite Lan�amento Recupera��o do 1� Bim">1� Bim</a></li>
                                                 <li><a href="nota/form_lanca_notasecretrec2.php"  title="Permite Lan�amento Recupera��o do 2� Bim">2� Bim</a></li>
							<li><a href="nota/form_lanca_notasecretrec3.php"  title="Permite Lan�amento Recupera��o do 3� Bim">3� Bim</a></li>
                                                <li><a href="nota/form_lanca_notasecretrec4.php"  title="Permite Lan�armento de Nota">4� Bim</a></li>
                                               <li><a href="nota/form_lanca_rec1semsecret.php"  title="Permite Altera��o de Nota 1� Semestre Ensino Regular/1� e 2� Semestre EJA ">1� SEM ER/1�e 2� SEM EJA</a></li>
                                              <li><a href="nota/form_lanca_rec2semsecret.php"  title="Permite Lan�armento de Nota 2� Semestre Bim Recupera��o">2� Semestre</a></li>
                                              <li><a href="nota/form_lanca_rec_anual_secretaria.php"  title="Permite Lan�armento de Recupera��o Anual">Anual</a></li>


                                           </ul>
                                        </li>

                                     

			       <li class="menupai"><a href="#">Altera��o Nota Recupera��o</a>
       			    <ul>
			               <li><a href="nota/form_lanca_nota_alterarec1bimsecret.php"  title="Permite alterar Notas 1� Bim">1� Bim</a></li>
			               <li><a href="nota/form_lanca_nota_alterarec2bimsecret.php"  title="Permite alterar de Nota 2� Bim">2� Bim</a></li>
			               <li><a href="nota/form_lanca_nota_alterarec3bimsecret.php"  title="Permite alterar Notas 3� Bim">3� Bim</a></li>
			               <li><a href="nota/form_lanca_nota_alterarec4bimsecret.php"  title="Permite alterar Notas 4� Bim">4� Bim</a></li>
                                    <li><a href="nota/form_nota_altera1semestrerec_secretaria.php"  title="Permite Altera��o de Nota 1� Semestre Ensino Regular/1� e 2� Semestre EJA ">1� SEM ER/1�e 2� SEM EJA</a></li>
                                    <li><a href="nota/form_nota_altera2semestrerec_secretaria.php"  title="Permite Altera��o de Nota Recupera��o 2� Semestre">2� Semestre</a></li>
                                    <li><a href="nota/form_nota_alterarec_anual.php"  title="Permite Altera��o de Nota Recupera��o Anual">Anual</a></li>

			               
			            

                              </ul>
			       </li>




                                         <li class="menupai"><a href="#">Exame Final</a>
                                               <ul>
                                                <li><a href="nota/form_lanca_examefinalsecretaria.php"  title="Permite o lan�amento do Exame Final">Inclus�o</a></li>
                                                <li><a href="nota/form_lanca_nota_altera_examefinal.php"  title="Permite Alterar  Exame Final">Altera��o</a></li>

                                              </ul>





                                        </li>






			           </ul>
                 </li>




         <li class="menupai"><a href="#">Relat�rios</a>
		          <ul>
					    <li><a href="nota/form_imprimi_turma_aluno.php"       title="Permite visualizar boletim individual">Boletim</a></li>
                                       <li><a href="nota/form_turma.php"  title="Permite visualizar quadro demonstrativo de notas">Quadro Demonstrativo</a></li>
                                       <li><a href="nota/form_nota_detalhe_secretaria.php"  title="Permite visualizar quadro notas">Quadro de notas</a></li>

                                       <li><a href="nota/form_imprimi_fichaindividual.php"   title="Permite Consulta Ficha Individual">Ficha Individual</a></li>





                                       <li class="menupai"><a href="#">ATA</a>
                                        <ul>
                                            <li><a href="nota/form_turma_atafina_eja.php"         title="Permite Consulta Ata de Resultado">Ata de Resultado EJA</a></li>
                                            <li><a href="nota/form_turma_atafina_ef.php"         title="Permite Consulta Ata de Resultado">Ata de Resultado</a></li>
					    </ul>




                                       <li class="menupai"><a href="#">Alunos</a>
                                        <ul>
                                         <li><a href="aluno/rel_alunos.php"                  title="Permite Consulta Alunos">Todos</a></li>
                                         <li><a href="aluno/rel_alunos_bf.php"               title="Permite Consulta Alunos com Bolsa Fam�lia">Bolsa Familia</a></li>
                                         <li><a href="aluno/rel_alunos_transpescolar.php"    title="Permite Consulta Alunos com Benef�cio  - Transporte Escolar">Transp Escolar</a></li>
                                         <li><a href="aluno/rel_alunos_situacao.php"         title="Permite Consulta Turma x Alunos - Situa��o">Por Situa��o</a></li>
					    </ul>

     			  </ul>
	     	</li>









 <li><a href="turmamanutencao/form_forca_fechamento_etapas.php"  title="For�a Fchamento de Etapas Alunos Recebidos de Outras Escolas">For�a Fechamento de Etapas</a></li>


       	<li class="menupai"><a href="#">Fechamento Ano</a>
      	  <ul>

                     <li><a href="nota/estatistica_ef.php"  title="Consolida��o dos Dados do Ensino Regular.">Consolida��o ER</a></li>
                     <li><a href="nota/estatistica_eja.php"  title="Consolida��o dos Dados do EJA.">Consolida��o EJA</a></li>
                      <li><a href="supervisao/form_fechamento_anoletivo.php"   title="Fechamento de ano letivo">Fechamento de Ano Letivo</a></li>
                      <li><a href="supervisao/form_abertura_anoletivo.php"   title="Abertura do ano letivo">Abertura de Ano Letivo</a></li>

			  </ul>
		</li>




		<li><a href="form_altera_senhaescola.php"           title="Permite que o usu�rio altere sua senha." >Troca Senha</a></li>
              
              <li><a href="../login.php"                       title="Permitir voltar a tela de login" >Login</a></li>

	  </ul>			

	</div>
</div>

<!--     <div id="rodape" class="fonterodape">
			<p>Todos direitos reservados GTI/SEDUC</p>
     </div>-->


</div>
</center>

</body>
</html>
