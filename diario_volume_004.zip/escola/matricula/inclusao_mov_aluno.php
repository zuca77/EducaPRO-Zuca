<?
session_start();
if (isset($_SESSION["login_usuario"]))
  {
	 $login     =  $_SESSION["login_usuario"];
     $nte       =  $_SESSION["nivel_usuario"];
	 $inep      =  $_SESSION["inep_usuario"] ;
     $ntelogin  =  $_SESSION["nte_login"];
     $cpf       =  $_SESSION["cpf_usuario"];
	 include ("../funcoes.php");

  }
 else
  {
     		 header("../../Location: login.php");
  }

if(file_exists("../../conexao_mysql.php"))
{
        require "../../conexao_mysql.php";
        mysql_query("SET NAMES 'latin1_swedish_ci'");
} else
{
        echo "Arquivo conexao_mysql nao foi encontrado";
        exit;
}




if($_SERVER["REQUEST_METHOD"] == "POST")
{
$txtid_turmaaluno = $_POST['txtid'];
$txtid_aluno      = $_POST['txtid_aluno'];
$txttpmov         = $_POST['txttpmov'];
$txtobs           = $_POST['txtobs'];
$txtdtmovimento   = $_POST['txtdtmovimento']; //informa��o do banco
$txtstatus        = $_POST['txtstatus']; //informa��o do banco

}



if (trim($txtobs)=='')
   {
    echo "<html><head><title>Resposta !!!</title></head>";
    echo "<body background=\"background_mensagens.jpg\" style=\"background-attachment:fixed; background-repeat:no-repeat\">";
    echo "<br><br><br>";
    echo "<center><img src=\"faleconosco/atencao.gif\" alt=\"\"><p><font color=\"#FF0000\" face=\"Verdana\" size=\"4\"><blink>Usu�rio informe o motivo da transfer�ncia.!</blink> <b></b></font></center>";
    echo "<br><br><center><a href=\"form_assoc_aluno_tuma.php\"><img src=\"faleconosco/button_voltar2_.gif\" alt=\"Voltar\" border=\"0\" /></a></center>";
    echo "</body></html>";
    exit;

   }


$diai = substr($txtdtmovimento, 0,2);
$anoi = substr($txtdtmovimento, -4);
$mesi = substr($txtdtmovimento, -7,2);
$txtdtmovimento=$anoi.".".$mesi.".".$diai;




$sql="select * from ano where  inep = '$inep'  and situacao = 'A'";
$resultado=mysql_query($sql) or die (mysql_error());
$linhas=mysql_num_rows($resultado);
 if ($linhas>0)
  {
       while($pegargrade=mysql_fetch_array($resultado))
       {
           $txtano      =  $pegargrade["ano"];
         }
  }
 else
  {
    echo "<html><head><title>Resposta !!!</title></head>";
    echo "<body background=\"background_mensagens.jpg\" style=\"background-attachment:fixed; background-repeat:no-repeat\">";
    echo "<br><br><br>";
    echo "<center><img src=\"faleconosco/atencao.gif\" alt=\"\"><p><font color=\"#FF0000\" face=\"Verdana\" size=\"4\"><blink>Processo n�o pode ser realizado . Usu�rio! n�o existe ano aberto.</blink> <b></b></font></center>";
    echo "<br><br><center><a href=\"../mnadmescola.php\"><img src=\"faleconosco/button_voltar2_.gif\" alt=\"Voltar\" border=\"0\" /></a></center>";
    echo "</body></html>";
    exit;

  }




   $sql="select max(id) as id,id_turma,id_aluno,situacao from turma_aluno where id_aluno = '$txtid_aluno' GROUP BY id";
   $resultado=mysql_query($sql) or die (mysql_error());
   $linhas=mysql_num_rows($resultado);
   if($linhas>0)
         {
           while($pegar=mysql_fetch_array($resultado))
             {
                $id_aluno          = $pegar["id_aluno"];
                $txtid_turmaaluno  = $pegar["id"];
                $id_turma          = $pegar["id_turma"];
                $situacao          = $pegar["situacao"];

              }
         }




$sql_turma = "select * from turma_aluno where id = '$txtid_turmaaluno'";
$resultado_turma=mysql_query($sql_turma) or die (mysql_error());
$linhas_turma   =mysql_num_rows($resultado_turma);
if($linhas_turma>0)
{
       while($pegar_turma=mysql_fetch_array($resultado_turma))
         {
           $txtano_turma     =  $pegar_turma["ano"];
         }

}




$dia = date('d');
$mes = date('m');
$ano = date('Y');
$data1 =$ano.".".$mes.".".$dia;




if($linhas>0)
{


 if ($txtano_turma == $txtano)
  {



 $sql="update turma_aluno set situacao = '3' where id = '$txtid_turmaaluno'";
if(@mysql_query($sql))
 {
 $success = mysql_affected_rows();
 if($success ==true)
  {
             $sql="update aluno set id_turma='0', status ='3' where id = '$txtid_aluno'";

             if(@mysql_query($sql))
                {
                   $success = mysql_affected_rows();
                   if($success ==true)
                      {
                          $sql = "insert into movimenta_aluno (id_aluno,id_movimento,id_turmaaluno,obs,data,usuario,dt_situacao,id_status)
                          values ('$txtid_aluno','3','$txtid_turmaaluno','$txtobs','$data1','$cpf','$txtdtmovimento',$txtstatus)";
                            if(@mysql_query($sql))
                              {
                               $success = mysql_affected_rows();
                                 if($success ==true)
                                    {
                                      echo "<html><head><title>Resposta !!!</title></head>";
                                      echo "<body background=\"background_mensagens.jpg\" style=\"background-attachment:fixed; background-repeat:no-repeat\">";
                                      echo "<br><br><br>";
                                      echo "<center><img src=\"faleconosco/atencao.gif\" alt=\"\"><p><font color=\"#ff6600\" face=\"Verdana\" size=\"4\">Aluno Movimentado  Com Sucesso.!!!! <b></b></font></center>";
                                      echo "<br><br><center><a href=\"form_assoc_aluno_tuma.php\"><img src=\"faleconosco/button_voltar2_.gif\" alt=\"Voltar\" border=\"0\" /></a></center>";
                                      echo "</body></html>";
                                    }
                              }
                         else
                                {
                                  //verifico se nao estao tentando gravar um dado que ja existe, pois usei UNIQUE na tabela
                                    if(mysql_errno() == 1062)
                                    		  {
                                                        echo $erros[mysql_errno()];
                                                                        exit;
                                              }
                                         else
                                             {
                                                       echo "Erro nao foi possivel efetuar atualiza��o do aluno";
                                                        exit;
                                             }
                                              @mysql_close();
                                    }
                      }
                   }
                 else
                    {
                            //verifico se nao estao tentando gravar um dado que ja existe, pois usei UNIQUE na tabela
                                    if(mysql_errno() == 1062)
                                    		  {
                                                        echo $erros[mysql_errno()];
                                                                        exit;
                                              }
                                         else
                                             {
                                                       echo "Erro nao foi possivel efetuar atualiza��o do aluno";
                                                        exit;
                                             }
                                              @mysql_close();
                     }

     }
    else
     {

             $sql="update aluno set id_turma='0', status ='3' where id = '$txtid_aluno'";
             if(@mysql_query($sql))
                {
                   $success = mysql_affected_rows();
                   if($success ==true)
                      {
                          $sql = "insert into movimenta_aluno (id_aluno,id_movimento,id_turmaaluno,obs,data,usuario,dt_situacao,id_status)
                          values ('$txtid_aluno','3','$txtid_turmaaluno','$txtobs','$data1','$cpf','$txtdtmovimento',$txtstatus)";
                            if(@mysql_query($sql))
                              {
                               $success = mysql_affected_rows();
                                 if($success ==true)
                                    {
                                      echo "<html><head><title>Resposta !!!</title></head>";
                                      echo "<body background=\"background_mensagens.jpg\" style=\"background-attachment:fixed; background-repeat:no-repeat\">";
                                      echo "<br><br><br>";
                                      echo "<center><img src=\"faleconosco/atencao.gif\" alt=\"\"><p><font color=\"#ff6600\" face=\"Verdana\" size=\"4\">Aluno Movimentado  Com Sucesso.!!!! <b></b></font></center>";
                                      echo "<br><br><center><a href=\"form_assoc_aluno_tuma.php\"><img src=\"faleconosco/button_voltar2_.gif\" alt=\"Voltar\" border=\"0\" /></a></center>";
                                      echo "</body></html>";
                                    }
                              }
                         else
                                {
                                  //verifico se nao estao tentando gravar um dado que ja existe, pois usei UNIQUE na tabela
                                    if(mysql_errno() == 1062)
                                    		  {
                                                        echo $erros[mysql_errno()];
                                                                        exit;
                                              }
                                         else
                                             {
                                                       echo "Erro nao foi possivel efetuar atualiza��o do aluno";
                                                        exit;
                                             }
                                              @mysql_close();
                                    }
                      }
                   }





     }


  }
 else
   {
        //verifico se nao estao tentando gravar um dado que ja existe, pois usei UNIQUE na tabela




             $sql="update aluno set id_turma='0', status ='3' where id = '$txtid_aluno'";
             if(@mysql_query($sql))
                {
                   $success = mysql_affected_rows();
                   if($success ==true)
                      {
                          $sql = "insert into movimenta_aluno (id_aluno,id_movimento,id_turmaaluno,obs,data,usuario,dt_situacao,id_status)
                          values ('$txtid_aluno','3','$txtid_turmaaluno','$txtobs','$data1','$cpf','$txtdtmovimento',$txtstatus)";
                            if(@mysql_query($sql))
                              {
                               $success = mysql_affected_rows();
                                 if($success ==true)
                                    {
                                      echo "<html><head><title>Resposta !!!</title></head>";
                                      echo "<body background=\"background_mensagens.jpg\" style=\"background-attachment:fixed; background-repeat:no-repeat\">";
                                      echo "<br><br><br>";
                                      echo "<center><img src=\"faleconosco/atencao.gif\" alt=\"\"><p><font color=\"#ff6600\" face=\"Verdana\" size=\"4\">Aluno Movimentado  Com Sucesso.!!!! <b></b></font></center>";
                                      echo "<br><br><center><a href=\"form_assoc_aluno_tuma.php\"><img src=\"faleconosco/button_voltar2_.gif\" alt=\"Voltar\" border=\"0\" /></a></center>";
                                      echo "</body></html>";
                                    }
                              }
                         else
                                {
                                  //verifico se nao estao tentando gravar um dado que ja existe, pois usei UNIQUE na tabela
                                    if(mysql_errno() == 1062)
                                    		  {
                                                        echo $erros[mysql_errno()];
                                                                        exit;
                                              }
                                         else
                                             {
                                                       echo "Erro nao foi possivel efetuar atualiza��o do aluno";
                                                        exit;
                                             }
                                              @mysql_close();
                                    }
                      }
                   }
     }
}
   else
    {

//echo "$txtano_turma*$txtano*$txtid_turmaaluno";

             $sql="update aluno set id_turma='0', status ='3' where id = '$txtid_aluno'";
             if(@mysql_query($sql))
                {
                   $success = mysql_affected_rows();
                   if($success ==true)
                      {
                          $sql = "insert into movimenta_aluno (id_aluno,id_movimento,id_turmaaluno,obs,data,usuario,dt_situacao,id_status)
                          values ('$txtid_aluno','3','$txtid_turmaaluno','$txtobs','$data1','$cpf','$txtdtmovimento',$txtstatus)";
                            if(@mysql_query($sql))
                              {
                               $success = mysql_affected_rows();
                                 if($success ==true)
                                    {
                                      echo "<html><head><title>Resposta !!!</title></head>";
                                      echo "<body background=\"background_mensagens.jpg\" style=\"background-attachment:fixed; background-repeat:no-repeat\">";
                                      echo "<br><br><br>";
                                      echo "<center><img src=\"faleconosco/atencao.gif\" alt=\"\"><p><font color=\"#ff6600\" face=\"Verdana\" size=\"4\">Aluno Movimentado  Com Sucesso.!!!! <b></b></font></center>";
                                      echo "<br><br><center><a href=\"form_assoc_aluno_tuma.php\"><img src=\"faleconosco/button_voltar2_.gif\" alt=\"Voltar\" border=\"0\" /></a></center>";
                                      echo "</body></html>";
                                    }
                              }
                         else
                                {
                                  //verifico se nao estao tentando gravar um dado que ja existe, pois usei UNIQUE na tabela
                                    if(mysql_errno() == 1062)
                                    		  {
                                                        echo $erros[mysql_errno()];
                                                                        exit;
                                              }
                                         else
                                             {
                                                       echo "Erro nao foi possivel efetuar atualiza��o do aluno";
                                                        exit;
                                             }
                                              @mysql_close();
                                    }
                      }
                   }


       }

}


else
{




             $sql="update aluno set id_turma='0', status ='3' where id = '$txtid_aluno'";
             if(@mysql_query($sql))
                {
                   $success = mysql_affected_rows();
                   if($success ==true)
                      {
                          $sql = "insert into movimenta_aluno (id_aluno,id_movimento,id_turmaaluno,obs,data,usuario,dt_situacao,id_status)
                          values ('$txtid_aluno','3','$txtid_turmaaluno','$txtobs','$data1','$cpf','$txtdtmovimento',$txtstatus)";
                            if(@mysql_query($sql))
                              {
                               $success = mysql_affected_rows();
                                 if($success ==true)
                                    {
                                      echo "<html><head><title>Resposta !!!</title></head>";
                                      echo "<body background=\"background_mensagens.jpg\" style=\"background-attachment:fixed; background-repeat:no-repeat\">";
                                      echo "<br><br><br>";
                                      echo "<center><img src=\"faleconosco/atencao.gif\" alt=\"\"><p><font color=\"#ff6600\" face=\"Verdana\" size=\"4\">Aluno Movimentado  Com Sucesso.!!!! <b></b></font></center>";
                                      echo "<br><br><center><a href=\"form_assoc_aluno_tuma.php\"><img src=\"faleconosco/button_voltar2_.gif\" alt=\"Voltar\" border=\"0\" /></a></center>";
                                      echo "</body></html>";
                                    }
                              }
                         else
                                {
                                  //verifico se nao estao tentando gravar um dado que ja existe, pois usei UNIQUE na tabela
                                    if(mysql_errno() == 1062)
                                    		  {
                                                        echo $erros[mysql_errno()];
                                                                        exit;
                                              }
                                         else
                                             {
                                                       echo "Erro nao foi possivel efetuar atualiza��o do aluno";
                                                        exit;
                                             }
                                              @mysql_close();
                                    }
                      }
                   }

}//if linha



?>
