<?php
session_start();
if (isset($_SESSION["login_usuario"]))
  {
     $login     =  $_SESSION["login_usuario"];
     $nte       =  $_SESSION["nivel_usuario"];
	 $inep      =  $_SESSION["inep_usuario"] ;
     $ntelogin  =  $_SESSION["nte_login"];
     $cpf1       = $_SESSION["cpf_usuario"];

	 include ("../funcoes.php");
     echo  saudacoes()."   ". "$login" ."  -  ". $nte."  ".dataextenso() ." - ".$inep;

  }
 else
  {
    		 header("../Location: login.php");
  }





if(file_exists("../conexao_mysql.php"))
{
        require "../conexao_mysql.php";
        mysql_query("SET NAMES 'utf8'");		             
} else 
{
        echo "Conexão nao foi encontrado";
        exit;
}






if($cpf1!="")
{ 

$sql="select * from servidorrec where cpf = '$cpf1'";
$resultado=mysql_query($sql) or die (mysql_error());
$linhas=mysql_num_rows($resultado);

if($linhas>0)
{
   while($pegar=mysql_fetch_array($resultado))
   {
           $dtabertura    = date("d/m/Y",strtotime($dado["DATA"]));

   
    $cpf              =$pegar["cpf"];
    $pis              =$pegar["pis"]; 	
    $rg               =$pegar["rg"]; 	
	$orgaoexp         =$pegar["orgaoexp"]; 	
    $cep              =$pegar["cep"];
	$dtemissaorg      =date("d/m/Y",strtotime($pegar["dtemissaorg"]));
	$te               =$pegar["te"]; 	
	$zona             =$pegar["zona"]; 	
	$secao            =$pegar["secao"]; 	
	$dtemissaote      =date("d/m/Y",strtotime($pegar["dtemissaote"]));
	$nome             =$pegar["nome"]; 	
	$estcivil         =$pegar["estcivil"]; 	
	$numero           =$pegar["numero"]; 		
	$dtnascimento      =date("d/m/Y",strtotime($pegar["dtnascimento"]));
	$sexo             =$pegar["sexo"]; 	
	$conjuge          =$pegar["conjuge"]; 	
	$mae              =$pegar["mae"]; 	
    $pai                 =$pegar["pai"]; 	
	$endereco         =$pegar["endereco"]; 	
	$bairro           =$pegar["bairro"]; 	
	$fonesetor        =$pegar["fonesetor"]; 	
	$fonecontato      =$pegar["fonecontato"]; 	
	$foneresidencial  =$pegar["foneresidencial"]; 	
	$celular          =$pegar["celular"]; 	
	$email            =$pegar["email"]; 	
	$muni             =$pegar["municipio"];


//*************Estado******************************
$estado           =$pegar["estado"]; 	

$sqlestados="select * from estados where cod_estados = '$estado'";
$resultadoestados=mysql_query($sqlestados) or die (mysql_error());
$linhasestados   =mysql_num_rows($resultadoestados);

if($linhasestados>0)
{
   while($pegarestados=mysql_fetch_array($resultadoestados))
	{
    	$descrciaoestados    =$pegarestados["sigla"]; 	
	}
 }	


//*************Municipio******************************
$cidade           =$pegar["cidade"]; 	

$sqlcidade="select * from cidades where cod_cidades = '$cidade'";
$resultadocidade=mysql_query($sqlcidade) or die (mysql_error());
$linhascidade   =mysql_num_rows($resultadocidade);

if($linhascidade>0)
{
   while($pegarcidade=mysql_fetch_array($resultadocidade))
	{
    	$descrciaocidade    =$pegarcidade["nome"]; 	
	}
 }	
//*********************************************************	



	

//*************Grau de Instrução******************************
$grauinstrucao    =$pegar["grauinstrucao"]; 

$sqlinstrucao="select * from grauinstrucao where codigo = '$grauinstrucao'";
$resultadoinstrucao=mysql_query($sqlinstrucao) or die (mysql_error());
$linhasinstrucao   =mysql_num_rows($resultadoinstrucao);

if($linhasinstrucao>0)
{
   while($pegarinstrucao=mysql_fetch_array($resultadoinstrucao))
	{
    	$descrciaoinstrucao    =$pegarinstrucao["descricao"]; 	
	}
 }	
//*********************************************************	
	
		
	$preaposentadoria =$pegar["preaposentadoria"]; 	
	$complemento      =$pegar["complemento"]; 	
	$fonecontato      =$pegar["fonecontato"]; 	
	$tpservidor       =$pegar["tpservidor"]; 	
	$ncontrato        =$pegar["ncontrato"]; 	
	$banco            =$pegar["banco"]; 	
	$agencia          =$pegar["agencia"]; 	
	$cc               =$pegar["cc"]; 	
 } 



     $dia = date('d');
     $mes = date('m');
     $ano = date('Y');
  
     $data1 =$dia.".".$mes.".".$ano;

}
else
{

					echo "<html><head><title>Resposta. </title></head>";
					echo "<body background=\"background_mensagens.jpg\" style=\"background-attachment:fixed; background-repeat:no-repeat\">";
					echo "<br>";
					echo "<center><p><font color=\"#ff6600\" face=\"Verdana\" size=\"4\">Servidor n�o Localizado. <b></b></font></center>";
					echo "<br><br><center><a href=\"mnnam.php\"><img src=\"faleconosco/button_voltar2_.gif\" alt=\"Voltar\" border=\"0\" /></a></center>";
					echo "</body></html>";
					exit;

}




}




?>

<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01//EN"
	"http://www.w3.org/TR/html4/strict.dtd">
<head>
	<title>SEDUC-RO</title>
	<link rel="stylesheet" href="style/forms.css" type="text/css" />
	<link rel="stylesheet" href="estilo.css" type="text/css" />
	<link rel="stylesheet" href="style/menu.css" type="text/css" />

	
	<link href="tablecloth/tablecloth.css" rel="stylesheet" type="text/css" media="screen" />
	
	<script type="text/javascript" src="tablecloth/tablecloth.js"></script>
	<script src="lib/jquery-1.4.2.js" type="text/javascript"></script>
	<script src="lib/validate.js" type="text/javascript"></script>
	<script src="lib/forms.js" type="text/javascript"></script>
	<script src="generic1.js" type="text/javascript"></script>
    <script src="lib/jquery.maskedinput-1.1.1.js" type="text/javascript"></script>
	<meta http-equiv="Content-type" content="text/html; charset=utf-8" />





 	<link type="text/css" href="jquery-ui-1.8.18.custom/css/ui-lightness/jquery-ui-1.8.18.custom.css" rel="stylesheet" />
<!--	Versao nao trabalha com validade <script type="text/javascript" src="jquery-ui-1.8.18.custom/js/jquery-1.7.1.min.js"></script>-->
	<script type="text/javascript" src="jquery-ui-1.8.18.custom/js/jquery-ui-1.8.18.custom.min.js"></script>


<script>


	$(function() {
		$( "#txtdtnascimento" ).datepicker({
			changeMonth: true,
			changeYear: true
		});
	});

$(function() {
        $("#txtdtnascimento").datepicker();
        $('#txtdtnascimento').datepicker('option', 'dateFormat', 'dd/mm/yy');
});



	$(function() {
		$( "#txtDataEmissao" ).datepicker({
			changeMonth: true,
			changeYear: true
		});
	});


$(function() {
        $("#txtDataEmissao").datepicker();
        $('#txtDataEmissao').datepicker('option', 'dateFormat', 'dd/mm/yy');
});


	$(function() {
		$( "#txttdtte" ).datepicker({
			changeMonth: true,
			changeYear: true
		});
	});


$(function() {
        $("#txttdtte").datepicker();
        $('#txttdtte').datepicker('option', 'dateFormat', 'dd/mm/yy');
});

</script>










</head>
<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01//EN"
	"http://www.w3.org/TR/html4/strict.dtd">
<head>
	<title>SEDUC-RO</title>
	<link rel="stylesheet" href="style/forms.css" type="text/css" />
	<link rel="stylesheet" href="estilo.css" type="text/css" />
	<link rel="stylesheet" href="style/menu.css" type="text/css" />


	<link href="tablecloth/tablecloth.css" rel="stylesheet" type="text/css" media="screen" />

	<script type="text/javascript" src="tablecloth/tablecloth.js"></script>
	<script src="lib/jquery-1.4.2.js" type="text/javascript"></script>
	<script src="lib/validate.js" type="text/javascript"></script>
	<script src="lib/forms.js" type="text/javascript"></script>
	<script src="generic1.js" type="text/javascript"></script>
    <script src="lib/jquery.maskedinput-1.1.1.js" type="text/javascript"></script>
	<meta http-equiv="Content-type" content="text/html; charset=utf-8" />





 	<link type="text/css" href="jquery-ui-1.8.18.custom/css/ui-lightness/jquery-ui-1.8.18.custom.css" rel="stylesheet" />
<!--	Versao nao trabalha com validade <script type="text/javascript" src="jquery-ui-1.8.18.custom/js/jquery-1.7.1.min.js"></script>-->
	<script type="text/javascript" src="jquery-ui-1.8.18.custom/js/jquery-ui-1.8.18.custom.min.js"></script>


<script>


	$(function() {
		$( "#txtdtnascimento" ).datepicker({
			changeMonth: true,
			changeYear: true
		});
	});

$(function() {
        $("#txtdtnascimento").datepicker();
        $('#txtdtnascimento').datepicker('option', 'dateFormat', 'dd/mm/yy');
});



	$(function() {
		$( "#txtDataEmissao" ).datepicker({
			changeMonth: true,
			changeYear: true
		});
	});


$(function() {
        $("#txtDataEmissao").datepicker();
        $('#txtDataEmissao').datepicker('option', 'dateFormat', 'dd/mm/yy');
});


	$(function() {
		$( "#txttdtte" ).datepicker({
			changeMonth: true,
			changeYear: true
		});
	});


$(function() {
        $("#txttdtte").datepicker();
        $('#txttdtte').datepicker('option', 'dateFormat', 'dd/mm/yy');
});

</script>










</head>
<body>
	<div id="warpper">
		<div id="header">
		    <img src= "img/seduc_topo.jpg"/>
		</div>



			<div id="content">
				<form name = "recadastramento" class="form" action="altera_dados_pessoais_professor.php" method="post">

				 <div id="tema">
					   <p><center>Dados Pessoais</center></p>
				  </div>

					<p>
						<label for="txtCPF">CPF<img src= "img/check.gif"/></label>
						<input type="text" name="cpf" style="width:110px"  maxlength="11" id="cpf"  value= "<? echo $cpf; ?>"   readonly="true"/>

  				 <label for="txtPisPasep">PIS/PASEP:</label>
				<input type="text" name="pis" id="pis" style="width:110px" value= "<? echo $pis; ?>" maxlength="25" />

					</p>

					<p>
						<label for="txtRG">RG<img src= "img/check.gif"/></label>
						<input type="text" name="txtRG" style="width:110px" value= "<? echo $rg; ?>" id="txtRG" maxlength="20" />

						<label for="txtOrgaoExp" >Orgo Exp<img src= "img/check.gif"/></label>
						<input type="text" name="txtOrgaoExp" value= "<? echo $orgaoexp; ?>" style="width:70px" id="txtOrgaoExp"  maxlength="10"/>
						<label for="txtDataEmissao">Data Emisso<img src= "img/check.gif"/></label>
						<input type="text" name="txtDataEmissao" value= "<? echo $dtemissaorg; ?>" style="width:80px" id="txtDataEmissao" maxlength="12"/>
					</p>

					<p>
						<label for="lblte">Ttulo Eleitor<img src= "img/check.gif"/></label>
						<input type="text" name="txtte" style="width:100px" value= "<? echo $te; ?>" id="txtte" maxlength="20" />
						<label for="lblzona" >Zona<img src= "img/check.gif"/></label>
						<input type="text" name="txtzona" value= "<? echo $zona; ?>" style="width:50px" id="txtzona" maxlength="10" />
						<label for="lblsecao">Seção<img src= "img/check.gif"/></label>
						<input type="text" name="txtsecao" value= "<? echo $secao; ?>" style="width:50px" id="txtsecao" maxlength="5" />
						<label for="lbldtemissaote">Data Emissão<img src= "img/check.gif"/></label>
						<input type="text" name="txttdtte" value= "<? echo $dtemissaote; ?>" style="width:80px" id="txttdtte" maxlength="12" />

					</p>



					<p>
						<label for="txtNome">Nome<img src= "img/check.gif"/></label>
						<input type="text" name="txtNome" style="width:565px" maxlength="60" value= "<? echo $nome; ?>" id="txtNome" />
					</p>


					<p>
						<label for="lblselectecivil">Estado Civil<img src= "img/check.gif"/></label>
 			               <select id="selectcivil" name="selectcivil" style="width:150px" value= "<? echo $estcivil; ?>">
              		          <option value="CASADO">CASADO</option>
            		          <option value="SOLTEIRO">SOLTEIRO</option>
              		          <option value="VIUVO">VIUVO</option>
            		          <option value="DESQUITADO">DESQUITADO</option>
              		          <option value="DIVORCIADO">DIVORCIADO</option>
            		          <option value="UNIAOESTAVEL">UNIAO ESTAVEL</option>
    		               </select>
						<label for="lbldtnascimento">Data Nascimento<img src= "img/check.gif"/></label>
						<input type="text" name="txtdtnascimento" value= "<? echo $dtnascimento; ?>" style="width:70px" id="txtdtnascimento" />
                         </p>



  		       <p>
				<label for="selectsexo">Sexo</label>
             <select id="selectsexo1" name="selectsexo1" style="width:140px" >
                     	<?php if($sexo == 'M')
					   {
					?>
			       <option value=" <?php echo "M"?>">MASCULINO</option>
				   <?php
					   }
					   else
				   {
							   ?>
						       <option value="<?php echo "F" ?>">FEMININO</option>
							  <option value="M">MASCULINO</option>
            		          <option value="F">FEMININO</option>

	   						   <?php
							   }
							   ?>

						   </select>
					</p>


					<p>
						<label for="lblconjuge">Conjuge</label>
						<input type="text" name="txtconjuge" style="width:565px" maxlength="60" value= "<? echo $conjuge; ?>" id="txtconjuge" />
					</p>

					<p>
						<label for="lblmae">Nome Mãe<img src= "img/check.gif"/></label>
						<input type="text" name="txtmae" style="width:565px" maxlength="60" value= "<? echo $mae; ?>" id="txtmae" />
					</p>
					<p>
						<label for="lblpai">Nome Pai</label>
						<input type="text" name="txtpai" style="width:565px" maxlength="60" value= "<? echo $pai; ?>" id="txtpai" />
					</p>


					<p>
						<label for="lblEndereco">Endereo<img src= "img/check.gif"/></label>
						<input type="text" name="txtEndereco" style="width:565px" value= "<? echo $endereco; ?>"  maxlength="60" size="60" id="txtEndereco" />
					</p>

					<p>
						<label for="lblEndereco">Complemento</label>
						<input type="text" name="txtcomplemento" style="width:565px" value= "<? echo $complemento; ?>"  maxlength="40" size="60" id="txtcomplemento" />
					</p>


					<p>
						<label for="lblBairro">Bairro<img src= "img/check.gif"/></label>
						<input type="text" name="txtBairro" value= "<? echo $bairro; ?>" id="txtBairro"  maxlength="40"/>
						<label for="lblBairro">N.<img src= "img/check.gif"/></label>
						<input type="text" name="txtnr" style="width:60px" value= "<? echo $numero; ?>" id="txtnr" maxlength="5"/>
			            <label for="txtCEP">CEP<img src= "img/check.gif"/></label>
            			<input id="txtcep" name="txtcep" type="text" style="width:90px" value= "<? echo $cep; ?>" maxlength="8" />
					</p>
					<p>
						<label for="txtFoneSetor">Telefone Comercial</label>
						<input type="text" name="txtFoneSetor" style="width:90px" value= "<? echo $fonesetor; ?>" id="txtFoneSetor"  maxlength="20"/>
						<label for="txtFoneRes">Residencial</label>
						<input type="text" name="txtFoneRes" style="width:90px" value= "<? echo $foneresidencial; ?>" id="txtFoneRes" maxlength="20"/>
						<label for="txtCelular">Celular</label>
						<input type="text" name="txtCelular" style="width:90px" value= "<? echo $celular; ?>" id="txtCelular" maxlength="20"/>
						<label for="txtCelular">Contato<img src= "img/check.gif"/></label>
						<input type="text" name="txtcontato" style="width:90px" value= "<? echo $fonecontato; ?>" id="txtcontato" maxlength="25"/>

					</p>

                 <p>
					<label for="lblcod_estados">Municipio:</label>
					   <select name="cod_muni" id="cod_muni" >
					   <option value=""></option>
  					  <?php
						   $sql = "select codigo, descricao FROM municipio order by descricao";
						   $res = mysql_query($sql);
						   if($res)
							  {
								while($row = mysql_fetch_array($res)){
							    ?>
  			                    <option value="<?php echo $row['codigo']?>"
						        <?php if($row['codigo'] == $muni){ echo "selected";}?>>
								<?php echo $row['descricao'];?>
								<?php
							      } }
						        ?>
					   </select>
					</p>



					<p>
						<label for="txtEmail">E-mail</label>
						<input type="text" name="txtEmail" style="width:565px" value= "<? echo $email; ?>" id="txtEmail" maxlength="80"/>
					</p>


					<p>

					<label for="lblcod_estados">Naturalidade - Estado:</label>
					   <select name="cod_estado" id="cod_estado" >
					   <option value=""></option>
  					  <?php
						   $sql = "select cod_estados, sigla FROM estados order by sigla";
						   $res = mysql_query($sql);
						   if($res)
							  {
								while($row = mysql_fetch_array($res)){
							    ?>
  			                    <option value="<?php echo $row['cod_estados']?>"
						        <?php if($row['cod_estados'] == $estado){ echo "selected";}?>>
								<?php echo $row['sigla'];?>
								<?php
							      } }
						        ?>
					   </select>

          		<label for="lblcod_cidades">Cidade:</label>
         		<span class="carregando">Aguarde, carregando...</span>
		          <select name="cod_cidades" id="cod_cidades">
			           <option value="">-- Escolha  estado --</option>
					<?php
						$sql = "select * from cidades";
						$resultado1 = mysql_query($sql);
						if($resultado1)
							{
							while($linhas = mysql_fetch_array($resultado1)){
							?>
								<option value="<?php echo $linhas['cod_cidades']; ?>"
								<?php if($linhas['cod_cidades'] == $cidade){ echo "selected";  } ?>>
								<?php echo $linhas['nome'];  ?>
								</option>
								<?php } }
								 ?>
							</select>
						</p>
					<p>

					<label for="lblinstrucao">Grau de Instrucao</label>
						<select name="txtinstrucao" id="txtinstrucao"  class="textBox">
						<option value="">Selecione</option>

<?php
$sql = "select * from grauinstrucao"; //aqui faz a consulta no banco de dados
$resultado1 = mysql_query($sql); //aqui é o retorno da consulta
if($resultado1)//teste se houve resultado entra no while
{
while($linhas = mysql_fetch_array($resultado1)){ //monta um vetor colocando todos os resultados em $linhas
?>
<option value="<?php echo $linhas['codigo'];//aqui é o valor geralmente se coloca o id da tabela ?>"
<?php if($linhas['codigo'] == $grauinstrucao){ echo "selected"; /*aqui eu testo e vejo se alguma opção foi selecionada eu a mantenho selecionada*/ } ?>>
<?php echo $linhas['descricao']; /*aqui é a parte de exibição a informação que o usuario ira ver na tela "as opções"*/ ?>
</option>
<?php } } ?>
</select>

					</p>


					  <p>
						  <label for="txtBanco">Banco:<img src= "img/check.gif"/></label>
						  <input type="text" name="txtBanco" value= "<? echo $banco; ?>" style="width:50px" id="txtBanco" maxlength="3" />
						  <label for="txtAgencia" >Ag�ncia:<img src= "img/check.gif"/></label>
						  <input type="text" name="txtAgencia" value= "<? echo $agencia; ?>" style="width:60px" id="txtAgencia" maxlength="10" />
						  <label for="txtConta">Conta:<img src= "img/check.gif"/></label>
						  <input type="text" name="txtConta" value= "<? echo $cc; ?>" style="width:100px" id="txtConta" maxlength="20"/>
					  </p>

    		<p id="finish">
           <input type="button" value=" Voltar " onclick="location.href='mnprofessor.php';">
            <input type="submit" value="Alterar Dados" />

	    	</p>
				</form>
			</div>
		</div>
		<div id="footer">
			<p>Todos direitos reservados/GTI/SEDUC-RO Copyright(C) </p>

   </p>
		</div>
	</div>
</body>

