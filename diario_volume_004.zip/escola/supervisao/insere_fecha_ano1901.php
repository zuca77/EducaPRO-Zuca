<?php
session_start();
if (isset($_SESSION["login_usuario"]))
  {
	 $login     =  $_SESSION["login_usuario"];
     $nte       =  $_SESSION["nivel_usuario"];
	 $inep      =  $_SESSION["inep_usuario"] ;
     $ntelogin  =  $_SESSION["nte_login"];
     $cpf       = $_SESSION["cpf_usuario"];
     include ("../funcoes.php");
     echo  saudacoes()."   ". "$login" ."  -  ". $nte."  ".dataextenso() ." - ".$inep;

  }
 else
  {
     		 header("Location: ../../login.php");
  }



include ("../../conexao_mysql.php");

if(file_exists("../../conexao_mysql.php"))
{
        require "../../conexao_mysql.php";

} else
{
        echo "Conex�o nao foi encontrado";
        exit;
}



if($_SERVER["REQUEST_METHOD"] == "POST")
{
   $txtano	     = $_POST['txtano'];





   if ($txtano=='')
       {
    echo "<html><head><title>Resposta !!!</title></head>";
    echo "<body background=\"background_mensagens.jpg\" style=\"background-attachment:fixed; background-repeat:no-repeat\">";
    echo "<br><br><br>";
    echo "<center><img src=\"faleconosco/atencao.gif\" alt=\"\"><p><font color=\"#FF0000\" face=\"Verdana\" size=\"4\"><b>Campo Obtigat�rio. Selecione o ano letivo.</b></font></center>";
    echo "<br><br><center><a href=\"form_liberacao_bim.php\"><img src=\"faleconosco/button_voltar2_.gif\" alt=\"Voltar\" border=\"0\" /></a></center>";
    echo "</body></html>";
    exit;

       }

if (trim($inep)=='')
   {
    echo "<html><head><title>Resposta !!!</title></head>";
    echo "<body background=\"background_mensagens.jpg\" style=\"background-attachment:fixed; background-repeat:no-repeat\">";
    echo "<br><br><br>";
    echo "<center><img src=\"faleconosco/atencao.gif\" alt=\"\"><p><font color=\"#FF0000\" face=\"Verdana\" size=\"4\"><blink>Escola n�o localizada.!</blink> <b></b></font></center>";
    echo "<br><br><center><a href=\"form_liberacao_bim.php\"><img src=\"faleconosco/button_voltar2_.gif\" alt=\"Voltar\" border=\"0\" /></a></center>";
    echo "</body></html>";
    exit;

   }


$sql="select * from turma where inep = '$inep' and ano = '$txtano'  and ((fechado is null) or (fechado <> 'S'))";
$resultado=mysql_query($sql) or die (mysql_error());
$linhas=mysql_num_rows($resultado);
if ($linhas > 0)
{
        echo "<html><head><title>Resposta !!!</title></head>";
        echo "<body background=\"background_mensagens.jpg\" style=\"background-attachment:fixed; background-repeat:no-repeat\">";
        echo "<br><br><br>";
        echo "<center><img src=\"faleconosco/atencao.gif\" alt=\"\"><p><font color=\"#FF0000\" face=\"Verdana\" size=\"4\"><b>Ano n�o pode ser fechado. Existe Turmas Abertas.</b></font></center>";
        echo "<br><br><center><a href=\"../turma/form_inclusao_turma.php\"><img src=\"faleconosco/button_voltar2_.gif\" alt=\"Voltar\" border=\"0\" /></a></center>";
        echo "</body></html>";
        exit;
}

$sql="select * from etapa_liberacao where inep = '$inep' and ano = '$txtano'  and ((situacao is null) or (situacao <> 'F'))";
$resultado=mysql_query($sql) or die (mysql_error());
$linhas=mysql_num_rows($resultado);
if ($linhas > 0)
     {
        echo "<html><head><title>Resposta !!!</title></head>";
        echo "<body background=\"background_mensagens.jpg\" style=\"background-attachment:fixed; background-repeat:no-repeat\">";
        echo "<br><br><br>";
        echo "<center><img src=\"faleconosco/atencao.gif\" alt=\"\"><p><font color=\"#FF0000\" face=\"Verdana\" size=\"4\"><b>Ano n�o pode ser fechado. Existe Etapas Abertas.</b></font></center>";
        echo "<br><br><center><a href=\"form_liberacao_bim.php\"><img src=\"faleconosco/button_voltar2_.gif\" alt=\"Voltar\" border=\"0\" /></a></center>";
        echo "</body></html>";
        exit;
     }

/******************************************************************/

 		  $sql_turma = mysql_query("select count(*) as total_turma from turma where inep = '$inep' and ano = '$txtano' and modalidade = '1'");
          $total_turma_ef = mysql_result($sql_turma, 0, "total_turma");


   		  $sql_compara_estatistica = mysql_query("select count(*) as total_estatistica from estatistica where inep = '$inep' and ano = '$txtano' and id_modalidade = '1'");
          $total_estatistica_ef = mysql_result($sql_compara_estatistica, 0, "total_estatistica");




   if ($total_turmas_ef != $total_estatistica_ef)
   {
    echo "<html><head><title>Resposta !!!</title></head>";
    echo "<body background=\"background_mensagens.jpg\" style=\"background-attachment:fixed; background-repeat:no-repeat\">";
    echo "<br><br><br>";
    echo "<center><img src=\"faleconosco/atencao.gif\" alt=\"\"><p><font color=\"#FF0000\" face=\"Verdana\" size=\"4\"><b>Ensino Regular ainda n�o consolidado! - Click em Voltar </b></font></center>";
    echo "<br><br><center><a href=\"../mnadmescola.php\"><img src=\"faleconosco/button_voltar2_.gif\" alt=\"Voltar\" border=\"0\" /></a></center>";
    echo "</body></html>";
    exit;
    }

/*********************eja*********************************************/


 		  $sql_turma = mysql_query("select count(*) as total_turma from turma where inep = '$inep' and ano = '$txtano' and modalidade = '2'");
          $total_turma_eja = mysql_result($sql_turma, 0, "total_turma");


   		  $sql_compara_estatistica = mysql_query("select count(*) as total_estatistica from estatistica where inep = '$inep' and ano = '$txtano' and id_modalidade = '2'");
          $total_estatistica_eja = mysql_result($sql_compara_estatistica, 0, "total_estatistica");



   if ($total_turmas_eja != $total_estatistica_eja)
   {
    echo "<html><head><title>Resposta !!!</title></head>";
    echo "<body background=\"background_mensagens.jpg\" style=\"background-attachment:fixed; background-repeat:no-repeat\">";
    echo "<br><br><br>";
    echo "<center><img src=\"faleconosco/atencao.gif\" alt=\"\"><p><font color=\"#FF0000\" face=\"Verdana\" size=\"4\"><b>Ensino EJA ainda n�o consolidado! - Click em Voltar </b></font></center>";
    echo "<br><br><center><a href=\"../mnadmescola.php\"><img src=\"faleconosco/button_voltar2_.gif\" alt=\"Voltar\" border=\"0\" /></a></center>";
    echo "</body></html>";
    exit;
    }






 exit;





/*tratamento das datas*/



        echo "<html><head><title>Resposta !!!</title></head>";
        echo "<body background=\"background_mensagens.jpg\" style=\"background-attachment:fixed; background-repeat:no-repeat\">";




$dia = date('d');
$mes = date('m');
$ano = date('Y');

$data =$ano.".".$mes.".".$dia;


$sql = "update  ano set
        situacao  ='F',
        usuario   ='$cpf',
        data      ='$data'
        where ano = '$txtano'  and inep = '$inep'";






if(@mysql_query($sql))
{
  if(mysql_affected_rows() == 1)
   {

   }

}
else
   {
        //verifico se nao estao tentando gravar um dado que ja existe, pois usei UNIQUE na tabela
        if(mysql_errno() == 1062)
		  {
                echo $erros[mysql_errno()];
                exit;
          }
		  else
		  {
                echo "Erro nao foi possivel o fechamento do ano letivo";
                exit;
          }
        @mysql_close();
   }

/*Fechamento de Turma*/

/*************Nota de Alunos*******************************************************************************************************/



$sql = "update  nota_aluno set
        bim1  = 'S',
        bim2  = 'S',
        bim3  = 'S',
        bim4  = 'S',
        rec1  = 'S',
        rec2  = 'S',
        rec3  = 'S',
        rec4  = 'S',
        final = 'S',
        ano_fechado  ='S'
        where ano = '$txtano'  and inep = '$inep'";
if(@mysql_query($sql))
{
  if(mysql_affected_rows() == 1)
   {

        echo "<center><img src=\"\" alt=\"\"><p><font color=\"#FF0000\" face=\"Verdana\" size=\"4\"><b>Notas Fechada Com Sucesso!</b></font></center>";
   }

}
else
   {
        //verifico se nao estao tentando gravar um dado que ja existe, pois usei UNIQUE na tabela
        if(mysql_errno() == 1062)
		  {
                echo $erros[mysql_errno()];
                exit;
          }
		  else
		  {
                echo "Erro nao foi possivel Fechar o M�dulo de Nota de Aluno";
                exit;
          }
        @mysql_close();
   }





/*Fechamento de Turma*/

$sql="select * from turma where inep = '$inep' and ano = '$txtano'";
$resultado=mysql_query($sql) or die (mysql_error());
$linhas=mysql_num_rows($resultado);
if ($linhas > 0)
{

//mysql_query ( "START TRANSACTION" ); nao funciona com duas tabelas

$sql = "update turma set fechado = 'S', ano_fechado = 'S' where inep = '$inep' and  ano = '$txtano'";
if(@mysql_query($sql))
{
   if(mysql_affected_rows() == 1)
    {




 /*********Atualiza Turma Aluno***** Status 100 representa turma fechada aluno n�o possui ano*/
            $sql="update aluno set id_turma = '0',status = '100' where inep = '$inep'";
             if(@mysql_query($sql))
                {
                   $success = mysql_affected_rows();
                   if($success ==true)
                      {

        echo "<center><img src=\"\" alt=\"\"><p><font color=\"#FF0000\" face=\"Verdana\" size=\"4\"><b>Turma Fechada com Sucesso!</b></font></center>";



                      }
                }

        else
            {
              //verifico se nao estao tentando gravar um dado que ja existe, pois usei UNIQUE na tabela
                 if(mysql_errno() == 1062)
        		  {
                       echo $erros[mysql_errno()];
                       exit;
                   }
               else
                   {
                         echo "Erro nao foi possivel efetuar o fechamento do M�dulo Alunos";
                         exit;
                   }
            }




                $sql = "update turma_aluno set fechado = 'S' where inep = '$inep' and ano = '$txtano'";

                            if(@mysql_query($sql))
                              {
                               $success = mysql_affected_rows();
                                 if($success ==true)
                                    {

        echo "<center><img src=\"\" alt=\"\"><p><font color=\"#FF0000\" face=\"Verdana\" size=\"4\"><b>Turma X Aluno Fechada com Sucesso!</b></font></center>";





                                    }
                               }
                          else
                               {
                                  //verifico se nao estao tentando gravar um dado que ja existe, pois usei UNIQUE na tabela
                                    if(mysql_errno() == 1062)
                                    		  {
                                                        echo $erros[mysql_errno()];
                                                                        exit;
                                              }
                                         else
                                             {
                                                       echo "Erro nao foi possivel efetuar o fechamento Turma x Aluno.";
                                                        exit;
                                             }
                                              @mysql_close();
                               }


          }
      else
      {

               

      }






     }
     else
       {
                            //verifico se nao estao tentando gravar um dado que ja existe, pois usei UNIQUE na tabela
             if(mysql_errno() == 1062)
          		  {
                     echo $erros[mysql_errno()];
                     exit;
                   }
             else
              {
               echo "Erro nao foi possivel efetuar atualiza��o do aluno";
                exit;
              }
       }

  }


/*Turma dep de aluno*/


$sql = "update  turma_dep_aluno_disciplina set
        ano_fechado  ='S'
        where ano = '$txtano'  and inep = '$inep'";
if(@mysql_query($sql))
{
  if(mysql_affected_rows() == 1)
   {




        echo "<center><img src=\"\" alt=\"\"><p><font color=\"#FF0000\" face=\"Verdana\" size=\"4\"><b>Turma Depend�ncia Fechada Com Sucesso!</b></font></center>";


   }

}
else
   {
        //verifico se nao estao tentando gravar um dado que ja existe, pois usei UNIQUE na tabela
        if(mysql_errno() == 1062)
		  {
                echo $erros[mysql_errno()];
                exit;
          }
		  else
		  {
                echo "Erro nao foi possivel Fechar o M�dulo de Depend�ncia.";
                exit;
          }
        @mysql_close();
   }




/*Modulo calendario*/




$sql = "update  oc_calendar set
        ano_fechado  ='S'
        where YEAR(start_date) = '$txtano'  and inep = '$inep'";
if(@mysql_query($sql))
{
  if(mysql_affected_rows() == 1)
   {

        echo "<center><img src=\"\" alt=\"\"><p><font color=\"#FF0000\" face=\"Verdana\" size=\"4\"><b>Calend�rio Fechado Com Sucesso!.</b></font></center>";

   }

}
else
   {
        //verifico se nao estao tentando gravar um dado que ja existe, pois usei UNIQUE na tabela
        if(mysql_errno() == 1062)
		  {
                echo $erros[mysql_errno()];
                exit;
          }
		  else
		  {
                echo "Erro nao foi possivel o fechamendo do calend�rio.";
                exit;
          }
        @mysql_close();
   }






/**Copiando gradecurricular**/

$sql = "insert into grade_curricular_ano_fechado SELECT * FROM grade_curricular where inep = '$inep' and ano = '$txtano'";
if(@mysql_query($sql))
{
  if(mysql_affected_rows() == 1)
   {
        echo "<center><img src=\"\" alt=\"\"><p><font color=\"#FF0000\" face=\"Verdana\" size=\"4\"><b>Grade Curricular Fechada Com Sucesso!.</b></font></center>";

   }

}
else
   {
        //verifico se nao estao tentando gravar um dado que ja existe, pois usei UNIQUE na tabela
        if(mysql_errno() == 1062)
		  {
                echo $erros[mysql_errno()];
                exit;
          }
		  else
		  {
                echo "Erro nao foi possivel o fechamendo do calend�rio.";
                exit;
          }
        @mysql_close();
   }



$sql = "update grade_curricular  set
        ano_fechado  ='S'
        where ano = '$txtano'  and inep = '$inep'";
if(@mysql_query($sql))
{
  if(mysql_affected_rows() == 1)
   {

        echo "<center><img src=\"\" alt=\"\"><p><font color=\"#FF0000\" face=\"Verdana\" size=\"4\"><b>Calend�rio Fechado Com Sucesso!.</b></font></center>";

   }

}
else
   {
        //verifico se nao estao tentando gravar um dado que ja existe, pois usei UNIQUE na tabela
        if(mysql_errno() == 1062)
		  {
                echo $erros[mysql_errno()];
                exit;
          }
		  else
		  {
                echo "Erro nao foi possivel o fechamendo do calend�rio.";
                exit;
          }
        @mysql_close();
   }























 /**Copiando nota**/

$sql = "insert into nota_aluno_ano_fechado SELECT * FROM nota_aluno where inep = '$inep' and ano = '$txtano'";
if(@mysql_query($sql))
{
  if(mysql_affected_rows() == 1)
   {
        echo "<center><img src=\"\" alt=\"\"><p><font color=\"#FF0000\" face=\"Verdana\" size=\"4\"><b>C�pias de Notas Realizadas Com Sucesso!.</b></font></center>";

   }

}
else
   {
        //verifico se nao estao tentando gravar um dado que ja existe, pois usei UNIQUE na tabela
        if(mysql_errno() == 1062)
		  {
                echo $erros[mysql_errno()];
                exit;
          }
		  else
		  {
                echo "Erro nao foi possivel o fechamendo do calend�rio.";
                exit;
          }
        @mysql_close();
   }




 /**Copiando frequencia**/

$sql = "insert into frequencia_aluno_ano_fechado SELECT * FROM frequencia_aluno where inep = '$inep' and ano = '$txtano'";
if(@mysql_query($sql))
{
  if(mysql_affected_rows() == 1)
   {
        echo "<center><img src=\"\" alt=\"\"><p><font color=\"#FF0000\" face=\"Verdana\" size=\"4\"><b>C�pias de Frequencia Realizada Com Sucesso!.</b></font></center>";

   }
}
else
   {
        //verifico se nao estao tentando gravar um dado que ja existe, pois usei UNIQUE na tabela
        if(mysql_errno() == 1062)
		  {
                echo $erros[mysql_errno()];
                exit;
          }
		  else
		  {
                echo "Erro nao foi possivel o fechamendo do calend�rio.";
                exit;
          }
        @mysql_close();
   }


 /**Copiando frequqncia cabeca**/

$sql = "insert into frequencia_aluno_ano_fechado SELECT * FROM frequencia_cabeca where inep = '$inep' and ano = '$txtano'";
if(@mysql_query($sql))
{
  if(mysql_affected_rows() == 1)
   {

   }
}
else
   {
        //verifico se nao estao tentando gravar um dado que ja existe, pois usei UNIQUE na tabela
        if(mysql_errno() == 1062)
		  {
                echo $erros[mysql_errno()];
                exit;
          }
		  else
		  {
                echo "Erro nao foi possivel o fechamendo do calend�rio.";
                exit;
          }
        @mysql_close();
   }









 /***Deletando frequencia Cabe�a***/

$sql = "delete frequencia_cabeca where inep = '$inep' and ano = '$txtano'";
if(@mysql_query($sql))
{
  if(mysql_affected_rows() == 1)
   {

   }
}
else
   {
        //verifico se nao estao tentando gravar um dado que ja existe, pois usei UNIQUE na tabela
        if(mysql_errno() == 1062)
		  {
                echo $erros[mysql_errno()];
                exit;
          }
		  else
		  {
                echo "Erro nao foi possivel o fechamendo do calend�rio.";
                exit;
          }
        @mysql_close();
   }






 /**Copiando frequencia**/

$sql = "delete frequencia_aluno where inep = '$inep' and ano = '$txtano'";
if(@mysql_query($sql))
{
  if(mysql_affected_rows() == 1)
   {

   }
}
else
   {
        //verifico se nao estao tentando gravar um dado que ja existe, pois usei UNIQUE na tabela
        if(mysql_errno() == 1062)
		  {
                echo $erros[mysql_errno()];
                exit;
          }
		  else
		  {
                echo "Erro nao foi possivel o fechamendo do calend�rio.";
                exit;
          }
        @mysql_close();
   }






 /**Copiando professor disciplina**/

$sql = "insert into professor_disciplina_ano_fechado SELECT * FROM professor_disciplina where inep = '$inep' and ano = '$txtano'";
if(@mysql_query($sql))
{
  if(mysql_affected_rows() == 1)
   {
        echo "<center><img src=\"\" alt=\"\"><p><font color=\"#FF0000\" face=\"Verdana\" size=\"4\"><b>Copiando Proffessor Disciplinas!.</b></font></center>";

   }
}
else
   {
        //verifico se nao estao tentando gravar um dado que ja existe, pois usei UNIQUE na tabela
        if(mysql_errno() == 1062)
		  {
                echo $erros[mysql_errno()];
                exit;
          }
		  else
		  {
                echo "Erro nao foi possivel o fechamendo do calend�rio.";
                exit;
          }
        @mysql_close();
   }




 /**Copiando professor disciplina**/

$sql = "insert into professor_disciplina_ano_fechado SELECT * FROM professor_disciplina where inep = '$inep' and ano = '$txtano'";
if(@mysql_query($sql))
{
  if(mysql_affected_rows() == 1)
   {
        echo "<center><img src=\"\" alt=\"\"><p><font color=\"#FF0000\" face=\"Verdana\" size=\"4\"><b>Copiando Proffessor Disciplinas!.</b></font></center>";

   }
}
else
   {
        //verifico se nao estao tentando gravar um dado que ja existe, pois usei UNIQUE na tabela
        if(mysql_errno() == 1062)
		  {
                echo $erros[mysql_errno()];
                exit;
          }
		  else
		  {
                echo "Erro nao foi possivel o fechamendo do calend�rio.";
                exit;
          }
        @mysql_close();
   }









 /**Copiando professor turma professor disciplina**/

$sql = "insert into turmaprofessor_ano_fechado SELECT * FROM turmaprofessor where inep = '$inep' and ano = '$txtano'";
if(@mysql_query($sql))
{
  if(mysql_affected_rows() == 1)
   {
        echo "<center><img src=\"\" alt=\"\"><p><font color=\"#FF0000\" face=\"Verdana\" size=\"4\"><b>Copiando Proffessor Turma!.</b></font></center>";

   }
}
else
   {
        //verifico se nao estao tentando gravar um dado que ja existe, pois usei UNIQUE na tabela
        if(mysql_errno() == 1062)
		  {
                echo $erros[mysql_errno()];
                exit;
          }
		  else
		  {
                echo "Erro nao foi possivel o fechamendo do calend�rio.";
                exit;
          }
        @mysql_close();
   }





















        echo "<center><img src=\"\" alt=\"\"><p><font color=\"#FF0000\" face=\"Verdana\" size=\"4\"><b>Fechamento de Ano Realizado com Sucesso.</b></font></center>";
        echo "<center><img src=\"\" alt=\"\"><p><font color=\"#FF0000\" face=\"Verdana\" size=\"4\"><b>Fa�a Abertura de um novo ano letivo.</b></font></center>";
        echo "<br><br><center><a href=\"../mnadmescola.php\"><img src=\"faleconosco/button_voltar2_.gif\" alt=\"Voltar\" border=\"0\" /></a></center>";
        echo "</body></html>";


/*        echo "<br><br><br>";
        echo "<center><img src=\"\" alt=\"\"><p><font color=\"#FF0000\" face=\"Verdana\" size=\"4\"><b>Turma Fechada com Sucesso!</b></font></center>";
        echo "<center><img src=\"\" alt=\"\"><p><font color=\"#FF0000\" face=\"Verdana\" size=\"4\"><b>Turma X Aluno Fechada com Sucesso!</b></font></center>";
        echo "<center><img src=\"\" alt=\"\"><p><font color=\"#FF0000\" face=\"Verdana\" size=\"4\"><b>Turma Depend�ncia Fechada Com Sucesso!</b></font></center>";
        echo "<center><img src=\"\" alt=\"\"><p><font color=\"#FF0000\" face=\"Verdana\" size=\"4\"><b>Notas Fechada Com Sucesso!</b></font></center>";
        echo "<center><img src=\"\" alt=\"\"><p><font color=\"#FF0000\" face=\"Verdana\" size=\"4\"><b>Calend�rio Fechado Com Sucesso!.</b></font></center>";
        echo "<center><img src=\"\" alt=\"\"><p><font color=\"#FF0000\" face=\"Verdana\" size=\"4\"><b>Grade Curricular Fechada Com Sucesso!.</b></font></center>";
        echo "<center><img src=\"\" alt=\"\"><p><font color=\"#FF0000\" face=\"Verdana\" size=\"4\"><b>C�pias de Notas Realizadas Com Sucesso!.</b></font></center>";
        echo "<center><img src=\"\" alt=\"\"><p><font color=\"#FF0000\" face=\"Verdana\" size=\"4\"><b>C�pias de Frequencia Realizada Com Sucesso!.</b></font></center>";
        echo "<center><img src=\"\" alt=\"\"><p><font color=\"#FF0000\" face=\"Verdana\" size=\"4\"><b>Fechamento de Ano Realizado com Sucesso.</b></font></center>";
        echo "<center><img src=\"\" alt=\"\"><p><font color=\"#FF0000\" face=\"Verdana\" size=\"4\"><b>Fa�a Abertura de um novo ano letivo.</b></font></center>";
        echo "<br><br><center><a href=\"../mnadmescola.php\"><img src=\"faleconosco/button_voltar2_.gif\" alt=\"Voltar\" border=\"0\" /></a></center>";
        echo "</body></html>";
   */













}//post



?>



