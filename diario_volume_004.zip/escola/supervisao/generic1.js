
	 /* Autor : Paulo Eduardo
	 * Data  : 30.04.2012 
	 * Analista : Paulo Eduardo
	 * Programador : Paulo Eduardo
*/

$(document).ready(function() {
	$('#toggle').click(function() {
		$('#hidden').toggle(400);
  	return false;
	});

$(".form").validate({
	          rules:{

              txtturma:			{required: true,},
              txtnaluno:		{required: true,},
			  selectsexo: 		{required: true,},
			  txtcertidao: 		{required: true,},
              txtfolha:			{required: true,},
              txtlivro:			{required: true,},
			  cod_estado:		{required: true,},
			  cod_cidades:		{required: true,},
              /*            
			  txtpai:			{required: true,},
              txtRGpai :		{required: true,},
			  txtOrgaoExppai:	{required: true,},
              txtdtemissaorgpai:{required: true,},
              cpfpai :			{required: true,},
			  */
			  txtmae:			{required: true,},
              txtRGmae:			{required: true,},
              txtOrgaoExpmae :	{required: true,},
			  txtdtemissaorgmae:{required: true,},
              cpf:  {cpf: true},		 
              txtOrgaoExpmae :	{required: true,},
			  txtdtemissaorgmae:{required: true,},
              txtEndereco:	    {required: true,},
	          txtBairro:		{required: true,},
	          txtnr:			{required: true,},
	          txtcep:			{required: true,},
	          txtcomplemento:	{required: true,},
	          cod_muni:		    {required: true,},
	          txtcontato:		{required: true,},

			  txtmodalidade:		{required: true,},
			  selectsemestre:		{required: true,},
			  txtetapa:             {required: true,},


              txtdtinicio: {required: true, dateBR: true},
              txtdtfim: {required: true, dateBR: true},			  
              txtdt_fechamento: {required: true, dateBR: true},			  






},
  messages:{

              txtturma:			{required: 'Selecione a turma.',},
              txtnaluno:		{required: 'Informe o nome do aluno',minLength: 5,},
			  selectsexo: 		{required: 'Selecione o Sexo.'},
			  txtcertidao: 		{required: 'Infomre o n�mero da certid�o de nascimento.',},
              txtfolha:			{required: 'Informe o n�mero da folha de registro.',},
              txtlivro:			{required: 'Informe o n�mero do livro.',},
			  cod_estado:		{required: 'Informe o estado de nascimento.',},
			  cod_cidades:		{required: 'Informe o munic�pio de nascimento.',},
             /* 
			  txtpai:			{required: 'Informe o nome do pai ',minLength: 5,},
              txtRGpai :		{required: 'Informe o nu�mero da RG do pai.',},
			  txtOrgaoExppai:	{required: 'Informe org�o de expedi��o.',},
              txtdtemissaorgpai:{required: 'Informe a data de emiss�o.',},
              cpfpai :				{required: 'Informe o CPF',},
			  */
			  txtmae:			{required: 'Informe o nome da mae ',minLength: 5,},
              txtRGmae:			{required: 'Informe o nu�mero da RG da m�e',},
              txtOrgaoExpmae :	{required: 'Informe org�o de expedi��o',},
			  txtdtemissaorgmae:{required: 'Informe a data de emiss�o',},
              	          cpf:  {  cpf: 'CPF invalido'},
	          txtEndereco:	    {required: 'Informe o nome da rua ou avenida.',},
	          txtBairro:		{required: 'Informe o bairro',},
	          txtnr:			{required: 'Informe o n�mero',},
	          txtcep:			{required: 'Informe o cep',},
	          cod_muni:		    {required: 'Informe o municipio',},
	          txtcontato:		{required: 'Informe o telefone para contato',},
              
			  txtmodalidade:		{required: 'Informe a modalidade',},
			  selectsemestre:		{required: 'Informe o semestre',},
			  txtetapa:             {required: 'Informe a etapa',},

               txtdtinicio: {required: 'Informe a data inicio da etapa', dateBR: 'Digite uma data valida'},	            
              txtdtfim: {required: 'Informe a data fim da etapa', dateBR: 'Digite uma data valida'},	            
              txtdt_fechamento: {required: 'Informe a data de previs�o de fechamento', dateBR: 'Digite uma data valida'},	            	            
	            




}
     });
 });






$(document).ready(function() {
  $("input").keyup(function(){
    $(this).val($(this).val().toUpperCase());
     })
}) 




jQuery(function($){
   $("#txtdtnascimento").mask("99/99/9999");
   $("#txtdtemissaorgpai").mask("99/99/9999");
   $("#txtdtemissaorgmae").mask("99/99/9999");   
   $("#txtcep").mask("99999999");   
   $("#txtcontato").mask("(99)9999-99999");      

 $("#txtCelular").mask("(99)9999-9999");         
   
   $("#txtdtinicio").mask("99/99/9999");
   $("#txtdtfim").mask("99/99/9999");
   $("#txtdt_fechamento").mask("99/99/9999");

});




$(function() {
		$( "#txtdtinicial" ).datepicker({
			changeMonth: true,
			changeYear: true
		});
	});

$(function() {
        $("#txtdtinicial").datepicker();
        $('#txtdtinicial').datepicker('option', 'dateFormat', 'dd/mm/yy');
});


$(function() {
		$( "#txtdtfinal" ).datepicker({
			changeMonth: true,
			changeYear: true
		});
	});

$(function() {
        $("#txtdtfinal").datepicker();
        $('#txtdtfinal').datepicker('option', 'dateFormat', 'dd/mm/yy');
});

$(function() {
		$( "#txtdtretorno" ).datepicker({
			changeMonth: true,
			changeYear: true
		});
	});

$(function() {
        $("#txtdtretorno").datepicker();
        $('#txtdtretorno').datepicker('option', 'dateFormat', 'dd/mm/yy');
});






function Enum(num){  

 var tecla = num.which;
//alert(tecla);
if (document.all)
    var tecla = event.keyCode;
else if(document.layers)
  var tecla = num.which;
		
//alert(tecla);
if (((tecla > 47) && (tecla < 58)) || (tecla == 0))
  {
   return true;
  }
else
 {
   if (tecla == 8)
    	 return true
   if (tecla != 8)
    	 return false
   else
    	 return false;
  }
}






		$(function(){
			$('#cod_estado').change(function(){
	 
 				if( $(this).val() ) {
					$('#cod_cidades').hide();
					$('.carregando').show();
					$.getJSON('cidades.ajax.php?search=',{cod_estado: $(this).val(), ajax: 'true'}, function(j){
						var options = '<option value=""></option>';	
						for (var i = 0; i < j.length; i++) {
							options += '<option value="' + j[i].cod_cidades + '">' + j[i].nome + '</option>';

						}	
						$('#cod_cidades').html(options).show();
						$('.carregando').hide();
					});
				} else {
					$('#cod_cidades').html('<option value="">– Escolha um estado –</option>');

				}
			});
		});


function mascaradtnascimento(campoData){

   var data = campoData;
    if (data.length == 2){
                  dia=data;
				  data = data + '/';
 				  document.concurso.txtdtnascimento.value = data;
	              			  		  
      return true;              
              }
      if (data.length == 5)
	  {
          data = data + '/';
          document.concurso.txtdtnascimento.value = data;
			
          return true;
	   }
   
      if (data.length > 5)
	  {
		  
		  dia = (document.concurso.txtdtnascimento.value.substring(0,2)); 
		  mes = (document.concurso.txtdtnascimento.value.substring(3,5)); 
          ano = (document.concurso.txtdtnascimento.value.substring(6,10)); 
  	     
		
           situacao = ""; 
            // verifica o dia valido para cada mes 
            if ((dia < 01)||(dia < 01 || dia > 30) && (  mes == 04 || mes == 06 || mes == 09 || mes == 11 ) || dia > 31) 
			  {  
				alert("Dia Inválido.");
				document.concurso.txtdtnascimento.sefocus();
                situacao = "falsa";
              } 


            // verifica se o mes e valido 
            if (mes < 01 || mes > 12 ) 
			  { 
				alert("Dia Inválido.");
				document.concurso.txtdtnascimento.sefocus();
                situacao = "falsa"; 
              } 

           if (mes == 2 && ( dia < 01 || dia > 29 || ( dia > 28 && (parseInt(ano / 4) != ano / 4)))) 
		    { 
     		 alert("Mês Inválido.");
			 document.concurso.txtdtnascimento.sefocus();
              situacao = "falsa"; 
            }
          
		  dia = (document.concurso.txtdtnascimento.value.substring(0,2)); 
		  mes = (document.concurso.txtdtnascimento.value.substring(3,5)); 
          ano = (document.concurso.txtdtnascimento.value.substring(6,10)); 

          return true;
	   }
   
   }




function mascaradtrg(campoData){
   var data = campoData;
    if (data.length == 2){
                  dia=data;
				  data = data + '/';
 				  document.concurso.txtdtemissaorg.value = data;
	              			  		  
      return true;              
              }
      if (data.length == 5)
	  {
          data = data + '/';
          document.concurso.txtdtemissaorg.value = data;
			
          return true;
	   }
   
      if (data.length > 5)
	  {
		  
		  dia = (document.concurso.txtdtemissaorg.value.substring(0,2)); 
		  mes = (document.concurso.txtdtemissaorg.value.substring(3,5)); 
          ano = (document.concurso.txtdtemissaorg.value.substring(6,10)); 
  	     
		
           situacao = ""; 
            // verifica o dia valido para cada mes 
            if ((dia < 01)||(dia < 01 || dia > 30) && (  mes == 04 || mes == 06 || mes == 09 || mes == 11 ) || dia > 31) 
			  {  
				alert("Dia Inválido.");
				document.concurso.txtdtemissaorg.sefocus();
                situacao = "falsa";
              } 


            // verifica se o mes e valido 
            if (mes < 01 || mes > 12 ) 
			  { 
				alert("Dia Inválido.");
				document.concurso.txtdtemissaorg.sefocus();
                situacao = "falsa"; 
              } 

           if (mes == 2 && ( dia < 01 || dia > 29 || ( dia > 28 && (parseInt(ano / 4) != ano / 4)))) 
		    { 
     		 alert("Mês Inválido.");
			 document.concurso.txtdtemissaorg.sefocus();
              situacao = "falsa"; 
            }
          
		  
		  dia = (document.concurso.txtdtemissaorg.value.substring(0,2)); 
		  mes = (document.concurso.txtdtemissaorg.value.substring(3,5)); 
          ano = (document.concurso.txtdtemissaorg.value.substring(6,10)); 

          return true;
	   }
   
   }




function blocTexto(valor)
{
    
	quant = 4100;
	
    total = valor.length;
    if(total <= quant)
    {
        resto = quant - total;
        document.getElementById('cont').innerHTML = resto;
    }
    else
    {
        document.getElementById('laudo').value = valor.substr(0,quant);
    }
}



function blocTexto(valor)
{
    
	quant = 4100;
	
    total = valor.length;
    if(total <= quant)
    {
        resto = quant - total;
        document.getElementById('cont').innerHTML = resto;
    }
    else
    {
        document.getElementById('laudo').value = valor.substr(0,quant);
    }
}



function modalidade()
{

	  if (document.form.txtmodalidade.value == '1')
         {
		     document.form.selectsemestre.disabled=true;
		 }
     else
         {
		     document.form.selectsemestre.disabled=false;

          }
  }




	$(function() {
		$( "#txtdtfim" ).datepicker({
			changeMonth: true,
			changeYear: true
		});
	});

$(function() {
        $("#txtdtfim").datepicker();
        $('#txtdtfim').datepicker('option', 'dateFormat', 'dd/mm/yy');
});




$(function() {
		$( "#txtdtinicio" ).datepicker({
			changeMonth: true,
			changeYear: true
		});
	});

$(function() {
        $("#txtdtinicio").datepicker();
        $('#txtdtinicio').datepicker('option', 'dateFormat', 'dd/mm/yy');
});







	$(function() {
		$( "#txtdt_fechamento" ).datepicker({
			changeMonth: true,
			changeYear: true
		});
	});

$(function() {
        $("#txtdt_fechamento").datepicker();
        $('#txtdt_fechamento').datepicker('option', 'dateFormat', 'dd/mm/yy');
});
