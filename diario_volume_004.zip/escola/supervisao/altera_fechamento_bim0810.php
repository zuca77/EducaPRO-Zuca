<?php
session_start();

if (isset($_SESSION["login_usuario"]))
  {
   // session_cache_expire(1);
	 $login     =  $_SESSION["login_usuario"];
     $nte       =  $_SESSION["nivel_usuario"];
	 $inep      =  $_SESSION["inep_usuario"] ;
     $ntelogin  =  $_SESSION["nte_login"];
     $cpf1       = $_SESSION["cpf_usuario"];

	 include ("../funcoes.php");
     echo  saudacoes()."   ". "$login" ."  -  ". $nte."  ".dataextenso()." ".$inep;

  }
 else
  {
     		 header("../../Location: login.php");
  }


include ("../../conexao_mysql.php");

if(file_exists("../../conexao_mysql.php"))
{
        require "../../conexao_mysql.php";

} else
{
        echo "Conex�o nao foi encontrado";
        exit;
}





/*verifico se os dados estao vindos do formulario, porque se uma pessoa acessar essa pagina diretamente 
poderia dar erro, entao eu testo antes*/

if($_SERVER["REQUEST_METHOD"] == "POST") 
{
$id	                = $_POST['id'];
$tipomov            = $_POST['tipomov'];
$txtid_etapa        = $_POST['txtid_etapa'];



     if($tipomov =="")
		{

echo "<html><head><title>Resposta !!!</title></head>";
echo "<body background=\"background_mensagens.jpg\" style=\"background-attachment:fixed; background-repeat:no-repeat\">";
echo "<br><br><br>";
echo "<center><img src=\"faleconosco/atencao.gif\" alt=\"\"><p><font color=\"#ff6600\" face=\"Verdana\" size=\"4\">Informe a Situa��o! </font></center>";
echo "<br><br><center><a href=\"form_liberacao_bim.php\"><img src=\"faleconosco/button_voltar2_.gif\" alt=\"Voltar\" border=\"0\" /></a></center>";
echo "</body></html>";
exit;
        }


     if($txtid_etapa =="")
		{

echo "<html><head><title>Resposta !!!</title></head>";
echo "<body background=\"background_mensagens.jpg\" style=\"background-attachment:fixed; background-repeat:no-repeat\">";
echo "<br><br><br>";
echo "<center><img src=\"faleconosco/atencao.gif\" alt=\"\"><p><font color=\"#ff6600\" face=\"Verdana\" size=\"4\">Informe a etapa! </font></center>";
echo "<br><br><center><a href=\"form_liberacao_bim.php\"><img src=\"faleconosco/button_voltar2_.gif\" alt=\"Voltar\" border=\"0\" /></a></center>";
echo "</body></html>";
exit;
        }

$sqlgerencia = "select * from ano where inep = '$inep' and situacao = 'A'";
$resultadoger=mysql_query($sqlgerencia) or die (mysql_error());
$linhas   =mysql_num_rows($resultadoger);
if($linhas>0)
{
   while($pegar=mysql_fetch_array($resultadoger))
	{

    	$txtano    =$pegar["ano"];


    }
 }
else
  {
   $txtano = "2013";
  }








//echo "$dtemissaorg";
$dia = date('d');
$mes = date('m');
$ano = date('Y');

$data =$ano."-".$mes."-".$dia;






$sql="select * from etapa_liberacao where id= $id";
$resultado=mysql_query($sql) or die (mysql_error());
$linhas=mysql_num_rows($resultado);
if ($linhas>0)
{
//mysql_query ( "START TRANSACTION" );


$sql = "update etapa_liberacao set
		dtfechamento           ='$data',
		situacao               ='$tipomov'
        where   id             = '$id'";

if(@mysql_query($sql))
  {
//      mysql_query ( "COMMIT" );
      $success = mysql_affected_rows();


 if($success ==true)
   {
/**************************************************************************************************************************/


     if ($tipomov=='F')
       {
         if ($txtid_etapa==1)
            {
               $sqlaltera = "update nota_aluno set  bim1 = 'S'
               where  inep = '$inep'  and    ano = '$txtano' and ((bim1 = 'N') || (bim1 is null))";
             }

       else if ($txtid_etapa==2)
            {
               $sqlaltera = "update nota_aluno set  bim2 = 'S'
               where  inep = '$inep'  and    ano = '$txtano' and ((bim2 = 'N') || (bim2 is null))";
             }

       else if ($txtid_etapa==3)
            {
               $sqlaltera = "update nota_aluno set  bim3 = 'S'
               where  inep = '$inep'  and    ano = '$txtano' and ((bim3 = 'N') || (bim3 is null)";
             }

       else if ($txtid_etapa==4)
            {
               $sqlaltera = "update nota_aluno set  bim4 = 'S'
               where  inep = '$inep'  and    ano = '$txtano' and ((bim4 = 'N') || (bim4 is null))";
             }

       else if ($txtid_etapa==5)
            {
               $sqlaltera = "update nota_aluno set  rec1 = 'S'
               where  inep = '$inep'  and  ano = '$txtano' and ((rec1 = 'N') || (rec1 is null))";
             }

       else if ($txtid_etapa==6)
            {
               $sqlaltera = "update nota_aluno set  rec2 = 'S'
               where  inep = '$inep'  and    ano = '$txtano' and ((rec2 = 'N') || (rec2 is null))";
             }

       else if ($txtid_etapa==7)
            {
               $sqlaltera = "update nota_aluno set  rec3 = 'S'
               where  inep = '$inep'  and    ano = '$txtano' and ((rec3 = 'N') || (rec3 is null))";
             }
       else if ($txtid_etapa==8)
            {
               $sqlaltera = "update nota_aluno set  rec4 = 'S'
               where  inep = '$inep'  and    ano = '$txtano' and ((rec4 = 'N') || (rec4 is null))";
             }

       else if ($txtid_etapa==9) // exame final
            {
               $sqlaltera = "update nota_aluno set  final = 'S'
               where  inep = '$inep'  and    ano = '$txtano' and ((final = 'N') || (final is null))";
             }

       else if ($txtid_etapa==10) //1 semestral
            {
               $sqlaltera = "update nota_aluno set  rec1 = 'S', rec2 = 'S'
               where  inep = '$inep'  and    ano = '$txtano'";
             }


       else if ($txtid_etapa==11)  // anual
            {
               $sqlaltera = "update nota_aluno set  set  rec1 = 'S', rec2 = 'S',rec3 = 'S',rec4 = 'S'
               where  inep = '$inep'  and    ano = '$txtano'";
             }

       else if ($txtid_etapa==12) // 2 semestre
            {
               $sqlaltera = "update nota_aluno set  ,rec3 = 'S',rec4 = 'S'
               where  inep = '$inep'   and  ano = '$txtano'";
             }



         if (@mysql_query($sqlaltera))
              {

                if(mysql_affected_rows() == 1)
    		         {

                     echo "<html><head><title>Resposta !!!</title></head>";
                     echo "<body background=\"background_mensagens.jpg\" style=\"background-attachment:fixed; background-repeat:no-repeat\">";
                     echo "<br><br><br>";
                     echo "<center><img src=\"faleconosco/atencao.gif\" alt=\"\"><p><font color=\"#ff6600\" face=\"Verdana\" size=\"4\">Etapa Alterada com Sucesso! </font></center>";
                     echo "<br><br><center><a href=\"form_liberacao_bim.php\"><img src=\"faleconosco/button_voltar2_.gif\" alt=\"Voltar\" border=\"0\" /></a></center>";
                     echo "</body></html>";
                     exit;
                       }
              }

       else
          {
             //verifico se nao estao tentando gravar um dado que ja existe, pois usei UNIQUE na tabela
             if(mysql_errno() == 1062)
		       {
                 echo $erros[mysql_errno()];
                 exit;
               }
		     else
		       {
                  echo "Erro nao foi possivel efetuar o cadastro.";//provalmente caminho de banco de dados
                  exit;
               }
             @mysql_close();
           }

      }
  else  // caso a situacao seja aberta
    {
        /*
        $sql = "update etapa_liberacao set
		dtfechamento           ='$data',
		situacao               ='$tipomov'
        where   id             = '$id'";
       */


         if ($txtid_etapa==1)
            {
/*echo "aaa $txtid_etapa";
echo "aaa $inep";
echo "aaa $txtano";
*/
               $sqlaltera = "update nota_aluno set  bim1 = 'N'
               where  inep = '$inep'  and    ano = '$txtano' and ((bim1 = 'S') || (bim1 is null))";
             }

       else if ($txtid_etapa==2)
            {
               $sqlaltera = "update nota_aluno set  bim2 = 'N'
               where  inep = '$inep'  and    ano = '$txtano' and ((bim2 = 'S') || (bim2 is null))";
             }

       else if ($txtid_etapa==3)
            {
               $sqlaltera = "update nota_aluno set  bim3 = 'N'
               where  inep = '$inep'  and    ano = '$txtano' and ((bim3 = 'S') || (bim3 is null)";
             }

       else if ($txtid_etapa==4)
            {
               $sqlaltera = "update nota_aluno set  bim4 = 'N'
               where  inep = '$inep'  and    ano = '$txtano' and ((bim4 = 'S') || (bim4 is null))";
             }

       else if ($txtid_etapa==5)
            {
               $sqlaltera = "update nota_aluno set  rec1 = 'N'
               where  inep = '$inep'  and  ano = '$txtano' and ((rec1 = 'S') || (rec1 is null))";
             }

       else if ($txtid_etapa==6)
            {
               $sqlaltera = "update nota_aluno set  rec2 = 'N'
               where  inep = '$inep'  and    ano = '$txtano' and ((rec2 = 'S') || (rec2 is null))";
             }

       else if ($txtid_etapa==7)
            {
               $sqlaltera = "update nota_aluno set  rec3 = 'N'
               where  inep = '$inep'  and    ano = '$txtano' and ((rec3 = 'S') || (rec3 is null))";
             }
       else if ($txtid_etapa==8)
            {
               $sqlaltera = "update nota_aluno set  rec4 = 'N'
               where  inep = '$inep'  and    ano = '$txtano' and ((rec4 = 'S') || (rec4 is null))";
             }

       else if ($txtid_etapa==9) // exame final
            {
               $sqlaltera = "update nota_aluno set  final = 'N'
               where  inep = '$inep'  and    ano = '$txtano' and ((final = 'S') || (final is null))";
             }

       else if ($txtid_etapa==10) //1 semestral
            {
               $sqlaltera = "update nota_aluno set  rec1 = 'N', rec2 = 'N'
               where  inep = '$inep'  and    ano = '$txtano'";
             }


       else if ($txtid_etapa==11)  // anual
            {
               $sqlaltera = "update nota_aluno set  set  rec1 = 'N', rec2 = 'N',rec3 = 'N',rec4 = 'N'
               where  inep = '$inep'  and    ano = '$txtano'";
             }

       else if ($txtid_etapa==12) // 2 semestre
            {
               $sqlaltera = "update nota_aluno set  ,rec3 = 'N',rec4 = 'N'
               where  inep = '$inep'   and  ano = '$txtano'";
             }
if(@mysql_query($sqlaltera))
  {
      mysql_query ( "COMMIT" );
      $success = mysql_affected_rows();

     if($success ==true)
		{

echo "<html><head><title>Resposta !!!</title></head>";
echo "<body background=\"background_mensagens.jpg\" style=\"background-attachment:fixed; background-repeat:no-repeat\">";
echo "<br><br><br>";
echo "<center><img src=\"faleconosco/atencao.gif\" alt=\"\"><p><font color=\"#ff6600\" face=\"Verdana\" size=\"4\">Etapa Alterada com Sucesso! </font></center>";
echo "<br><br><center><a href=\"form_liberacao_bim.php\"><img src=\"faleconosco/button_voltar2_.gif\" alt=\"Voltar\" border=\"0\" /></a></center>";
echo "</body></html>";
exit;
        }

    else
		{

         echo "<html><head><title>Resposta !!!</title></head>";
         echo "<body background=\"background_mensagens.jpg\" style=\"background-attachment:fixed; background-repeat:no-repeat\">";
         echo "<br><br><br>";
         echo "<center><img src=\"faleconosco/atencao.gif\" alt=\"\"><p><font color=\"#ff6600\" face=\"Verdana\" size=\"4\">Etapa alterada com sucesso! </font></center>";
         echo "<br><br><center><a href=\"form_liberacao_bim.php\"><img src=\"faleconosco/button_voltar2_.gif\" alt=\"Voltar\" border=\"0\" /></a></center>";
         echo "</body></html>";
         exit;
        }



  }
 else
   {
        //verifico se nao estao tentando gravar um dado que ja existe, pois usei UNIQUE na tabela
        if(mysql_errno() == 1062)
		  {
                echo $erros[mysql_errno()];
                exit;
          }
		  else
		  {
                echo "Erro nao foi possivel efetuar o cadastro";
                exit;
          }
        @mysql_close();
     }




}

                     echo "<html><head><title>Resposta !!!</title></head>";
                     echo "<body background=\"background_mensagens.jpg\" style=\"background-attachment:fixed; background-repeat:no-repeat\">";
                     echo "<br><br><br>";
                     echo "<center><img src=\"faleconosco/atencao.gif\" alt=\"\"><p><font color=\"#ff6600\" face=\"Verdana\" size=\"4\">Etapa Alterada com Sucesso! </font></center>";
                     echo "<br><br><center><a href=\"form_liberacao_bim.php\"><img src=\"faleconosco/button_voltar2_.gif\" alt=\"Voltar\" border=\"0\" /></a></center>";
                     echo "</body></html>";
                     exit;


      }
    else
     {
                     echo "<html><head><title>Resposta !!!</title></head>";
                     echo "<body background=\"background_mensagens.jpg\" style=\"background-attachment:fixed; background-repeat:no-repeat\">";
                     echo "<br><br><br>";
                     echo "<center><img src=\"faleconosco/atencao.gif\" alt=\"\"><p><font color=\"#ff6600\" face=\"Verdana\" size=\"4\">Etapa Alterada com Sucesso! </font></center>";
                     echo "<br><br><center><a href=\"form_liberacao_bim.php\"><img src=\"faleconosco/button_voltar2_.gif\" alt=\"Voltar\" border=\"0\" /></a></center>";
                     echo "</body></html>";
                     exit;

     }





















/********************************************************************************************************************************************/
        }
               
    else
		{

         echo "<html><head><title>Resposta !!!</title></head>";
         echo "<body background=\"background_mensagens.jpg\" style=\"background-attachment:fixed; background-repeat:no-repeat\">";
         echo "<br><br><br>";
         echo "<center><img src=\"faleconosco/atencao.gif\" alt=\"\"><p><font color=\"#ff6600\" face=\"Verdana\" size=\"4\">Etapa alterada com sucesso! </font></center>";
         echo "<br><br><center><a href=\"form_liberacao_bim.php\"><img src=\"faleconosco/button_voltar2_.gif\" alt=\"Voltar\" border=\"0\" /></a></center>";
         echo "</body></html>";
         exit;
        }



  }
 else
   {
        //verifico se nao estao tentando gravar um dado que ja existe, pois usei UNIQUE na tabela
        if(mysql_errno() == 1062)
		  {
                echo $erros[mysql_errno()];
                exit;
          }
		  else
		  {
                echo "Erro nao foi possivel efetuar o cadastro";
                exit;
          }
        @mysql_close();
     }


}
else
{
echo "<html><head><title>Resposta !!!</title></head>";
echo "<body background=\"background_mensagens.jpg\" style=\"background-attachment:fixed; background-repeat:no-repeat\">";
echo "<br><br><br>";
echo "<center><img src=\"faleconosco/atencao.gif\" alt=\"\"><p><font color=\"#ff6600\" face=\"Verdana\" size=\"4\">Registro n�o localizado.! <b></b></font></center>";
echo "<br><br><center><a href=\"../mtz/mnmtz.php\"><img src=\"faleconosco/button_voltar2_.gif\" alt=\"Voltar\" border=\"0\" /></a></center>";
echo "</body></html>";
}






