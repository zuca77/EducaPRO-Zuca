<?php
require_once __DIR__ . '/../../start.php';
$pdo = new Conexao;

$title = 'Libera��o de etapas';

$sql = "SELECT id, descricao FROM modalidadeensino ORDER BY id";
$modalidades = $pdo->query($sql)->fetchAll();

$sql = "SELECT id, descricao FROM etapa_ano ORDER BY id";
$etapas = $pdo->query($sql)->fetchAll();

$sql = "SELECT codigo AS id, descricao FROM habilitacao WHERE disciplina = 'S' ORDER BY descricao";
$disciplinas = $pdo->query($sql)->fetchAll();

$sql = "SELECT l.id,e.descricao AS desc_etapa,l.id_etapa,l.id_modalidade,m.descricao AS desc_mod,dt_inicio,dt_fim,ano,data,usuario,l.semestre,
					l.situacao,l.dt_fechamento_bim, h.descricao AS disciplina
				FROM etapa_liberacao l
					JOIN etapa_ano e ON l.id_etapa = e.id
					JOIN modalidadeensino m ON l.id_modalidade = m.id
					LEFT JOIN habilitacao h ON l.id_disciplina = h.codigo
			  WHERE l.inep  = '{$inep}'
			  	AND l.ano = '{$txtano}'
			  ORDER BY m.descricao, e.descricao, l.semestre, h.descricao, l.dt_inicio;";
$etapasLiberacao = $pdo->query($sql)->fetchAll();

$sql = "SELECT l.id, e.descricao AS etapa, l.semestre, m.descricao AS modalidade, l.dt_inicio AS start, l.dt_fim AS end, l.id_modalidade, h.descricao AS disciplina, l.id_etapa
				FROM etapa_liberacao l
					JOIN etapa_ano e ON l.id_etapa = e.id
					JOIN modalidadeensino m ON l.id_modalidade = m.id
					LEFT JOIN habilitacao h ON l.id_disciplina = h.codigo
			  WHERE l.inep  = '{$inep}'
			  	AND l.ano = '{$txtano}'
			  ORDER BY m.descricao, e.descricao, l.semestre, l.dt_inicio;";
$etapasLiberacaoJson = $pdo->query($sql)->fetchAll();
$etapasArray = array();
foreach($etapasLiberacaoJson as $etaj) {
	$content = $etaj['id_modalidade'] == Modalidade::EJA ? $etaj['etapa'].' / Semestre '.$etaj['semestre'] : $etaj['etapa'];
    $content = in_array($etaj['id_etapa'], [Etapa::MODULAR, Etapa::MODULAR_2_ANO]) ? $etaj['etapa'].' / '.$etaj['disciplina'] : $content;
	$content = str_replace('�', '�', $content);
	array_push($etapasArray, array(
		'content' => utf8_encode($content),
		'start' => $etaj['start'],
		'end' => $etaj['end'],
		'modalidade' => utf8_encode($etaj['modalidade']),
	));
}

?><!DOCTYPE HTML>
<html>
	<head>
		<?php require_once page_head(); ?>
	</head>
	<body>
		<?php require_once page_header(); ?>

		<div class="container">
			<form class="submit-wait" action="insere_liberacao_etapa.php" method="POST">
				<fieldset class="well well-sm">
					<legend>Adicionar nova etapa</legend>

					<div class="row">
						<div class="col-md-4">
							<div class="form-group">
								<label for="txtmodalidade">Modalidade</label>
								<select name="txtmodalidade" id="txtmodalidade" class="form-control chosen" required>
									<option value="">Selecione a Modalidade</option>
									<?php foreach($modalidades as $mo): ?>
									<option value="<?php echo $mo['id'] ?>"><?php echo $mo['descricao'] ?></option>
									<?php endforeach ?>
								</select>
							</div>
						</div>
						<div class="col-md-4">
							<div class="form-group">
								<label for="txtetapa">Etapa</label>
								<select name="txtetapa" id="txtetapa" class="form-control chosen" required>
									<option value="">Selecione a Etapa</option>
									<?php foreach($etapas as $et) :?>
									<option value="<?php echo $et['id'] ?>"><?php echo $et['descricao'] ?></option>
									<?php endforeach ?>
								</select>
							</div>
						</div>
						<div class="col-md-4">
							<div class="form-group" id="formGroupSemestre" style="display:none">
								<label for="selectsemestre">Semestre <small class="text-muted">(Apenas Modalidade EJA)</small></label>
								<select id="selectsemestre" name="selectsemestre" class="form-control" required>
									<option value="1">1� Semestre</option>
									<option value="2">2� Semestre</option>
								</select>
							</div>
							<div class="form-group" id="formGroupDisciplina" style="display:none">
								<label for="id_disciplina">Disciplina <small class="text-muted">(Apenas Etapa Modular)</small></label>
								<select name="id_disciplina" id="id_disciplina" class="form-control" required>
									<option value="">Selecione a disciplina</option>
									<?php foreach($disciplinas as $disc) :?>
									<option value="<?php echo $disc['id'] ?>"><?php echo $disc['descricao'] ?></option>
									<?php endforeach ?>
								</select>
							</div>
						</div>
					</div>

					<div class="row">
						<div class="col-md-2">
							 <div class="form-group">
								<label for="txtdtinicio">Data Inicial</label>
								<input type="text" name="txtdtinicio" value="" class="form-control mask-data" maxlength="10" id="txtdtinicio" placeholder="Data inicial" required>
							</div>
						</div>
						<div class="col-md-2">
							<div class="form-group">
								<label for="txtdtfim">Data Final</label>
								<input type="text" name="txtdtfim" value="" class="form-control mask-data" maxlength="10" id="txtdtfim" placeholder="Data final" required>
							</div>
						</div>
						<div class="col-md-2">
							<div class="form-group">
								<label for="txtdt_fechamento">Bloqueio Previs�o</label>
								<input type="text" name="txtdt_fechamento" value="" class="form-control mask-data" maxlength="10" id="txtdt_fechamento" placeholder="Data bloqueio" required>
							</div>
						</div>
						<div class="col-md-2">
							<button type="submit" class="btn btn-block btn-offset btn-primary btn-submit-wait">ADICIONAR ETAPA</button>
						</div>
						<div class="col-md-2">
							<button type="button" class="btn btn-default btn-back btn-offset">Voltar</button>
						</div>
					</div>
				</fieldset>
			</form>

			<div class="alert alert-info">
				<strong>ATEN��O!</strong>
				As datas das etapas por modalidade n�o devem coincidir.
				<br>
				Ou seja, a data de in�cio de uma etapa seguinte deve ser ap�s a data de fim da outra, nunca no mesmo dia.
			</div>

			<?php if (sizeof($etapasLiberacao) == 0): ?>
			<div class="alert alert-danger">
				<strong>IMPORTANTE!</strong>
				Deve ser definido o per�odo das etapas por modalidade.
			</div>
			<?php else: ?>
			<table class="table table-bordered table-hover table-condensed table-striped">
				<tr>
					<th width="20"></th>
					<th width="20"></th>
					<th>Modalidade / Etapa / Semestre</th>
					<th width="20">In�cio</th>
					<th width="20">Fim</th>
					<th width="20">Bloqueio</th>
					<th width="20">Situa��o</th>
					<th width="20"></th>
				</tr>
				<?php foreach ($etapasLiberacao as $eta): ?>
				<tr title="Data: <?php echo formataData($eta['data']); ?> - Usu�rio: <?php echo $eta["usuario"]; ?>">
					<td>
						<a href="<?php url("escola/supervisao/form_alteracao_dt_previa.php?codigo={$eta['id']}") ?>" class="btn btn-xs btn-default" title="Editar per�odo">
							<i class="fa fa-edit"></i>
							PER�ODO
						</a>
					</td>
					<td>
						<a href="<?php url("escola/supervisao/altera_situacao_etapa.php?id={$eta['id']}") ?>" title="Alterar situa��o de etapa" class="btn btn-xs btn-block btn-<?php echo $eta['situacao'] == 'F' ? 'success' : 'warning' ?>">
							<?php echo $eta['situacao'] == 'F' ? 'ABRIR' : 'FECHAR' ?>
						</a>
					</td>
					<td>
						<small>
							<?php echo $eta["desc_mod"]; ?> /
							<?php echo $eta["desc_etapa"]; ?>
							<?php if($eta['id_modalidade'] == Modalidade::EJA && !empty($eta["semestre"])): ?>
							/ SEMETRE <?php echo $eta["semestre"]; ?>
							<?php endif; ?>
							<?php if(in_array($eta['id_etapa'], [Etapa::MODULAR, Etapa::MODULAR_2_ANO])): ?>
							/ <?php echo $eta["disciplina"]; ?>
							<?php endif; ?>
						</small>
					</td>
					<td><?php echo formataData($eta['dt_inicio']); ?></td>
					<td><?php echo formataData($eta['dt_fim']); ?></td>
					<td><?php echo formataData($eta['dt_fechamento_bim']); ?></td>
					<td>
						<b class="text-<?php echo $eta['situacao'] == 'A' ? 'success' : 'warning' ?>">
							<?php echo $eta["situacao"]=='A' ? 'ABERTA' : 'FECHADA' ?>
						</b>
					</td>
					<td align="center">
						<a href="<?php url("escola/supervisao/exclui_fechamento_bim.php?codigo={$eta['id']}") ?>" class="btn btn-xs btn-danger" onclick="return confirm('Confirma excluir?')">
							EXCLUIR
						</a>
					</td>
				</tr>
				<?php endforeach ?>
			</table>
			<?php endif ?>

			<?php if (sizeof($etapasArray) > 0): ?>
			<fieldset>
				<legend>Linha do tempo</legend>

				<div id="timeline" style="height: 200px;"></div>
			</fieldset>
			<?php endif ?>
		</div>

		<?php require_once page_footer(); ?>
		<script>
			$(function() {
				$('#txtetapa').on('change', function() {
					var id_etapa = $(this).val();
					if (id_etapa == 13 || id_etapa == 14) { // MODULAR
						$('#formGroupDisciplina').show();
						$('#id_disciplina').attr('disabled', false).attr('required', true);
					} else {
						$('#formGroupDisciplina').hide();
						$('#id_disciplina').attr('disabled', true).attr('required', false);
					}
				});
				$('#txtmodalidade').on('change', function() {
					var id_modalidade = $(this).val();
					if (id_modalidade == 2) { // EJA
						$('#formGroupSemestre').show();
						$('#selectsemestre').attr('disabled', false).attr('required', true);
					} else if(id_modalidade == 4) { // MEDIA��O
						$('#txtetapa').val(13).trigger('change').trigger('chosen:updated');
						$('#formGroupSemestre').hide();
						$('#selectsemestre').attr('disabled', true).attr('required', false);
					} else {
						$('#formGroupSemestre').hide();
						$('#selectsemestre').attr('disabled', true).attr('required', false);
					}
				});
			});
		</script>
		<?php if (sizeof($etapasArray) > 0): ?>
		<script type="text/javascript" src="https://www.gstatic.com/charts/loader.js"></script>
    <script type="text/javascript">
      var dadosEtapas = <?php echo isset($etapasArray) && sizeof($etapasArray) > 0 ? json_encode($etapasArray) : '{}'; ?>;
      google.charts.load('current', {'packages':['timeline'], 'language': 'pt-BR'});
      google.charts.setOnLoadCallback(drawChart);
      function drawChart() {
        var container = document.getElementById('timeline');
        var chart = new google.visualization.Timeline(container);
        var dataTable = new google.visualization.DataTable();

        dataTable.addColumn({ type: 'string', id: 'Modalidade' });
        dataTable.addColumn({ type: 'string', id: 'Etapa' });
        dataTable.addColumn({ type: 'date', id: 'In�cio' });
        dataTable.addColumn({ type: 'date', id: 'Fim' });

        var rows = [];
        for (key in dadosEtapas) {
        	var dado = dadosEtapas[key];
        	rows.push([dado.modalidade, dado.content, new Date(dado.start), new Date(dado.end)]);
        }

        var options = {
        	tooltip: {
        		trigger: 'focus'
        	}
        };

        dataTable.addRows(rows);
        chart.draw(dataTable, options);
      }
    </script>
		<?php endif ?>
	</body>
</html>