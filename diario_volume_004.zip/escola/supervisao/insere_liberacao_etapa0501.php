<?php

session_start();
if (isset($_SESSION["login_usuario"]))
  {
   // session_cache_expire(1);
	 $login     =  $_SESSION["login_usuario"];
     $nte       =  $_SESSION["nivel_usuario"];
	 $inep      =  $_SESSION["inep_usuario"] ;
     $ntelogin  =  $_SESSION["nte_login"];
     $cpf       = $_SESSION["cpf_usuario"];
     include ("../funcoes.php");
     echo  saudacoes()."   ". "$login" ."  -  ". $nte."  ".dataextenso() ." - ".$inep;

  }
 else
  {
     		 header("Location: ../../login.php");
  }



include ("../../conexao_mysql.php");

if(file_exists("../../conexao_mysql.php"))
{
        require "../../conexao_mysql.php";

} else
{
        echo "Conex�o nao foi encontrado";
        exit;
}



if($_SERVER["REQUEST_METHOD"] == "POST")
{
$txtdtinicio	     = $_POST['txtdtinicio'];
$txtdtfim            = $_POST['txtdtfim'];
$txtetapa            = $_POST['txtetapa'];
$txtmodalidade       = $_POST['txtmodalidade'];
$selectsemestre       = $_POST['selectsemestre'];




if  (     (($txtmodalidade==2) && ($txtetapa==3)) || (($txtmodalidade==2) && ($txtetapa==4)) || (($txtmodalidade==2) && ($txtetapa==7)) ||
           (($txtmodalidade==2) && ($txtetapa==8)) || (($txtmodalidade==2) && ($txtetapa==7))  || (($txtmodalidade==2) && ($txtetapa==11))  )  // 
      {
    echo "<html><head><title>Resposta !!!</title></head>";
    echo "<body background=\"background_mensagens.jpg\" style=\"background-attachment:fixed; background-repeat:no-repeat\">";
    echo "<br><br><br>";
    echo "<center><img src=\"faleconosco/atencao.gif\" alt=\"\"><p><font color=\"#FF0000\" face=\"Verdana\" size=\"4\">Modalidade n�o aceita essa etapa. </font></center>";
    echo "<br><br><center><a href=\"form_liberacao_bim.php\"><img src=\"faleconosco/button_voltar2_.gif\" alt=\"Voltar\" border=\"0\" /></a></center>";
    echo "</body></html>";
    exit;


      }










/*tratamento das datas*/
$diai = substr($txtdtinicio, 0,2);
$anoi = substr($txtdtinicio, -4);
$mesi = substr($txtdtinicio, -7,2);
$txtdtinicio=$anoi.".".$mesi.".".$diai;


/*tratamento das datas*/
$diaf = substr($txtdtfim, 0,2);
$anof = substr($txtdtfim, -4);
$mesf = substr($txtdtfim, -7,2);
$txtdtfim=$anof.".".$mesf.".".$diaf;










   if ($anof<$anoi)
       {
    echo "<html><head><title>Resposta !!!</title></head>";
    echo "<body background=\"background_mensagens.jpg\" style=\"background-attachment:fixed; background-repeat:no-repeat\">";
    echo "<br><br><br>";
    echo "<center><img src=\"faleconosco/atencao.gif\" alt=\"\"><p><font color=\"#FF0000\" face=\"Verdana\" size=\"4\"><blink>Data final n�o pode ser menor que a data inicial.!</blink> <b></b></font></center>";
    echo "<br><br><center><a href=\"form_liberacao_bim.php\"><img src=\"faleconosco/button_voltar2_.gif\" alt=\"Voltar\" border=\"0\" /></a></center>";
    echo "</body></html>";
    exit;

       }



   if (($anof==$anoi) && ($mesf<$mesi))
       {
    echo "<html><head><title>Resposta !!!</title></head>";
    echo "<body background=\"background_mensagens.jpg\" style=\"background-attachment:fixed; background-repeat:no-repeat\">";
    echo "<br><br><br>";
    echo "<center><img src=\"faleconosco/atencao.gif\" alt=\"\"><p><font color=\"#FF0000\" face=\"Verdana\" size=\"4\"><blink>Data final n�o pode ser menor que a data inicial.!</blink> <b></b></font></center>";
    echo "<br><br><center><a href=\"form_liberacao_bim.php\"><img src=\"faleconosco/button_voltar2_.gif\" alt=\"Voltar\" border=\"0\" /></a></center>";
    echo "</body></html>";
    exit;

       }


   if (($anof==$anoi) && ($mesf==$mesi) && ($diaf<$diai))
       {
    echo "<html><head><title>Resposta !!!</title></head>";
    echo "<body background=\"background_mensagens.jpg\" style=\"background-attachment:fixed; background-repeat:no-repeat\">";
    echo "<br><br><br>";
    echo "<center><img src=\"faleconosco/atencao.gif\" alt=\"\"><p><font color=\"#FF0000\" face=\"Verdana\" size=\"4\"><blink>Data final n�o pode ser menor que a data inicial.!</blink> <b></b></font></center>";
    echo "<br><br><center><a href=\"form_liberacao_bim.php\"><img src=\"faleconosco/button_voltar2_.gif\" alt=\"Voltar\" border=\"0\" /></a></center>";
    echo "</body></html>";
    exit;

       }


if (trim($inep)=='')
   {
    echo "<html><head><title>Resposta !!!</title></head>";
    echo "<body background=\"background_mensagens.jpg\" style=\"background-attachment:fixed; background-repeat:no-repeat\">";
    echo "<br><br><br>";
    echo "<center><img src=\"faleconosco/atencao.gif\" alt=\"\"><p><font color=\"#FF0000\" face=\"Verdana\" size=\"4\"><blink>Escola n�o localizada.!</blink> <b></b></font></center>";
    echo "<br><br><center><a href=\"form_liberacao_bim.php\"><img src=\"faleconosco/button_voltar2_.gif\" alt=\"Voltar\" border=\"0\" /></a></center>";
    echo "</body></html>";
    exit;

   }





if (trim($txtetapa)=='')
   {
    echo "<html><head><title>Resposta !!!</title></head>";
    echo "<body background=\"background_mensagens.jpg\" style=\"background-attachment:fixed; background-repeat:no-repeat\">";
    echo "<br><br><br>";
    echo "<center><img src=\"faleconosco/atencao.gif\" alt=\"\"><p><font color=\"#FF0000\" face=\"Verdana\" size=\"4\"><blink>Campo Obrigat�rio. Informe a Etapa.!</blink> <b></b></font></center>";
    echo "<br><br><center><a href=\"form_liberacao_bim.php\"><img src=\"faleconosco/button_voltar2_.gif\" alt=\"Voltar\" border=\"0\" /></a></center>";
    echo "</body></html>";
    exit;

   }


if (trim($txtmodalidade)=='')
   {
    echo "<html><head><title>Resposta !!!</title></head>";
    echo "<body background=\"background_mensagens.jpg\" style=\"background-attachment:fixed; background-repeat:no-repeat\">";
    echo "<br><br><br>";
    echo "<center><img src=\"faleconosco/atencao.gif\" alt=\"\"><p><font color=\"#FF0000\" face=\"Verdana\" size=\"4\"><blink>Campo Obrigat�rio. Informe a Modalidade.!</blink> <b></b></font></center>";
    echo "<br><br><center><a href=\"form_liberacao_bim.php\"><img src=\"faleconosco/button_voltar2_.gif\" alt=\"Voltar\" border=\"0\" /></a></center>";
    echo "</body></html>";
    exit;

   }





/*tratamento das datas*/




$dia = date('d');
$mes = date('m');
$ano = date('Y');

$data =$ano.".".$mes.".".$dia;


if ($txtmodalidade==1)
{
$sql="select * from  etapa_liberacao where id_etapa  = '$txtetapa' and id_modalidade = '$txtmodalidade'
and inep= '$inep' and ano= '$ano' ";
}
else
{
$sql="select * from  etapa_liberacao where id_etapa  = '$txtetapa' and id_modalidade = '$txtmodalidade' and
semestre  =  '$selectsemestre'  and inep= '$inep' and ano= '$ano'";
}


$resultado=mysql_query($sql) or die (mysql_error());


$situacao           = mysql_result($resultado, 0, "situacao");


if ($situacao=='F')
                   {
                      echo "<html><head><title>Resposta !!!</title></head>";
                      echo "<body background=\"background_mensagens.jpg\" style=\"background-attachment:fixed; background-repeat:no-repeat\">";
                      echo "<br><br><br>";
                      echo "<center><img src=\"faleconosco/atencao.gif\" alt=\"\"><p><font color=\"#FF0000\" face=\"Verdana\" size=\"4\"><b>Dados
                      N�o Podem Ser Alterados. Etapa Fechada.</b></font></center>";
                      echo "<br><br><center><a href=\"form_liberacao_bim.php\"><img src=\"faleconosco/button_voltar2_.gif\" alt=\"Voltar\" border=\"0\" /></a></center>";
                      echo "</body></html>";
                      exit;
                    }




$linhas=mysql_num_rows($resultado);
if ($linhas>0)
 { 

/*echo "$txtdtinicio*";
echo "$txtdtfim*";
echo "$cpf*";
echo "$txtmodalidade*";
echo "$selectsemestre*";
echo "$data*";
echo "$inep*";
echo "$ano*";
*/

if ($txtmodalidade==2)
{
 $sql = "update  etapa_liberacao set
            dt_inicio = '$txtdtinicio',
            dt_fim    = '$txtdtfim',
            usuario   = '$cpf',
 	     id_modalidade = '$txtmodalidade',
            semestre      = '$selectsemestre',
            data          = '$data'
            where         id_etapa= '$txtetapa'  and inep= '$inep' and ano= '$ano'
            and id_modalidade = '$txtmodalidade' and semestre = '$selectsemestre'";
 }          
else
{

   $sql =  "update  etapa_liberacao set
            dt_inicio = '$txtdtinicio',
            dt_fim    = '$txtdtfim',
            usuario   = '$cpf',
 	     id_modalidade = '$txtmodalidade',
            semestre   = '$selectsemestre',
            data      = '$data'
            where  id_modalidade = '$txtmodalidade' and id_etapa= '$txtetapa'  and inep= '$inep' and ano= '$ano'";


}



           if(@mysql_query($sql))
              {
  
               if(mysql_affected_rows() == 1)
                   {
                      echo "<html><head><title>Resposta !!!</title></head>";
                      echo "<body background=\"background_mensagens.jpg\" style=\"background-attachment:fixed; background-repeat:no-repeat\">";
                      echo "<br><br><br>";
                      echo "<center><img src=\"faleconosco/atencao.gif\" alt=\"\"><p><font color=\"#FF0000\" face=\"Verdana\" size=\"4\"><blink>Dados Alterados com Sucesso!</blink> <b></b></font></center>";
                      echo "<br><br><center><a href=\"form_liberacao_bim.php\"><img src=\"faleconosco/button_voltar2_.gif\" alt=\"Voltar\" border=\"0\" /></a></center>";
                      echo "</body></html>";
                      exit;
                    }
                 else

                   {
                      echo "<html><head><title>Resposta !!!</title></head>";
                      echo "<body background=\"background_mensagens.jpg\" style=\"background-attachment:fixed; background-repeat:no-repeat\">";
                      echo "<br><br><br>";
                      echo "<center><img src=\"faleconosco/atencao.gif\" alt=\"\"><p><font color=\"#FF0000\" face=\"Verdana\" size=\"4\"><blink>Dados Alterados com Sucesso!</blink> <b></b></font></center>";
                      echo "<br><br><center><a href=\"form_liberacao_bim.php\"><img src=\"faleconosco/button_voltar2_.gif\" alt=\"Voltar\" border=\"0\" /></a></center>";
                      echo "</body></html>";
                      exit;
                    }


                }
               else
                  {
        //verifico se nao estao tentando gravar um dado que ja existe, pois usei UNIQUE na tabela
                   if(mysql_errno() == 1062)
		             {
                       echo $erros[mysql_errno()];
                       exit;
                     }
		            else
		              {
                        echo "Erro nao foi possivel incluir o registro";
                        exit;
                      }
                       @mysql_close();
                    }

}
else
{


$sql = "insert into etapa_liberacao(inep,id_etapa,dt_inicio,dt_fim,ano,usuario,data,id_modalidade,semestre)
values ('$inep','$txtetapa','$txtdtinicio','$txtdtfim','$ano','$cpf','$data','$txtmodalidade','$selectsemestre')";


if(@mysql_query($sql))
{
  if(mysql_affected_rows() == 1)
   {
        echo "<html><head><title>Resposta !!!</title></head>";
        echo "<body background=\"background_mensagens.jpg\" style=\"background-attachment:fixed; background-repeat:no-repeat\">";
        echo "<br><br><br>";
        echo "<center><img src=\"faleconosco/atencao.gif\" alt=\"\"><p><font color=\"#FF0000\" face=\"Verdana\" size=\"4\"><blink>Dados Gravados com Sucesso!</blink> <b></b></font></center>";
        echo "<br><br><center><a href=\"form_liberacao_bim.php\"><img src=\"faleconosco/button_voltar2_.gif\" alt=\"Voltar\" border=\"0\" /></a></center>";
        echo "</body></html>";
        exit;
   }

}
else
   {
        //verifico se nao estao tentando gravar um dado que ja existe, pois usei UNIQUE na tabela
        if(mysql_errno() == 1062)
		  {
                echo $erros[mysql_errno()];
                exit;
          }
		  else
		  {
                echo "Erro nao foi possivel incluir o registro";
                exit;
          }
        @mysql_close();
   }

  }


}//post



?>



