<?php
session_start();
if (isset($_SESSION["login_usuario"]))
  {
     $login     =  $_SESSION["login_usuario"];
     $nte       =  $_SESSION["nivel_usuario"];
	 $inep      =  $_SESSION["inep_usuario"] ;
     $ntelogin  =  $_SESSION["nte_login"];
     $cpf1       = $_SESSION["cpf_usuario"];

	 include ("../../funcoes.php");

  }
 else
  {
    		 header("../../Location: login.php");
  }



/*include ("../../conexao_mysql.php");

if(file_exists("../../conexao_mysql.php"))
{
        require "../../conexao_mysql.php";

} else
{
        echo "Conex�o nao foi encontrado";
        exit;
}

     include ("../funcoes.php");
*/


$id=$_GET["valor"];



 $totalcaracter    = strlen($id);
 $posicao          = strpos($id, '*');
 $turmadiario      = substr($id, 0, $posicao);
 $disciplina       = substr($id, $posicao+1,  $totalcaracter);




 if ($turmadiario=='')
   {
    echo "<html><head><title>Resposta !!!</title></head>";
    echo "<body background=\"background_mensagens.jpg\" style=\"background-attachment:fixed; background-repeat:no-repeat\">";
    echo "<br><br><br>";
    echo "<center><img src=\"faleconosco/atencao.gif\" alt=\"\"><p><font color=\"#FF0000\" face=\"Verdana\" size=\"4\"><blink>Professor informe a turma!</blink> <b></b></font></center>";
    echo "<br><br><center><a href=\"form_lanca_notabim2secret.php\"><img src=\"faleconosco/button_voltar2_.gif\" alt=\"Voltar\" border=\"0\" /></a></center>";
    echo "</body></html>";
    exit;
   }



if ($disciplina=='')
   {
    echo "<html><head><title>Resposta !!!</title></head>";
    echo "<body background=\"background_mensagens.jpg\" style=\"background-attachment:fixed; background-repeat:no-repeat\">";
    echo "<br><br><br>";
    echo "<center><img src=\"faleconosco/atencao.gif\" alt=\"\"><p><font color=\"#FF0000\" face=\"Verdana\" size=\"4\"><blink>Professor informe a disciplina!</blink> <b></b></font></center>";
    echo "<br><br><center><a href=\"form_lanca_notabim2secret.php\"><img src=\"faleconosco/button_voltar2_.gif\" alt=\"Voltar\" border=\"0\" /></a></center>";
    echo "</body></html>";
    exit;
   }




$sql_turma_dependente="select * from  turma where id = '$turmadiario'";
$resultado_turma_dependente=mysql_query($sql_turma_dependente) or die (mysql_error());
$linhas_turma_dependente=mysql_num_rows($resultado_turma_dependente);
if ($linhas_turma_dependente>0)
 {
while($pegar_turma_dependente=mysql_fetch_array($resultado_turma_dependente))
    {
      $turma_dependente       = $pegar_turma_dependente["TURMAS"];
      $id_modalidade_turma       = $pegar_turma_dependente["MODALIDADE"];
    }
 }
/***************Verificar se a turma e modalidade e 1 e 2*******************************************************/



$dia = date('d');
$mes = date('m');
$ano = date('Y');

$data =$ano."-".$mes."-".$dia;


$sql="SELECT ano, situacao FROM ano where situacao = 'A' and inep = '$inep'";
$resultado=mysql_query($sql) or die (mysql_error());
$linhas=mysql_num_rows($resultado);
if ($linhas>0)
 {
    while($pegar=mysql_fetch_array($resultado))
   {
         $txtano       = $pegar["ano"];
   }
 }


/*$sqlgerencia = "select * from  etapa_liberacao where inep  = '$inep'
               and ano= '$txtano'
               and id_etapa = '2'
               and id_modalidade = '$id_modalidade_turma'
               and situacao = 'F'";

$resultadoger=mysql_query($sqlgerencia) or die (mysql_error());
$linhas   =mysql_num_rows($resultadoger);
if($linhas>0)
{

 /************* O lan�amento est� dentro do prazo*****************************/
/*                      echo "<html><head><title>Resposta !!!</title></head>";
                      echo "<body background=\"background_mensagens.jpg\" style=\"background-attachment:fixed; background-repeat:no-repeat\">";
                      echo "<br><br><br>";
                      echo "<center><img src=\"faleconosco/atencao.gif\" alt=\"\"><p><font color=\"#FF0000\" face=\"Verdana\" size=\"4\">
                      <b>Per�odo de lan�amento encerrado.</b></font></center>";
                      echo "</body></html>";
                      exit;
}


$sqlgerencia = "select * from  etapa_liberacao where inep  = '$inep'
               and ano= '$txtano'
               and situacao = 'A'
               and id_modalidade = '$id_modalidade_turma'
               and id_etapa = '2'";
$resultadoger=mysql_query($sqlgerencia) or die (mysql_error());
$linhas   =mysql_num_rows($resultadoger);
if($linhas<=0)
{
    /************* O lan�amento est� dentro do prazo*****************************/
/*                      echo "<html><head><title>Resposta !!!</title></head>";
                      echo "<body background=\"background_mensagens.jpg\" style=\"background-attachment:fixed; background-repeat:no-repeat\">";
                      echo "<br><br><br>";
                      echo "<center><img src=\"faleconosco/atencao.gif\" alt=\"\"><p><font color=\"#FF0000\" face=\"Verdana\" size=\"4\"><b>Per�odo n�o definido para  Lan�amento.</b></font></center>";
                      echo "</body></html>";
                      exit;
}



$sqlgerencia = "select * from  etapa_liberacao where inep  = '$inep'
               and ano= '$txtano'
               and dt_inicio <= '$data'
               and dt_fim    >= '$data'
               and id_modalidade = '$id_modalidade_turma'
               and situacao  = 'A'
               and id_etapa  = '2'";
$resultadoger=mysql_query($sqlgerencia) or die (mysql_error());
$linhas   =mysql_num_rows($resultadoger);
if($linhas>0)
{
    /************* O lan�amento est� dentro do prazo*****************************/

/*}
else
{

                      echo "<html><head><title>Resposta !!!</title></head>";
                      echo "<body background=\"background_mensagens.jpg\" style=\"background-attachment:fixed; background-repeat:no-repeat\">";
                      echo "<br><br><br>";
                      echo "<center><img src=\"faleconosco/atencao.gif\" alt=\"\"><p><font color=\"#FF0000\" face=\"Verdana\" size=\"4\"><b>Lan�amento de nota fora do per�odo.</b></font></center>";
                      echo "</body></html>";
                      exit;


}
*/

























/***************************************************************************************************************/


$sql="select * from  turmaprofessor
where id_turma = '$turmadiario'
and id_disciplina = '$disciplina'
and ano = '$txtano'";
$resultado=mysql_query($sql) or die (mysql_error());
$linhas=mysql_num_rows($resultado);
if ($linhas>0)
 {
while($pegar=mysql_fetch_array($resultado))
    {
      $cpf            = $pegar["cpf"];
      $iddisciplina   = $pegar["id_disciplina"];
      $idprofessor    = $pegar["cpf"];
    }
 }
else
 {
                      echo "<html><head><title>Resposta !!!</title></head>";
                      echo "<body background=\"background_mensagens.jpg\" style=\"background-attachment:fixed; background-repeat:no-repeat\">";
                      echo "<br><br><br>";
                      echo "<center><img src=\"faleconosco/atencao.gif\" alt=\"\"><p><font color=\"#FF0000\" face=\"Verdana\" size=\"4\"><b>N�o Existe Professor associado a disciplina.</b></font></center>";
                      echo "</body></html>";
                      exit;


 }

  $id_turma =  $turmadiario;









  $sql="select * from habilitacao where codigo = '$disciplina'";
  $resultado=mysql_query($sql) or die (mysql_error());
  $linhas=mysql_num_rows($resultado);
  if($linhas>0)
 {
while($pegar=mysql_fetch_array($resultado))
    {
      $descdisciplina      = $pegar["descricao"];
    }
 }







/*************************************************/


if(!empty($_GET["valor"]))
 {
if (($turma_dependente=='75') || ($turma_dependente=='76') || ($turma_dependente=='77') || ($turma_dependente=='78')
     || ($turma_dependente=='79') || ($turma_dependente=='100') || ($turma_dependente=='101'))
  {

   $sql="select a.id as idaluno,ta.n_chamada as chamada,ta.situacao,t.id,a.nome
   from turma_aluno ta,turma t, aluno a,turma_dep_aluno_disciplina dp
   where ta.id_aluno=a.id and t.id =ta.id_turma and t.id = '$id_turma' and ta.inep='$inep'
   and dp.id_turma = t.id and dp.id_disciplina = '$disciplina'
   and dp.id_aluno = ta.id_aluno
   order by ta.n_chamada";
  }
else
  {
    $sql="select a.id as idaluno,ta.n_chamada as chamada,ta.situacao,t.id,a.nome
    from turma_aluno ta,turma t, aluno a  where ta.id_aluno=a.id and t.id =ta.id_turma and t.id = '$id_turma' and ta.inep='$inep'
      order by ta.n_chamada";
   }





$resultado=mysql_query($sql) or die (mysql_error());
$linhas=mysql_num_rows($resultado);

if($linhas>0)
 {
?>
<html>
<head>
 <script language="javascript" src="generic_notabim.js"></script>
</head>
<body>
<br>
<form name="form" action="inclui_nota3bimsecretaria.php" method="post">
 	   <p>
		 <br>Disciplina -><font size="4" color="#FF0000" style="width:300px"><?echo $descdisciplina;?></font>
 	   </p>

<table border="0" width="100%" id="tabzebra">
<tr>
  <td width="20"><b>Turma</b>
   <td><b>N</b>
  <td><b>Nome</b>
  <td><b>Nota</b></td>
  <td><b>Falta</b></td>
  <td><b>Situacao</b></td>

      <input type="hidden"  id="txtturmadiario" name="txtturmadiario"  value = "<?echo $turmadiario;?>"  style="width:35px" maxlength="5"   onKeyPress="return Enum(event)" readonly="true"/></td>
      <input type="hidden"  id="txtdisciplina" name="txtdisciplina"  value = "<?echo $disciplina;?>"  style="width:35px" maxlength="5"   onKeyPress="return Enum(event)" readonly="true"/></td>
      <input type="hidden"  id="txtprofessor" name="txtprofessor"  value = "<?echo $idprofessor;?>"  style="width:35px" maxlength="5"   onKeyPress="return Enum(event)" readonly="true"/></td>
      <input type="hidden"  id="txtturmaprofessor" name="txtturmaprofessor"  value = "<?echo $id_turma;?>"  style="width:35px" maxlength="5"   onKeyPress="return Enum(event)" readonly="true"/></td>


</tr>
<?
while($pegar=mysql_fetch_array($resultado))
{

?> 


<tr>
      <td><font size="2"> <?echo $pegar["id"];?>
      <input type="hidden"  id="txtidaluno" name="txtidaluno[]"  value = "<?echo $pegar["idaluno"];?>"  style="width:35px" maxlength="5"   onKeyPress="return Enum(event)" readonly="true"/></td>
      <td><font> <?echo $pegar["chamada"];?> </td>
      <td><font> <?echo $pegar["nome"];?> </td>
<?
if (($pegar["situacao"]=='1') || ($pegar["situacao"]=='8'))
{
?>
  	  <td><input type="text"  name="txtnota[]" style="width:25px" maxlength="3" value="0"  id="txtnota"    onkeyup="ValidaValor(this, 10);"  onBlur="validacampo(this, 0);"   onKeyPress="return Enum(event)"></td>
   	  <td><input type="text"  name="txtfalta[]" style="width:25px" maxlength="3" value="0" id="txtfalta"     onKeyPress="return Enum(event)"></td>
      <td><font> <?echo $pegar["situacao"];?> </td>
  </tr>
<?
}
else
{
?>
  	  <td><input type="text"  name="txtnota[]" style="width:25px" maxlength="3" value="0"  id="txtnota"    onkeyup="ValidaValor(this, 10);"  onBlur="validacampo(this, 0);"   onKeyPress="return Enum(event)" readonly="true"></td>
   	  <td><input type="text"  name="txtfalta[]" style="width:25px" maxlength="3" value="0" id="txtfalta"     onKeyPress="return Enum(event)" readonly="true"></td>
      <td><font> <?echo $pegar["situacao"];?> </td>
  </tr>

<?
    }//if
   }
 }
}








if (($turma_dependente=='75') || ($turma_dependente=='76') || ($turma_dependente=='77') || ($turma_dependente=='78')
     || ($turma_dependente=='79'))
  {

   $sql="select count(*) as total
   from turma_aluno ta,turma t, aluno a,turma_dep_aluno_disciplina dp
   where ta.id_aluno=a.id and t.id =ta.id_turma and t.id = '$id_turma' and ta.inep='$inep'
   and dp.id_turma = t.id and dp.id_disciplina = '$disciplina'
   and dp.id_aluno = ta.id_aluno
   order by ta.n_chamada";
  }
else
  {
    $sql="select count(*) as total
    from turma_aluno ta,turma t, aluno a  where ta.id_aluno=a.id and t.id =ta.id_turma and t.id = '$id_turma' and ta.inep='$inep'
      order by ta.n_chamada";
   }




// $sql = "select count(*) as total from turma_aluno ta,turma t, aluno a  where ta.id_aluno=a.id and t.id =ta.id_turma and t.id = '$id_turma' and ta.inep='$inep' order by ta.n_chamada";
 
 $resultado=mysql_query($sql) or die (mysql_error());
 $linhas=mysql_num_rows($resultado);
 while($pegar=mysql_fetch_array($resultado))
{
     $total = $pegar["total"];
}//while
if ($total>0)
  {
?>
<tr><td>Total</td>
   	  <td><font size="2"> <?echo $total;?> </td>
  </tr>

  <tr><td></td>
     <td><input type="submit" value="Registrar" class="btn btn-primary" onClick="return confirm('Confirma o processo ?')"/></td>

 


  </tr>



<?
}
else
{
?>

<tr><td>Total</td>
   	  <td><font size="2"> <?echo $total;?> </td>
  </tr>

<br>
<br>
<tr>
<td align="center" bgcolor="#CCCCCC"><strong><font color="#FF0000" size="1" face="Verdana, Arial, Helvetica, sans-serif">
</tr>

<?
 }



?>

</table>
  <script>
   cor_tabela("tabzebra");
 </script>
</body>
</html>
