<?php
session_start();
if (isset($_SESSION["login_usuario"]))
  {
     $login     =  $_SESSION["login_usuario"];
     $nte       =  $_SESSION["nivel_usuario"];
	 $inep      =  $_SESSION["inep_usuario"] ;
     $ntelogin  =  $_SESSION["nte_login"];
     $cpf1       = $_SESSION["cpf_usuario"];

	 include ("../../funcoes.php");

  }
 else
  {
    		 header("../../Location: login.php");
  }


$dia = date('d');
$mes = date('m');
$ano = date('Y');
$data =$dia.".".$mes.".".$ano;


$txtturma=$_GET["codigo"];

if(!empty($_GET["codigo"]))
 {



$sqlgerencia = "select e.inep,e.descricao as descescola,e.fone,e.regularizada, e.endereco,e.bairro,e.numero,m.descricao as descmuni from escola e , municipio m  where inep ='$inep' and e.municipio = m.codigo";
$resultadoger=mysql_query($sqlgerencia) or die (mysql_error());
$linhas   =mysql_num_rows($resultadoger);
if($linhas>0)
{
   while($pegar=mysql_fetch_array($resultadoger))
	{

    	$descescola    =$pegar["descescola"];
    	$descmunici    =$pegar["descmuni"];

    	$endereco      =$pegar["endereco"];
    	$bairro        =$pegar["bairro"];
    	$numero        =$pegar["numero"];

    	$fone         =$pegar["fone"];
    	$regularizada        =$pegar["regularizada"];



    }
 }







$sqlaluno="select * from turma  where id = '$txtturma'";
$resultadoaluno=mysql_query($sqlaluno) or die (mysql_error());
$linhasaluno=mysql_num_rows($resultadoaluno);
if ($linhasaluno>0)
 {
while($pegaraluno=mysql_fetch_array($resultadoaluno))
    {
      $turmadesc       = $pegaraluno["DESCRICAO"];
	}
 }



/* Filtrando turma e escola*/

 $sql="select ta.id,a.nome,ta.situacao,ta.n_chamada,ta.id_aluno,t.descricao,ta.id_turma
       from aluno a,turma_aluno ta,turma t
       where  t.inep = '$inep'
	   and    ta.id_aluno = a.id
	   and    ta.id_turma = t.id
	   and    t.id = '$txtturma'
       order by ta.n_chamada, ta.n_chamada";

/*

 $sql="select ta.id,a.nome,ta.situacao,ta.n_chamada,ta.id_aluno,t.descricao,ta.id_turma
       from aluno a,turma_aluno ta,turma t, habilitacao h
       where  t.inep = '$inep'
	   and    ta.id_aluno = a.id
	   and    ta.id_turma = t.id
	   and    t.id = '$txtturma'
       and    h.codigo = ta.id_disciplina

       order by ta.n_chamada, ta.n_chamada";
*/


$resultado=mysql_query($sql) or die (mysql_error());
$linhas=mysql_num_rows($resultado);
if($linhas>0)
 {

?>


<html>
<head>

<title>:: DIARIO ELETRONCIO ::</title>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1">
<link href="../biblioteca/menu/menu.css" rel="stylesheet" type="text/css">
<script language="JavaScript" src="../biblioteca/menu/JSCookMenu.js" type="text/javascript"></script>
<script language="JavaScript" src="../biblioteca/menu/theme.js" type="text/javascript"></script>
<link rel="stylesheet" type="text/css" href="../biblioteca/padraoestilo.css">

<script type="text/javascript" src="../biblioteca/sortabletable.js"></script>
<link type="text/css" rel="StyleSheet" href="../biblioteca/sortabletable.css" />
</head>

<style>
.titulopagina
{
    font-size: 11px;
    color:    #000099;
	background-color:#E8E8E8;
	height:25px;
    font-family: verdana , arial
}

table.bordasimples {border-collapse: collapse;}

table.bordasimples tr td {border:1px solid #CCCCCC;}

.subtitulo
{
	font-family: verdana ;
	font-size: 10pt;
    color: #22408f;
	font-weight: bold;
}

.nomecampo
{
    font-size: 10px;
    color: midnightblue;
    font-family: verdana, arial;
	font-weight: bold;
}
.escrita
{
    font-size: 10px;
    color: #000000;
    font-family: verdana, arial
}
.escritanormal
{
    font-size: 9px;
    color: #000000;
    font-family: verdana, arial;
	font-weight: normal;
}



</style>
<script language="javascript">
function DoPrinting() {
    if (!window.print) {
        alert("Netscape, Internet Explorer 4.0 ou superior!")
        return
    }
    window.print();
}
</script>

</head>
<table width="100%">
<tr>


      <td class="nomecampo" align="center"><b><img src= "../img/brasao.jpg" /></b></td>


</tr>
<tr>
<td>







<table border="0"  class="bordasimples" cellspacing="0"  align="center" width="100%" bgcolor=#ffffff>

<tr>
	<td colspan="6"  bgcolor="#EAEAEA"  class="subtitulo" align="center"><b>GOVERNO DO ESTADO DE ROND�NIA</b></td>
</tr>

<tr>
	<td colspan="6"  bgcolor="#EAEAEA"  class="subtitulo" align="center"><b>SECRETARIA DE ESTADO DA EDUCA��O</b></td>
</tr>

<tr>
	<td colspan="6"  bgcolor="#EAEAEA"  class="subtitulo" align="center"><b>GER�NCIA DE TECNOLOGIA DA INFORMA��O</b></td>
</tr>


<tr>
	<td colspan="6"  bgcolor="#EAEAEA"  class="subtitulo" align="center"><b>Dados da Escola</b></td>
</tr>
<tr>
	<td class="nomecampo"><b>C�digo INEP:</b></td>
	<td>&nbsp;<?echo $inep;?></td>
	<td class="nomecampo"><b>Raz�o Social:</b></td>
	<td class = "escrita">&nbsp;<?echo $descescola;?></td>
	<td class="nomecampo"><b>Zona:</b></td>
	<td>&nbsp;Urbana</td>

</tr>



<tr>
	<td class="nomecampo"><b>Endere�o:</b></td>
	<td class = "escrita">&nbsp;<?echo $endereco;?></td>
	<td class="nomecampo"><b>N�:</b></td>
	<td>&nbsp;<?echo $numero;?></td>
	<td class="nomecampo"><b>Bairro</b></td>
	<td class = "escrita">&nbsp;<?echo $bairro;?></td>

</tr>
<tr>
	<td class="nomecampo"><b>UF:</b></td>
    <td>&nbsp;RO</td>
	<td class="nomecampo"><b>Munic�pio:</b></td>
	<td class = "escrita">&nbsp;<?echo $descmunici;?></td>
	<td class="nomecampo"><b>Regularizada:</b></td>
	<td>&nbsp;<?echo $regularizada;?></td>

  </tr>

 <tr>

	<td class="nomecampo"><b>Telefone:</b></td>
	<td>&nbsp;<?echo $fone;?></td>
	<td class="nomecampo"><b>Dep. administrativa:</b></td>
	<td colspan="3">&nbsp;Estadual</td>
</tr>

</table>



<table width="100%">
<tr>
<td>&nbsp;  </td>
</tr>
<tr>
<td>
<table border="0"  class="bordasimples" cellspacing="0"  align="center" width="100%" bgcolor=#ffffff>

<tr>
	<td colspan="6"  bgcolor="#EAEAEA"  class="subtitulo" align="center"><b>Quadro Demonstrativo 1� Bim</b></td>
</tr>


<tr>
	<td class="nomecampo"><b>Turma</b></td>
	<td class = "escrita">&nbsp;<?echo $turmadesc;?></td>
</tr>




</table>



<table width="100%">
<tr>
<td>&nbsp;  </td>
</tr>

<table border="0" class="bordasimples"  cellspacing="0"  align="center" width="100%" bgcolor=#ffffff>

<tr>
 <td class="nomecampo"><b>N�</b></td>
 <td colspan="3" class="nomecampo"><b>Nome</b></td>
 <td class="nomecampo"><b>Situa��o</b></td>
 <?

$sqldisc="select codigo
       from turma t,nota_aluno n, habilitacao h
       where      t.inep = '$inep'
	   and        t.id='$txtturma'
	   and        h.codigo = n.id_disciplina
	   and        n.id_turma=t.id
       GROUP BY codigo
       order      by h.codigo";



//***********************************Cabecalho******************************//
$resultadodisc=mysql_query($sqldisc) or die (mysql_error());
$linhassoma=mysql_num_rows($resultadodisc);
while($pegardisc=mysql_fetch_array($resultadodisc))
{
   $disciplina  =  $pegardisc["codigo"];
   $aluno       =  $pegardisc["id_aluno"];


// $sqldisciplina = ("select sigla from  habilitacao h, nota_aluno n where h.codigo = '$disciplina' and  n.id_disciplina = h.codigo");

   $sqldisciplina = ("select sigla from  habilitacao where codigo = '$disciplina'");
   $respostadisc = mysql_query($sqldisciplina) or die(mysql_error());
   while ($dado = mysql_fetch_array($respostadisc))
    {
     $vetor_disc = $dado["sigla"];

?>

        <td class = "escrita" align="center">&nbsp;<?echo $dado["sigla"];?></td>
     	<td class = "escrita" align="center">&nbsp;<?echo "FTA";?></td>


<?
   }//while externo
}



while($pegar=mysql_fetch_array($resultado))
{


 $aluno     = $pegar["id_aluno"];
 $situacao  = $pegar["situacao"];

$sqlsitua="select * from tipo_mov_aluno  where id = '$situacao'";
$resultadositua=mysql_query($sqlsitua) or die (mysql_error());
$linhassitua=mysql_num_rows($resultadositua);
if ($linhassitua>0)
 {
while($pegarsitua=mysql_fetch_array($resultadositua))
    {
      $situadesc       = $pegarsitua["descricao"];
	}
 }


?>


<tr>
    	<td class = "escrita">&nbsp;<?echo $pegar["n_chamada"];?></td>
    	<td colspan="3" class = "escritanormal">&nbsp;<?echo $pegar["nome"];?></td>
     	<td class = "escrita">&nbsp;<?echo $situadesc;?></td>

<?
// ********************************lancamento de nota********************************


 $sqlnota="select n.id_aluno,nota1,recuperacao1,t_falta1,h.codigo
       from   turma t,nota_aluno n, habilitacao h
       where  t.inep = '$inep'
	   and    t.id=    '$txtturma'
       and    n.id_aluno = '$aluno'
       and    h.codigo = n.id_disciplina
	   and    n.id_turma=t.id
       order by  h.codigo";
$resultadonota=mysql_query($sqlnota) or die (mysql_error());
$linhasnota=mysql_num_rows($resultadonota);
if($linhasnota>0)
{
/*variavel criada para permitir que nao repitar no */

$alunolaco="";

while($pegarnota=mysql_fetch_array($resultadonota))
 {


$sqlcontalinha = ("SELECT codigo
FROM habilitacao h, nota_aluno n
WHERE n.id_disciplina = h.codigo
AND n.inep = '$inep'
AND n.id_turma = '$txtturma'
GROUP BY codigo");
$resultadolinha=mysql_query($sqlcontalinha) or die (mysql_error());
$linhasdisc   =mysql_num_rows($resultadolinha);
/*$linhasdisc foi criada para contar quantas disciplina ja existe associada com a turma x aluno*/

//  echo "aluno $aluno";
//  echo "alunopassuo $alunolaco";
  if (($linhasdisc > 0) && ($alunolaco!=$aluno))
     {

  $alunolaco =$aluno;


  $disciplina  = $pegarnota["codigo"];
  $nota1bim    = $pegarnota["nota1"];
  $fal1bim     = $pegarnota["t_falta1"];
  $rec1bim     = $pegarnota["recuperacao1"];

   $disc_notaaluno    = $pegarnota["codigo"];


  if  ($nota1bim > $rec1bim)
     {
       $notaconsiderada =$nota1bim;
     }
   else
     {
       $notaconsiderada =$rec1bim;
     }




$sqldisciplina = ("SELECT codigo
FROM habilitacao h, nota_aluno n
WHERE n.id_disciplina = h.codigo
AND n.inep = '$inep'
AND n.id_turma = '$txtturma'
GROUP BY codigo");
   $respostadisc = mysql_query($sqldisciplina) or die(mysql_error());
   while ($dado = mysql_fetch_array($respostadisc))
     {
        $cod_disc = $dado["codigo"];

       if ($disc_notaaluno==$cod_disc)
        {
  ?>
        <td class = "escrita"  align="center" >&nbsp;<?echo number_format($notaconsiderada, 1, ',', '.'); ?></td>
    	<td class = "escrita"  align="center">&nbsp;<?echo $pegarnota["t_falta1"];?></td>
 <?
        }
   else
       {
      ?>
        <td class = "escrita"  align="center" ></td>
    	<td class = "escrita"  align="center"></td>
      <?
       }

        //echo "linha $linhasdisc - $aluno";
        $linhasdisc=$linhasdisc-1;

    //   }
      }//while interno disciplina
    }
   }
  } //if
?>
  </tr>
<?


   }//alunos





}
 }




 $sql = "select count(*) as total           from aluno a,turma_aluno ta,turma t
       where  t.inep = '$inep'
	   and    ta.id_aluno=a.id
	   and    ta.id_turma=t.id
	   and    t.id= '$txtturma'
       order by ta.n_chamada, ta.n_chamada";

 $resultado=mysql_query($sql) or die (mysql_error());
 $linhas=mysql_num_rows($resultado);
 while($pegar=mysql_fetch_array($resultado))
{
     $total = $pegar["total"];

}//while


if ($total>0)
  {
?>


<?
}
else
{
?>



<?
 }
?>
</table>

<table width="100%">
<tr>
<td>&nbsp;  </td>
</tr>
<tr>
<td>
<table border="0"  class="bordasimples" cellspacing="0"  align="center" width="100%" bgcolor=#ffffff>

<tr>
	<td colspan="6"  bgcolor="#EAEAEA"  class="subtitulo" align="center"><b>Assinatura</b></td>
</tr>
<tr>
	<td class="nomecampo"><b>Professor</b></td>
	<td>&nbsp;</td>
	<td class="nomecampo"><b>Supervis�o</b></td>
	<td>&nbsp;</td>
</tr>
</table>


<table width="100%">
<tr>
<td>&nbsp;  </td>
</tr>
<tr>
<td>
<table border="0"  class="bordasimples" cellspacing="0"  align="center" width="100%" bgcolor=#ffffff>
<tr>
	<td class="nomecampo"><b><img src= "../../imagem/impressora.jpg" onClick="DoPrinting()" title = "Click para imprimir - formul�rio em modo paissagem."/></b></td>
</tr>
</table>




