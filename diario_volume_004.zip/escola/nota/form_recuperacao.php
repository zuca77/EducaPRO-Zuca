<?php
require_once __DIR__.'/../../start.php';
$pdo = new Conexao;

Auth::blackList(array('PROF', 'NAM', 'BF'));

$title = "Lan�amento de Recupera��o";

if($txtano >=2017)
{
	$turmasDependencia = Turma::$turmasRetencaoParcial;
}
else {
	$turmasDependencia = Turma::$turmasDependencia;
}

$turmasMediacaoTecnologica = Turma::$turmasMediacaoTecnologica;

$cargaHorariaAvaliacao = GradeCurricular::CARGA_HORARIA_AVALICACAO;

$disciplinas = array();

$sql = "SELECT id, descricao, fechado
				FROM turma
				WHERE inep = '{$inep}' AND ano = '{$txtano}'
				ORDER BY fechado ASC, descricao";

$turmas = $pdo->query($sql);

if(isset($_GET['id_turma']) && !empty($_GET['id_turma']))
{
	$turma = Turma::get($_GET['id_turma']);
	if (isset($turma)) {
		$disciplinas = Turma::getDisciplinasGrade($inep, $turma['id']);
		$turmaEja = Turma::modalidadeEja($turma['id']);
	}
}

if(isset($_GET['id_disciplina']) && !empty($_GET['id_disciplina']))
{
	$sql = "SELECT codigo as id, descricao FROM habilitacao WHERE codigo = :id;";
	$sth = $pdo->prepare($sql);
	$sth->bindParam(':id', $_GET['id_disciplina']);
	$disciplina = $sth->execute() ? $sth->fetch() : null;
} 

if(isset($disciplina) && isset($turma))
{
	$id_turma = $_GET['id_turma'];
	$id_disciplina = $_GET['id_disciplina'];
	$turmaMediacaoTecnologica = Turma::modalidadeMediacaoTecnologia($turma);

	$sql = "SELECT cpf FROM turmaprofessor
			WHERE id_turma = :id_turma
			AND id_disciplina = :id_disciplina
			AND ano = :ano";
	$sth = $pdo->prepare($sql);
	$sth->bindParam(':id_turma', $id_turma);
	$sth->bindParam(':id_disciplina', $id_disciplina);
	$sth->bindParam(':ano', $txtano);

	$turmaprofessor = $sth->execute() ? $sth->fetch() : null;

	if (in_array($turma['turmas'], $turmasDependencia) || $turmaMediacaoTecnologica) {
		$sql = "SELECT a.id AS id_aluno,ta.n_chamada AS chamada,ta.situacao,t.id,a.nome, sa.descricao AS situacaodesc
				FROM turma_aluno ta,turma t, aluno a,turma_dep_aluno_disciplina dp, tipo_mov_aluno sa
				WHERE ta.id_aluno = a.id
				AND t.inep = '{$inep}'
				AND t.ano = '{$txtano}'
				AND t.id = :id_turma
				AND t.id = ta.id_turma
				AND dp.id_disciplina = :id_disciplina
				AND dp.id_turma = t.id
				AND dp.id_aluno = ta.id_aluno
				AND sa.id = ta.situacao
				ORDER BY ta.n_chamada";
		$sth = $pdo->prepare($sql);
		$sth->bindParam(':id_turma', $id_turma);
		$sth->bindParam(':id_disciplina', $id_disciplina);
	} else {
		$sql = "SELECT a.id AS id_aluno,ta.n_chamada AS chamada,ta.situacao,t.id,a.nome, sa.descricao AS situacaodesc
				FROM turma_aluno ta,turma t, aluno a, tipo_mov_aluno sa
				WHERE ta.id_aluno=a.id
				AND t.inep = '{$inep}'
				AND t.ano = '{$txtano}'
				AND t.id = :id_turma
				AND t.id = ta.id_turma
				AND sa.id = ta.situacao
				ORDER BY ta.n_chamada";
		$sth = $pdo->prepare($sql);
		$sth->bindParam(':id_turma', $id_turma);
	}

	$alunos = $sth->execute() ? $sth->fetchAll() : array();
	$turmaEja = Turma::modalidadeEja($id_turma);
	$tipoRecuperacao = Escola::tipoRecuperacao($inep, $txtano, $turma['modalidade']);
	$adereExameFinal = Escola::adereExameFinal($inep, $txtano, $turma['modalidade']);

	$cargaDisciplina = GradeCurricular::cargaDisciplina($_GET['id_turma'], $_GET['id_disciplina']);
}

$bloqueios = array();

?><!DOCTYPE html>
<html>
	<head>
		<?php require_once page_head(); ?>
		<style>tr.row-nota input { width: 60px !important; }</style>
	</head>
	<body>
		<?php require_once page_header(); ?>

		<div class="container">
			<form class="well well-sm" method="get">
				<div class="row">
					<div class="col-md-8">
						<div class="form-group">
							<label for="id_turma">Turma</label>
							<select name="id_turma" id="id_turma" class="form-control chosen" required onchange="this.form.submit()">
								<option value=""></option>
								<?php foreach ($turmas as $t): ?>
									<option value="<?php echo $t['id'] ?>" <?php echo (isset($_GET['id_turma']) && $t['id']==$_GET['id_turma']) ? 'selected' : '' ?>>
										<?php echo $t['descricao'] ?>
										<?php echo $t['fechado'] == 'S' ? '(FECHADA)' : '(ABERTA)' ?>
									</option>
								<?php endforeach ?>
							</select>
						</div>
					</div>
					<div class="col-md-4">
						<div class="form-group">
							<label for="id_disciplina">Disciplina</label>
							<select name="id_disciplina" id="id_disciplina" class="form-control chosen" onchange="this.form.submit()">
								<option value=""></option>
								<?php foreach ($disciplinas as $d): ?>
									<option value="<?php echo $d['id'] ?>" <?php echo (isset($_GET['id_disciplina']) && $d['id']==$_GET['id_disciplina']) ? 'selected' : '' ?>>
										<?php echo $d['descricao'] ?>
									</option>
								<?php endforeach ?>
							</select>
						</div>
					</div>
				</div>

				<p id="finish">
					<input type="submit" class="btn btn-primary"  value="PESQUISAR">
					<button class="btn btn-default btn-back pull-right">Voltar</button>
				</p>
			</form>

			<?php if (isset($alunos) && $turmaMediacaoTecnologica && sizeof($alunos) == 0): ?>
				<div class="alert alert-info">
					N�o h� nenhum estudante associado a esta disciplina desta turma.
					<a class="alert-link" href="<?php url("escola/turmamanutencao/form_turma_mediacao_tecnologica.php?id_turma={$turma['id']}") ?>">ASSOCIAR DISCIPLINAS AOS ESTUDANTES</a>
				</div>
			<?php elseif (isset($alunos) && sizeof($alunos) == 0): ?>
				<div class="alert alert-info">
					N�o h� nenhum estudante associado a esta turma.
				</div>
			<?php else: ?>

			<?php if(isset($disciplina) && isset($turma)): ?>
			<hr>
			<form class="form-inline submit-wait" action="altera_recuperacao.php" method="post">
				<div class="">
					<table class="table table-bordered table-striped">
						<tr>
							<th width="20">Turma</th>
							<td><b class="text-primary"><?php echo $turma['descricao'] ?></b></td>
							<th width="20">Disciplina</th>
							<td><b class="text-danger"><?php echo $disciplina['descricao']; ?></b></td>
							<td width="10">
								<a href="<?php url('escola/nota/form_recuperacao.php') ?>" class="btn btn-xs btn-default pull-right">x</a>
							</td>
						</tr>
						<?php if (isset($cargaDisciplina)): ?>
						<tr>
							<td colspan="2"></td>
							<th class="text-right" title="Carga hor�ria">C.H.</th>
							<td colspan="2"><b class="text-warning"><?php echo $cargaDisciplina ?></b></td>
						</tr>
						<?php endif ?>
					</table>
				</div>

				<input type="hidden" name="id_turma" value="<?php echo $turma['id']; ?>">
				<input type="hidden" name="id_disciplina" value="<?php echo $disciplina['id']; ?>">
				<input type="hidden" name="professor" value="<?php echo $turmaprofessor['cpf']; ?>">

				<div class="table-responsive">
					<table class="table table-bordered table-condensed table-hover table-striped">
						<thead>
 							<?php if ($tipoRecuperacao == TipoRecuperacao::BIMESTRAL || $tipoRecuperacao == TipoRecuperacao::SEMESTRAL): ?>
							<tr>
								<th colspan="2"></th>
								<?php if ($tipoRecuperacao == TipoRecuperacao::BIMESTRAL): ?>
									<th width="145" class="text-center">1&deg; Bimestre</th>
									<th width="145" class="text-center">2&deg; Bimestre</th>
									<?php if (!$turmaEja): ?>
									<th width="145" class="text-center">3&deg; Bimestre</th>
									<th width="145" class="text-center">4&deg; Bimestre</th>
									<?php endif ?>
								<?php endif ?>
								<?php if($tipoRecuperacao == TipoRecuperacao::SEMESTRAL): ?>
									<th width="145" class="text-center">1&deg; Semestre</th>
									<?php if (!$turmaEja): ?>
										<th width="145" class="text-center">2&deg; Semestre</th>
									<?php endif ?>
								<?php endif ?>
								<?php if ($adereExameFinal): ?>
									<th width="140" class="text-center">Etapa Final</th>
								<?php endif ?>
								<th></th>
								<th></th>
							</tr>
							<?php endif ?>

							<tr>
								<th width="20" class="text-center">N&deg;</th>
								<th>Nome do estudante</th>
								<?php if ($tipoRecuperacao == TipoRecuperacao::BIMESTRAL): ?>
									<th class="text-center">Recupera��o/Faltas</th>
									<th class="text-center">Recupera��o/Faltas</th>
									<?php if (!$turmaEja): ?>
										<th class="text-center">Recupera��o/Faltas</th>
										<th class="text-center">Recupera��o/Faltas</th>
									<?php endif ?>
								<?php elseif($tipoRecuperacao == TipoRecuperacao::SEMESTRAL): ?>
									<th class="text-center">Recupera��o/Faltas</th>
									<?php if (!$turmaEja): ?>
										<th class="text-center">Recupera��o/Faltas</th>
									<?php endif ?>
								<?php elseif($tipoRecuperacao == TipoRecuperacao::ANUAL): ?>
									<th width="200" class="text-center">Recupera��o Anual/Faltas</th>
								<?php elseif($tipoRecuperacao == TipoRecuperacao::PARALELA): ?>
									<th width="170" class="text-center">Recupera��o I / Faltas</th>
									<th width="170" class="text-center">Recupera��o II / Faltas</th>
									<th width="170" class="text-center">Recupera��o III / Faltas</th>
								<?php endif ?>
								<?php if ($adereExameFinal): ?>
									<th width="100" class="text-center">Exame Final</th>
								<?php endif ?>
								<th width="160">Situa&ccedil;&atilde;o</th>
								<th width="40"></th>
							</tr>
						</thead>
						<tbody>
							<?php foreach($alunos as $aluno):
								$id_aluno = $aluno['id_aluno'];
								$nota = Nota::get($id_turma, $id_disciplina, $id_aluno, null, false);
								$bloqueado = in_array($aluno["situacao"], $bloqueios);
								$disable = $bloqueado ? "disabled" : "";
							?>
							<tr class="row-nota <?php echo $aluno['situacao'] != SituacaoAluno::MATRICULADO ? 'warning' : '' ?>">
								<td class="text-center">
									<input type="hidden" name="id_aluno[]" value="<?php echo $id_aluno; ?>" <?php echo $disable; ?>>
									<?php echo $aluno["chamada"]; ?>
								</td>
								<td><?php echo $aluno["nome"]; ?></td>
								<?php if (isset($nota['eliminacao_componente']) && $nota['eliminacao_componente']): ?>
								<?php $colSize = $turmaEja ? 2 : 2; if($adereExameFinal) $colSize++; if($turmaMediacaoTecnologica) $colSize = 3; ?>
								<td colspan="<?php echo $colSize ?>" class="text-center">
									<span class="text-info">
										<i class="fa fa-info-circle"></i>
										<?php echo $nota['componente_eliminado'] ?>
									</span>
								</td>
								<?php else: ?>

									<?php if ($tipoRecuperacao == TipoRecuperacao::BIMESTRAL): ?>
										<?php for ($i=1; $i <= ($turmaEja ? 2 : 4); $i++): ?>
											<td>
												<div class="input-group">
													<input type="text" name="<?php echo "recuperacao".$i."[{$id_aluno}]"; ?>" class="mask-nota form-control input-sm" maxlength="4" value="<?php echo $nota['recuperacao'.$i] ?>" <?php echo $disable; ?>>
													<span class="input-group-btn" style="width:0px;"></span>
													<input type="number" name="<?php echo "falta".$i."[{$id_aluno}]"; ?>" class="form-control input-sm" value="<?php echo !empty($nota['t_falta_rec'.$i]) ? $nota['t_falta_rec'.$i] : '' ?>" onkeypress="return Enum(event)" <?php echo $disable; ?>>
												</div>
											</td>
										<?php endfor; ?>
									<?php endif ?>

									<?php if ($tipoRecuperacao == TipoRecuperacao::SEMESTRAL): ?>
										<?php for ($i=1; $i <= ($turmaEja ? 1 : 2); $i++): ?>
											<td>
												<div class="input-group">
													<input type="text" name="<?php echo "recuperacao".$i."[{$id_aluno}]"; ?>" class="mask-nota form-control input-sm" maxlength="4" value="<?php echo $nota['recuperacao'.$i] ?>" <?php echo $disable; ?>>
													<span class="input-group-btn" style="width:0px;"></span>
													<input type="number" name="<?php echo "falta".$i."[{$id_aluno}]"; ?>" class="form-control input-sm" value="<?php echo $nota['t_falta_rec'.$i] ?>" onkeypress="return Enum(event)" <?php echo $disable; ?>>
												</div>
											</td>
										<?php endfor; ?>
									<?php endif ?>

									<?php if ($tipoRecuperacao == TipoRecuperacao::ANUAL): ?>
										<td>
											<div class="input-group">
												<input type="text" name="<?php echo "recuperacao1[{$id_aluno}]"; ?>" class="mask-nota form-control input-sm" maxlength="4" value="<?php echo $nota['recuperacao1'] ?>" <?php echo $disable; ?>>
												<span class="input-group-btn" style="width:0px;"></span>
												<input type="number" name="<?php echo "falta1[{$id_aluno}]"; ?>" class="form-control input-sm" value="<?php echo !empty($nota['t_falta_rec1']) ? $nota['t_falta_rec1'] : '' ?>" onkeypress="return Enum(event)" <?php echo $disable; ?>>
											</div>
										</td>
									<?php endif ?>

									<?php if ($tipoRecuperacao == TipoRecuperacao::PARALELA): ?>
										<?php for ($i=1; $i <= 3; $i++): ?>
											<td>
												<div class="input-group">
													<?php if ($i == 3 && $cargaDisciplina <= $cargaHorariaAvaliacao): ?>
														<input type="text" name="<?php echo "recuperacao".$i."[{$id_aluno}]"; ?>" class="mask-nota form-control input-sm" maxlength="4" value="<?php echo $nota['recuperacao'.$i] ?>" readonly>
														<span class="input-group-btn" style="width:0px;"></span>
														<input type="number" name="<?php echo "falta".$i."[{$id_aluno}]"; ?>" class="form-control input-sm" value="<?php echo !empty($nota['t_falta_rec'.$i]) ? $nota['t_falta_rec'.$i] : '' ?>" readonly>
													<?php else: ?>
														<input type="text" name="<?php echo "recuperacao".$i."[{$id_aluno}]"; ?>" class="mask-nota form-control input-sm" maxlength="4" value="<?php echo $nota['recuperacao'.$i] ?>" <?php echo $disable; ?>>
														<span class="input-group-btn" style="width:0px;"></span>
														<input type="number" name="<?php echo "falta".$i."[{$id_aluno}]"; ?>" class="form-control input-sm" value="<?php echo !empty($nota['t_falta_rec'.$i]) ? $nota['t_falta_rec'.$i] : '' ?>" onkeypress="return Enum(event)" <?php echo $disable; ?>>
													<?php endif ?>
												</div>
											</td>
										<?php endfor; ?>
									<?php endif ?>

									<?php if ($adereExameFinal): ?>
										<td>
											<div class="input-group">
												<input type="text" name="<?php echo "examefinal[{$id_aluno}]"; ?>" class="mask-nota form-control input-sm" maxlength="4" value="<?php echo isset($nota['examefinal']) ? $nota['examefinal'] : '' ?>" <?php echo $disable; ?>>
											</div>
										</td>
									<?php endif ?>
								<?php endif ?>
								<td>
									<small><?php echo $aluno["situacaodesc"]; ?></small>
								</td>
								<td>
									<button type="button" class="btn btn-xs btn-default btn-notas-alteracao" title="Hist�rico"
											data-id="<?php echo encrypt_decrypt('encrypt', $nota['id']); ?>">
										<i class="fa fa-lg fa-history"></i>
									</button>
								</td>
							</tr>
							<?php endforeach; ?>
							<tr>
								<th>Total</th>
								<th colspan="7"><?php echo sizeof($alunos); ?></th>
							</tr>
						</tbody>
					</table>
				</div>

				<div class="well well-sm">
					<button type="submit" class="btn btn-primary btn-submit-wait" onclick="return confirm('Confirma as altera��es?')">SALVAR RECUPERA��O</button>
					<button type="button" class="btn btn-default btn-back pull-right">Voltar</button>
				</div>
			</form>

			<?php endif; ?>

			<?php endif; ?>
		</div>

		<?php require '../../partials/modalNotasAlteracoes.php' ?>

		<?php require_once page_footer(); ?>
		<script src="<?php echo js('modalNotasAlteracoes.js') ?>"></script>
	</body>
</html>