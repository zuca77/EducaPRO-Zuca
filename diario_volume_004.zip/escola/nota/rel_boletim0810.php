<?php
session_start();
if (isset($_SESSION["login_usuario"]))
  {
     $login     =  $_SESSION["login_usuario"];
     $nte       =  $_SESSION["nivel_usuario"];
	 $inep      =  $_SESSION["inep_usuario"] ;
     $ntelogin  =  $_SESSION["nte_login"];
     $cpf1       = $_SESSION["cpf_usuario"];

	 include ("../../funcoes.php");
//     echo  saudacoes()."   ". "$login" ."  -  ". $nte."  ".dataextenso() ." - ".$inep;

  }
 else
  {
    		 header("../../Location: login.php");
  }





$sql="SELECT ano, situacao FROM ano where situacao = 'A' and inep = '$inep'";
$resultado=mysql_query($sql) or die (mysql_error());
$linhas=mysql_num_rows($resultado);
if ($linhas>0)
 {
    while($pegar=mysql_fetch_array($resultado))
   {
         $txtano       = $pegar["ano"];
   }
 }




  $id =  $_GET['codigo'];

/* $totalcaracter = strlen($id);
 $posicao        = strpos($id, '*');
 $aluno          = substr($id, 0, $posicao);
 $turma    = substr($id, $posicao+1,  $totalcaracter);
 */

 $totalcaracter  = strlen($id);
 $posicao        = strpos($id, '*');
 $aluno          = substr($id, 0, $posicao);
 $posicao2       = strpos($id, '-');
 $turma          = substr($id, $posicao+1,$posicao2-$posicao-1);
 $n_chamadax     = substr($id, $posicao2+1, $totalcaracter-$posicao2);




$sqlgerencia = "select e.inep,e.descricao as descescola,e.fone,e.regularizada, e.endereco,e.bairro,e.numero,m.descricao as descmuni from escola e , municipio m  where inep ='$inep' and e.municipio = m.codigo";
$resultadoger=mysql_query($sqlgerencia) or die (mysql_error());
$linhas   =mysql_num_rows($resultadoger);
if($linhas>0)
{
   while($pegar=mysql_fetch_array($resultadoger))
	{

    	$descescola    =$pegar["descescola"];
    	$descmunici    =$pegar["descmuni"];

    	$endereco      =$pegar["endereco"];
    	$bairro        =$pegar["bairro"];
    	$numero        =$pegar["numero"];

    	$fone         =$pegar["fone"];
    	$regularizada        =$pegar["regularizada"];



    }
 }


$sqlaluno="select * from turma t,turma_aluno ta where t.id=ta.id_turma
and ta.id_aluno = '$aluno' and t.ano='$txtano' and t.id = $turma and n_chamada = '$n_chamadax'";

$resultadoaluno=mysql_query($sqlaluno) or die (mysql_error());
$linhasaluno=mysql_num_rows($resultadoaluno);
if ($linhasaluno>0)
 {
while($pegaraluno=mysql_fetch_array($resultadoaluno))
    {
      $turmadesc             = $pegaraluno["DESCRICAO"];
	  $n_chamada             = $pegaraluno["n_chamada"];
	  $modalidade            = $pegaraluno["MODALIDADE"];
	  $turma_dep             = $pegaraluno["turmas"];
	  $id_grade              = $pegaraluno["id_grade"];


 	  $turmasserie           = $pegaraluno["TURMAS"];
 	  $ano_letivo            = $pegaraluno["ANO"];
 	  $situacao_aluno        = $pegaraluno["situacao"];
      $grade_curricular_x    = $pegaraluno["id_grade"];
      $grade_curricular      = $pegaraluno["id_grade"];
      $dtfecha_turma         = date("d/m/Y",strtotime($pegaraluno["dtfecha_turma"]));
   	  $turma_dep             = $pegaraluno["TURMAS"];
   	  $semestre              = $pegaraluno["SEMESTRE"];




        if (($dtfecha_turma=='31/12/1969')  || ($dtfecha_turma=='30/11/-0001'))
		   {
		     $dtfecha_turma='Turma Aberta';
		   }



	}
 }


if ($id_grade=='')
  {
	echo "<html><head><title>Resposta !!!</title></head>";
	echo "<body background=\"background_mensagens.jpg\" style=\"background-attachment:fixed; background-repeat:no-repeat\">";
	echo "<br><br><br>";
	echo "<center><img src=\"faleconosco/atencao.gif\" alt=\"\"><p><font color=\"#ff6600\" face=\"Verdana\" size=\"4\">N�o existe grade associada! <b></b></font></center>";
	echo "<br><br><center><a href=\"form_imprimi_turma_aluno.php\"><img src=\"faleconosco/button_voltar2_.gif\" alt=\"Voltar\" border=\"0\" /></a></center>";
       echo "</body></html>";
       exit;
   }





$dia = date('d');
$mes = date('m');
$ano = date('Y');

$data =$dia.".".$mes.".".$ano;





$re = mysql_query("select count(*) as total from nota_aluno
where  id_aluno = '$aluno' and  ano ='$txtano'");
$total = mysql_result($re, 0, "total");
if ($total==0)
  {
	echo "<html><head><title>Resposta !!!</title></head>";
	echo "<body background=\"background_mensagens.jpg\" style=\"background-attachment:fixed; background-repeat:no-repeat\">";
	   echo "<br><br><br>";
	   echo "<center><img src=\"faleconosco/atencao.gif\" alt=\"\"><p><font color=\"#ff6600\" face=\"Verdana\" size=\"4\">Banco Sem Informa��o!!!! <b></b></font></center>";
	   echo "<br><br><center><a href=\"form_imprimi_turma_aluno.php\"><img src=\"faleconosco/button_voltar2_.gif\" alt=\"Voltar\" border=\"0\" /></a></center>";
       echo "</body></html>";
       exit;
   }







$banco_vazio = 0;

//$re = mysql_query("select count(*) as total from nota_aluno n, habilitacao h where h.codigo = n.id_disciplina");

$re = mysql_query("select count(*) as total from nota_aluno  where  id_aluno = '$aluno' ");
$total = mysql_result($re, 0, "total");
if ($total==0)
  {

       $banco_vazio = 1;
   }





 /*************************Totaliznado Faltas**********************************************************************************/

 $re = mysql_query("select  sum( t_falta1 + t_falta2 + t_falta3 + t_falta4 ) as total from nota_aluno  where  id_aluno = '$aluno'  and ano = '$txtano' ");
 $total_conta_faltas = mysql_result($re, 0, "total");



/***********************************************************************************************************/




if (($modalidade=='1') || ($modalidade=='3'))
 {
   if (($turma_dep=='75') || ($turma_dep=='76') || ($turma_dep=='77') ||($turma_dep=='78') ||($turma_dep=='79'))
       {



$sql=mysql_query(" SELECT * , (nota1 + nota2 + nota3 + nota4) AS soma, (nota1 + nota2 + nota3 + nota4) /4 media
FROM nota_aluno n, habilitacao h, turma_dep_aluno_disciplina t
WHERE h.codigo = n.id_disciplina
AND n.id_aluno = '$aluno'
AND n.ano = '$txtano'
AND n.id_turmaprofessor = '$turma'
AND t.id_turma = n.id_turmaprofessor
AND n.inep = t.inep
AND t.id_disciplina = h.codigo
AND t.id_aluno = n.id_aluno ");



       }
     else
      {
        /*$sql=mysql_query("select *,(nota1+nota2+nota3+nota4) as soma,(nota1+nota2+nota3+nota4)/4   media
         from nota_aluno n, habilitacao h where h.codigo = n.id_disciplina and id_aluno = '$aluno' and n.ano= '$txtano'");
        */

        $sql=mysql_query("SELECT * , (nota1 + nota2 + nota3 + nota4) AS soma, (nota1 + nota2 + nota3 + nota4) /4 media
				FROM nota_aluno n, habilitacao h, turma_aluno t
				WHERE h.codigo = n.id_disciplina
				AND t.id_aluno = '$aluno'
				AND n.ano = '$txtano'
				AND t.id_aluno = n.id_aluno
                AND t.id_turma = n.id_turma
                AND t.n_chamada = '$n_chamadax'
                AND t.situacao in (1,2,3)");



 





         }
 
  }
else
  {
   $sql=mysql_query("select *,(nota1+nota2) as soma,(nota1+nota2)/2   media
   from nota_aluno n, habilitacao h,turma t where h.codigo = n.id_disciplina
   and id_aluno = '$aluno'
   and n.ano = '$txtano'
   and t.id=n.id_turma
   and t.semestre = '$semestre'");
 }






$conta = mysql_num_rows($sql);
/*Pegando o numero de chamado*/







$sqlaluno="select * from aluno where id = '$aluno'";
$resultadoaluno=mysql_query($sqlaluno) or die (mysql_error());
$linhasaluno=mysql_num_rows($resultadoaluno);
if ($linhasaluno>0)
 {
while($pegaraluno=mysql_fetch_array($resultadoaluno))
    {
      $alunodesc      = $pegaraluno["nome"];
      $nomepai        = $pegaraluno["nome_pai"];
      $nomemae        = $pegaraluno["nome_mae"];
      $endaluno       = $pegaraluno["endereco"];
      $numeroaluno    = $pegaraluno["numero"];
      $bairroaluno    = $pegaraluno["bairro"];
      
      $dtnacimento    = date("d/m/Y",strtotime($pegaraluno["dt_nascimento"]));



	}
 }


?>


<html>
<head>

<title>:: DIARIO ELETRONCIO ::</title>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1">
<link href="../biblioteca/menu/menu.css" rel="stylesheet" type="text/css">
<script language="JavaScript" src="../biblioteca/menu/JSCookMenu.js" type="text/javascript"></script>
<script language="JavaScript" src="../biblioteca/menu/theme.js" type="text/javascript"></script>
<link rel="stylesheet" type="text/css" href="../biblioteca/padraoestilo.css">

<script type="text/javascript" src="../biblioteca/sortabletable.js"></script>
<link type="text/css" rel="StyleSheet" href="../biblioteca/sortabletable.css" />
</head>

<style>
.titulopagina
{
    font-size: 11px;
    color:    #000099;
	background-color:#E8E8E8;
	height:25px;
    font-family: verdana , arial
}

table.bordasimples {border-collapse: collapse;}

table.bordasimples tr td {border:1px solid #CCCCCC;}

.subtitulo
{
	font-family: verdana ;
	font-size: 10pt;
    color: #22408f;
	font-weight: bold;
}

.nomecampo
{
    font-size: 10px;
    color: midnightblue;
    font-family: verdana, arial;
	font-weight: bold;
}
.escrita
{
    font-size: 10px;
    color: #000000;
    font-family: verdana, arial
}
.escritanormal
{
    font-size: 10px;
    color: #000000;
    font-family: verdana, arial;
	font-weight: normal;
}



</style>
<script language="javascript">
function DoPrinting() {
    if (!window.print) {
        alert("Netscape, Internet Explorer 4.0 ou superior!")
        return
    }
    window.print();
}
</script>

<style media="print">
.botao {
display: none;
}
</style>


</head>
<table width="100%">
<tr>


      <td class="nomecampo" align="center"><b><img src= "../img/brasao.jpg" /></b></td>


</tr>
<tr>
<td>

<table width="100%">
<tr>
<td>&nbsp;  </td>
</tr>
<tr>
<td>
<table border="0"  class="bordasimples" cellspacing="0"  align="center" width="100%" bgcolor=#ffffff>

<tr>
	<td colspan="6"  bgcolor="#EAEAEA"  class="subtitulo" align="center"><b>GOVERNO DO ESTADO DE ROND�NIA</b></td>
</tr>

<tr>
	<td colspan="6"  bgcolor="#EAEAEA"  class="subtitulo" align="center"><b>SECRETARIA DE ESTADO DA EDUCA��O</b></td>
</tr>

<tr>
	<td colspan="6"  bgcolor="#EAEAEA"  class="subtitulo" align="center"><b>GER�NCIA DE TECNOLOGIA DA INFORMA��O</b></td>
</tr>


<tr>
	<td colspan="6"  bgcolor="#EAEAEA"  class="subtitulo" align="center"><b>Dados da Escola</b></td>
</tr>
<tr>
	<td class="nomecampo"><b>C�digo INEP:</b></td>
	<td>&nbsp;<?echo $inep;?></td>
	<td class="nomecampo"><b>Raz�o Social:</b></td>
	<td class = "escrita">&nbsp;<?echo $descescola;?></td>
	<td class="nomecampo"><b>Zona:</b></td>
	<td>&nbsp;Urbana</td>

</tr>



<tr>
	<td class="nomecampo"><b>Endere�o:</b></td>
	<td class = "escrita">&nbsp;<?echo $endereco;?></td>
	<td class="nomecampo"><b>N�:</b></td>
	<td>&nbsp;<?echo $numero;?></td>
	<td class="nomecampo"><b>Bairro</b></td>
	<td class = "escrita">&nbsp;<?echo $bairro;?></td>

</tr>
<tr>
	<td class="nomecampo"><b>UF:</b></td>
    <td>&nbsp;RO</td>
	<td class="nomecampo"><b>Munic�pio:</b></td>
	<td class = "escrita">&nbsp;<?echo $descmunici;?></td>
	<td class="nomecampo"><b>Regularizada:</b></td>
	<td>&nbsp;<?echo $regularizada;?></td>

  </tr>

 <tr>

	<td class="nomecampo"><b>Telefone:</b></td>
	<td>&nbsp;<?echo $fone;?></td>
	<td class="nomecampo"><b>Dep. administrativa:</b></td>
	<td colspan="3">&nbsp;Estadual</td>
</tr>

</table>

<?

  while($pegar=mysql_fetch_array($resultado))
      {

        $iddisciplina           = $pegar["disciplina"];
        $idturma                = $pegar["idturma"];
        $cpfprofessor           = $pegar["cpf"];
     }
?>



<table width="100%">
<tr>
<td>&nbsp;  </td>
</tr>
<tr>
<td>
<table border="0"  class="bordasimples" cellspacing="0"  align="center" width="100%" bgcolor=#ffffff>

<tr>
	<td colspan="6"  bgcolor="#EAEAEA"  class="subtitulo" align="center"><b>Dados do Aluno(a)</b></td>
</tr>

<tr>
	<td class="nomecampo"><b>Nome:</b></td>
	<td class = "escrita">&nbsp;<?echo $alunodesc;?></td>
	<td class="nomecampo"><b>Nascimento:</b></td>
	<td colspan="5" class = "escrita">&nbsp;<?echo $dtnacimento;?></td>

</tr>
<tr>
	<td class="nomecampo"><b>Pai</b></td>
	<td class = "escrita">&nbsp;<?echo $nomepai;?></td>
	<td class="nomecampo"><b>M�e</b></td>
	<td class = "escrita" colspan="5">&nbsp;<?echo $nomemae;?></td>


</tr>
<tr>
	<td class="nomecampo"><b>Endere�o</b></td>
	<td class = "escrita">&nbsp;<?echo $endaluno;?></td>
	<td class="nomecampo"><b>Bairro</b></td>
	<td class = "escrita">&nbsp;<?echo $bairroaluno;?></td>
	<td class="nomecampo"><b>N�</b></td>
	<td class = "escrita" colspan="5" >&nbsp;<?echo $numeroaluno;?></td>
</tr>



<tr>
	<td class="nomecampo"><b>Turma</b></td>
	<td class = "escrita">&nbsp;<?echo $turmadesc;?></td>
	<td class="nomecampo"><b>Chamada</b></td>
	<td class = "escrita" >&nbsp;<?echo $n_chamada;?></td>
	<td class="nomecampo"><b>Modalidade</b></td>
	<td class = "escrita" colspan="5">&nbsp;<?echo $modalidade;?></td>

</tr>




</table>



<table width="100%">
<tr>
<td>&nbsp;  </td>
</tr>

<table border="0" class="bordasimples"  cellspacing="0"  align="center" width="100%" bgcolor=#ffffff>

<tr>
	<td colspan="18"  bgcolor="#EAEAEA"  class="subtitulo" align="center"><b>BOLETIM</b></td>
</tr>


<?
  if (($modalidade=='1')|| ($modalidade=='3'))
  {
?>

<tr>
 <td class="nomecampo"><b>Componente Curricular</b></td>
 <td class="nomecampo"><b>1�Bim</b></td>
 <td class="nomecampo"><b>F 1�B</b></td>
 <td class="nomecampo"><b>2�Bim</b></td>
 <td class="nomecampo"><b>F 2�B</b></td>
 <td class="nomecampo"><b>3�Bim</b></td>
 <td class="nomecampo"><b>F 3�B</b></td>
 <td class="nomecampo"><b>4�Bim</b></td>
 <td class="nomecampo"><b>F 4�B</b></td>
 <td class="nomecampo"><b>R 1�B</b></td>
 <td class="nomecampo"><b>R 2�B</b></td>
 <td class="nomecampo"><b>R 3�B</b></td>
 <td class="nomecampo"><b>R 4�B</b></td>
 <td class="nomecampo"><b>Soma </b></td>
 <td class="nomecampo"><b>M�dia</b></td>
 <td class="nomecampo"><b>Ex Final</b></td>
 <td class="nomecampo"><b>Situa��o</b></td>
</tr>

<?
}
else
{
?>



<tr>
 <td class="nomecampo"><b>Componente Curricular</b></td>
 <td class="nomecampo" align="center"><b>1�Bim</b></td>
 <td class="nomecampo" align="center"><b>F 1�B</b></td>
 <td class="nomecampo" align="center"><b>2�Bim</b></td>
 <td class="nomecampo" align="center"><b>F 2�B</b></td>
 <td class="nomecampo" align="center"><b>R 1�B</b></td>
 <td class="nomecampo" align="center"><b>R 2�B</b></td>
 <td class="nomecampo" align="center"><b>Soma </b></td>
 <td class="nomecampo" align="center"><b>M�dia</b></td>
 <td class="nomecampo" align="center"><b>Ex Final</b></td>
 <td class="nomecampo" align="center"><b>M F</b></td>
 <td class="nomecampo" align="center"><b>Situa��o</b></td>
</tr>

<?
}//else



$sql_turma_aluno = "select * from turma_aluno where inep ='$inep' and id_aluno = '$aluno'
and id_turma = '$turma'
and n_chamada = '$n_chamadax'";
$resultado_turma_aluno=mysql_query($sql_turma_aluno) or die (mysql_error());
$linhas_turma_aluno   =mysql_num_rows($resultado_turma_aluno);
if($linhas_turma_aluno>0)
{
   while($linhas_turma_aluno=mysql_fetch_array($resultado_turma_aluno))
   	   {
        	$id_situacao   =$linhas_turma_aluno["situacao"];
      }
 }


$sqlsitua="select * from tipo_mov_aluno  where id = '$id_situacao'";
$resultadositua=mysql_query($sqlsitua) or die (mysql_error());
$linhassitua=mysql_num_rows($resultadositua);
if ($linhassitua>0)
 {
while($pegarsitua=mysql_fetch_array($resultadositua))
    {
      $situa_desc       = $pegarsitua["descricao"];
	}
 }





while ($dado = mysql_fetch_array($sql))
  {
   $dtabertura    = date("d/m/Y",strtotime($dado["data"]));

   $mfinal=0;
   $n1 =  $dado["nota1"];
   $n2 =  $dado["nota2"];
   $n3 =  $dado["nota3"];
   $n4 =  $dado["nota4"];


   $examefinal =  $dado["examefinal"];


   $nrec1 = $dado["recuperacao1"];
   $nrec2 = $dado["recuperacao2"];
   $nrec3 = $dado["recuperacao3"];
   $nrec4 = $dado["recuperacao4"];


   $bim1 = $dado["bim1"];
   $bim2 = $dado["bim2"];
   $bim3 = $dado["bim3"];
   $bim4 = $dado["bim4"];





   $id_disciplina = $dado["id_disciplina"];




   if ($n1 > $nrec1)
        {
         $notareal1 = $n1;
        }
  else
       {
          $notareal1 = $nrec1;
       }

   if ($n2 > $nrec2)
        {
         $notareal2 = $n2;
        }
  else
       {
          $notareal2 = $nrec2;
       }

   if ($n3 > $nrec3)
        {
         $notareal3 = $n3;
        }
  else
       {
          $notareal3 = $nrec3;
       }

   if ($n4 > $nrec4)
        {
         $notareal4 = $n4;
        }
  else
       {
          $notareal4 = $nrec4;
       }



  /**/




/*echo "d $id_disciplina*";
echo "g $id_grade*";
echo "m $modalidade*";
echo "I $inep*";
*/

 $sqlgrade="select * from grade_curricular where id_disciplina = '$id_disciplina'
 and id_serie = '$id_grade' and id_modalidade = '$modalidade'     and inep = '$inep'";
 $resultadograde=mysql_query($sqlgrade) or die (mysql_error());
 $linhasgrade=mysql_num_rows($resultadograde);
 if ($linhasgrade>0)
  {
while($pegargrade=mysql_fetch_array($resultadograde))
     {
      $reprova      =  $pegargrade["reprova"];



     }

  }


  /**/




if (($modalidade=='1') || ($modalidade=='3')) // regular e especial
 {

if ($id_situacao=='1')
 {


   $soma   = ($notareal1+$notareal2+$notareal3+$notareal4);
   $media  = ($soma)/4;
   $mfinal = 0; 



if  ($reprova=='S')
{
  if (($media < 6.0))
     {
        
           $mfinal = ($media*6 + $examefinal*4);

          if ($mfinal < 50.0)

            {
               $situacao = "REPROVADO";
             }
          else
            {
               $situacao = "APROVADO";

            }
      }
   else
            $situacao = "APROVADO";
 }
else
  {
       $situacao = "APROVADO";
  }






  if (($bim1 != 'S') || ($bim2 != 'S') ||  ($bim3 != 'S') ||  ($bim4 != 'S'))
       $situacao = "CURSANDO";

     }// if situacao
   else
      $situacao = $situa_desc;



?>
<!-- colocando os dados em uma tabela -->
<tr>
    	<td class = "escrita">&nbsp;<?echo $dado["descricao"];?></td>
     	<td class = "escrita" align="center">&nbsp;<?echo $dado["nota1"];?></td>
     	<td class = "escrita" align="center">&nbsp;<?echo $dado["t_falta1"];?></td>
     	<td class = "escrita" align="center">&nbsp;<?echo $dado["nota2"];?></td>
     	<td class = "escrita" align="center">&nbsp;<?echo $dado["t_falta2"];?></td>

      	<td class = "escrita" align="center">&nbsp;<?echo $dado["nota3"];?></td>
     	<td class = "escrita" align="center">&nbsp;<?echo $dado["t_falta3"];?></td>
     	<td class = "escrita" align="center">&nbsp;<?echo $dado["nota4"];?></td>
     	<td class = "escrita" align="center">&nbsp;<?echo $dado["t_falta4"];?></td>


      	<td class = "escrita" align="center">&nbsp;<?echo $dado["recuperacao1"];?></td>
     	<td class = "escrita" align="center">&nbsp;<?echo $dado["recuperacao2"];?></td>
     	<td class = "escrita" align="center">&nbsp;<?echo $dado["recuperacao3"];?></td>
     	<td class = "escrita" align="center">&nbsp;<?echo $dado["recuperacao4"];?></td>

        <td class = "escrita" align="center">&nbsp;<?echo number_format($soma, 1, ',', '.'); ?></td>
        <td class = "escrita" align="center">&nbsp;<?echo number_format($media, 1, ',', '.'); ?></td>
     	<td class = "escrita" align="center">&nbsp;<?echo $dado["examefinal"];?></td>


  <?
  if ($situacao=='APROVADO') 
   {
  ?>
        <td align="center"><font size="2" color="#000099"><?echo $situacao;?></td>
  <?
   }
  else
   {
 ?>
       <td align="center"><font size="2" color="#FF0000"><?echo $situacao;?></td>

   <?
   }
 ?> 





</tr>
<?
 }
else
{
   $soma = ($notareal1+$notareal2);
   $media = ($soma)/2;

 $mf = 0;

if ($id_situacao=='1')
 {

if  ($reprova=='S')
   {

     if (($media < 6.0))
     {
           $mfinal = ($media*6 + $examefinal*4);

          if ($mfinal < 50.0)
            {
                 $mf = ($mfinal / 10);
                 $situacao = "REPROVADO";
             }
          else
            {
                 $mf = ($mfinal / 10);
                 $situacao = "APROVADO";

            }
    }
   else
            $situacao = "APROVADO";

 }
else
  {
       $situacao = "APROVADO";
  }


  if (($bim1 != 'S') || ($bim2 != 'S'))
       $situacao = "CURSANDO";

              if ($modalidade ==2)
                  if ($total_conta_faltas >100)
                       $situacao =  "REPROVADO POR FALTA";



}



?>

<tr>
    	<td class = "escrita">&nbsp;<?echo $dado["descricao"];?></td>
     	<td class = "escrita" align="center">&nbsp;<?echo $dado["nota1"];?></td>
     	<td class = "escrita" align="center">&nbsp;<?echo $dado["t_falta1"];?></td>
     	<td class = "escrita" align="center">&nbsp;<?echo $dado["nota2"];?></td>
     	<td class = "escrita" align="center">&nbsp;<?echo $dado["t_falta2"];?></td>

      	<td class = "escrita" align="center">&nbsp;<?echo $dado["recuperacao1"];?></td>
     	<td class = "escrita" align="center">&nbsp;<?echo $dado["recuperacao2"];?></td>

        <td class = "escrita" align="center">&nbsp;<?echo number_format($soma, 1, ',', '.'); ?></td>
        <td class = "escrita" align="center">&nbsp;<?echo number_format($media, 1, ',', '.'); ?></td>
        <td class = "escrita" align="center">&nbsp;<?echo $dado["examefinal"];?></td>
        <td class = "escrita" align="center">&nbsp;<?echo number_format($mf, 1, ',', '.'); ?></td>

<?
if ($id_situacao=='1')
 {

  
if (($media < 6.0)  && ($mfinal<50.0))
   {

  /* echo "$media*";	
   echo "$mfinal*";
   echo "a $mfinal";
   echo $dado["descricao"];
   echo "*$reprova"; 
*/
?>
   <td align="center"><font size="2" color="#FF0000"><?echo "$situacao";?></td>
<?
    }
else
   {
?>
     <td align="center"><font size="2"><?echo "$situacao";?></td>
<?
   }
 }//if situacao
 else
    {
      $situacao =   $situa_desc;

?>
 <td align="center"><font size="2"><?echo  $situacao;?></td>
<?


    }




?>
</tr>




<?
 }
}//loop
?>








<table width="100%">
<tr>
<td>&nbsp;  </td>
</tr>
<tr>
<td>
<table border="0"  class="bordasimples" cellspacing="0"  align="center" width="100%" bgcolor=#ffffff>

<tr>
	<td colspan="6"  bgcolor="#EAEAEA"  class="subtitulo" align="center"><b>Assinatura</b></td>
</tr>
<?
if (($modalidade=='1') || ($modalidade=='3')) // regular e especial
 {
?>

<tr>
	<td class="nomecampo"><b>1� Bimestre</b></td>
	<td class="nomecampo"><b>Ass. Respons�vel</b></td>
</tr>
<tr>
	<td class="nomecampo"><b>2� Bimestre</b></td>
	<td class="nomecampo"><b>Ass. Respons�vel</b></td>
</tr>
<tr>
	<td class="nomecampo"><b>3� Bimestre</b></td>
	<td class="nomecampo"><b>Ass. Respons�vel</b></td>
</tr>
<tr>
	<td class="nomecampo"><b>4� Bimestre</b></td>
	<td class="nomecampo"><b>Ass. Respons�vel</b></td>
</tr>
<?
}
else  // regular e especial
 {
?>


<tr>
	<td class="nomecampo"><b>1� Bimestre</b></td>
	<td class="nomecampo"><b>Ass. Respons�vel</b></td>
</tr>
<tr>
	<td class="nomecampo"><b>2� Bimestre</b></td>
   <td class="nomecampo"><b>Ass. Respons�vel</b></td>
</tr>

<?
}
?>


</table>

<table width="100%">
<tr>
<td>&nbsp;  </td>
</tr>
<tr>
<td>
<table border="0"  class="bordasimples" cellspacing="0"  align="center" width="100%" bgcolor=#ffffff>
<tr>
	<td class="botao"><b><img src= "../../imagem/impressora.jpg" onClick="DoPrinting()" title = "Click para imprimir."/></b></td>
</tr>
</table>

