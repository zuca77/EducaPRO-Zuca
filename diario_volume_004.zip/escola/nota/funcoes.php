<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1" />
<title>NTE-Porto Velho</title>
 <script language="javascript" src="generic.js"></script>	
</head>



<?php


if(file_exists("../../conexao_mysql.php"))
{
        require "../../conexao_mysql.php";

} else
{
        echo "Conex�o nao foi encontrado";
        exit;
}

function saudacoes()
{
$hr = date(" H ");
if($hr >= 12 && $hr<18) {
$resp = "Boa tarde!!!!     ";}
else if ($hr >= 0 && $hr <12 ){
$resp = "Bom dia!!!      ";}
else {
$resp = "Boa noite!!!     ";}
echo "$resp";
}

function dataextenso(){
// leitura das datas
$dia = date('d');
$mes = date('m');
$ano = date('Y');
$semana = date('w');


// configura��o mes

switch ($mes)
  {
case 1: $mes = "JANEIRO"; break;
case 2: $mes = "FEVEREIRO"; break;
case 3: $mes = "MAR�O"; break;
case 4: $mes = "ABRIL"; break;
case 5: $mes = "MAIO"; break;
case 6: $mes = "JUNHO"; break;
case 7: $mes = "JULHO"; break;
case 8: $mes = "AGOSTO"; break;
case 9: $mes = "SETEMBRO"; break;
case 10: $mes = "OUTUBRO"; break;
case 11: $mes = "NOVEMBRO"; break;
case 12: $mes = "DEZEMBRO"; break;
    }


// configura��o semana

switch ($semana) 
     {
case 0: $semana = "DOMINGO"; break;
case 1: $semana = "SEGUNDA FEIRA"; break;
case 2: $semana = "TER�A-FEIRA"; break;
case 3: $semana = "QUARTA-FEIRA"; break;
case 4: $semana = "QUINTA-FEIRA"; break;
case 5: $semana = "SEXTA-FEIRA"; break;
case 6: $semana = "S�BADO"; break;

      }
//Agora basta imprimir na tela...
print ("$semana, $dia DE $mes DE $ano");
}


function combo_pastas() 
 {
	$consulta = mysql_query("SELECT * FROM pasta order by nome_pasta ASC");
	$resultado = mysql_num_rows($consulta);
	if($resultado == "") {
		echo "<font face=verdana size=-1> existe categoria!!!</font>";
		echo "<a href=cria_categoria.php><font face=verdana size=-1>Criar categoria</font></a>";
 }
 else	
  {
		echo "<select name=select>";
		while($dados = mysql_fetch_array($consulta)) 
		{ 
			echo "<option>$dados[nome_pasta]</option>"; 
		}
			echo "</select>";
  }
}

function combo_cursoproinfo() 
 {
	$consulta = mysql_query("SELECT descricao FROM cursoproinfo order by descricao ASC");
	$resultado = mysql_num_rows($consulta);
	if($resultado == "") {
		echo "<font face=verdana size=-1> existe categoria!!!</font>";
		echo "<a href=cria_categoria.php><font face=verdana size=-1>Criar categoria</font></a>";
 }
 else	
  {
		echo "<select name=oficina  onBlur = pesquisa(form1)>";
		while($dados = mysql_fetch_array($consulta)) 
		{ 
			echo "<option>$dados[descricao]</option>"; 
	
		}
			echo "</select>";
  }
}





function combo_processopassagem() 
 {
	$consulta = mysql_query("SELECT processo FROM processopassagem order by processo ASC");
	$resultado = mysql_num_rows($consulta);
	if($resultado == "") {
		echo "<font face=verdana size=-1> existe categoria!!!</font>";
		echo "<a href=cria_categoria.php><font face=verdana size=-1>Criar categoria</font></a>";
 }
 else	
  {
		echo "<select name=processo  onBlur = pesquisa(form1)>";
		while($dados = mysql_fetch_array($consulta)) 
		{ 
			echo "<option>$dados[processo]</option>"; 
	
		}
			echo "</select>";
  }
}

function combo_trecho() 
 {
	$consulta = mysql_query("select * from trecho");
	$resultado = mysql_num_rows($consulta);
	if($resultado == "") 
	  {
		echo "<font face=verdana size=-1> existe categoria!!!</font>";
		echo "<a href=cria_categoria.php><font face=verdana size=-1>Criar categoria</font></a>";
	   } 
  else
     {
			echo "<select name=trecho onBlur = pesquisa(form)>";
			while($dados = mysql_fetch_array($consulta)) 
		    	{ 
				  echo "<option value=$dados[CODIGO]>$dados[DESCRICAO]</option>"; 
			    }
			echo  "</select>";
	 }
 }





function lista_programa() 
 {
	$consulta = mysql_query("select * from programa");
	$resultado = mysql_num_rows($consulta);
	if($resultado == "") 
	 {
		echo "<font face=verdana size=-1> existe categoria!!!</font>";
		echo "<a href=cria_categoria.php><font face=verdana size=-1>Criar categoria</font></a>";
	}
  else
   {
			echo "<select name=programa>";
			while($dados = mysql_fetch_array($consulta)) 
			{ 
				echo "<option value=$dados[PROGRAMA]>$dados[PROGRAMA]</option>"; 
			}
			echo "</select>";
	}
}

function protocolo() 
 {
	$consulta = mysql_query("SELECT * FROM chamado by nome_pasta ASC");
	$resultado = mysql_num_rows($consulta);
	if($resultado == "") {
		echo "<font face=verdana size=-1> existe categoria!!!</font>";
		echo "<a href=cria_categoria.php><font face=verdana size=-1>Criar categoria</font></a>";
 }
 else	
  {
		echo "<select name=select>";
		while($dados = mysql_fetch_array($consulta)) 
		{ 
			echo "<option>$dados[nome_pasta]</option>"; 
		}
			echo "</select>";
  }
}


function logar($login,$password) 
{
	$resultado = mysql_query("SELECT * FROM usuario WHERE user = '$login' AND pass = '$password'");
	$linhas = mysql_num_rows($resultado);
	if($linhas == 0) 
	{
		echo "<font face=verdana size=-1>Senha incorreta ou usuario cadastrado, tente novamente !!!</font><br>";
		echo "<a href=index.php><font face=verdana size=-1>voltar</fonte></a>";
	} else 
	{
			while($dados = mysql_fetch_array($resultado)) 
			 {
				session_start();
				$_SESSION['login_arquivo'] = $login;
				$_SESSION['grupo_login'] = $dados[grupo];
				$_SESSION['senha_arquivo'] = $password;
				header("Location: manager.php"); 
			}
	}
}


function lista_municipio() 
 {
	$consulta = mysql_query("select * from  municipio ");
	$resultado = mysql_num_rows($consulta);
	if($resultado == "") 
	 {
		echo "<font face=verdana size=-1> existe categoria!!!</font>";
		echo "<a href=cria_categoria.php><font face=verdana size=-1>Criar categoria</font></a>";
	}
  else
   {
			echo "<select name=municipio id=municipio>";
			echo "<option value=''>Selecione o Munic�pio</option>";
			while($dados = mysql_fetch_array($consulta)) 
			{ 
				echo "<option value=$dados[CODIGO]>$dados[DESCRICAO]</option>"; 
			}
			echo "</select>";
	}
}




function lista_escola() 
 {
	$consulta = mysql_query("select * from escola ");
	$resultado = mysql_num_rows($consulta);
	if($resultado == "") 
	 {
		echo "<font face=verdana size=-1> existe categoria!!!</font>";
		echo "<a href=cria_categoria.php><font face=verdana size=-1>Criar categoria</font></a>";
	}
  else
   {
			echo "<select name=escola>";
			while($dados = mysql_fetch_array($consulta)) 
			{ 
				echo "<option value=$dados[INEP]>$dados[DESCRICAO]</option>"; 
			}
			echo "</select>";
	}
}



function lista_municipio_Altera() 
 {
	$consulta = mysql_query("select * from  municipio ");
	$resultado = mysql_num_rows($consulta);
	if($resultado == "") 
	 {
		echo "<font face=verdana size=-1> existe categoria!!!</font>";
		echo "<a href=cria_categoria.php><font face=verdana size=-1>Criar categoria</font></a>";
	}
  else
   {
		echo "<select name=municipio id=municipio onChange=alteramuni(this.value)>";
		echo "<option value=''>Selecione Munic�pio</option>"; 
		while($dados = mysql_fetch_array($consulta)) 
		{ 
			echo "<option value=$dados[CODIGO]>$dados[DESCRICAO]</option>"; 
		}
		echo "</select>";
	}
}



function lista_municipio_Altera1() 
 {
	$consulta = mysql_query("select * from  municipio ");
	$resultado = mysql_num_rows($consulta);
	if($resultado == "") 
	 {
		echo "<font face=verdana size=-1> existe categoria!!!</font>";
		echo "<a href=cria_categoria.php><font face=verdana size=-1>Criar categoria</font></a>";
	}
  else
   {
			echo "<select name=municipio onChange=alteramuni(this.value)>";
			while($dados = mysql_fetch_array($consulta)) 
			{ 
				echo "<option value=$dados[CODIGO]>$dados[DESCRICAO]</option>"; 
			}
			echo "</select>";
	}
}



function lista_escola1($nome_campo="escola",$MULT=FALSE)
{
 $sql = "select CODIGO,DESCRICAO from escola";
 $resposta = mysql_query($sql);

$ufs = array();
while ($linha = mysql_fetch_array($resposta )) 
 { 
     $ufs[] = ($linha["DESCRICAO"]);
 }
  $ret = "<select name='$nome_campo'";
  $ret.=($MULT) ? " MULTIPLE" : " ";
  $ret.=  ">\n";
 foreach($ufs as $chv => $vlr)
   {
   $ret.=   "<option value='$chv'>$vlr</option>\n"; 
   }
  $ret.="</select>\n";  
  return $ret;

  mysql_free_result( $resposta );
  mysql_close($conexao);

}

function lista_ativo() 
 {
	$consulta = mysql_query("select * from  ativo ");
	$resultado = mysql_num_rows($consulta);
	if($resultado == "") 
	 {
		echo "<font face=verdana size=-1> existe categoria!!!</font>";
		echo "<a href=cria_categoria.php><font face=verdana size=-1>Criar categoria</font></a>";
	}
  else
   {
			echo "<select name=ativo onblur= disabilitainternet() >";
			while($dados = mysql_fetch_array($consulta)) 
			{ 
				echo "<option value=$dados[DESCRICAO]>$dados[DESCRICAO]</option>"; 
			}
			echo "</select>";
	}
}

 function tpoficina($nome_campo="USR_UF",$MULT=FALSE)
 {
   $ufs= array(""=>"...Selecione Tipo...",
			   "BLOG" => "BLOG",
       		   "MOVIE" => "MOVIEMAKER",   
      		   "PIKASA" => "PIKASA",   
       		   "AUDACITY" => "AUDACITY",
			   "OFFICE" => "OFIICE");

   $ret = "<select name='$nome_campo'";
   $ret.=($MULT) ? " MULTIPLE" : " ";
   $ret.=  ">\n";

   foreach($ufs as $chv => $vlr)
      {
	   $ret.=   "<option value='$chv'>$vlr</option>\n"; 
	  }
    $ret.="</select>\n";
	return $ret;
 }

 function tpformacao($nome_campo="tipo",$MULT=FALSE)
 {
   $ufs= array(""=>"...Selecione Tipo...",
			   "IED" => "INTRODUCAO A ED DIGITAL 40H - PROINFO",
       		   "EAT" => "ENS APRENDENDO C TIC S 100H - PROINFO");

   $ret = "<select name='$nome_campo'";
   $ret.=($MULT) ? " MULTIPLE" : " ";
   $ret.=  ">\n";

   foreach($ufs as $chv => $vlr)
      {
	   $ret.=   "<option value='$chv'>$vlr</option>\n"; 
	  }
    $ret.="</select>\n";
	return $ret;
 }



/*function lista_programa() 
 {
	$consulta = mysql_query("select * from  programa");
	$resultado = mysql_num_rows($consulta);
	if($resultado == "") 
	 {
		echo "<font face=verdana size=-1> existe categoria!!!</font>";
		echo "<a href=cria_categoria.php><font face=verdana size=-1>Criar categoria</font></a>";
	}
  else
   {
			echo "<select name=programa onChange=formregchamado(this.value)>";
			while($dados = mysql_fetch_array($consulta)) 
			{ 
				echo "<option value=$dados[PROGRAMA]>$dados[PROGRAMA]</option>"; 
			}
			echo "</select>";
	}
}

*/
 function programa($nome_campo="programa",$MULT=FALSE)
 {
   $ufs= array(""=>"...Selecione Programa...",
			   "PROINFO"   => "PROINFO",
       		   "ALVORADA"  => "ALVORADA",
			   "DESPERTAR" => "DESPERTAR",
			   "PROMED"    => "PROMED",
			   "PROINESP"  => "PROINESP",
			   "TELINHA ESCOLA"  => "TELINHA NA ESCOLA");

   $ret = "<select name='$nome_campo'";
   $ret.=($MULT) ? " MULTIPLE" : " ";
   $ret.=  ">\n";

   foreach($ufs as $chv => $vlr)
      {
	   $ret.=   "<option value='$chv'>$vlr</option>\n"; 
	  }
    $ret.="</select>\n";
	return $ret;
 }




 function departamento($nome_campo="departamento",$MULT=FALSE )
 {
   $ufs= array(""=>"...Selecione Departamento...",
			   "GAB"               => "GABINETE",
       		   "ASS-JURIDICA"      => "ASSESSORIA JURIDICA",
			   "CPL"               => "COMISS�O PERMANTE LICITA��O",
			   "COORD-PEDAGOGICA"  => "COORD PEDAGOGICA",
			   "DAF"               => "DIRETORIA ADM FINANCEIRA",
			   "DAP"               => "DIRETORIA DE ALMOXARIFADO E PATRIM�NIO",
   			   "DME"               => "DIRETORIA DE MANUTEN��O ESCOLAR",
   			   "DERA"              => "DIRETORIA EDIFIC REFORMA E AMPLIA��O",
			   "GT"                => "GER�NCIA DE TRANSPORTES ESCOLAR",
   			   "GCI"               => "GER�NCIA DE CONTROLE E INTERNO",
			   "GTI"               => "GER�NCIA DE TECNOLOGIA E INFORMA��O",
   			   "GPOP"              => "GER�NCIA PLANEJAMENTO E OR�AMENTO PROJETO",
			   "GCPC"              => "GER�NCIA DE CONV�NIO E PRESTA��O DE CONTAS",
			   "GE"                => "GER�NCIA DE EDUCA��O",
			   "GEP"               => "GER�NCIA DE EDUCA��O PROFISSIONAL",
			   "GPE"               => "GER�NCIA DE PROJETOS ESPECIAIS",
			   "CAP"               => "CAP",
			   "NEJA"              => "NEJA",
			   "NAM"               => "NAM",
   			   "PROINFANTIL"       => "PROINFANTIL",			   
			   "CONS ESTADUAL"     => "CONSELHO ESTADUAL",			   
			   "TV-ESCOLA"         => "TV ESCOLA",	
			   "CAS"               => "CAS",
			   "PRO-FUNCIONARIO"   => "PRO-FUNCIONARIO",		
			   "REGIMENTO"         => "REGIMENTO",					   
			   "PTE"               => "PTE",					   			   			   
			   "NTE"               => "NTE",					   			   
			   "GACA"              => "GER�NCIA DE APARELHAMENTO CONTR E AVALIA��O",
               "RENCENTRO"         => "REN CENTRO",			   
               "RENSUL"            => "REN SUL",			   			   
               "RENLESTE"          => "REN LESTE",			   			   
               "PIE"               => "PIE",			   			   
               "CEC"               => "CEC-COORD DE ESPORTE E CURLTURA",			   			   			   			   
               "PRODEF/GE"         => "PRODEF/GE",			   			   			   			   			   
               "PEDEM/GE"         => "PRODEF/GE",			   			   			   			   			   			   
               "ALMOXARIFADO/SEDUC" => "ALMOXARIFADO/SEDUC",			   			   			   			   			   			   
               "NUCELI/DAF/SEDUC" => "NUCELI/DAF/SEDUC",			   			   			   			   			   			   
			   );
   $ret = "<select name='$nome_campo'";
   $ret.=($MULT) ? " MULTIPLE" : " ";
   $ret.=  ">\n";

   foreach($ufs as $chv => $vlr)
      {
	   $ret.=   "<option value='$chv'>$vlr</option>\n"; 
	  }
    $ret.="</select>\n";
	return $ret;
 }


 function empresa($nome_campo="empresa",$MULT=FALSE)
 {
   $ufs= array(""=>"...Selecione Empresa...",
			   "GLOBAL SYSTEM"   => "GLOBAL SYSTEM",
       		   "ITECH"  => "ITECH",
  		    "SEDUC"  => "SEDUC");

   $ret = "<select name='$nome_campo'";
   $ret.=($MULT) ? " MULTIPLE" : " ";
   $ret.=  ">\n";

   foreach($ufs as $chv => $vlr)
      {
	   $ret.=   "<option value='$chv'>$vlr</option>\n"; 
	  }
    $ret.="</select>\n";
	return $ret;
 }


function zebrar($i)
{
    return func_get_arg(abs($i) % (func_num_args() - 1) + 1);
}

?>


