<?
/*
session_start();

if (isset($_SESSION["login_usuario"]))
  {
   // session_cache_expire(1);
	 $login     =  $_SESSION["login_usuario"];
     $nte       =  $_SESSION["nivel_usuario"];
	 $inep      =  $_SESSION["inep_usuario"] ;
     $ntelogin  =  $_SESSION["nte_login"];
     $cpf       = $_SESSION["cpf_usuario"];

	 include ("../funcoes.php");
     echo  saudacoes()."   ". "$login" ."  -  ". $nte."  ".dataextenso()." ".$inep;

  }
 else
  {
     		 header("../../Location: login.php");
  }


include ("../../conexao_mysql.php");

if(file_exists("../../conexao_mysql.php"))
{
        require "../../conexao_mysql.php";

} else
{
        echo "Conex�o nao foi encontrado";
        exit;
}

*/




include ("../../conexao_mysql.php");

if(file_exists("../../conexao_mysql.php"))
{
        require "../../conexao_mysql.php";

} else
{
        echo "Conex�o nao foi encontrado";
        exit;
}




if($_SERVER["REQUEST_METHOD"] == "POST") 
{

$txtturma	         = $_POST['txtturma'];
$txtnaluno           = $_POST['txtnaluno'];
$txtdtnascimento     = $_POST['txtdtnascimento'];
$selectsexo	         = $_POST['selectsexo'];
$txtcertidao         = $_POST['txtcertidao'];
$txtfolha            = $_POST['txtfolha'];
$txtlivro            = $_POST['txtlivro'];
$cod_estado          = $_POST['cod_estado'];
$cod_cidades         = $_POST['cod_cidades'];

$txtpai              = $_POST['txtpai'];
$txtRGpai            = $_POST['txtRGpai'];
$txtOrgaoExppai      = $_POST['txtOrgaoExppai'];
$txtdtemissaorgpai   = $_POST['txtdtemissaorgpai'];
$cpfpai                 = $_POST['cpfpai'];

$txtmae              = $_POST['txtmae'];
$txtRGmae            = $_POST['txtRGmae'];
$txtOrgaoExpmae      = $_POST['txtOrgaoExpmae'];
$txtdtemissaorgmae   = $_POST['txtdtemissaorgmae'];
$cpf                 = $_POST['cpf'];

$txtEndereco         = $_POST['txtEndereco'];
$txtBairro           = $_POST['txtBairro'];
$txtcep              = $_POST['txtcep'];
$txtcomplemento      = $_POST['txtcomplemento'];
$cod_muni            = $_POST['cod_muni'];

$txtcontato          = $_POST['txtcontato'];
$txtCelular          = $_POST['txtCelular'];
$txtEmail            = $_POST['txtEmail'];

$txtnr             = $_POST['txtnr'];
$txtobs            = $_POST['txtobs'];


/*tratamento das datas*/
$diai = substr($txtdtnascimento, 0,2);
$anoi = substr($txtdtnascimento, -4);
$mesi = substr($txtdtnascimento, -7,2);
$txtdtnascimento=$anoi.".".$mesi.".".$diai;



$diaf = substr($txtdtemissaorgpai, 0,2);
$anof = substr($txtdtemissaorgpai, -4);
$mesf = substr($txtdtemissaorgpai, -7,2);
$txtdtemissaorgpai=$anof.".".$mesf.".".$diaf;




$diaret = substr($txtdtemissaorgmae, 0,2);
$anoret = substr($txtdtemissaorgmae, -4);
$mesret = substr($txtdtemissaorgmae, -7,2);
$txtdtemissaorgmae=$anoret.".".$mesret.".".$diaret;

$dia = date('d');
$mes = date('m');
$ano = date('Y');
$data =$dia.".".$mes.".".$ano;
$data1 =$dia.".".$mes.".".$ano;




/*****************************************************************/
$sql="select * from  aluno_matricula_chamada where nome_aluno = '$txtnaluno' and TURMAS = '$txtturma' and NOME_PAI='$txtpai' and NOME_MAE = '$txtmae'";
$resultado=mysql_query($sql) or die (mysql_error());
$linhas=mysql_num_rows($resultado);
if ($linhas>0)
 {

    echo "<html><head><title>Resposta !!!</title></head>";
    echo "<body background=\"background_mensagens.jpg\" style=\"background-attachment:fixed; background-repeat:no-repeat\">";
    echo "<br><br><br>";
    echo "<center><img src=\"faleconosco/atencao.gif\" alt=\"\"><p><font color=\"#FF0000\" face=\"Verdana\" size=\"4\"><blink>Aluno j� matriculado - Click em Voltar.!</blink> <b></b></font></center>";
    echo "<br><br><center><a href=\"form_pesquisa_aluno.php\"><img src=\"faleconosco/button_voltar2_.gif\" alt=\"Voltar\" border=\"0\" /></a></center>";
    echo "</body></html>";
    exit;
 }

/****************************************************************/


$sql="select * from  vagaschamadaescolar where id = '$txtturma'";
$resultado=mysql_query($sql) or die (mysql_error());
$linhas=mysql_num_rows($resultado);
if ($linhas>0)
 { 
while($pegar=mysql_fetch_array($resultado))
    {
      $saldo = $pegar["T_VAGAS"];
      $descricao_turma = $pegar["DESCRICAO"];

    }

if ($saldo<=0)
   {
  ?>


 <html><head><title>Resposta !!!</title>
 <style type="text/css">
<!--
.style3 {
	font-size: 36px;
	font-weight: bold;
	color: #0000FF;
}
 </style>
-->
 </head>

 <body background=\"background_mensagens.jpg\" style=\"background-attachment:fixed; background-repeat:no-repeat\">
 <META HTTP-EQUIV=Refresh CONTENT="2; URL=form_inclusao.php">
 <br><br><br>
 <center>
      <span class="style3"><font face=\"Verdana\" color="#FF0000">Turma n�o possui vaga dispon�vel.!</font> </span>
 </center>
 </body></html>

 <?
exit;
   }
 else
  {
   $saldo = $saldo-1;
  }




$sql = "update vagaschamadaescolar set
		t_vagas     ='$saldo'
        where id   = '$txtturma'";
if(@mysql_query($sql))
  {

      $success = mysql_affected_rows();
        if(mysql_affected_rows() == 1)
		{
        }
  }
 else
   {
        //verifico se nao estao tentando gravar um dado que ja existe, pois usei UNIQUE na tabela
        if(mysql_errno() == 1062)
		  {
                echo $erros[mysql_errno()];
                exit;
          }
		  else
		  {
                echo "Erro nao foi possivel efetuar a grava��o de saldo";
                exit;
          }
        @mysql_close();
     }

/*********inserindo pedidio***********/

$sql = "insert into aluno_matricula_chamada(INEP,TURMAS,NOME_ALUNO,DTNASCIMENTO,SEXO,CERTIDAO_NASCI,CERTIDAO_FOLHA,CERTIDAO_LIVRO,UFNATURALIDADE,CIDADENATURAL,NOME_PAI,RG_PAI,ORGEXPRG_PAI,DTRG_PAI,CPF,NOME_MAE,RG_MAE,ORGEXPRG_MAE,DTRG_MAE,
CPF_MAE,ENDERECO,BAIRRO,NUMERO,CEP,COMPLEMENTO,MUNICIPIO,FONECONTATO,FONECELULAR,EMAIL,OBS)
 values ('$txtinep','$txtturma','$txtnaluno','$txtdtnascimento','$selectsexo','$txtcertidao','$txtfolha','$txtlivro','$cod_estado','$cod_cidades','$txtpai','$txtRGpai','$txtOrgaoExppai','$txtdtemissaorgpai','$cpfpai','$txtmae','$txtRGmae','$txtOrgaoExpmae','$txtdtemissaorgmae','$cpf',
 '$txtEndereco','$txtBairro','$txtnr','$txtcep','$txtcomplemento','$cod_muni','$txtcontato','$txtCelular','$txtEmail','$txtobs')";



if(@mysql_query($sql))
{
  if(mysql_affected_rows() == 1)
   {

   $sql = "select last_insert_id()";
   $resp= mysql_query($sql);
   $id  = mysql_fetch_array($resp);


/**********************************************************************************************************************************************/
  ?>
  

<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">

<script language="javascript">

function DoPrinting()
{
    if (!window.print) {
        alert("Netscape, Internet Explorer 4.0 ou superior!")
        return
    }
    window.print();
}
</script>

<head>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1" />
<title>:: CHAMADA ESCOLAR ::</title>
<style type="text/css">
<!--
.style1 {
	font-size: large;
	font-weight: bold;
}
.style2 {
	font-size: x-large;
	font-weight: bold;
}
.style3 {
	font-size: large;
	font-family: Verdana, Arial, Helvetica, sans-serif;
}
.style5 {font-family: Verdana, Arial, Helvetica, sans-serif}
.style6 {font-size: xx-large; font-weight: bold; font-family: Verdana, Arial, Helvetica, sans-serif; }
.style7 {font-size: x-large; font-weight: bold; font-family: Verdana, Arial, Helvetica, sans-serif; }
.style8 {font-size: large; font-weight: bold; font-family: Verdana, Arial, Helvetica, sans-serif; }
-->
</style>
</head>

<body>
<div align="left">
  <table width="988" border="1" cellpadding="0" cellspacing="0" bordercolor="#000000">
    <tr>
      <td colspan="7" rowspan="4"><table width="100%" border="0" cellpadding="0" cellspacing="0">
          <tr>
            <td width="120" class="style5"><div align="center"><img src="../img/logo_brazil.jpg" width="113" height="118" /></div></td>
            <td width="706" class="style5"><p align="center" class="style2">GOVERNO DO ESTADO DE ROND�NIA<br>
			SECRETARIA DE ESTADO DE EDUCA��O - SEDUC<br>
			GERENCIA DE TECNOLOGIA DA INFORMA��O - GTI</p>
              <p align="center" class="style2"></p></td>
          </tr>
      </table></td>
      <td width="131" height="36" bgcolor="#CCCCCC"><div align="center" class="style3">DATE </div></td>
    </tr>
    <tr>
      <td height="46"><div align="center" class="style3"><span class="style5"></span><span class="style5"><? echo $data1 ?></span></div></td>
    </tr>
    <tr>
      <td height="47" bgcolor="#CCCCCC"><div align="center" class="style3">GTI</div></td>
    </tr>
    <tr>
      <td height="38" class="style3"><div align="center"><? echo $nte; ?></div></td>
    </tr>
    <tr>
      <td height="68" colspan="8" bgcolor="#999999"><div align="center" class="style7">CHAMADA ESCOLAR - 2013- SEDUC - RO</div></td><br>
    </tr>

    <tr>
      <td height="49" colspan="8"><div align="left" class="style7"><span class="style8"><br />
        Matricula:        <?echo  $id[0]?>    <br>
        Nome do Aluno:    <?echo $txtnaluno?> <br>
        Turma:            <?echo $descricao_turma?> <br>
        Sexo:             <?echo $selectsexo?> <br>
        Certid�o:         <?echo $txtcertidao?> <br>

        Certid�o:         <?echo $txtcertidao?> <br>
        Livro:            <?echo $txtlivro?> <br>
        Folha:            <?echo $txtfolha?> <br>


        Nome da M�e:     <?echo $txtpai?> <br>
        CPF:             <?echo $cpfpai?> <br>

        Nome da M�e:       <?echo $txtmae?> <br>
        CPF:               <?echo $cpf?> <br>


        Endere�o:          <?echo $txtEndereco?> <br>
        Bairro:            <?echo $txtBairro?> <br>
        Numero:            <?echo $txtnr?> <br>
        CEP:               <?echo $txtcep?> <br>



		</div></td>
    </tr>


    <tr>
      <td height="20" colspan="8"><div align="center" class="style7">
      </td>
    </tr>

  <tr>
      <td height="2" colspan="2" bgcolor="#CCCCCC" class="style3"><div align="center" class="style5"><strong>Protocolo de Matricula</strong></div>	  </td>
      <td colspan="6" bgcolor="#CCCCCC" class="style3"><div align="center" class="style5"><strong>DATA </strong></div></td>
    </tr>


    <tr>
      <td>
____________________________________________________________________________________________________<br><br>
____________________________________________________________________________________________________<br><br>
_____________________________________________________________________________________________________<br><br>
_____________________________________________________________________________________________________<br><br>
  	  </td>
  </tr>
 </table>
</div>

<tr>
<td>
&nbsp&nbsp
</td>
</tr>
<tr>
 <br/>
    <tr>
  	  <td height="2" colspan="2" bgcolor="#CCCCCC" class="style3"><div class="style5">
	  <strong><center><BR><BR>

	  <br>

	  <BR><BR><BR>
	 _________________________
	<BR>
      Dire��o
	 <BR><BR><BR>
	  </strong></div></td>
    </tr>



<td align="center">
<form>
  <input type="button"  value="Imprimir a p�gina"   onClick="DoPrinting()" />
  <input type="button" value=" Voltar " onclick="location.href='mnadmescolar.php';">
</form>
</td>
</tr>
</body>
</html>


 <?
/**********************************************************************************************************************************************/
exit;
   }

} else
   {
        //verifico se nao estao tentando gravar um dado que ja existe, pois usei UNIQUE na tabela
        if(mysql_errno() == 1062)
		  {
                echo $erros[mysql_errno()];
                exit;
          }
		  else
		  {
                echo "Erro nao foi possivel incluir o pedido";
                exit;
          }
        @mysql_close();
     }

 }//select kit

 }//post

?>
