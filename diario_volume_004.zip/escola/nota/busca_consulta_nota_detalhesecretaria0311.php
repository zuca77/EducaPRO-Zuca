<?php
session_start();
if (isset($_SESSION["login_usuario"]))
  {
     $login     =  $_SESSION["login_usuario"];
     $nte       =  $_SESSION["nivel_usuario"];
	 $inep      =  $_SESSION["inep_usuario"] ;
     $ntelogin  =  $_SESSION["nte_login"];
     $cpf1       = $_SESSION["cpf_usuario"];

	 include ("../../funcoes.php");

  }
 else
  {
    		 header("../../Location: login.php");
  }


$id=$_GET["valor"];

$totalcaracter    = strlen($id);
$posicao          = strpos($id, '*');
$turmadiario      = substr($id, 0, $posicao);
$disciplina       = substr($id, $posicao+1,  $totalcaracter);


$sql="SELECT ano, situacao FROM ano where situacao = 'A' and inep = '$inep'";
$resultado=mysql_query($sql) or die (mysql_error());
$linhas=mysql_num_rows($resultado);
if ($linhas>0)
 {
    while($pegar=mysql_fetch_array($resultado))
   {
         $txtano       = $pegar["ano"];
   }
 }




$sql="select * from  turmaprofessor where id = '$turmadiario'";
$resultado=mysql_query($sql) or die (mysql_error());
$linhas=mysql_num_rows($resultado);
if ($linhas>0)
 {
while($pegar=mysql_fetch_array($resultado))
    {
      $id_turma       = $pegar["id_turma"];
      $cpf            = $pegar["cpf"];
      $iddisciplina   = $pegar["id_disciplina"];
      $idprofessor    = $pegar["cpf"];
    }
 }


 $sqlmodalidade = "SELECT modalidade,semestre FROM turma where id = '$turmadiario' and inep = '$inep'";
 $resultadomodalidade=mysql_query($sqlmodalidade) or die (mysql_error());
 $linhasmodalidade=mysql_num_rows($resultadomodalidade);
 if ($linhasmodalidade>0)
 {
    while($pegarmodalidade=mysql_fetch_array($resultadomodalidade))
   {
           $id_modalidade       = $pegarmodalidade["modalidade"];
      	    $semestre             = $pegarmodalidade["semestre"];

   }
 }





  $sql="select * from habilitacao where codigo = '$disciplina'";
  $resultado=mysql_query($sql) or die (mysql_error());
  $linhas=mysql_num_rows($resultado);
  if($linhas>0)
 {
while($pegar=mysql_fetch_array($resultado))
    {
      $descdisciplina      = $pegar["descricao"];
    }
 }


if(!empty($_GET["valor"]))
 {

$sql="SELECT ta.id_aluno, ta.id_turma, a.nome, t.descricao AS descturma,ta.n_chamada,ta.situacao,t.modalidade
FROM  turma t, aluno a, turma_aluno ta
WHERE ta.id_turma = t.id
and   ta.id_aluno = a.id
and   ta.inep     = '$inep'
and   ta.id_turma = '$turmadiario'
order by ta.n_chamada";
$resultado=mysql_query($sql) or die (mysql_error());
$linhas=mysql_num_rows($resultado);

if($linhas>0)
 {
?>
<html>
<head>
 <script language="javascript" src="generic_notabim.js"></script>

<style>
.titulopagina
{
    font-size: 11px;
    color:    #000099;
	background-color:#E8E8E8;
	height:25px;
    font-family: verdana , arial
}

table.bordasimples {border-collapse: collapse;}

table.bordasimples tr td {border:1px solid #CCCCCC;}

.subtitulo
{
	font-family: verdana ;
	font-size: 9pt;
    color: #22408f;
	font-weight: bold;
}

.nomecampo
{
    font-size: 9px;
    color: midnightblue;
    font-family: verdana, arial;
	font-weight: bold;
}
.escrita
{
    font-size: 9px;
    color: #000000;
    font-family: verdana, arial
}
.escritanormal
{
    font-size: 9px;
    color: #000000;
    font-family: verdana, arial;
	font-weight: normal;
}





</style>


<style media="print">
.botao {
display: none;
}
</style>


</head>
<body>

<form name="form" action="altera_nota3bim.php" method="post">
 	   <p>
		 <br>Disciplina -><font size="4" color="#FF0000" style="width:300px"><?echo $descdisciplina;?></font>
 	   </p>

<table border="0" class="bordasimples"  cellspacing="0"  align="center" width="100%" bgcolor=#ffffff>

<?
if (($id_modalidade=='1') || ($id_modalidade=='3')) //regular ou especial
{
?>
<tr>
  <td class="nomecampo"><b>N�</b>
  <td class="nomecampo"><b>Nome</b>
  <td class="nomecampo"><b>Status</b>
  <td class="nomecampo"><b>1�B</b></td>
  <td class="nomecampo"><b>F1</b></td>
  <td class="nomecampo"><b>2�B</b></td>
  <td class="nomecampo"><b>F2</b></td>
  <td class="nomecampo"><b>3�B</b></td>
  <td class="nomecampo"><b>F3</b></td>
  <td class="nomecampo"><b>4�B</b></td>
  <td class="nomecampo"><b>F4</b></td>
  
  <td class="nomecampo"><b>R1</b></td>
  <td class="nomecampo"><b>F1</b></td>
  <td class="nomecampo"><b>R2</b></td>
  <td class="nomecampo"><b>F2</b></td>
  <td class="nomecampo"><b>R3</b></td>
  <td class="nomecampo"><b>F3</b></td>
  <td class="nomecampo"><b>R4</b></td>
  <td class="nomecampo"><b>F4</b></td>
  <td class="nomecampo"><b>T.F</b></td>
  <td class="nomecampo"><b>SM</b></td>
  <td class="nomecampo"><b>M.A</b></td>
  <td class="nomecampo"><b>E.F</b></td>
<?
}
else // caso seja eja
{
?>
  <td class="nomecampo"><b>N�</b>
  <td class="nomecampo"><b>Nome</b>
  <td class="nomecampo"><b>Status</b>
  <td class="nomecampo"><b>1�B</b></td>
  <td class="nomecampo"><b>F1</b></td>
  <td class="nomecampo"><b>2�B</b></td>
  <td class="nomecampo"><b>F2</b></td>

  <td class="nomecampo"><b>R1</b></td>
  <td class="nomecampo"><b>F1</b></td>
  <td class="nomecampo"><b>R2</b></td>
  <td class="nomecampo"><b>F2</b></td>
  <td class="nomecampo"><b>T.F</b></td>
  <td class="nomecampo"><b>SM</b></td>
  <td class="nomecampo"><b>M.A</b></td>
  <td class="nomecampo"><b>E.F</b></td>
<?
}
?>

















      <input type="hidden"  id="txtturmadiario" name="txtturmadiario"  value = "<?echo $turmadiario;?>"  style="width:35px" maxlength="5"   onKeyPress="return Enum(event)" readonly="true"/></td>
      <input type="hidden"  id="txtdisciplina" name="txtdisciplina"  value = "<?echo $disciplina;?>"  style="width:35px" maxlength="5"   onKeyPress="return Enum(event)" readonly="true"/></td>
      <input type="hidden"  id="txtprofessor" name="txtprofessor"  value = "<?echo $idprofessor;?>"  style="width:35px" maxlength="5"   onKeyPress="return Enum(event)" readonly="true"/></td>
      <input type="hidden"  id="txtturmaprofessor" name="txtturmaprofessor"  value = "<?echo $id_turma;?>"  style="width:35px" maxlength="5"   onKeyPress="return Enum(event)" readonly="true"/></td>


</tr>
<?
while($pegar=mysql_fetch_array($resultado))
{
      $id_aluno         =  $pegar["id_aluno"];
      $n_chamada        =  $pegar["n_chamada"];
      $nome_aluno       =  $pegar["nome"];
      $situacao         =  $pegar["situacao"];



if (($id_modalidade=='1') || ($id_modalidade=='3')) //regular ou especial
{
   $sqlnota="SELECT n.id as id_nota, n.id_turma, h.descricao AS disciplina, t.descricao AS descturma, n.id_disciplina, n.id_professor,
   n.nota1,n.nota2,n.nota3,n.nota4,sum(n.nota1+n.nota2+n.nota3+n.nota4) as soma_bimestre,
   sum(n.nota1+n.nota2) as soma_bimestre_eja,
   avg(n.nota1+n.nota2+n.nota3+n.nota4) as media_anual,
   avg(n.nota1+n.nota2) as media_anual_eja,
   ta.n_chamada,n.t_falta1,n.t_falta2,n.t_falta3,n.t_falta4,ta.situacao,
   recuperacao1,recuperacao2,recuperacao3,recuperacao4,t_falta_rec1,t_falta_rec2,t_falta_rec3,t_falta_rec4,
   sum(n.t_falta1+n.t_falta2+n.t_falta3+n.t_falta4+t_falta_rec1+t_falta_rec2+t_falta_rec3+t_falta_rec4) as total_faltas,
   sum(n.t_falta1+n.t_falta2+t_falta_rec1+t_falta_rec2) as total_faltas_eja,examefinal
   FROM nota_aluno n, turma_aluno ta, habilitacao h, turma t
        WHERE
        ta.id_aluno = n.id_aluno
        AND ta.ano = n.ano
        AND ta.inep = n.inep
        AND ta.id_turma = n.id_turma
        AND h.codigo = n.id_disciplina
        AND t.id = ta.id_turma
        AND ta.ano = '$txtano'        
        and ta.inep         ='$inep'
        and n.id_disciplina = '$disciplina'
        and ta.id_turma = '$turmadiario'
        and ta.id_aluno = '$id_aluno'
        and ta.id_turma = t.id";


  }
else
  {
  $sqlnota="SELECT n.id as id_nota, n.id_turma, h.descricao AS disciplina, t.descricao AS descturma, n.id_disciplina, n.id_professor,
  n.nota1,n.nota2,n.nota3,n.nota4,sum(n.nota1+n.nota2+n.nota3+n.nota4) as soma_bimestre,
  sum(n.nota1+n.nota2) as soma_bimestre_eja,
  avg(n.nota1+n.nota2+n.nota3+n.nota4) as media_anual,
  avg(n.nota1+n.nota2) as media_anual_eja,
  ta.n_chamada,n.t_falta1,n.t_falta2,n.t_falta3,n.t_falta4,ta.situacao,
  recuperacao1,recuperacao2,recuperacao3,recuperacao4,t_falta_rec1,t_falta_rec2,t_falta_rec3,t_falta_rec4,
  sum(n.t_falta1+n.t_falta2+n.t_falta3+n.t_falta4+t_falta_rec1+t_falta_rec2+t_falta_rec3+t_falta_rec4) as total_faltas,
  sum(n.t_falta1+n.t_falta2+t_falta_rec1+t_falta_rec2) as total_faltas_eja,examefinal
  FROM nota_aluno n, turma_aluno ta, habilitacao h, turma t
  WHERE
   ta.id_aluno = n.id_aluno
   AND ta.ano = n.ano
   AND ta.inep = n.inep
   AND ta.id_turma = n.id_turma
   AND h.codigo = n.id_disciplina
   AND t.id = ta.id_turma
   AND ta.ano = '$txtano'
   and t.semestre  = '$semestre'
   and n.id_disciplina = '$disciplina'
   and ta.id_aluno = '$id_aluno'";
  }


$resultadonota=mysql_query($sqlnota) or die (mysql_error());
$linhasnota=mysql_num_rows($resultadonota);


if ($linhasnota>0)
 {


    while($pegarnota=mysql_fetch_array($resultadonota))
     {
 
    
    

  $mfinal=0;
   $n1 =  $pegarnota["nota1"];
   $n2 =  $pegarnota["nota2"];
   $n3 =  $pegarnota["nota3"];
   $n4 =  $pegarnota["nota4"];
   

   $examefinal =  $pegarnota["examefinal"];


   $nrec1 = $pegarnota["recuperacao1"];
   $nrec2 = $pegarnota["recuperacao2"];
   $nrec3 = $pegarnota["recuperacao3"];
   $nrec4 = $pegarnota["recuperacao4"];


   $bim1 = $pegarnota["bim1"];
   $bim2 = $pegarnota["bim2"];
   $bim3 = $pegarnota["bim3"];
   $bim4 = $pegarnota["bim4"];


    
 
   $id_disciplina = $pegarnota["id_disciplina"];




   if ($n1 > $nrec1)
        {
         $notareal1 = $n1;
        }
  else
       {
          $notareal1 = $nrec1;
       }

   if ($n2 > $nrec2)
        {
         $notareal2 = $n2;
        }
  else
       {
          $notareal2 = $nrec2;
       }

   if ($n3 > $nrec3)
        {
         $notareal3 = $n3;
        }
  else
       {
          $notareal3 = $nrec3;
       }

   if ($n4 > $nrec4)
        {
         $notareal4 = $n4;
        }
  else
       {
          $notareal4 = $nrec4;
       }


   $soma   = ($notareal1+$notareal2+$notareal3+$notareal4);
   $media  = ($soma)/4;
   $mfinal = 0;
   




if (($id_modalidade=='1') || ($id_modalidade=='3')) //regular ou especial
{

?>
<tr>


      <td class = "escrita"><font> <?echo $n_chamada;?> </td>
      <td class = "escrita"><font> <?echo $nome_aluno;?> </td>
      <td class = "escrita"><font> <?echo $situacao;?> </td>
      <td class = "escrita"><font> 
         <?  /*Caso n�o exista nota lancada*/
             
              if ($pegarnota["id_nota"]=="")
                {
                   echo  "SN";
                }
            else
                {
                    echo number_format($n1, 1, ',', '.');
                }
            ?>
         </td>
     
   	  <td class = "escrita"><font> <?echo $pegarnota["t_falta1"];?></td>

  	  <td class = "escrita"><font> 
          <?
             if ($pegarnota["id_nota"]=="")
                {


                   echo  "SN";                
                }
            else
                {
                 echo number_format($n2, 1, ',', '.');
                }
            ?>                  

	</td>

   	  <td class = "escrita"><font> <?echo $pegarnota["t_falta2"];?></td>

  	  <td class = "escrita"><font>
             <?

             if ($pegarnota["id_nota"]=="")
               {
                   echo  "SN";                
               }
            else
                {
                echo number_format($n3, 1, ',', '.');
                }

             ?>
       </td>

   	  <td class = "escrita"><font> <?echo $pegarnota["t_falta3"];?></td>
  	  <td class = "escrita"><font> 
	    	<?
             if ($pegarnota["id_nota"]=="")
               {
                   echo  "SN";                
               }
            else
                {
                echo number_format($n4, 1, ',', '.');
                }
               ?>
       </td>
   	  <td class = "escrita"><font> <?echo $pegarnota["t_falta4"];?></td>


  	  <td class = "escrita"><font> 
            <?
             if ($pegarnota["id_nota"]=="")
               {
                    echo  "SN";
               }
            else
                {
                    echo number_format($nrec1, 1, ',', '.');
                }
            ?>
      </td>
   	  




 
        <td class = "escrita"><font> <?echo $pegarnota["t_falta_rec1"];?></td>
  
	  <td class = "escrita"><font> <?


             if ($pegarnota["id_nota"]=="")
               {
                   echo  "SN";                
               }
            else
                {
              echo number_format($nrec2, 1, ',', '.');
                }


        ?></td>

   	  <td class = "escrita"><font> <?echo $pegarnota["t_falta_rec2"];?></td>


  	  <td class = "escrita"><font> <?


             if ($pegarnota["id_nota"]=="")
               {
                   echo  "SN";                
               }
            else
                {
              echo number_format($nrec3, 1, ',', '.');
                }


          ?></td>
   	  
         <td class = "escrita"> <font> <?echo $pegarnota["t_falta_rec3"];?></td>
  	  
         <td class = "escrita"><font> <?

             if ($pegarnota["id_nota"]=="")
               {
                   echo  "SN";                
               }
            else
                {
              echo number_format($nrec4, 1, ',', '.');
                }



              ?></td>
   	  




       <td class = "escrita"><font> <?echo $pegarnota["t_falta_rec4"];?></td>


   	  <td class = "escrita"><font> <?echo $pegarnota["total_faltas"];?></td>




   	  <td class = "escrita"><font> <?echo  number_format($soma , 1, ',', '.');?></td>
   	  <td class = "escrita"><font> <?echo  number_format($media, 1, ',', '.'); ?></td>
   	  <td class = "escrita"><font> <?echo  $pegarnota["examefinal"];?></td>
  </tr>
<?
}
else // caso seja eja
{


 
   $soma = ($notareal1+$notareal2);
   $media = ($soma)/2;


?>


      <td class = "escrita"><font> <?echo $pegar["n_chamada"];?> </td>
      <td class = "escrita"><font> <?echo $pegar["nome"];?> </td>
      <td class = "escrita"><font> <?echo $pegar["situacao"];?> </td>
  	  <td class = "escrita"><font> <?echo number_format($n1, 1, ',', '.');?></td>
   	  <td class = "escrita"><font> <?echo $pegarnota["t_falta1"];?></td>
  	  <td class = "escrita"><font> <?echo number_format($n2, 1, ',', '.');?></td>
   	  <td class = "escrita"><font> <?echo $pegarnota["t_falta2"];?></td>


  	  <td class = "escrita"><font> <?echo number_format($nrec1, 1, ',', '.');?></td>
   	  <td class = "escrita"><font> <?echo $pegarnota["t_falta_rec1"];?></td>
  	  <td class = "escrita"><font> <?echo number_format($nrec2, 1, ',', '.');?></td>
   	  <td class = "escrita"><font> <?echo $pegarnota["t_falta_rec2"];?></td>

   	  <td class = "escrita"><font> <?echo $pegarnota["total_faltas_eja"];?></td>

   	  <td class = "escrita"><font> <?echo  number_format($soma, 1, ',', '.');?></td>
   	  <td class = "escrita"><font> <?echo  number_format($media, 1, ',', '.'); ?></td>
   	  <td class = "escrita"><font> <?echo  $pegarnota["examefinal"];?></td>
  </tr>

<?
     }//else eja
   }
 }
else // caso nao encontre a nota do aluno
  {

if (($id_modalidade=='1') || ($id_modalidade=='3')) //regular ou especial
{


 ?>
<tr>
      <td class = "escrita"><font> <?echo $n_chamada;?> </td>
      <td class = "escrita"><font> <?echo $nome_aluno;?> </td>
      <td class = "escrita"><font> <?echo $pegar["situacao"];?> </td>
  	  <td><font> <?echo "-";?></td>
   	  <td><font> <?echo "-";?></td>
  	  <td><font> <?echo "-";?></td>
   	  <td><font> <?echo "-";?></td>
  	  <td><font> <?echo "-";?></td>
   	  <td><font> <?echo "-";?></td>
  	  <td><font> <?echo "-";?></td>
   	  <td><font> <?echo "-";?></td>
   	  <td><font> <?echo "-";?></td>
  	  <td><font> <?echo "-";?></td>
   	  <td><font> <?echo "-";?></td>
  	  <td><font> <?echo "-";?></td>
   	  <td><font> <?echo "-";?></td>
  	  <td><font> <?echo "-";?></td>
   	  <td><font> <?echo "-";?></td>
  	  <td><font> <?echo "-";?></td>
   	  <td><font> <?echo "-";?></td>
   	  <td><font> <?echo "-";?></td>
  	  <td><font> <?echo "-";?></td>
   	  <td><font> <?echo "-";?></td>




  </tr>
  <?
  }
else // caso seja eja
  {

  ?>
<tr>
      <td class = "escrita"><font> <?echo $n_chamada;?> </td>
      <td class = "escrita"><font> <?echo $nome_aluno;?> </td>
      <td class = "escrita"><font> <?echo $pegar["situacao"];?> </td>
  	  <td><font> <?echo "-";?></td>
   	  <td><font> <?echo "-";?></td>
  	  <td><font> <?echo "-";?></td>
   	  <td><font> <?echo "-";?></td>
  	  <td><font> <?echo "-";?></td>
   	  <td><font> <?echo "-";?></td>
  	  <td><font> <?echo "-";?></td>
   	  <td><font> <?echo "-";?></td>
   	  <td><font> <?echo "-";?></td>
  	  <td><font> <?echo "-";?></td>
   	  <td><font> <?echo "-";?></td>
  	  <td><font> <?echo "-";?></td>
   	  <td><font> <?echo "-";?></td>
  	  <td><font> <?echo "-";?></td>
   	  <td><font> <?echo "-";?></td>
  </tr>
  <?
     }
   }
 }// while pega nota
} // if pega nota



}



$sql = "select count(*) as total
FROM nota_aluno n, habilitacao h, turma t, aluno a, turma_aluno ta
WHERE n.id_disciplina = h.codigo
AND a.id            = n.id_aluno
AND ta.id_turma     = t.id
AND ta.id_aluno     = a.id
and ta.inep         ='$inep'
and n.id_disciplina = '$disciplina'
and ta.id_turma     = '$turmadiario'
and ta.id_turma = t.id";

 
 $resultado=mysql_query($sql) or die (mysql_error());
 $linhas=mysql_num_rows($resultado);
 while($pegar=mysql_fetch_array($resultado))
{
     $total = $pegar["total"];
}//while

if ($total>0)
  {
?>










<?
}
else
{
?>


<tr><td>Total</td>
   	  <td><font size="2" > <BR> Banco sem informacao. Verifique se realmente as notas foram lancada para esta turma e disciplina<br></td>
  </tr>




<br>
<br>
<tr>
<td align="center" bgcolor="#CCCCCC"><strong><font color="#FF0000" size="1" face="Verdana, Arial, Helvetica, sans-serif">
</tr>

<?
 }



?>

</table>


<table width="100%">
<tr>
<td>
<table border="0"  class="bordasimples" cellspacing="0"  align="center" width="100%" bgcolor=#ffffff>

<tr>
	<td colspan="6"  bgcolor="#EAEAEA"  class="subtitulo" align="center"><b>Assinatura</b></td>
</tr>
<tr>

	<td class="nomecampo"><b>Professor</b></td>
	<td>&nbsp;&nbsp;&nbsp;&nbsp;</td>


	<td class="nomecampo"><b>Supervis�o</b></td>
	<td>&nbsp;&nbsp;&nbsp;&nbsp;</td>
	<td class="nomecampo"><b>Dire��o</b></td>
	<td>&nbsp;&nbsp;&nbsp;&nbsp;</td>
</tr>

</table>



</body>
</html>
