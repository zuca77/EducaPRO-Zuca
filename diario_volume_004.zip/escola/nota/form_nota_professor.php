<?php
require_once __DIR__.'/../../start.php';
$pdo = new Conexao;

Auth::whiteList(array('PROF'));

$title = "Lan�amento de Notas";
$subtitle = 'Liberado para turmas abertas';

$turmasDependencia = Turma::$turmasDependencia;
$turmasMediacaoTecnologica = Turma::$turmasMediacaoTecnologica;

$cargaHorariaAvaliacao = GradeCurricular::CARGA_HORARIA_AVALICACAO;

$disciplinas = array();

$sql = "SELECT DISTINCT t.id, t.descricao 
				FROM turma t
					JOIN turmaprofessor tp ON tp.id_turma = t.id
				WHERE t.inep = '{$inep}'
	        AND ((t.fechado IS NULL) OR (t.fechado = 'N')) 
	        AND t.ano = '{$txtano}'
	        AND tp.cpf = '{$cpf}'
				ORDER BY descricao";
$turmas = $pdo->query($sql);

if(isset($_GET['id_turma']) && !empty($_GET['id_turma']))
{
	$turma = Turma::get($_GET['id_turma']);
	$turmaMediacaoTecnologica = in_array($turma['turmas'], $turmasMediacaoTecnologica);

	if (isset($turma)) {
		$disciplinas = Turma::getDisciplinasProfessor($inep, $turma['id'], $cpf);
		$turmaEja = Turma::modalidadeEja($turma['id']);
	}
}

if(isset($_GET['id_disciplina']) && !empty($_GET['id_disciplina']))
{
	$sql = "SELECT codigo as id, descricao FROM habilitacao WHERE codigo = :id;";
	$sth = $pdo->prepare($sql);
	$sth->bindParam(':id', $_GET['id_disciplina']);
	$disciplina = $sth->execute() ? $sth->fetch() : null;
}

if(isset($disciplina) && isset($turma))
{
	$id_turma = $_GET['id_turma'];
	$id_disciplina = $_GET['id_disciplina'];

	if (in_array($turma['turmas'], $turmasDependencia) || $turmaMediacaoTecnologica) {

		$sql = "SELECT a.id AS id_aluno,ta.n_chamada AS chamada,ta.situacao,t.id,a.nome, sa.descricao AS situacaodesc
						FROM turma_aluno ta,turma t, aluno a,turma_dep_aluno_disciplina dp, tipo_mov_aluno sa
						WHERE ta.id_aluno = a.id
							AND t.inep = '{$inep}'
							AND t.ano = '{$txtano}'
							AND t.id = :id_turma
							AND t.id = ta.id_turma
							AND dp.id_disciplina = :id_disciplina
							AND dp.id_turma = t.id
							AND dp.id_aluno = ta.id_aluno
							AND sa.id = ta.situacao
						ORDER BY ta.n_chamada";
		$sth = $pdo->prepare($sql);
		$sth->bindParam(':id_turma', $id_turma);
		$sth->bindParam(':id_disciplina', $id_disciplina);
	} else {
		$sql = "SELECT a.id AS id_aluno,ta.n_chamada AS chamada,ta.situacao,t.id,a.nome, sa.descricao AS situacaodesc
						FROM turma_aluno ta,turma t, aluno a, tipo_mov_aluno sa
						WHERE ta.id_aluno=a.id
							AND t.inep = '{$inep}'
							AND t.ano = '{$txtano}'
							AND t.id = :id_turma
							AND t.id = ta.id_turma
							AND sa.id = ta.situacao
						ORDER BY ta.n_chamada";
		$sth = $pdo->prepare($sql);
		$sth->bindParam(':id_turma', $id_turma);
	}
	$alunos = $sth->execute() ? $sth->fetchAll() : array();
	$bloqueios = array(SituacaoAluno::REMANEJADO, SituacaoAluno::TRANSFERIDO);

	$id_disciplina_etapa = ($turmaMediacaoTecnologica) ? $_GET['id_disciplina'] : null;
	$etapasLiberadas = Etapa::etapasLiberadas($inep, $txtano, $turma['modalidade'], $id_disciplina_etapa);

	$cargaDisciplina = GradeCurricular::cargaDisciplina($_GET['id_turma'], $_GET['id_disciplina']);
}

?><!DOCTYPE html>
<html>
	<head>
		<?php require_once page_head(); ?>
		<style>tr.row-nota input { width: 60px !important; }</style>
	</head>
	<body>
		<?php require_once page_header(); ?>

		<div class="container">
			<form class="well well-sm" method="get">
				<div class="row">
					<div class="col-md-8">
						<div class="form-group">
							<label for="id_turma">Turma</label>
							<select name="id_turma" id="id_turma" class="form-control chosen" required onchange="this.form.submit()">
								<option value=""></option>
								<?php foreach ($turmas as $t): ?>
									<option value="<?php echo $t['id'] ?>" <?php echo (isset($_GET['id_turma']) && $t['id']==$_GET['id_turma']) ? 'selected' : '' ?>>
										<?php echo $t['descricao'] ?>
									</option>
								<?php endforeach ?>
							</select>
						</div>
					</div>
					<div class="col-md-4">
						<div class="form-group">
							<label for="id_disciplina">Disciplina</label>
							<select name="id_disciplina" id="id_disciplina" class="form-control chosen" onchange="this.form.submit()">
								<option value=""></option>
								<?php foreach ($disciplinas as $d): ?>
									<option value="<?php echo $d['id'] ?>" <?php echo (isset($_GET['id_disciplina']) && $d['id']==$_GET['id_disciplina']) ? 'selected' : '' ?>>
										<?php echo $d['descricao'] ?>
									</option>
								<?php endforeach ?>
							</select>
						</div>
					</div>
				</div>

				<p id="finish">
					<input type="submit" class="btn btn-primary"  value="PESQUISAR">
					<button class="btn btn-default btn-back pull-right">Voltar</button>
				</p>
			</form>

			<?php if(isset($disciplina) && isset($turma)): ?>
			<hr>
			<form class="form-inline submit-wait" action="altera_notas.php" method="post">
				<div class="table-responsive">
					<table class="table table-bordered table-condensed">
						<tr>
							<th width="10">Turma</th>
							<th colspan="2" class="text-primary"><?php echo $turma['descricao'] ?></th>
							<td width="10"><a href="<?php url('escola/nota/form_recuperacao_professor.php') ?>" title="Deselecionar turma" class="btn btn-xs btn-default pull-right">x</a></td>
						</tr>
						<tr>
							<th width="10">Disciplina</th>
							<th class="text-danger"><?php echo $disciplina['descricao']; ?></th>
							<?php if (isset($cargaDisciplina)): ?>
								<th width="10" class="text-right" title="Carga hor�ria">C.H.</th>
								<td><b class="text-warning"><?php echo $cargaDisciplina ?></b></td>
							<?php endif ?>
						</tr>
					</table>
				</div>

				<input type="hidden" name="id_turma" value="<?php echo $turma['id']; ?>">
				<input type="hidden" name="id_disciplina" value="<?php echo $disciplina['id']; ?>">
				<input type="hidden" name="professor" value="<?php echo $cpf; ?>">
				<input type="hidden" name="form_prof" value="<?php echo true ?>">

				<div class="table-responsive">
					<table class="table table-bordered table-condensed table-hover table-striped">
						<thead>
							<tr>
								<th class="text-center" width="30">N�</th>
								<th>Nome do estudante</th>
								<?php if ($turmaMediacaoTecnologica): ?>
									<th width="120" class="text-center">Avalia��o I</th>
									<th width="120" class="text-center">Avalia��o II</th>
									<th width="120" class="text-center">Avalia��o III</th>
									<th width="130" class="text-center">Ava. Extra Classe</th>
								<?php else: ?>
									<th width="120" class="text-center">Nota 1� Bim</th>
									<th width="120" class="text-center">Nota 2� Bim</th>
									<?php if (!$turmaEja): ?>
									<th width="120" class="text-center">Nota 3� Bim</th>
									<th width="120" class="text-center">Nota 4� Bim</th>
									<?php endif ?>
								<?php endif ?>
								<th width="160">Situa&ccedil;&atilde;o</th>
							</tr>
						</thead>
						<tbody>
							<?php foreach($alunos as $aluno):
								$id_aluno = $aluno['id_aluno'];
								$nota = Nota::get($id_turma, $id_disciplina, $id_aluno, null, false);
								$bloqueado = in_array($aluno["situacao"], $bloqueios);

								$disable = $bloqueado ? "disabled" : "";
							?>
							<tr class="row-nota">
								<td class="text-center">
									<input type="hidden" name="id_aluno[]" value="<?php echo $id_aluno; ?>" <?php echo $disable ?>>
									<?php echo $aluno["chamada"]; ?>
								</td>
								<td><?php echo $aluno["nome"]; ?></td>

								<td class="text-center">
								<?php if (in_array(Etapa::BIM1, $etapasLiberadas) || ($turmaMediacaoTecnologica && in_array(Etapa::MODULAR, $etapasLiberadas))): ?>
									<input type="text" name="<?php echo "nota1[{$id_aluno}]"; ?>" class="mask-nota form-control input-sm" maxlength="4" value="<?php echo $nota['nota1'] ?>" id="txtnota" onblur="validacampo(this, 0);" <?php echo $disable ?>>
								<?php else: ?>
									<input type="hidden" name="<?php echo "nota1[{$id_aluno}]"; ?>" value="<?php echo $nota['nota1'] ?>">
									<input type="text" class="mask-nota form-control input-sm" maxlength="4" value="<?php echo $nota['nota1'] ?>" id="txtnota" disabled title="Etapa Bloqueada">
								<?php endif ?>
								</td>

								<td class="text-center">
								<?php if (in_array(Etapa::BIM2, $etapasLiberadas) || ($turmaMediacaoTecnologica && in_array(Etapa::MODULAR, $etapasLiberadas))): ?>
									<input type="text" name="<?php echo "nota2[{$id_aluno}]"; ?>" class="mask-nota form-control input-sm" maxlength="4" value="<?php echo $nota['nota2'] ?>" id="txtnota" onblur="validacampo(this, 0);" <?php echo $disable ?>>
								<?php else: ?>
									<input type="hidden" name="<?php echo "nota2[{$id_aluno}]"; ?>" value="<?php echo $nota['nota2'] ?>">
									<input type="text" class="mask-nota form-control input-sm" maxlength="4" value="<?php echo $nota['nota2'] ?>" id="txtnota" disabled title="Etapa Bloqueada">
								<?php endif ?>
								</td>

								<?php if (!$turmaEja): ?>
								<td class="text-center">
								<?php if (in_array(Etapa::BIM3, $etapasLiberadas) || (($turmaMediacaoTecnologica && in_array(Etapa::MODULAR, $etapasLiberadas)) && $cargaDisciplina > $cargaHorariaAvaliacao)): ?>
									<input type="text" name="<?php echo "nota3[{$id_aluno}]"; ?>" class="mask-nota form-control input-sm" maxlength="4" value="<?php echo $nota['nota3'] ?>" id="txtnota" onblur="validacampo(this, 0);" <?php echo $disable ?>>
								<?php else: ?>
									<input type="hidden" name="<?php echo "nota3[{$id_aluno}]"; ?>" value="<?php echo $nota['nota3'] ?>">
									<input type="text" class="mask-nota form-control input-sm" maxlength="4" value="<?php echo $nota['nota3'] ?>" id="txtnota" disabled title="Etapa Bloqueada">
								<?php endif ?>
								</td>

								<td class="text-center">
								<?php if (in_array(Etapa::BIM4, $etapasLiberadas) || ($turmaMediacaoTecnologica && in_array(Etapa::MODULAR, $etapasLiberadas))): ?>
									<input type="text" name="<?php echo "nota4[{$id_aluno}]"; ?>" class="mask-nota form-control input-sm" maxlength="4" value="<?php echo $nota['nota4'] ?>" id="txtnota" onblur="validacampo(this, 0);" <?php echo $disable ?>>
								<?php else: ?>
									<input type="hidden" name="<?php echo "nota4[{$id_aluno}]"; ?>" value="<?php echo $nota['nota4'] ?>">
									<input type="text" class="mask-nota form-control input-sm" maxlength="4" value="<?php echo $nota['nota4'] ?>" id="txtnota" disabled title="Etapa Bloqueada">
								<?php endif ?>
								</td>
								<?php endif ?>

								<td>
									<small><?php echo $aluno["situacaodesc"]; ?></small>
								</td>
							</tr>
							<?php endforeach; ?>
						</tbody>
						<tfoot>
							<tr>
								<th>Total</th>
								<td colspan="10"><?php echo sizeof($alunos); ?> estudantes</td>
							</tr>
						</tfoot>
					</table>
				</div>

				<div class="well well-sm">
					<button type="submit" class="btn btn-primary btn-submit-wait" onclick="return confirm('Confirma as altera��es?')">SALVAR NOTAS</button>
					<a href="../mnadmescola.php" class="btn btn-default pull-right">Voltar</a>
				</div>
			</form>
			<?php endif; ?>
		</div>

		<?php require_once page_footer(); ?>
	</body>
</html>