<?
session_start();
if (isset($_SESSION["login_usuario"]))
  {
     $login     =  $_SESSION["login_usuario"];
     $nte       =  $_SESSION["nivel_usuario"];
	 $inep      =  $_SESSION["inep_usuario"] ;
     $ntelogin  =  $_SESSION["nte_login"];
     $cpf1       = $_SESSION["cpf_usuario"];

	 include ("../../funcoes.php");

  }
 else
  {
    		 header("../../Location: login.php");
  }



/*include ("../../conexao_mysql.php");

if(file_exists("../../conexao_mysql.php"))
{
        require "../../conexao_mysql.php";

} else
{
        echo "Conex�o nao foi encontrado";
        exit;
}

     include ("../funcoes.php");
*/


if($_SERVER["REQUEST_METHOD"] == "POST")
{
    $txtturmadiario	           = $_POST["txtturmadiario"];
    $txtdisciplina	           = $_POST["txtdisciplina"];
    $txtprofessor	           = $_POST["txtprofessor"];
    $txtturmaprofessor	       = $_POST["txtturmaprofessor"];
}
/*----------------------------------------------------------------*/


if (trim($inep)=='')
   {
    echo "<html><head><title>Resposta !!!</title></head>";
    echo "<body background=\"background_mensagens.jpg\" style=\"background-attachment:fixed; background-repeat:no-repeat\">";
    echo "<br><br><br>";
    echo "<center><img src=\"faleconosco/atencao.gif\" alt=\"\"><p><font color=\"#FF0000\" face=\"Verdana\" size=\"4\"><blink>Escola n�o localizada.!</blink> <b></b></font></center>";
    echo "<br><br><center><a href=\"form_nota3bim_professor.php\"><img src=\"faleconosco/button_voltar2_.gif\" alt=\"Voltar\" border=\"0\" /></a></center>";
    echo "</body></html>";
    exit;
   }




if (trim($txtturmadiario)=='')
   {
    echo "<html><head><title>Resposta !!!</title></head>";
    echo "<body background=\"background_mensagens.jpg\" style=\"background-attachment:fixed; background-repeat:no-repeat\">";
    echo "<br><br><br>";
    echo "<center><img src=\"faleconosco/atencao.gif\" alt=\"\"><p><font color=\"#FF0000\" face=\"Verdana\" size=\"4\"><blink>Turma n�o definida.!</blink> <b></b></font></center>";
    echo "<br><br><center><a href=\"form_nota3bim_professor.php\"><img src=\"faleconosco/button_voltar2_.gif\" alt=\"Voltar\" border=\"0\" /></a></center>";
    echo "</body></html>";
    exit;
   }







$dia = date('d');
$mes = date('m');
$ano = date('Y');
$data =$ano.".".$mes.".".$dia;


$sql="SELECT ano, situacao FROM ano where situacao = 'A' and inep = '$inep'";
$resultado=mysql_query($sql) or die (mysql_error());
$linhas=mysql_num_rows($resultado);
if ($linhas>0)
 {
    while($pegar=mysql_fetch_array($resultado))
   {
         $ano       = $pegar["ano"];
   }
 }


$sqlcabeca="select * from  nota_cabecalho where id_turma = '$txtturmadiario'  and inep= '$inep' and id_disciplina='$txtdisciplina'  and ano='$ano' and bimestre = '3BIM'";
$resultado=mysql_query($sqlcabeca) or die (mysql_error());
$linhas=mysql_num_rows($resultado);
$achou = $linhas;

if ($linhas<=0)
{
      $sql    = "insert into nota_cabecalho (inep,id_turma,data,usuario,ano,id_disciplina,id_turmaprofessor,bimestre)
      values ('$inep','$txtturmadiario','$data','$cpf','$ano','$txtdisciplina','$txtturmaprofessor','3BIM')";

   if (@mysql_query($sql))
      {
        if(mysql_affected_rows() == 1)
    		{
            }
       }
    else
      {
        //verifico se nao estao tentando gravar um dado que ja existe, pois usei UNIQUE na tabela
        if(mysql_errno() == 1062)
		  {
                echo $erros[mysql_errno()];
                exit;
          }
		  else
		  {
                echo "Erro nao foi possivel efetuar o cadastro.";//provalmente caminho de banco de dados
                exit;
          }
        @mysql_close();
     }
   }





if(isset($_POST[txtidaluno]))
         {
$contaaceito=0;
$contarejeitado=0;

  for($i = 0; $i < count($_POST["txtidaluno"]); $i++)
    {
  //echo "a opcao ".$_POST[opc][$i]."foi selecionada!<br/>";
         $idaluno               =$_POST[txtidaluno][$i];
         $nota                  =$_POST[txtnota][$i];
         $falta                 =$_POST[txtfalta][$i];




      $sql_situacao="SELECT situacao FROM turma_aluno where id_aluno = '$idaluno'
      and inep = '$inep'
      and id_turma = '$txtturmadiario'";
      $resultado_situacao=mysql_query($sql_situacao) or die (mysql_error());
      $linhas_situacao=mysql_num_rows($resultado_situacao);
      if ($linhas_situacao>0)
       {
         while($pegar_situacao=mysql_fetch_array($resultado_situacao))
        {
         $situacao_aluno       = $pegar_situacao["situacao"];
        }
       }







if (($situacao_aluno == '1') || ($situacao_aluno == '8'))
{
   if ($situacao_aluno == '1')
     {
   /*Verifica se a turma e de dependencia para permitir lancamento de nota tanto regular como dependencia*/

         

         $sqlturma_nota="select * from  nota_aluno where  id_aluno = '$idaluno' and inep= '$inep'
         and id_disciplina='$txtdisciplina' and ano = '$ano' and id_turma = '$txtturmadiario'";
         $resultado_diario_nota=mysql_query($sqlturma_nota) or die (mysql_error());
         $linhasturma_diario_nota=mysql_num_rows($resultado_diario_nota);
         if ($linhasturma_diario_nota>0)
               {
              while($pegar_nota=mysql_fetch_array($resultado_diario_nota))
                  	  {
             	        $id_turma_bd_nota       =$pegar_nota["id_turma"];
                      $inep_bd                =$pegar_nota["inep"];
                       }
                 }

  
         


       $sqlturma_diario="select * from  turma  where  id = '$id_turma_bd_nota'
                            and ((turmas = '75')
                            or (turmas   = '76')
                            or (turmas   = '77')
                            or (turmas   = '78')
                            or (turmas   = '79'))";
         $resultado_diario=mysql_query($sqlturma_diario) or die (mysql_error());
         $linhasturma_diario=mysql_num_rows($resultado_diario);
         if ($linhasturma_diario>0)
               {
               $turma_de_dependencia = '1';
               }
          else
              {
              $turma_de_dependencia = '0';

              }




        if   ($turma_de_dependencia == '1')
            {

             $sql="select * from  nota_aluno n, turma t where  id_aluno = '$idaluno'
             and n.id_disciplina='$txtdisciplina'
             and t.ano = '$ano'
             and n.id_turma = t.id and  ((turmas = '75')
                            or (turmas   = '76')
                            or (turmas   = '77')
                            or (turmas   = '78')
                            or (turmas   = '79')) and nota2 >=0";
             $resultado=mysql_query($sql) or die (mysql_error());
             $linhas=mysql_num_rows($resultado);


            }
        else
            {

               $sql="select * from  nota_aluno n, turma t where  id_aluno = '$idaluno'
               and n.id_disciplina='$txtdisciplina'
               and t.ano = '$ano'
               and n.id_turma = t.id and not ((turmas = '75')
                            or (turmas   = '76')
                            or (turmas   = '77')
                            or (turmas   = '78')
                            or (turmas   = '79')) and nota2 >=0";
               $resultado=mysql_query($sql) or die (mysql_error());
               $linhas=mysql_num_rows($resultado);

             }


/**********************************************/


   }

else if ($situacao_aluno == '8')
     {
         $sql="select * from  nota_aluno where  id_aluno = '$idaluno'
         and inep= '$inep'
         and id_disciplina='$txtdisciplina'
         and ano = '$ano'
         and id_turma = '$txtturmadiario'";
         $resultado=mysql_query($sql) or die (mysql_error());
         $linhas=mysql_num_rows($resultado);
      }


if ($linhas<=0)
 {

     /*   echo "$i - Aluno $idaluno *";
        echo "$i - Nota  $nota *";
         echo "$i - Falta $falta *";
       */

          $sql = "insert into nota_aluno (inep,id_professor,id_aluno,id_turma,data,usuario,ano,nota3,t_falta3,id_disciplina,id_turmaprofessor,bim3)
          values ('$inep','$txtprofessor','$idaluno','$txtturmadiario','$data','$cpf1','$ano','$nota','$falta','$txtdisciplina','$txtturmaprofessor','S')";


     if (@mysql_query($sql))
      {
        if(mysql_affected_rows() == 1)
    		{




 /***************************Grava no Auditoria***************************************************************/



   $sqlauditoria = "insert into nota_auditoria (inep,id_professor,id_aluno,id_turma,data,usuario,ano,nota,falta,id_disciplina,id_etapa,situacao)
   values ('$inep','$txtprofessor','$idaluno','$txtturmadiario','$data','$cpf1','$ano','$nota','$falta','$txtdisciplina','3','IP')";
   if (@mysql_query($sqlauditoria))
        {
        if(mysql_affected_rows() == 1)
    		{
            }
        }
       else
        {
        //verifico se nao estao tentando gravar um dado que ja existe, pois usei UNIQUE na tabela
        if(mysql_errno() == 1062)
		      {
                echo $erros[mysql_errno()];
                exit;
              }
		  else
		    {
                echo "Erro nao foi possivel efetuar o cadastro.";//provalmente caminho de banco de dados
                exit;
            }
        }
/*******************************Fim nota auditoria******************************************************************************************************/




















            $contaaceito=$contaaceito+1;
             /*Dados Gravado*/
            }
       }
    else
      {
        //verifico se nao estao tentando gravar um dado que ja existe, pois usei UNIQUE na tabela
        if(mysql_errno() == 1062)
		  {
                echo $erros[mysql_errno()];
                exit;
          }
		  else
		  {
                echo "Erro nao foi possivel efetuar o cadastro.";//provalmente caminho de banco de dados
                exit;
          }
        @mysql_close();
     }
   }
  else
    {


       if ('S' ==  mysql_result($resultado, 0,"bim3"))
         {
            $contarejeitado=$contarejeitado +1;
          }
        else
        {
        /*
         echo " Aluno $idaluno *";
         echo " - Nota  $nota *";
         echo " - Falta $falta *";


         echo "turmA $txtturmadiario";
         echo "PROFESSOR $txtprofessor";
         echo "INEP $inep";
         echo "DISCIPLINA $txtdisciplina";
         echo "ALUNO $idaluno";
          */

         $sqlaltera = "update nota_aluno set  nota3 ='$nota', t_falta3 = '$falta', bim3 = 'S'
         where   id_aluno = '$idaluno'  and id_disciplina='$txtdisciplina' and ano = '$ano'";



         if (@mysql_query($sqlaltera))
              {

                if(mysql_affected_rows() == 1)
    		         {





 /***************************Grava no Auditoria***************************************************************/



   $sqlauditoria = "insert into nota_auditoria (inep,id_professor,id_aluno,id_turma,data,usuario,ano,nota,falta,id_disciplina,id_etapa,situacao)
   values ('$inep','$txtprofessor','$idaluno','$txtturmadiario','$data','$cpf1','$ano','$nota','$falta','$txtdisciplina','3','IP')";
   if (@mysql_query($sqlauditoria))
        {
        if(mysql_affected_rows() == 1)
    		{
            }
        }
       else
        {
        //verifico se nao estao tentando gravar um dado que ja existe, pois usei UNIQUE na tabela
        if(mysql_errno() == 1062)
		      {
                echo $erros[mysql_errno()];
                exit;
              }
		  else
		    {
                echo "Erro nao foi possivel efetuar o cadastro.";//provalmente caminho de banco de dados
                exit;
            }
        }
/*******************************Fim nota auditoria******************************************************************************************************/


                       $contaaceito=$contaaceito+1;
                       /*Dados Gravado*/
                              }
              }

       else
          {
             //verifico se nao estao tentando gravar um dado que ja existe, pois usei UNIQUE na tabela
             if(mysql_errno() == 1062)
		       {
                 echo $erros[mysql_errno()];
                 exit;
               }
		     else
		       {
                  echo "Erro nao foi possivel efetuar o cadastro.";//provalmente caminho de banco de dados
                  exit;
               }
             @mysql_close();
           }

      }

    }
    
}//situacao


} //for

}
else
   {
	echo "<html><head><title>Resposta !!!</title></head>";
	echo "<body background=\"background_mensagens.jpg\" style=\"background-attachment:fixed; background-repeat:no-repeat\">";
	echo "<br><br><br>";
	echo "<center><img src=\"faleconosco/atencao.gif\" alt=\"\"><p><font color=\"#ff6600\" face=\"Verdana\" size=\"4\">Nenhuma Nota Alterada! <b></b></font></center>";
	echo "<br><br><center><a href=\"form_nota3bim_professor.php\"><img src=\"faleconosco/button_voltar2_.gif\" alt=\"Voltar\" border=\"0\" /></a></center>";
	echo "</body></html>";
       exit;
    }




	echo "<html><head><title>Resposta !!!</title></head>";
	echo "<body background=\"background_mensagens.jpg\" style=\"background-attachment:fixed; background-repeat:no-repeat\">";
	echo "<br><br><br>";
	echo "<center><img src=\"faleconosco/atencao.gif\" alt=\"\"><p><font color=\"#ff6600\" face=\"Verdana\" size=\"4\">Total de Notas Inseridas = $contaaceito <br> Total de notas rejeitadas ( Utiliza altera��o de notas ) = $contarejeitado <b></b></font></center>";
	echo "<br><br><center><a href=\"form_nota3bim_professor.php\"><img src=\"faleconosco/button_voltar2_.gif\" alt=\"Voltar\" border=\"0\" /></a></center>";
	echo "</body></html>";








//*******Arquivo de log********************************************************
                  $datalog=date("d-m-Y-H:i:s");
                  $fp = fopen("log/logs.txt", "a",0);
                  // Escreve "exemplo de escrita" no bloco1.txt
                  $assunto="lancamento de nota 3 bimestre modulo professor";
                  $escreve = fwrite($fp, "$cpf,$login,$inep,$nte,$ntelogin,$assunto,$datalog.\r\n");
                 // Fecha o arquivo
                   fclose($abre);



    exit;

?>












