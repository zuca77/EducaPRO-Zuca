<?php
require_once __DIR__.'/../../start.php';
$pdo = new Conexao;

Auth::blackList(array('PROF', 'NAM', 'BF'));

$title = "Lan�amento parcial";

$disciplinas = array();

$modalidadeMediacaoTecnologica = Modalidade::PRESENCIAL_MEDIACAO_TECNOLOGICA;

$sql = "SELECT id, descricao, fechado FROM turma
				WHERE inep = '{$inep}' AND ano = '{$txtano}'
				ORDER BY fechado ASC, descricao";
$turmas = $pdo->query($sql);

$sql = "SELECT id, descricao FROM tp_avaliacao
				WHERE id_modalidade = :id_modalidade;";
$sth = $pdo->prepare($sql);
$sth->bindParam(':id_modalidade', $modalidadeMediacaoTecnologica);
$avaliacoes = $sth->execute() ? $sth->fetchAll() : null;

if(isset($_GET['id_turma']) && !empty($_GET['id_turma'])) {
	$turma = Turma::get($_GET['id_turma']);
	$disciplinas = Turma::getDisciplinasGrade($inep, $_GET['id_turma']);
}

if(isset($turma) && isset($_GET['id_disciplina']) && !empty($_GET['id_disciplina'])) {
	$sql = "SELECT h.codigo as id, h.descricao
					FROM habilitacao h
						JOIN grade_curricular g ON g.id_disciplina = h.codigo
					WHERE h.codigo = :id
						AND g.id_modalidade = :id_modalidade;";
	$sth = $pdo->prepare($sql);
	$sth->bindParam(':id', $_GET['id_disciplina']);
	$sth->bindParam(':id_modalidade', $turma['modalidade']);

	$disciplina = $sth->execute() ? $sth->fetch() : null;
}

if(isset($turma) && isset($disciplina)) {
	$id_turma = $_GET['id_turma'];
	$id_disciplina = $_GET['id_disciplina'];

	$sql = "SELECT tp.id, tp.cpf, s.nome
					FROM turmaprofessor tp
						JOIN servidorrec s ON s.cpf = tp.cpf
					WHERE inep = '{$inep}'
						AND ano = '{$txtano}'
						AND id_turma = :id_turma
						AND id_disciplina = :id_disciplina";
	$sth = $pdo->prepare($sql);
	$sth->bindParam(':id_turma', $id_turma);
	$sth->bindParam(':id_disciplina', $id_disciplina);
	$turmaprofessor = $sth->execute() ? $sth->fetch() : null;

	$sql = "SELECT ta.id, a.id AS id_aluno,ta.n_chamada,ta.situacao,a.nome, sa.descricao AS situacaodesc
					FROM turma_aluno ta
						JOIN turma t ON ta.id_turma = t.id
						JOIN aluno a ON ta.id_aluno = a.id
						JOIN tipo_mov_aluno sa ON ta.situacao = sa.id
					WHERE t.inep = '{$inep}'
						AND t.ano = '{$txtano}'
						AND t.id = :id_turma
					ORDER BY ta.n_chamada";
	$sth = $pdo->prepare($sql);
	$sth->bindParam(':id_turma', $id_turma);
	$alunos = $sth->execute() ? $sth->fetchAll() : array();
	$bloqueios = array(SituacaoAluno::REMANEJADO);
}

if (isset($_GET['id_avaliacao']) && !empty($_GET['id_avaliacao'])) {
	$sql = "SELECT id, descricao FROM tp_avaliacao
					WHERE id = :id;";
	$sth = $pdo->prepare($sql);
	$sth->bindParam(':id', $_GET['id_avaliacao']);
	$avaliacao = $sth->execute() ? $sth->fetch() : null;
}

if(isset($turma) && isset($_GET['id_aluno']) && !empty($_GET['id_aluno'])) {
	$sql = "SELECT ta.id, a.id AS id_aluno,ta.n_chamada,ta.situacao,a.nome, sa.descricao AS situacaodesc
					FROM turma_aluno ta
						JOIN turma t ON ta.id_turma = t.id
						JOIN aluno a ON ta.id_aluno = a.id
						JOIN tipo_mov_aluno sa ON ta.situacao = sa.id
					WHERE t.inep = '{$inep}'
						AND t.ano = '{$txtano}'
						AND t.id = :id_turma
						AND ta.id = :id
					ORDER BY ta.n_chamada";
	$sth = $pdo->prepare($sql);
	$sth->bindParam(':id', $_GET['id_aluno']);
	$sth->bindParam(':id_turma', $turma['id']);

	$turmaAluno = $sth->execute() ? $sth->fetch() : null;

	$nota = Nota::get($turma['id'], $disciplina['id'], $turmaAluno['id_aluno']);
	$notasParciais = NotaParcial::getByNota($nota['id'], $_GET['id_avaliacao']);
	$notaAtual = NotaParcial::getByAvaliacao($nota, $_GET['id_avaliacao']);
	$faltasAtual = NotaParcial::getFaltasByAvaliacao($nota, $_GET['id_avaliacao']);
}

?><!DOCTYPE html>
<html>
	<head>
		<?php require_once page_head(); ?>
	</head>
	<body>
		<?php require_once page_header(); ?>

		<div class="container">
			<form class="well well-sm" method="get">
				<div class="row">
					<div class="col-md-8">
						<div class="form-group">
							<label for="id_turma">Turma</label>
							<select name="id_turma" id="id_turma" class="form-control chosen-deselect" required onchange="this.form.submit()">
								<option value="">Selecione a turma</option>
								<?php foreach ($turmas as $t): ?>
									<option value="<?php echo $t['id'] ?>" <?php echo (isset($_GET['id_turma']) && $t['id']==$_GET['id_turma']) ? 'selected' : '' ?>>
										<?php echo $t['descricao'] ?>
										<?php echo $t['fechado'] == 'S' ? '(FECHADA)' : '(ABERTA)' ?>
									</option>
								<?php endforeach ?>
							</select>
						</div>
					</div>
					<div class="col-md-4">
						<div class="form-group">
							<label for="id_disciplina">Disciplina</label>
							<select name="id_disciplina" id="id_disciplina" class="form-control chosen-deselect" onchange="this.form.submit()">
								<option value="">Selecione a disciplina</option>
								<?php foreach ($disciplinas as $d): ?>
									<option value="<?php echo $d['id'] ?>" <?php echo (isset($_GET['id_disciplina']) && $d['id']==$_GET['id_disciplina']) ? 'selected' : '' ?>>
										<?php echo $d['descricao'] ?>
									</option>
								<?php endforeach ?>
							</select>
						</div>
					</div>
				</div>

				<div class="row">
					<div class="col-md-8">
						<div class="form-group">
							<label for="id_aluno">Aluno</label>
							<select name="id_aluno" id="id_aluno" class="form-control chosen" onchange="this.form.submit()">
								<option value="">Selecione o aluno</option>
								<?php foreach ($alunos as $alu): ?>
									<option value="<?php echo $alu['id'] ?>" <?php selected(isset($_GET['id_aluno']) && !empty($_GET['id_aluno']) && $alu['id'] == $_GET['id_aluno']) ?>>
										#<?php echo $alu['n_chamada'] ?> <?php echo $alu['nome'] ?>
										(<?php echo $alu['situacaodesc'] ?>)
									</option>
								<?php endforeach ?>
							</select>
						</div>
					</div>
					<div class="col-md-4">
						<div class="form-group">
							<label for="id_avaliacao">Avalia��o</label>
							<select name="id_avaliacao" id="id_avaliacao" class="form-control" onchange="this.form.submit()">
								<option value="">Selecione a valia��o</option>
								<?php foreach ($avaliacoes as $ava): ?>
								<option value="<?php echo $ava['id'] ?>" <?php selected(isset($_GET['id_avaliacao']) && !empty($_GET['id_avaliacao']) && $ava['id'] == $_GET['id_avaliacao']) ?>>
									<?php echo $ava['descricao'] ?>
								</option>
								<?php endforeach ?>
							</select>
						</div>
					</div>
				</div>
			</form>

		<?php if(isset($disciplina) && isset($turma)): ?>
		<hr>
		<table class="table table-bordered table-striped">
			<tr>
				<th width="20">Turma</th>
				<td><b class="text-primary"><?php echo $turma['descricao'] ?></b></td>
				<th width="20">Disciplina</th>
				<td><b class="text-danger"><?php echo $disciplina['descricao']; ?></b></td>
				<td width="10">
					<a href="<?php url('escola/nota/form_nota.php') ?>" class="btn btn-xs btn-default pull-right">x</a>
				</td>
			</tr>
			<tr>
				<th>Professor</th>
				<td colspan="4"><b class="text-success"><?php echo $turmaprofessor['cpf'] ?> <?php echo $turmaprofessor['nome'] ?></b></td>
			</tr>
		</table>
		<?php endif; ?>

		<?php if (isset($avaliacao) && isset($turmaAluno)): ?>
		<form class="submit-wait" action="insere_nota_parcial.php" method="POST">
			<input type="hidden" name="id_aluno" value="<?php echo $turmaAluno['id_aluno']; ?>">
			<input type="hidden" name="id_turma" value="<?php echo $turma['id']; ?>">
			<input type="hidden" name="id_disciplina" value="<?php echo $disciplina['id']; ?>">
			<input type="hidden" name="id_turmaprofessor" value="<?php echo $turmaprofessor['id']; ?>">
			<input type="hidden" name="id_avaliacao" value="<?php echo $avaliacao['id']; ?>">
			<input type="hidden" name="id_aluno_turma" value="<?php echo $turmaAluno['id']; ?>">

			<table class="table table-bordered table-condensed">
				<tr>
					<th width="40">N�</th>
					<th>Nome do aluno</th>
					<th width="170"><?php echo $avaliacao['descricao'] ?></th>
					<th width="140">Faltas</th>
					<th width="160">Situa��o</th>
				</tr>
				<tr>
					<td><?php echo $turmaAluno['n_chamada'] ?></td>
					<td><?php echo $turmaAluno['nome'] ?></td>
					<td>
						<input type="text" readonly class="form-control input-sm mask-nota" placeholder="Nota" value="<?php echo $notaAtual ?>">
					</td>
					<td>
						<input type="number" name="faltas" class="form-control input-sm" placeholder="Faltas" required value="<?php echo $faltasAtual ?>">
					</td>
					<td><small><?php echo $turmaAluno['situacaodesc'] ?></small></td>
				</tr>

				<tr>
					<th class="text-center" colspan="2">Avali��es parciais</th>
					<th>Nota parcial</th>
					<th>Data</th>
					<th></th>
				</tr>

				<?php foreach ($notasParciais as $np): ?>
				<tr>
					<td class="text-right" colspan="2"><?php echo $np['descricao'] ?></td>
					<td>
						<?php echo $np['nota'] ?>
					</td>
					<td><?php echo formataData($np['data_nota']) ?></td>
					<td>
						<a href="<?php url("escola/nota/exclui_nota_parcial.php?id={$np['id']}&id_nota_aluno={$nota['id']}") ?>" class="btn btn-xs btn-block btn-danger" onclick="return confirm('Confirma excluir nota parcial?')">EXCLUIR NOTA</a>
					</td>
				</tr>
				<?php endforeach ?>
			</table>

			<fieldset class="well well-sm">
				<legend>Adicionar nota parcial</legend>

				<div class="row">
					<div class="col-md-2">
						<div class="form-group">
							<label for="nota">Nota parcial</label>
							<input type="text" id="nota" name="nota" class="form-control mask-nota" placeholder="Nota parcial" required>
						</div>
					</div>
					<div class="col-md-2">
						<div class="form-group">
							<label for="data">Data da nota</label>
							<input type="text" id="data" name="data" class="form-control mask-data" placeholder="Data da nota" value="<?php echo date('d/m/Y') ?>" required>
						</div>
					</div>
					<div class="col-md-6">
						<div class="form-group">
							<label for="obs">Descri��o</label>
							<input type="text" class="form-control" id="obs" name="obs" placeholder="Descri��o da nota" required>
						</div>
					</div>
					<div class="col-md-2">
						<button type="submit" class="btn btn-block btn-success" style="margin-top:20px"><i class="fa fa-plus"></i> ADICIONAR</button>
					</div>
				</div>

			</fieldset>

		</form>
		<?php endif ?>
		</div>

		<?php require_once page_footer(); ?>
	</body>
</html>