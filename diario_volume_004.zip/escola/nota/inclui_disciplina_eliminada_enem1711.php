<?
session_start();
if (isset($_SESSION["login_usuario"]))
  {
     $login     =  $_SESSION["login_usuario"];
     $nte       =  $_SESSION["nivel_usuario"];
	 $inep      =  $_SESSION["inep_usuario"] ;
     $ntelogin  =  $_SESSION["nte_login"];
     $cpf1       = $_SESSION["cpf_usuario"];

	 include ("../../funcoes.php");

  }
 else
  {
    		 header("../../Location: login.php");
  }



$sql="SELECT ano, situacao FROM ano where situacao = 'A' and inep = '$inep'";
$resultado=mysql_query($sql) or die (mysql_error());
$linhas=mysql_num_rows($resultado);
if ($linhas>0)
 {
    while($pegar=mysql_fetch_array($resultado))
   {
         $txtano       = $pegar["ano"];
   }
 }




$dia = date('d');
$mes = date('m');
$ano = date('Y');
$data =$ano.".".$mes.".".$dia;






if($_SERVER["REQUEST_METHOD"] == "POST")
{
    $txtturmadiario	           = $_POST["txtid_turma"];
    $idaluno    	           = $_POST["txtid_aluno"];
    $txtid_ensino              = "2";
    $nota    	               = $_POST["txtnota"];
    $txtid_provao  	           = "2";
    $txtdtmovimento  	       = $_POST["txtdtmovimento"];
    $txtobs  	               = $_POST["txtobs"];
    $txtareaconhecimento  	   = $_POST["txtareaconhecimento"];



$diai = substr($txtdtmovimento, 0,2);
$anoi = substr($txtdtmovimento, -4);
$mesi = substr($txtdtmovimento, -7,2);
$txtdtmovimento=$anoi.".".$mesi.".".$diai;


}


if (trim($inep)=='')
   {
    echo "<html><head><title>Resposta !!!</title></head>";
    echo "<body background=\"background_mensagens.jpg\" style=\"background-attachment:fixed; background-repeat:no-repeat\">";
    echo "<br><br><br>";
    echo "<center><img src=\"faleconosco/atencao.gif\" alt=\"\"><p><font color=\"#FF0000\" face=\"Verdana\" size=\"4\"><blink>Escola n�o localizada.!</blink> <b></b></font></center>";
    echo "<br><br><center><a href=\"form_lancanota_aluno_eliminacao_enem.php\"><img src=\"faleconosco/button_voltar2_.gif\" alt=\"Voltar\" border=\"0\" /></a></center>";
    echo "</body></html>";
    exit;
   }



if (trim($txtturmadiario)=='')
   {
    echo "<html><head><title>Resposta !!!</title></head>";
    echo "<body background=\"background_mensagens.jpg\" style=\"background-attachment:fixed; background-repeat:no-repeat\">";
    echo "<br><br><br>";
    echo "<center><img src=\"faleconosco/atencao.gif\" alt=\"\"><p><font color=\"#FF0000\" face=\"Verdana\" size=\"4\"><blink>Turma n�o definida.!</blink> <b></b></font></center>";
    echo "<br><br><center><a href=\"form_lancanota_aluno_eliminacao_enem.php\"><img src=\"faleconosco/button_voltar2_.gif\" alt=\"Voltar\" border=\"0\" /></a></center>";
    echo "</body></html>";
    exit;
   }

 if (trim($idaluno)=='')
   {
    echo "<html><head><title>Resposta !!!</title></head>";
    echo "<body background=\"background_mensagens.jpg\" style=\"background-attachment:fixed; background-repeat:no-repeat\">";
    echo "<br><br><br>";
    echo "<center><img src=\"faleconosco/atencao.gif\" alt=\"\"><p><font color=\"#FF0000\" face=\"Verdana\" size=\"4\"><blink>Aluno n�o definido.!</blink> <b></b></font></center>";
    echo "<br><br><center><a href=\"form_lancanota_aluno_eliminacao_enem.php\"><img src=\"faleconosco/button_voltar2_.gif\" alt=\"Voltar\" border=\"0\" /></a></center>";
    echo "</body></html>";
    exit;
   }



 if (trim($txtid_ensino)=='')
   {
    echo "<html><head><title>Resposta !!!</title></head>";
    echo "<body background=\"background_mensagens.jpg\" style=\"background-attachment:fixed; background-repeat:no-repeat\">";
    echo "<br><br><br>";
    echo "<center><img src=\"faleconosco/atencao.gif\" alt=\"\"><p><font color=\"#FF0000\" face=\"Verdana\" size=\"4\"><blink>Ensino n�o definido.!</blink> <b></b></font></center>";
    echo "<br><br><center><a href=\"form_lancanota_aluno_eliminacao_enem.php\"><img src=\"faleconosco/button_voltar2_.gif\" alt=\"Voltar\" border=\"0\" /></a></center>";
    echo "</body></html>";
    exit;
   }



 if ($nota < 1.0)
   {
    echo "<html><head><title>Resposta !!!</title></head>";
    echo "<body background=\"background_mensagens.jpg\" style=\"background-attachment:fixed; background-repeat:no-repeat\">";
    echo "<br><br><br>";
    echo "<center><img src=\"faleconosco/atencao.gif\" alt=\"\"><p><font color=\"#FF0000\" face=\"Verdana\" size=\"4\"><blink>Nota n�o pode ser menor que 5.</blink> <b></b></font></center>";
    echo "<br><br><center><a href=\"form_lancanota_aluno_eliminacao_enem.php\"><img src=\"faleconosco/button_voltar2_.gif\" alt=\"Voltar\" border=\"0\" /></a></center>";
    echo "</body></html>";
    exit;
   }



 if (trim($txtobs) == "")
   {
    echo "<html><head><title>Resposta !!!</title></head>";
    echo "<body background=\"background_mensagens.jpg\" style=\"background-attachment:fixed; background-repeat:no-repeat\">";
    echo "<br><br><br>";
    echo "<center><img src=\"faleconosco/atencao.gif\" alt=\"\"><p><font color=\"#FF0000\" face=\"Verdana\" size=\"4\"><b>Campo de Observa��o obrigat�rio</b></font></center>";
    echo "<br><br><center><a href=\"form_lancanota_aluno_eliminacao_enem.php\"><img src=\"faleconosco/button_voltar2_.gif\" alt=\"Voltar\" border=\"0\" /></a></center>";
    echo "</body></html>";
    exit;
   }



 if (trim($txtareaconhecimento == '1') && ($nota < 450))
   {
    echo "<html><head><title>Resposta !!!</title></head>";
    echo "<body background=\"background_mensagens.jpg\" style=\"background-attachment:fixed; background-repeat:no-repeat\">";
    echo "<br><br><br>";
    echo "<center><img src=\"faleconosco/atencao.gif\" alt=\"\"><p><font color=\"#FF0000\" face=\"Verdana\" size=\"4\"><b>Valor deve ser maior ou igual a 450.0</b></font></center>";
    echo "<br><br><center><a href=\"form_lancanota_aluno_eliminacao_enem.php\"><img src=\"faleconosco/button_voltar2_.gif\" alt=\"Voltar\" border=\"0\" /></a></center>";
    echo "</body></html>";
    exit;
   }


 if (trim($txtareaconhecimento == '2') && ($nota < 450))
   {
    echo "<html><head><title>Resposta !!!</title></head>";
    echo "<body background=\"background_mensagens.jpg\" style=\"background-attachment:fixed; background-repeat:no-repeat\">";
    echo "<br><br><br>";
    echo "<center><img src=\"faleconosco/atencao.gif\" alt=\"\"><p><font color=\"#FF0000\" face=\"Verdana\" size=\"4\"><b>Valor deve ser maior ou igual a 450.0</b></font></center>";
    echo "<br><br><center><a href=\"form_lancanota_aluno_eliminacao_enem.php\"><img src=\"faleconosco/button_voltar2_.gif\" alt=\"Voltar\" border=\"0\" /></a></center>";
    echo "</body></html>";
    exit;
   }


 if (trim($txtareaconhecimento == '3') && ($nota < 450))
   {
    echo "<html><head><title>Resposta !!!</title></head>";
    echo "<body background=\"background_mensagens.jpg\" style=\"background-attachment:fixed; background-repeat:no-repeat\">";
    echo "<br><br><br>";
    echo "<center><img src=\"faleconosco/atencao.gif\" alt=\"\"><p><font color=\"#FF0000\" face=\"Verdana\" size=\"4\"><b>Valor deve ser maior ou igual a 450.0</b></font></center>";
    echo "<br><br><center><a href=\"form_lancanota_aluno_eliminacao_enem.php\"><img src=\"faleconosco/button_voltar2_.gif\" alt=\"Voltar\" border=\"0\" /></a></center>";
    echo "</body></html>";
    exit;
   }

 if (trim($txtareaconhecimento == '4') && ($nota < 450))
   {
    echo "<html><head><title>Resposta !!!</title></head>";
    echo "<body background=\"background_mensagens.jpg\" style=\"background-attachment:fixed; background-repeat:no-repeat\">";
    echo "<br><br><br>";
    echo "<center><img src=\"faleconosco/atencao.gif\" alt=\"\"><p><font color=\"#FF0000\" face=\"Verdana\" size=\"4\"><b>Valor deve ser maior ou igual a 450.0</b></font></center>";
    echo "<br><br><center><a href=\"form_lancanota_aluno_eliminacao_enem.php\"><img src=\"faleconosco/button_voltar2_.gif\" alt=\"Voltar\" border=\"0\" /></a></center>";
    echo "</body></html>";
    exit;
   }

 if (trim($txtareaconhecimento == '5') && ($nota < 450))
   {
    echo "<html><head><title>Resposta !!!</title></head>";
    echo "<body background=\"background_mensagens.jpg\" style=\"background-attachment:fixed; background-repeat:no-repeat\">";
    echo "<br><br><br>";
    echo "<center><img src=\"faleconosco/atencao.gif\" alt=\"\"><p><font color=\"#FF0000\" face=\"Verdana\" size=\"4\"><b>Valor deve ser maior ou igual a 450.0</b></font></center>";
    echo "<br><br><center><a href=\"form_lancanota_aluno_eliminacao_enem.php\"><img src=\"faleconosco/button_voltar2_.gif\" alt=\"Voltar\" border=\"0\" /></a></center>";
    echo "</body></html>";
    exit;
   }



$sqlgerencia = "select * from componente_eliminado where id_aluno = '$idaluno'
                                  and tp_avaliacao = '$txtid_provao' and id_ensino = '$txtid_ensino' and area_conhecimento= '$txtareaconhecimento'";
$resultadoger=mysql_query($sqlgerencia) or die (mysql_error());
$linhas   =mysql_num_rows($resultadoger);
if($linhas>0)
{
                      echo "<html><head><title>Resposta !!!</title></head>";
                      echo "<body background=\"background_mensagens.jpg\" style=\"background-attachment:fixed; background-repeat:no-repeat\">";
                      echo "<br><br><br>";
                      echo "<center><img src=\"faleconosco/atencao.gif\" alt=\"\"><p><font color=\"#FF0000\" face=\"Verdana\" size=\"4\"><b>Aluno j� eliminou esta disciplina.</b></font></center>";
                      echo "<br><br><center><a href=\"form_lancanota_aluno_eliminacao_enem.php\"><img src=\"faleconosco/button_voltar2_.gif\" alt=\"Voltar\" border=\"0\" /></a></center>";
                      echo "</body></html>";
                      exit;
}
else
{
      $sql    = "insert into componente_eliminado (inep,id_aluno,data,usuario,ano,obs,nota,tp_avaliacao,id_ensino,dt_movimento,id_turma,area_conhecimento)
                 values ('$inep','$idaluno','$data','$cpf1','$txtano','$txtobs','$nota','$txtid_provao','$txtid_ensino','$txtdtmovimento','$txtturmadiario','$txtareaconhecimento')";



   if (@mysql_query($sql))
      {
        if(mysql_affected_rows() == 1)
    		{
                      echo "<html><head><title>Resposta !!!</title></head>";
                      echo "<body background=\"background_mensagens.jpg\" style=\"background-attachment:fixed; background-repeat:no-repeat\">";
                      echo "<br><br><br>";
                      echo "<center><img src=\"faleconosco/atencao.gif\" alt=\"\"><p><font color=\"#FF0000\" face=\"Verdana\" size=\"4\"><b>Dados gravados com sucesso.</b></font></center>";
                      echo "<br><br><center><a href=\"form_lanca_nota_eliminacao_componente_enem.php\"><img src=\"faleconosco/button_voltar2_.gif\" alt=\"Voltar\" border=\"0\" /></a></center>";
                      echo "</body></html>";
                      exit;


            }
       }
    else
      {
        //verifico se nao estao tentando gravar um dado que ja existe, pois usei UNIQUE na tabela
        if(mysql_errno() == 1062)
		  {
                echo $erros[mysql_errno()];
                exit;
          }
		  else
		  {
                echo "Erro nao foi possivel efetuar o cadastro.";//provalmente caminho de banco de dados
                exit;
          }
        @mysql_close();
     }
 }










//*******Arquivo de log********************************************************
                  $datalog=date("d-m-Y-H:i:s");
                  $fp = fopen("log/logs.txt", "a",0);
                  $assunto="Elimina��o de Disciplina";
                  $escreve = fwrite($fp, "$cpf,$login,$inep,$nte,$ntelogin,$assunto,$idaluno,$txtdisciplina,$datalog.\r\n");
                  // Fecha o arquivo
                    fclose($fp);
    exit;

?>












