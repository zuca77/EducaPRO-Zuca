<?php
require_once __DIR__.'/../../start.php';
$pdo = new Conexao;

Auth::whiteList(array('PROF'));

$title = "Lan�amento de Recupera��o";
$subtitle = 'Liberado para turmas abertas';

$turmasDependencia = Turma::$turmasDependencia;
$turmasMediacaoTecnologica = Turma::$turmasMediacaoTecnologica;

$cargaHorariaAvaliacao = GradeCurricular::CARGA_HORARIA_AVALICACAO;
$disciplinas = array();

$sql = "SELECT DISTINCT t.id, t.descricao 
				FROM turma t
				INNER JOIN turmaprofessor tp ON tp.id_turma = t.id
				WHERE t.inep = '{$inep}'
	        AND ((t.fechado IS NULL) OR (t.fechado = 'N'))
	        AND t.ano = '{$txtano}'
	        AND tp.cpf = '{$cpf}'
				ORDER BY descricao";

$turmas = $pdo->query($sql);

if(isset($_GET['id_turma']) && !empty($_GET['id_turma']))
{
	$turma = Turma::get($_GET['id_turma']);
	if (isset($turma)) {
		$disciplinas = Turma::getDisciplinasProfessor($inep, $turma['id'], $cpf);
		$turmaEja = Turma::modalidadeEja($turma['id']);
	}
}

if(isset($_GET['id_disciplina']) && !empty($_GET['id_disciplina']))
{
	$sql = "SELECT codigo as id, descricao FROM habilitacao WHERE codigo = :id;";
	$sth = $pdo->prepare($sql);
	$sth->bindParam(':id', $_GET['id_disciplina']);
	$disciplina = $sth->execute() ? $sth->fetch() : null;
} 

if(isset($disciplina) && isset($turma))
{
	$id_turma = $_GET['id_turma'];
	$id_disciplina = $_GET['id_disciplina'];

	$sql = "SELECT cpf FROM turmaprofessor
			WHERE id_turma = :id_turma
			AND id_disciplina = :id_disciplina
			AND ano = :ano";
	$sth = $pdo->prepare($sql);
	$sth->bindParam(':id_turma', $id_turma);
	$sth->bindParam(':id_disciplina', $id_disciplina);
	$sth->bindParam(':ano', $txtano);

	$turmaprofessor = $sth->execute() ? $sth->fetch() : null;

	if (in_array($turma['turmas'], $turmasDependencia) || in_array($turma['turmas'], $turmasMediacaoTecnologica)) {

		$sql = "SELECT a.id AS id_aluno,ta.n_chamada AS chamada,ta.situacao,t.id,a.nome, sa.descricao AS situacaodesc
				FROM turma_aluno ta,turma t, aluno a,turma_dep_aluno_disciplina dp, tipo_mov_aluno sa
				WHERE ta.id_aluno = a.id
				AND t.inep = '{$inep}'
				AND t.ano = '{$txtano}'
				AND t.id = :id_turma
				AND t.id = ta.id_turma
				AND dp.id_disciplina = :id_disciplina
				AND dp.id_turma = t.id
				AND dp.id_aluno = ta.id_aluno
				AND sa.id = ta.situacao
				ORDER BY ta.n_chamada";
		$sth = $pdo->prepare($sql);
		$sth->bindParam(':id_turma', $id_turma);
		$sth->bindParam(':id_disciplina', $id_disciplina);
	} else {
		$sql = "SELECT a.id AS id_aluno,ta.n_chamada AS chamada,ta.situacao,t.id,a.nome, sa.descricao AS situacaodesc
				FROM turma_aluno ta,turma t, aluno a, tipo_mov_aluno sa
				WHERE ta.id_aluno=a.id
				AND t.inep = '{$inep}'
				AND t.ano = '{$txtano}'
				AND t.id = :id_turma
				AND t.id = ta.id_turma
				AND sa.id = ta.situacao
				ORDER BY ta.n_chamada";
		$sth = $pdo->prepare($sql);
		$sth->bindParam(':id_turma', $id_turma);
	}

	$alunos = $sth->execute() ? $sth->fetchAll() : array();
	$turmaEja = Turma::modalidadeEja($id_turma);
	$tipoRecuperacao = Escola::tipoRecuperacao($inep, $txtano, $turma['modalidade']);
	$adereExameFinal = Escola::adereExameFinal($inep, $txtano, $turma['modalidade']);

	$bloqueios = array(SituacaoAluno::REMANEJADO, SituacaoAluno::TRANSFERIDO);
	$etapasLiberadas = Etapa::etapasLiberadas($inep, $txtano, $turma['modalidade']);

	$cargaDisciplina = GradeCurricular::cargaDisciplina($_GET['id_turma'], $_GET['id_disciplina']);
}

?><!DOCTYPE html>
<html>
	<head>
		<?php require_once page_head(); ?>
		<style>tr.row-nota input { width: 60px !important; }</style>
	</head>
	<body>
		<?php require_once page_header(); ?>

		<div class="container">
			<form class="well well-sm" method="get">
				<div class="row">
					<div class="col-md-8">
						<div class="form-group">
							<label for="id_turma">Turma</label>
							<select name="id_turma" id="id_turma" class="form-control chosen" required onchange="this.form.submit()">
								<option value=""></option>
								<?php foreach ($turmas as $t): ?>
									<option value="<?php echo $t['id'] ?>" <?php echo (isset($_GET['id_turma']) && $t['id']==$_GET['id_turma']) ? 'selected' : '' ?>>
										<?php echo $t['descricao'] ?>
									</option>
								<?php endforeach ?>
							</select>
						</div>
					</div>
					<div class="col-md-4">
						<div class="form-group">
							<label for="id_disciplina">Disciplina</label>
							<select name="id_disciplina" id="id_disciplina" class="form-control chosen" onchange="this.form.submit()">
								<option value=""></option>
								<?php foreach ($disciplinas as $d): ?>
									<option value="<?php echo $d['id'] ?>" <?php echo (isset($_GET['id_disciplina']) && $d['id']==$_GET['id_disciplina']) ? 'selected' : '' ?>>
										<?php echo $d['descricao'] ?>
									</option>
								<?php endforeach ?>
							</select>
						</div>
					</div>
				</div>

				<p id="finish">
					<input type="submit" class="btn btn-primary"  value="PESQUISAR">
					<button class="btn btn-default btn-back pull-right">Voltar</button>
				</p>
			</form>

			<?php if(isset($disciplina) && isset($turma)): ?>
			<hr>
			<form class="form-inline submit-wait" action="altera_recuperacao.php" method="post">
				<div class="table-responsive">
					<table class="table table-bordered table-condensed">
						<tr>
							<th width="10">Turma</th>
							<th colspan="2" class="text-primary"><?php echo $turma['descricao'] ?></th>
							<td width="10"><a href="<?php url('escola/nota/form_recuperacao_professor.php') ?>" title="Deselecionar turma" class="btn btn-xs btn-default pull-right">x</a></td>
						</tr>
						<tr>
							<th width="10">Disciplina</th>
							<th class="text-danger"><?php echo $disciplina['descricao']; ?></th>
							<?php if (isset($cargaDisciplina)): ?>
								<th width="10" class="text-right" title="Carga hor�ria">C.H.</th>
								<td><b class="text-warning"><?php echo $cargaDisciplina ?></b></td>
							<?php endif ?>
						</tr>
					</table>
				</div>

				<input type="hidden" name="id_turma" value="<?php echo $turma['id']; ?>">
				<input type="hidden" name="id_disciplina" value="<?php echo $disciplina['id']; ?>">
				<input type="hidden" name="professor" value="<?php echo $turmaprofessor['cpf']; ?>">
				<input type="hidden" name="form_prof" value="<?php echo true ?>">

				<div class="table-responsive">
					<table class="table table-bordered table-condensed table-hover table-striped">
						<thead>
 							<?php if ($tipoRecuperacao == TipoRecuperacao::BIMESTRAL || $tipoRecuperacao == TipoRecuperacao::SEMESTRAL): ?>
							<tr>
								<th colspan="2"></th>
								<?php if ($tipoRecuperacao == TipoRecuperacao::BIMESTRAL): ?>
									<th width="110" class="text-center">1&deg; Bimestre</th>
									<th width="110" class="text-center">2&deg; Bimestre</th>
									<?php if (!$turmaEja): ?>
									<th width="110" class="text-center">3&deg; Bimestre</th>
									<th width="110" class="text-center">4&deg; Bimestre</th>
									<?php endif ?>
								<?php endif ?>
								<?php if($tipoRecuperacao == TipoRecuperacao::SEMESTRAL): ?>
									<th width="110" class="text-center">1&deg; Semestre</th>
									<?php if (!$turmaEja): ?>
										<th width="110" class="text-center">2&deg; Semestre</th>
									<?php endif ?>
								<?php endif ?>

								<?php if ($adereExameFinal): ?>
									<th width="110" class="text-center">Etapa Final</th>
								<?php endif ?>
								<th></th>
							</tr>
							<?php endif ?>

							<tr>
								<th class="text-center" width="30">N&deg;</th>
								<th>Nome do estudante</th>
								<?php if ($tipoRecuperacao == TipoRecuperacao::BIMESTRAL): ?>
									<th class="text-center">Recupera��o</th>
									<th class="text-center">Recupera��o </th>
									<?php if (!$turmaEja): ?>
										<th width="110" class="text-center">Recupera��o</th>
										<th width="110" class="text-center">Recupera��o</th>
									<?php endif ?>
								<?php elseif($tipoRecuperacao == TipoRecuperacao::SEMESTRAL): ?>
									<th width="110" class="text-center">Recupera��o</th>
									<?php if (!$turmaEja): ?>
										<th class="text-center">Recupera��o</th>
									<?php endif ?>
								<?php elseif($tipoRecuperacao == TipoRecuperacao::ANUAL): ?>
									<th width="150" class="text-center">Recupera��o Anual</th>
								<?php elseif($tipoRecuperacao == TipoRecuperacao::PARALELA): ?>
									<th width="120" class="text-center">Recupera��o I</th>
									<th width="120" class="text-center">Recupera��o II</th>
									<th width="120" class="text-center">Recupera��o III</th>
								<?php endif ?>
								<?php if ($adereExameFinal): ?>
									<th class="text-center">Exame Final</th>
								<?php endif ?>
								<th width="160">Situa&ccedil;&atilde;o</th>
							</tr>
						</thead>
						<tbody>
							<?php foreach($alunos as $aluno):
								$id_aluno = $aluno['id_aluno'];
								$nota = Nota::get($id_turma, $id_disciplina, $id_aluno, null, false);
								$bloqueado = in_array($aluno["situacao"], $bloqueios);
								$disable = $bloqueado ? "disabled" : "";
							?>
							<tr class="row-nota">
								<td class="text-center">
									<input type="hidden" name="id_aluno[]" value="<?php echo $id_aluno; ?>" <?php echo $disable; ?>>
									<?php echo $aluno["chamada"]; ?>
								</td>
								<td><?php echo $aluno["nome"]; ?></td>
								<?php if ($tipoRecuperacao == TipoRecuperacao::BIMESTRAL): ?>
									<?php for ($i=1; $i <= ($turmaEja ? 2 : 4); $i++): ?> 
										<td class="text-center">
											<input type="text" name="<?php echo "recuperacao".$i."[{$id_aluno}]"; ?>" class="mask-nota form-control input-sm" maxlength="4" value="<?php echo $nota['recuperacao'.$i] ?>" onblur="validacampo(this, 0);" <?php echo $disable; ?>
											<?php echo !in_array(4+$i, $etapasLiberadas) ? "disabled title=\"Etapa Bloqueada\"" : "" ?>>
										</td>
									<?php endfor; ?>
								<?php endif ?>

								<?php if ($tipoRecuperacao == TipoRecuperacao::SEMESTRAL): ?>
									<?php for ($i=1; $i <= ($turmaEja ? 1 : 2); $i++): ?> 
										<td class="text-center">
											<input type="text" name="<?php echo "recuperacao".$i."[{$id_aluno}]"; ?>" class="mask-nota form-control input-sm" maxlength="4" value="<?php echo $nota['recuperacao'.$i] ?>" onblur="validacampo(this, 0);" <?php echo $disable; ?>>
										</td>
									<?php endfor; ?>
								<?php endif ?>

								<?php if ($tipoRecuperacao == TipoRecuperacao::ANUAL): ?>
									<td class="text-center">
										<input type="text" name="<?php echo "recuperacao1[{$id_aluno}]"; ?>" class="mask-nota form-control input-sm" maxlength="4" value="<?php echo $nota['recuperacao1'] ?>" onblur="validacampo(this, 0);" <?php echo $disable; ?>
										<?php echo !in_array(11, $etapasLiberadas) ? "disabled title=\"Etapa Bloqueada\"" : "" ?>>
									</td>
								<?php endif ?>

								<?php if ($tipoRecuperacao == TipoRecuperacao::PARALELA): ?>
									<?php for ($i=1; $i <= 3; $i++): ?>
										<td>
											<div class="input-group">
												<?php if ($i == 3 && $cargaDisciplina <= $cargaHorariaAvaliacao): ?>
													<input type="text" name="<?php echo "recuperacao".$i."[{$id_aluno}]"; ?>" class="mask-nota form-control input-sm" maxlength="4" value="<?php echo $nota['recuperacao'.$i] ?>" readonly>
												<?php else: ?>
													<input type="text" name="<?php echo "recuperacao".$i."[{$id_aluno}]"; ?>" class="mask-nota form-control input-sm" maxlength="4" value="<?php echo $nota['recuperacao'.$i] ?>" onblur="validacampo(this, 0);" <?php echo $disable; ?>>
												<?php endif ?>
											</div>
										</td>
									<?php endfor; ?>
								<?php endif ?>

								<?php if ($adereExameFinal): ?>
									<td class="text-center">
										<input type="text" name="<?php echo "examefinal[{$id_aluno}]"; ?>" class="mask-nota form-control input-sm" maxlength="4" value="<?php echo isset($nota['examefinal']) ? $nota['examefinal'] : '' ?>" onblur="validacampo(this, 0);" <?php echo $disable; ?>
										<?php echo !in_array(9, $etapasLiberadas) ? "disabled title=\"Etapa Bloqueada\"" : "" ?>>
									</td>
								<?php endif ?>

								<td>
									<small><?php echo $aluno["situacaodesc"]; ?></small>
								</td>
							</tr>
							<?php endforeach; ?>
							<tr>
								<th>Total</th>
								<td colspan="5"><?php echo sizeof($alunos); ?> estudantes</td>
							</tr>
						</tbody>
					</table>
				</div>

				<div class="well well-sm">
					<button type="submit" class="btn btn-primary btn-submit-wait" onclick="return confirm('Confirma as altera��es?')">SALVAR NOTAS</button>
					<button type="button" class="btn btn-default btn-back pull-right">Voltar</button>
				</div>
			</form>
			<?php endif; ?>
		</div>

		<?php require_once page_footer(); ?>
	</body>
</html>