<?php
require_once '../start.php';
$pdo = new Conexao;

$title = 'Lota��o de professor';
$subtitle = 'Enquadramento de servidor';

$sql = "SELECT *, id FROM lotacao WHERE id =:id;";
$sth = $pdo->prepare($sql);
$sth->bindParam(':id', $_GET['codigo']);
$lotacao = $sth->execute() ? $sth->fetch() : null;

if (!$lotacao) {
    redirect('escola/form_consulta_memo.php');
}

$servidor = Servidor::get($lotacao['cpf']);
$habilitacao = Disciplina::get($lotacao['areaatuacao']);
$disciplinas = Disciplina::lista();

$sql = "SELECT id, descricao FROM licenca ORDER BY descricao";
$licencas = $pdo->query($sql)->fetchAll();

$sql = "SELECT id, descricao FROM ambienteescola ORDER BY descricao";
$ambientes = $pdo->query($sql)->fetchAll();

?><!DOCTYPE HTML>
<html>
<head>
    <?php require_once page_head(); ?>
</head>
<body>
<?php require_once page_header(); ?>
<div class="container">
    <form name="form" class="submit-wait" action="dados_pessoal_escola.php" method="POST">
        <input type="hidden" name="txtid" value="<?= $lotacao['id'] ?>">
        <input type="hidden" name="inep" value="<?= $inep ?>" id="inep">

        <div class="row">
            <div class="col-md-2">
                <p class="form-group">
                    <label for="cpf">CPF</label>
                    <input type="text" name="cpf" id="cpf" value="<?= $servidor['cpf']; ?>" class="form-control" readonly>
                </p>
            </div>
            <div class="col-md-8">
                <p class="form-group">
                    <label for="txtNome">Nome do servidor</label>
                    <input type="text" name="txtNome" class="form-control" value="<?= $servidor['nome']; ?>" id="txtNome" readonly>
                </p>
            </div>
            <div class="col-md-2">
                <p class="form-group">
                    <label for="txtdtnascimento">Nascimento</label>
                    <input type="text" class="form-control" value="<?= formataData($servidor['dtnascimento']) ?>" readonly>
                </p>
            </div>
        </div>

        <div class="row">
            <div class="col-md-6">
                <p class="form-group">
                    <label for="lblmae">Nome da M�e</label>
                    <input type="text" name="txtmae" value="<?= $servidor['mae']; ?>" id="txtmae" class="form-control" readonly>
                </p>
            </div>
            <div class="col-md-6">
                <p class="form-group">
                    <label for="lblpai">Nome do Pai</label>
                    <input type="text" name="txtpai" value="<?= $servidor['pai']; ?>" id="txtpai" class="form-control" readonly>
                </p>
            </div>
        </div>

        <div class="row">
            <div class="col-md-5">
                <p class="form-group">
                    <label for="lblEndereco">Endere�o</label>
                    <input type="text" name="txtEndereco" value="<?= $servidor['endereco']; ?>" class="form-control" id="txtEndereco" readonly>
                </p>
            </div>
            <div class="col-md-2">
                <p class="form-group">
                    <label for="txtnr">N�mero</label>
                    <input type="text" name="txtnr" value="<?= $servidor['numero']; ?>" id="txtnr" class="form-control" readonly>
                </p>
            </div>
            <div class="col-md-3">
                <p class="form-group">
                    <label for="txtBairro">Bairro</label>
                    <input type="text" name="txtBairro" value= "<?= $servidor['bairro']; ?>" id="txtBairro" class="form-control" readonly>
                </p>
            </div>
            <div class="col-md-2">
                <p class="form-group">
                    <label for="txtcep">CEP</label>
                    <input id="txtcep" name="txtcep" type="text" value= "<?= $servidor['cep']; ?>" class="form-control" readonly>
                </p>
            </div>
        </div>

        <div class="row">
            <div class="col-md-4">
                <p class="form-group">
                    <label for="lblEndereco">Email</label>
                    <input type="text" name="txtcomplemento" value="<?= $servidor['email']; ?>"  class="form-control" size="60" id="txtcomplemento" readonly>
                </p>
            </div>
            <div class="col-md-2">
                <p class="form-group">
                    <label for="txtFoneSetor">Telefone Comercial</label>
                    <input type="text" name="txtFoneSetor" value="<?= $servidor['fonesetor']; ?>" id="txtFoneSetor"  class="form-control" readonly>
                </p>
            </div>
            <div class="col-md-2">
                <p class="form-group">
                    <label for="txtFoneRes">Residencial</label>
                    <input type="text" name="txtFoneRes" value="<?= $servidor['foneresidencial']; ?>" id="txtFoneRes" class="form-control" readonly>
                </p>
            </div>
            <div class="col-md-2">
                <p class="form-group">
                    <label for="txtCelular">Celular</label>
                    <input type="text" name="txtCelular" value="<?= $servidor['celular']; ?>" id="txtCelular" class="form-control" readonly>
                </p>
            </div>
            <div class="col-md-2">
                <p class="form-group">
                    <label for="txtCelular">Contato</label>
                    <input type="text" name="txtcontato" value="<?= $servidor['fonecontato']; ?>" id="txtcontato" class="form-control" readonly>
                </p>
            </div>
        </div>

        <div class="row">
            <div class="col-md-2">
                <p class="form-group">
                    <label for="txtEmail">Matricula</label>
                    <input type="text" name="txtmatricula" value="<?= $lotacao['matricula']; ?>" id="txtmatricula" class="form-control" readonly>
                </p>
            </div>
            <div class="col-md-6">
                <p class="form-group">
                    <label for="txtlotacao">Lota��o</label>
                    <input type="text" name="txtlotacao" value= "<?= $habilitacao['descricao']; ?>" id="txtlotacao" class="form-control" readonly>
                </p>
            </div>
            <div class="col-md-2">
                <p class="form-group">
                    <label for="txtch">Carga Hor�ria <small class="text-muted">(C.H)</small></label>
                    <input type="text" name="txtch" value= "<?= $lotacao['chlotacao']; ?>" id="txtch" class="form-control" readonly>
                </p>
            </div>
            <div class="col-md-2">
                <p class="form-group">
                    <label for="txtdtlotacao1">Data da Apresenta��o</label>
                    <input type="text" name="txtdtlota11" value ="<?= date('d/m/Y') ?>" id="txtdtlota11"  class="form-control" readonly>
                </p>
            </div>
        </div>

        <hr>

        <div class="row">
            <div class="col-md-6">
                <p class="form-group">
                    <label for="selectncontrato">Situa��o</label>
                    <select id="selectsituacao" name="selectsituacao" class="form-control" required>
                        <option value="">Selecione a Situa��o</option>
                        <?php foreach ($licencas as $licen): ?>
                            <option value="<?= $licen['id'] ?>" <?php selected($licen['id'] == $lotacao['situacao']) ?>>
                                <?= $licen['descricao'] ?>
                            </option>
                        <?php endforeach ?>
                    </select>
                </p>
            </div>

            <div class="col-md-6">
                <div class="form-group">
                    <label for="selectexecercio" class="control-label">Local de Exerc�cio</label>
                    <select id="selectexecercio" name="selectexecercio" class="form-control chosen" required>
                        <option value="">Selecione o Local de Exerc�cio</option>
                        <?php foreach ($ambientes as $amb): ?>
                            <option value="<?= $amb['id'] ?>"
                                <?php selected($amb['id'] == $lotacao['ambescola']) ?>><?= $amb['descricao'] ?></option>
                        <?php endforeach ?>
                    </select>
                </div>
            </div>
        </div>

        <?php for($i=1; $i <= 4; $i++): ?>
            <div class="row">
                <div class="col-md-6">
                    <div class="form-group">
                        <?php $nameInputDisciplina = "txtautacao{$i}"; ?>
                        <label for="<?= $nameInputDisciplina ?>">Disciplina <?= $i ?></label>
                        <select name="<?= $nameInputDisciplina ?>" id="<?= $nameInputDisciplina ?>" class="form-control chosen">
                            <option value=""> - </option>
                            <?php foreach ($disciplinas as $disc): ?>
                                <option value="<?= $disc['id'] ?>" <?php selected($disc['id'] == ($lotacao['disciplina'.$i])) ?>>
                                    <?= $disc['descricao'] ?>
                                </option>
                            <?php endforeach ?>
                        </select>
                    </div>
                </div>

                <div class="col-md-2">
                    <label>
                        <input name="m<?= $i ?>" type="checkbox" value="M" id="m<?= $i ?>" <?php checked($lotacao['m'.$i] == 'M') ?>>
                        Manh�
                    </label>
                    <input type="number" name="txtqdtaaulas<?= $i ?>m" value="<?= $lotacao["qdtaaulas{$i}m"]; ?>" id="txtqdtaaulas<?= $i ?>m" maxlength="2" class="form-control">
                </div>

                <div class="col-md-2">
                    <label>
                        <input name="t<?= $i ?>" type="checkbox" value="T" id="t<?= $i ?>" <?php checked($lotacao['t'.$i] == 'T') ?>>
                        Tarde
                    </label>
                    <input type="number" name="txtqdtaaulas<?= $i ?>t" value="<?= $lotacao["qdtaaulas{$i}t"]; ?>" id="txtqdtaaulas<?= $i ?>t" class="form-control" maxlength="2">
                </div>

                <div class="col-md-2">
                    <label>
                        <input name="n<?= $i ?>" type="checkbox" value="N" id="n<?= $i ?>" <?php checked($lotacao['n'.$i] == 'N') ?>>
                        Noite
                    </label>
                    <input type="number" name="txtqdtaaulas<?= $i ?>n" value= "<?= $lotacao["qdtaaulas{$i}n"]; ?>" class="form-control" id="txtqdtaaulas<?= $i ?>n" maxlength="2">
                </div>
            </div>
        <?php endfor; ?>

        <div class="row">
            <div class="col-md-2">
                <p class="form-group">
                    <label for="txthe">Hora Extra</label>
                    <input type="number" name="txthe" value="<?= $lotacao['hextra']; ?>" class="form-control" id="txthe" maxlength="2">
                </p>
            </div>
            <div class="col-md-2">
                <p class="form-group">
                    <label for="txttfundamental">N� Turmas Fundamental</label>
                    <input type="number" name="txttfundamental" value= "<?= $lotacao['tfundamental']; ?>" class="form-control" title="Informe o total de turmas do ensino fundamenal" id="txttfundamental" maxlength="2"   onKeyPress="return Enum(event)"/>
                </p>
            </div>
            <div class="col-md-2">
                <p class="form-group">
                    <label for="txttmedio">N� Turmas M�dio</label>
                    <input type="number" name="txttmedio" value= "<?= $lotacao['tmedio']; ?>" class="form-control" id="txttmedio" maxlength="2" onKeyPress="return Enum(event)" title="Informe o total de turmas do ensino m�dio" />
                </p>
            </div>
            <div class="col-md-2">
                <p class="form-group">
                    <label for="txtteja">N� Turmas EJA</label>
                    <input type="number" name="txtteja" value= "<?= $lotacao['teja']; ?>" class="form-control" id="txtteja" maxlength="2"  onKeyPress="return Enum(event)" title="Informe o total de turmas do ensino EJA" />
                </p>
            </div>
        </div>

        <p class="form-group">
            <label>Observa��es</label>
            <textarea name="txtobsescola" class="form-control" rows="3" id="txtobsescola" type="text"><?= $lotacao['obsescola']; ?></textarea>
        </p>

        <div class="well well-sm">
            <button type="button" class="btn btn-default btn-back ">Voltar</button>
            <button type="submit" class="btn btn-primary btn-submit-wait pull-right">SALVAR ALTERA��ES</button>
        </div>
    </form>
</div>
<?php require_once page_footer(); ?>
</body>
</html>