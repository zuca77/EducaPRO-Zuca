<?php
require_once '../../start.php';
$pdo = new Conexao;

$title = 'Editar turma';

if (empty($_GET['codigo'])) {
    redirect('form_inclusao_turma.php');
}

$sql = "SELECT id,modalidade,turmas,t_vagas,inep,usuario,data,motivo,turno,descricao,tipomov,
		sala,ano,semestre,tipo_eja,fechado,dtfecha,obs,ata,id_grade,ano_fechado,dtfecha_turma,extensao_id
		FROM turma
		WHERE inep = '{$inep}'
			AND ano = '{$txtano}'
			AND id = :id;";
$sth = $pdo->prepare($sql);
$sth->bindParam(':id', $_GET['codigo']);
$turma = $sth->execute() ? $sth->fetch() : null;

if(!$turma) {
    redirect('form_inclusao_turma.php');
}

$sql = "SELECT id,descricao FROM modalidadeensino WHERE id = :modalidade;";
$sth = $pdo->prepare($sql);
$sth->bindParam(':modalidade', $turma['modalidade']);
$modalidadeensino = $sth->execute() ? $sth->fetch() : null;

$sql = "SELECT id,descricao FROM modalidadeensino";
$modalidades = $pdo->query($sql)->fetchAll();

$sql = "SELECT id, turmas AS descricao FROM serie
				WHERE modalidade = :modalidade;";
$sth = $pdo->prepare($sql);
$sth->bindParam(':modalidade', $turma['modalidade']);
$series = $sth->execute() ? $sth->fetchAll() : array();

$sql = "SELECT id,turmas as descricao FROM serie WHERE id = :turmas;";
$sth = $pdo->prepare($sql);
$sth->bindParam(':turmas', $turma['turmas']);
$serie = $sth->execute() ? $sth->fetch() : null;

$sql = "SELECT id FROM semestre;";
$semestres = $pdo->query($sql)->fetchAll();

$sql = "SELECT id, descricao FROM turno ORDER BY descricao;";
$turnos = $pdo->query($sql)->fetchAll();

$sql = "SELECT id, descricao FROM sala ORDER BY id";
$salas = $pdo->query($sql)->fetchAll();

$sql = "SELECT s.id, CONCAT(s.turmas, ' (', m.descricao, ')') AS descricao
		FROM grade_curricular AS g
		LEFT JOIN serie s ON s.id = g.id_serie
			JOIN modalidadeensino m ON m.id = g.id_modalidade
		WHERE inep = '{$inep}' and s.turmas <> ''
		GROUP BY g.id_serie
		ORDER BY g.id";
$grades = $pdo->query($sql)->fetchAll();

$extensoes = Extensoes::getList($_SESSION['escola']['codigo']);

?><!DOCTYPE HTML>
<html>
<head>
    <?php require_once page_head(); ?>
</head>
<body>
<?php require_once page_header(); ?>
<div class="container">
    <form action="altera_turma.php" class="submit-wait" method="post">

        <input type="hidden" name="id" value= "<?= $turma['id']; ?>">
        <input type="hidden" name="id_modalidade" value="<?= $turma['modalidade']; ?>">
        <input type="hidden" name="id_serie" value="<?= $turma['turmas']; ?>">

        <div class="row">
            <div class="col-md-5">
                <div class="form-group">
                    <label for="id_modalidade">Modalidade</label>
                    <select name="id_modalidade" id="id_modalidade" class="form-control" disabled required>
                        <option value=""></option>
                        <?php foreach ($modalidades as $modalidade): ?>
                            <option value="<?= $modalidade['id'] ?>" <?php selected($modalidade['id'] == $modalidadeensino['id']) ?>><?= $modalidade['descricao'] ?></option>
                        <?php endforeach ?>
                    </select>
                </div>
            </div>
            <div class="col-md-5">
                <div class="form-group field-serie">
                    <label for="id_serie">S�rie</label>
                    <div class="input-group">
                        <select name="id_serie" id="id_serie" class="form-control" disabled required>
                            <option value="">Selecione</option>
                            <?php foreach ($series as $se): ?>
                                <option value="<?= $se['id'] ?>" <?php selected($se['id'] == $turma['turmas']) ?>><?= $se['descricao'] ?></option>
                            <?php endforeach ?>
                        </select>
                        <div class="input-group-btn">
                            <button id="btnEditar" type="button" class="btn btn-default">EDITAR</button>
                        </div>
                    </div>
                </div>
            </div>
            <div class="col-md-2">
                <div class="form-group">
                    <label>Situa��o</label>
                    <input type="text" class="form-control" value="<?= $turma['fechado'] == 'S' ? 'FECHADA' : 'ABERTA'; ?>" readonly>
                </div>
            </div>
        </div>

        <div class="row">
            <div class="col-md-10">
                <div class="form-group">
                    <label>Descri��o da Turma</label>
                    <input type="text" class="form-control" value="<?= $turma['descricao']; ?>" id="descturma" readonly>
                </div>
            </div>
            <div class="col-md-2">
                <div class="form-group">
                    <label>Saldo de Vagas Atual</label>
                    <input type="text" class="form-control" value="<?= $turma['t_vagas']; ?>" id="txtsaldoatual" readonly>
                </div>
            </div>
        </div>

        <hr>

        <div class="row">
            <div class="col-md-1">
                <div class="form-group">
                    <label for="semestre">Semestre</label>
                    <select id="semestre" name="semestre" class="form-control" required>
                        <?php foreach($semestres as $sem): ?>
                            <option value="<?= $sem['id']?>" <?= $sem['id']==$turma['semestre'] ? 'selected' : '' ?>>
                                <?= $sem['id'] ?>
                            </option>
                        <?php endforeach ?>
                    </select>
                </div>
            </div>
            <div class="col-md-2">
                <div class="form-group">
                    <label for="turno">Turno</label>
                    <select id="turno" name="turno" class="form-control" required>
                        <?php foreach($turnos as $tu): ?>
                            <option value="<?= $tu['id']?>" <?= $tu['id']==$turma['turno'] ? 'selected' : '' ?>>
                                <?= $tu['descricao'];?>
                            </option>
                        <?php endforeach ?>
                    </select>
                </div>
            </div>
            <div class="col-md-1">
                <div class="form-group">
                    <label for="id_sala">Sala</label>
                    <select id="id_sala" name="id_sala" class="form-control" required>
                        <?php foreach($salas as $sa): ?>
                            <option value="<?= $sa['id']?>" <?php selected($sa['id'] == $turma['sala']) ?>>
                                <?= $sa['descricao'];?>
                            </option>
                        <?php endforeach ?>
                    </select>
                </div>
            </div>
            <div class="col-md-5">
                <div class="form-group">
                    <label for="id_grade">Matriz Curricular</label>
                    <select id="id_grade" name="id_grade" class="form-control chosen" required>
                        <?php foreach($grades as $gra): ?>
                            <option value="<?= $gra['id']?>" <?= $gra['id']==$turma['id_grade'] ? 'selected' : '' ?>>
                                <?= $gra['descricao'] ?>
                            </option>
                        <?php endforeach ?>
                    </select>
                </div>
            </div>

            <div class="col-md-3">
                <div class="form-group">
                    <label for="extensao_id">Extens�o</label>
                    <select name="extensao_id" id="extensao_id" class="form-control chosen">
                        <option value="">N�o possui</option>
                        <?php foreach($extensoes as $extensao): ?>
                            <option value="<?= $extensao['id'] ?>" <?= ($turma['extensao_id'] == $extensao['id']) ? 'selected' : '' ?>><?= $extensao['descricao'] ?></option>
                        <?php endforeach ?>
                    </select>
                </div>
            </div>
        </div>

        <div class="row">
            <div class="col-md-2">
                <div class="form-group">
                    <label for="qtdavaga">Saldo de vagas</label>
                    <input type="number" name="qtdavaga" class="form-control" value="<?= $turma['t_vagas']; ?>" id="qtdavaga" min="1" max="999">
                </div>
            </div>
            <div class="col-md-10">
                <div class="form-group">
                    <label for="justificativa">Justificativa</label>
                    <input type="text" name="justificativa" class="form-control" id="justificativa" placeholder="Informe a justificativa da altera��o" required>
                </div>
            </div>
        </div>

        <p class="well well-sm">
            <button type="button" class="btn btn-primary btn-submit-wait" id="btn-submit">SALVAR ALTERA��ES</button>
            <button type="button" class="btn btn-default btn-back pull-right">Voltar</button>
        </p>
    </form>

</div>
</body>
<?php require_once page_footer(); ?>
<script>
    $(function() {
        const $idModalidade = $('#id_modalidade');
        const $idSerie = $('#id_serie');
        const $btnSubmit = $('#btn-submit');
        const $form = $('.submit-wait');
        const $fieldSerie = $('.field-serie');

        const habilitarSelect = function ($element) {
            return $element.attr('disabled', false)
                .addClass('chosen')
                .chosen()
                .trigger('chosen:updated');
        };

        const gerarOptions = function (series) {
            var text = "<option value=''>Selecione</option>";
            series.forEach(function (serie) {
                text += "<option value="+ serie.id + ">" + serie.turmas + "</option>";
            });

            return text;
        };

        const campoSerieEValido = function () {
            if ($idSerie.val() === "") {
                $fieldSerie.append('<span class="message-error" style="color: #dd4b39; margin-top: 5px;">Selecione a s�rie</span>')
            } else {
                $fieldSerie.find('.message-error').remove();
                return true;
            }
        };

        $('#btnEditar').on('click', function() {
            if($idModalidade.attr('disabled')) {
                habilitarSelect($idModalidade);
                habilitarSelect($idSerie);
            }

            $(this).attr('disabled', true);
        });

        $idModalidade.on('change', function () {
            const url = '/escola/turma/escola_muni.ajax.php';
            const dados = { cod_estado: $(this).val() };

            $.get(url, dados)
                .done(function (response) {
                    const text = gerarOptions(JSON.parse(response));
                    $idSerie.empty().prepend(text).chosen().trigger('chosen:updated');
                });
        });

        $btnSubmit.on('click', function () {
            if (campoSerieEValido()) {
                $form.submit();
            }
        });
        $idSerie.on('change', campoSerieEValido);


    })
</script>
</html>