<?php
session_start();
if (isset($_SESSION["login_usuario"]))
  {
   // session_cache_expire(1);
	 $login     =  $_SESSION["login_usuario"];
     $nte       =  $_SESSION["nivel_usuario"];
	 $inep      =  $_SESSION["inep_usuario"] ;
     $ntelogin  =  $_SESSION["nte_login"];
     $cpf       = $_SESSION["cpf_usuario"];
     include ("../funcoes.php");
     echo  saudacoes()."   ". "$login" ."  -  ". $nte."  ".dataextenso() ." - ".$inep;

  }
 else
  {
     		 header("Location: ../../login.php");
  }



include ("../../conexao_mysql.php");

if(file_exists("../../conexao_mysql.php"))
{
        require "../../conexao_mysql.php";

} else
{
        echo "Conex�o nao foi encontrado";
        exit;
}



if($_SERVER["REQUEST_METHOD"] == "POST")
{
$txtmodalidade	      = $_POST['txtmodalidade'];
$txtturma             = $_POST['txtturma'];
$qtdavaga	          = $_POST['qtdavaga'];
$usuario              =  $cpf;
$motivo               ='Inser��o de Saldo de Vaga Inicial;';
$selecturno           = $_POST['selecturno'];
$txtsala              = $_POST['txtsala'];
$txtsemestre          = $_POST['txtsemestre'];
$txtgrade             = $_POST['txtgrade'];

/*----------------------------------------------------------------*/


$sql="select * from modalidadeensino where id = '$txtmodalidade' ";
$resultado=mysql_query($sql) or die (mysql_error());
while ( $linha_lotacao = mysql_fetch_array( $resultado))
{ 

     $modalidadedesc        =$linha_lotacao["DESCRICAO"];

}


$sql="select * from serie where id = '$txtturma'";
$resultado=mysql_query($sql) or die (mysql_error());
while ( $linha_lotacao = mysql_fetch_array( $resultado))
{ 
 	$turmadesc        =$linha_lotacao["TURMAS"];

}

$sql="select * from sala where id = '$txtsala'";
$resultado=mysql_query($sql) or die (mysql_error());
while ( $linha_lotacao = mysql_fetch_array( $resultado))
{
 	$descsala        =$linha_lotacao["descricao"];

}







if (trim($txtmodalidade)=='2')
{
  $descricao  =  $modalidadedesc ." - ". $turmadesc ." - ". $selecturno." - ". $descsala.  " -SEMESTRE - ".$txtsemestre ;

}
else
{
  $descricao  =  $modalidadedesc ." - ". $turmadesc ." - ". $selecturno." - ". $descsala ;
}


/*----------------------------------------------------------------*/








if (trim($inep)=='')
   {
    echo "<html><head><title>Resposta !!!</title></head>";
    echo "<body background=\"background_mensagens.jpg\" style=\"background-attachment:fixed; background-repeat:no-repeat\">";
    echo "<br><br><br>";
    echo "<center><img src=\"faleconosco/atencao.gif\" alt=\"\"><p><font color=\"#FF0000\" face=\"Verdana\" size=\"4\"><blink>Escola n�o localizada.!</blink> <b></b></font></center>";
    echo "<br><br><center><a href=\"form_inclusao_turma.php\"><img src=\"faleconosco/button_voltar2_.gif\" alt=\"Voltar\" border=\"0\" /></a></center>";
    echo "</body></html>";
    exit;

   }



if (trim($txtmodalidade)=='')
   {
    echo "<html><head><title>Resposta !!!</title></head>";
    echo "<body background=\"background_mensagens.jpg\" style=\"background-attachment:fixed; background-repeat:no-repeat\">";
    echo "<br><br><br>";
    echo "<center><img src=\"faleconosco/atencao.gif\" alt=\"\"><p><font color=\"#FF0000\" face=\"Verdana\" size=\"4\"><blink>Informe a modalidade.!</blink> <b></b></font></center>";
    echo "<br><br><center><a href=\"form_inclusao_turma.php\"><img src=\"faleconosco/button_voltar2_.gif\" alt=\"Voltar\" border=\"0\" /></a></center>";
    echo "</body></html>";
    exit;

   }

if (trim($txtturma)=='')
   {
    echo "<html><head><title>Resposta !!!</title></head>";
    echo "<body background=\"background_mensagens.jpg\" style=\"background-attachment:fixed; background-repeat:no-repeat\">";
    echo "<br><br><br>";
    echo "<center><img src=\"faleconosco/atencao.gif\" alt=\"\"><p><font color=\"#FF0000\" face=\"Verdana\" size=\"4\"><blink>Informe a turma.!</blink> <b></b></font></center>";
    echo "<br><br><center><a href=\"form_inclusao_turma.php\"><img src=\"faleconosco/button_voltar2_.gif\" alt=\"Voltar\" border=\"0\" /></a></center>";
    echo "</body></html>";
    exit;

   }


if (trim($selecturno)=='')
   {
    echo "<html><head><title>Resposta !!!</title></head>";
    echo "<body background=\"background_mensagens.jpg\" style=\"background-attachment:fixed; background-repeat:no-repeat\">";
    echo "<br><br><br>";
    echo "<center><img src=\"faleconosco/atencao.gif\" alt=\"\"><p><font color=\"#FF0000\" face=\"Verdana\" size=\"4\"><blink>Informe o turno.!</blink> <b></b></font></center>";
    echo "<br><br><center><a href=\"form_inclusao_turma.php\"><img src=\"faleconosco/button_voltar2_.gif\" alt=\"Voltar\" border=\"0\" /></a></center>";
    echo "</body></html>";
    exit;

   }




if (($txtgrade)=='')
   {
    echo "<html><head><title>Resposta !!!</title></head>";
    echo "<body background=\"background_mensagens.jpg\" style=\"background-attachment:fixed; background-repeat:no-repeat\">";
    echo "<br><br><br>";
    echo "<center><img src=\"faleconosco/atencao.gif\" alt=\"\"><p><font color=\"#FF0000\" face=\"Verdana\" size=\"4\"><blink>Informe a grade curricular.!</blink> <b></b></font></center>";
    echo "<br><br><center><a href=\"form_inclusao_turma.php\"><img src=\"faleconosco/button_voltar2_.gif\" alt=\"Voltar\" border=\"0\" /></a></center>";
    echo "</body></html>";
    exit;

   }





if (($qtdavaga)<=0)
   {
    echo "<html><head><title>Resposta !!!</title></head>";
    echo "<body background=\"background_mensagens.jpg\" style=\"background-attachment:fixed; background-repeat:no-repeat\">";
    echo "<br><br><br>";
    echo "<center><img src=\"faleconosco/atencao.gif\" alt=\"\"><p><font color=\"#FF0000\" face=\"Verdana\" size=\"4\"><blink>A Quantidade de Vaga deve ser maior ou igual a 1.!</blink> <b></b></font></center>";
    echo "<br><br><center><a href=\"form_inclusao_turma.php\"><img src=\"faleconosco/button_voltar2_.gif\" alt=\"Voltar\" border=\"0\" /></a></center>";
    echo "</body></html>";
    exit;
    }



/*tratamento das datas*/

$dia = date('d');
$mes = date('m');
$ano = date('Y');



$data =$ano.".".$mes.".".$dia;



$sql="select * from ano where ano = '$ano' and situacao = 'A' and inep = '$inep'";
$resultado=mysql_query($sql) or die (mysql_error());
$linhas=mysql_num_rows($resultado);
if ($linhas<=0)
 {
    echo "<html><head><title>Resposta !!!</title></head>";
    echo "<body background=\"background_mensagens.jpg\" style=\"background-attachment:fixed; background-repeat:no-repeat\">";
    echo "<br><br><br>";
    echo "<center><img src=\"faleconosco/atencao.gif\" alt=\"\"><p><font color=\"#FF0000\" face=\"Verdana\" size=\"4\"> <b>Turma n�o pode ser criada. Ano Letivo ainda n�o est� aberto!</b></font></center>";
    echo "<br><br><center><a href=\"form_inclusao_turma.php\"><img src=\"faleconosco/button_voltar2_.gif\" alt=\"Voltar\" border=\"0\" /></a></center>";
    echo "</body></html>";
    exit;
}




/*
$sql="select * from ano where ano <> '$ano' or situacao <> 'A'";
$resultado=mysql_query($sql) or die (mysql_error());
$linhas=mysql_num_rows($resultado);
if ($linhas>0)
 {
    echo "<html><head><title>Resposta !!!</title></head>";
    echo "<body background=\"background_mensagens.jpg\" style=\"background-attachment:fixed; background-repeat:no-repeat\">";
    echo "<br><br><br>";
    echo "<center><img src=\"faleconosco/atencao.gif\" alt=\"\"><p><font color=\"#FF0000\" face=\"Verdana\" size=\"4\"> <b>Turma n�o pode ser criada. Ano Letivo ainda n�o est� aberto.</b></font></center>";
    echo "<br><br><center><a href=\"form_inclusao_turma.php\"><img src=\"faleconosco/button_voltar2_.gif\" alt=\"Voltar\" border=\"0\" /></a></center>";
    echo "</body></html>";
    exit;
}



*/






$sql="select * from  turma where MODALIDADE= '$txtmodalidade' and TURMAS='$txtturma' and INEP= '$inep' 
and TURNO= '$selecturno'  and SALA= '$txtsala' and semestre = '$txtsemestre' and id_grade ='$txtgrade' and ano = '$ano' and ((fechado is null)  || (fechado <>'S'))" ;
$resultado=mysql_query($sql) or die (mysql_error());
$linhas=mysql_num_rows($resultado);
if ($linhas>0)
 { 
    echo "<html><head><title>Resposta !!!</title></head>";
    echo "<body background=\"background_mensagens.jpg\" style=\"background-attachment:fixed; background-repeat:no-repeat\">";
    echo "<br><br><br>";
    echo "<center><img src=\"faleconosco/atencao.gif\" alt=\"\"><p><font color=\"#FF0000\" face=\"Verdana\" size=\"4\"><blink>Dados j� cadastrado para esta modalidade, turma, turno e sala - Click em Voltar.!</blink> <b></b></font></center>";
    echo "<br><br><center><a href=\"form_inclusao_turma.php\"><img src=\"faleconosco/button_voltar2_.gif\" alt=\"Voltar\" border=\"0\" /></a></center>";
    echo "</body></html>";
    exit;
}

else
{


/*********inserindo pedidio***********/

$sql = "insert into turma(INEP,TURMAS,MODALIDADE,T_VAGAS,DATA,USUARIO,MOTIVO,TURNO,DESCRICAO,SALA,ANO,SEMESTRE,id_grade)
values ('$inep','$txtturma','$txtmodalidade','$qtdavaga','$data','$usuario','$motivo','$selecturno','$descricao','$txtsala','$ano','$txtsemestre','$txtgrade')";

if(@mysql_query($sql))
{
  if(mysql_affected_rows() == 1)
   {

  ?>


 <html><head><title>Resposta !!!</title>
 <style type="text/css">
<!--
.style3 {
	font-size: 36px;
	font-weight: bold;
	color: #0000FF;
}
-->
 </style>
 </head>
 <body background=\"background_mensagens.jpg\" style=\"background-attachment:fixed; background-repeat:no-repeat\">
 <META HTTP-EQUIV=Refresh CONTENT="1; URL=form_inclusao_turma.php">
 <br><br><br>
 <center>
               <span class="style3"><font face=\"Verdana\">Dados Registrado Com Sucesso.!</font> </span>
                                      </center>
 </body></html>



 <?



// *******Arquivo de log********************************************************
                  $datalog=date("d-m-Y-H:i:s");
                  $fp = fopen("log/logs.txt", "a",0);
                 // Escreve "exemplo de escrita" no bloco1.txt
                 $assunto="insercao de turma - insere_turma";
                 $escreve = fwrite($fp, "$cpf,$login,$inep,$nte,$ntelogin,$assunto,$datalog.\r\n");
                 // Fecha o arquivo
                    fclose($fp);

exit;
   }
/******Fim do insert*****************************************************************/
}
else
   {
        //verifico se nao estao tentando gravar um dado que ja existe, pois usei UNIQUE na tabela
        if(mysql_errno() == 1062)
		  {
                echo $erros[mysql_errno()];
                exit;
          }
		  else
		  {
                echo "Erro nao foi possivel incluir o registro";
                exit;
          }
        @mysql_close();
   }

  }//select kit



}//post



?>



