<?php
require_once '../../start.php';
$pdo = new Conexao;

Auth::blackList(array('PROF', 'NAM', 'BF'));

$title = 'Turmas do ano '. $_SESSION['txtano'];

$sql = "SELECT id, descricao FROM modalidadeensino ORDER BY DESCRICAO";
$modalidades = $pdo->query($sql)->fetchAll();

$sql = "SELECT id, descricao FROM turno";
$turnos = $pdo->query($sql)->fetchAll();

$sql = "SELECT id, descricao FROM sala ORDER BY id";
$salas = $pdo->query($sql)->fetchAll();

$sql = "SELECT id FROM semestre ORDER BY id";
$semestres = $pdo->query($sql)->fetchAll();

$sql = "SELECT s.id, CONCAT(s.turmas, ' (', m.descricao, ')') AS serie
		FROM grade_curricular g
			JOIN serie s ON s.id = g.id_serie
			JOIN modalidadeensino m ON m.id = g.id_modalidade
		WHERE g.inep = '{$inep}'
		GROUP BY g.id_serie
		ORDER BY g.id";
$grades = $pdo->query($sql)->fetchAll();

$sql = "SELECT v.id AS id ,s.descricao AS sala, m.descricao AS  modalidade, v.turmas AS id_serie, t.turmas AS turmas, v.t_vagas AS t_vagas,v.usuario AS usuario,
		v.motivo AS motivo,v.descricao AS descvagas,v.turno AS turno,v.semestre,v.fechado, v.id_grade,v.ano,v.data
		FROM turma v
			JOIN modalidadeensino m ON v.modalidade = m.id
			JOIN serie t ON v.turmas = t.id
			JOIN sala s ON v.sala = s.id
		WHERE v.inep = '{$inep}'
			AND v.ano = '{$txtano}'
			AND v.sala = s.id
			AND (v.fechado = 'N' OR v.fechado IS NULL)
		ORDER BY  v.descricao, v.semestre";
$turmasAbertas = $pdo->query($sql)->fetchAll();

$sql = "SELECT v.id AS id ,s.descricao AS sala, m.descricao AS  modalidade, v.turmas AS id_serie, t.turmas AS turmas, v.t_vagas AS t_vagas,v.usuario AS usuario,
			v.motivo AS motivo,v.descricao AS descvagas,v.turno AS turno,v.semestre,v.fechado, v.id_grade,v.ano,v.data
		FROM turma v, modalidadeensino m, serie t, sala s
		WHERE v.inep = '{$inep}'
		AND v.ano = '{$txtano}'
		AND v.sala = s.id
		AND v.modalidade = m.id
		AND v.turmas = t.id
		AND m.id = t.modalidade
		AND v.fechado = 'S'
		ORDER BY v.descricao, v.semestre";
$turmasFechadas = $pdo->query($sql)->fetchAll();

function totalAlunos($inep, $txtano, $id_turma) {
    $pdo = new Conexao;
    $sql = "SELECT COUNT(ta.id) FROM turma_aluno ta
			WHERE ta.inep = '{$inep}'
				AND ta.ano = '{$txtano}'
				AND ta.id_turma = :id_turma
				AND ta.situacao IN (1, 8)";
    $sth = $pdo->prepare($sql);
    $sth->bindParam(':id_turma', $id_turma);

    return $sth->execute() ? $sth->fetchColumn() : 0;
}

function serieGradeCurricular($id_serie) {
    $pdo = new Conexao;
    $sql = "SELECT turmas FROM serie WHERE id = :id";
    $sth = $pdo->prepare($sql);
    $sth->bindParam(':id', $id_serie);
    return $sth->execute() ? $sth->fetchColumn() : '';
}

$sql = "SELECT COUNT(id) FROM turma WHERE inep = '{$inep}' AND ano = '{$txtano}'";
$t_qtda_turma = $pdo->query($sql)->fetchColumn();

$sql = "SELECT COUNT(id) FROM turma WHERE inep = '{$inep}' AND ano = '{$txtano}' AND (fechado IS NULL OR fechado = 'N')";
$t_qtda_turma_abertas = $pdo->query($sql)->fetchColumn();

$sql = "SELECT COUNT(id) FROM turma WHERE inep = '{$inep}' AND ano = '{$txtano}' AND fechado = 'S'";
$t_qtda_turma_fechadas = $pdo->query($sql)->fetchColumn();

$sql = "SELECT SUM(t_vagas) FROM turma WHERE inep ='{$inep}' AND ano = '{$txtano}'";
$t_vagas_sala = $pdo->query($sql)->fetchColumn();

$sql = "SELECT COUNT(ta.id) FROM turma_aluno ta
		WHERE ta.inep = '{$inep}' AND ta.ano = '{$txtano}'
		AND ta.situacao IN (1, 8)";
$t_aluno_escola = $pdo->query($sql)->fetchColumn();

$saldo = $t_vagas_sala - $t_aluno_escola;

$extensoes = Extensoes::getList($_SESSION['escola']['codigo']);

?><!DOCTYPE HTML>
<html>
<head>
    <?php require_once page_head(); ?>
</head>
<body>
<?php require_once page_header(); ?>
<div class="container">
    <form class="submit-wait" action="insere_turma.php" method="POST">
        <fieldset class="well well-sm">
            <legend>
                Adicionar turma
            </legend>

            <div>
                <div class="row">
                    <div class="col-md-4">
                        <div class="form-group">
                            <label for="id_modalidade">Modalidade</label>
                            <select name="id_modalidade" id="id_modalidade" class="form-control chosen" required>
                                <option value="">Seleciona a modalidade</option>
                                <?php foreach($modalidades as $mo): ?>
                                    <option value="<?= $mo['id'] ?>"><?= $mo['descricao'] ?></option>
                                <?php endforeach ?>
                            </select>
                        </div>
                    </div>

                    <div class="col-md-4">
                        <div class="form-group">
                            <label for="id_serie">S�rie</label>
                            <select name="id_serie" id="id_serie" class="form-control chosen" required>
                                <option value="">Selecione a modalidade</option>
                            </select>
                        </div>
                    </div>

                    <div class="col-md-2">
                        <div class="form-group">
                            <label for="turno">Turno</label>
                            <select name="turno" id="turno" class="form-control chosen" required>
                                <option value="">Selecione o Turno</option>
                                <?php foreach($turnos as $tu) : ?>
                                    <option value="<?= $tu['id'] ?>"><?= $tu['descricao'] ?></option>
                                <?php endforeach ?>
                            </select>
                        </div>
                    </div>
                    <div class="col-md-2">
                        <div class="form-group">
                            <label for="id_sala">Sala</label>
                            <select name="id_sala" id="id_sala" class="form-control chosen" required>
                                <option value="">Selecione a Sala</option>
                                <?php foreach ($salas as $sa): ?>
                                    <option value="<?= $sa['id'] ?>"><?= $sa['descricao'] ?></option>
                                <?php endforeach ?>
                            </select>
                        </div>
                    </div>
                </div>

                <div class="row">
                    <div class="col-md-1">
                        <div class="form-group">
                            <label for="semestre">Semestre</label>
                            <select name="semestre" id="semestre" class="form-control" required>
                                <?php foreach ($semestres as $se): ?>
                                    <option value="<?= $se['id'] ?>"><?= $se['id'] ?></option>
                                <?php endforeach ?>
                            </select>
                        </div>
                    </div>
                    <div class="col-md-2">
                        <div class="form-group">
                            <label for="qtdavaga">Total de Vagas</label>
                            <input type="number" name="qtdavaga" class="form-control" required value="1" maxlength="4" id="qtdavaga" onKeyPress="return Enum(event)">
                        </div>
                    </div>
                    <div class="col-md-5">
                        <div class="form-group">
                            <label for="id_grade">Matriz Curricular</label>
                            <select name="id_grade" id="id_grade" class="form-control chosen" required>
                                <?php foreach($grades as $gra): ?>
                                    <option value="<?= $gra['id'] ?>"><?= $gra['serie'] ?></option>
                                <?php endforeach ?>
                            </select>
                        </div>
                        <div class="text-warning">
                            <i class="fa fa-warning"></i>
                            Deve utilizar a matriz curricular da mesma s�rie.
                        </div>
                    </div>

                    <div class="col-md-4">
                        <div class="form-group">
                            <label for="extensao_id">Extens�o</label>
                            <select name="extensao_id" id="extensao_id" class="form-control chosen">
                                <option value="">N�o possui</option>
                                <?php foreach($extensoes as $extensao): ?>
                                    <option value="<?= $extensao['id'] ?>"><?= $extensao['descricao'] ?></option>
                                <?php endforeach ?>
                            </select>
                        </div>
                    </div>
                </div>

                <p>
                    <button type="submit" class="btn btn-primary btn-submit-wait">ADICIONAR TURMA</button>
                    <button type="button" class="btn btn-default btn-back pull-right">Voltar</button>
                </p>
            </div>
        </fieldset>
    </form>

    <hr>
    <?php if(sizeof($turmasAbertas) > 0): ?>
        <fieldset>
            <legend>
                <i class="fa fa-unlock text-muted"></i>
                Turmas abertas de <?= $txtano ?>
                <small class="text-muted">(<?= sizeof($turmasAbertas) ?>)</small>
            </legend>

            <div class="table-responsive">
                <table class="table table-bordered table-condensed table-striped table-hover">
                    <tr>
                        <th width="70"></th>
                        <th>ID</th>
                        <th>Modalidade</th>
                        <th>S�rie</th>
                        <th class="text-center">Turno</th>
                        <th class="text-center">Sala</th>
                        <th class="text-center">Semestre</th>
                        <th title="Matriz Curricular">Matriz</th>
                        <th class="text-center" title="Vagas Dispon�veis">Vagas</th>
                        <th class="text-center" title="Estudantes na Turma">Estudantes</th>
                        <th class="text-center" title="Saldo de Vagas">Saldo</th>
                        <th width="10"></th>
                    </tr>
                    <?php
                    $somaTotalVagas = 0;
                    $somaTotalAlunos = 0;
                    $somaTotalSaldo = 0;

                    foreach($turmasAbertas as $tu):

                        $totalAlunos = totalAlunos($inep, $txtano, $tu['id']);
                        $cssClass = ($tu['id_grade']==$tu['id_serie']) ? '' : 'text-danger b';
                        $saldoTurma = $tu['t_vagas'] - $totalAlunos;
                        $serieGrade = serieGradeCurricular($tu['id_grade']);

                        $somaTotalVagas += $tu['t_vagas'];
                        $somaTotalAlunos += $totalAlunos;
                        $somaTotalSaldo += $saldoTurma;
                        ?>
                        <tr class="" title="<?= $tu["descvagas"];?>">
                            <td>
                                <div class="text-center btn-group btn-group-justified">
                                    <a class="btn btn-xs btn-primary" href="<?php url("escola/turma/form_altera_turma.php?codigo={$tu["id"]}") ?>" title="Editar turma">
                                        <i class="fa fa-edit fa-lg"></i>
                                    </a>
                                    <a class="btn btn-xs btn-default" href="<?php url("escola/turma/form_fecha_turma.php?codigo={$tu["id"]}") ?>" title="Fechar turma">
                                        <i class="fa fa-lock fa-lg"></i>
                                    </a>
                                </div>
                            </td>
                            <td width="10"><?= $tu['id'] ?></td>
                            <td><?= $tu["modalidade"];?></td>
                            <td><?= $tu["turmas"];?></td>
                            <td class="text-center"><?= $tu["turno"];?></td>
                            <td class="text-center"><?= $tu["sala"];?></td>
                            <td class="text-center"><?= $tu["semestre"];?></td>
                            <td class="text-center <?= $cssClass ?>" title="<?= empty($cssClass) ? '' : 'Aviso: Grade curricular diferente da s�rie atual.' ?>">
                                <?= empty($cssClass) ? '<i class="fa fa-check text-success"></i>' : $serieGrade ?>
                            </td>
                            <td class="text-center <?= ($tu['t_vagas'] < $totalAlunos) ? 'text-danger' : '' ?>"><?= $tu["t_vagas"];?></td>
                            <td class="text-center"><?= $totalAlunos;?></td>
                            <td class="text-center <?= ($saldoTurma < 0) ? 'text-danger' : '' ?>">
                                <?= $saldoTurma;?>
                            </td>
                            <td>
                                <button type="button" class="btn btn-xs btn-default" data-container="body" data-toggle="popover" data-placement="left"
                                        data-content="<small><?= $tu["descvagas"];?></small><br>Data: <?= formataData($tu['data']);?><br>Usu�rio: <?= $tu["usuario"];?>">
                                    <i class="fa fa-info-circle fa-lg"></i>
                                </button>
                            </td>
                        </tr>
                    <?php endforeach ?>
                    <tr>
                        <th colspan="7"></th>
                        <th class="text-center">Total</th>
                        <td class="text-center"><?= $somaTotalVagas ?></td>
                        <td class="text-center"><?= $somaTotalAlunos ?></td>
                        <td class="text-center"><?= $somaTotalSaldo ?></td>
                        <th colspan="2"></th>
                    </tr>
                </table>
            </div>
        </fieldset>
    <?php endif ?>

    <?php if(sizeof($turmasFechadas) > 0): ?>
        <fieldset>
            <legend>
                <i class="fa fa-lock text-muted"></i>
                Turmas fechadas de <?= $txtano ?>
                <small class="text-muted">(<?= sizeof($turmasFechadas) ?>)</small>
            </legend>

            <div class="table-responsive">
                <table class="table table-bordered table-condensed table-striped table-hover">
                    <tr>
                        <th width="70"></th>
                        <th>ID</th>
                        <th>Modalidade</th>
                        <th>S�rie</th>
                        <th class="text-center">Turno</th>
                        <th class="text-center">Sala</th>
                        <th class="text-center">Semestre</th>
                        <th title="Matriz Curricular">Matriz</th>
                        <th class="text-center" title="Vagas Dispon�veis">Vagas</th>
                        <th class="text-center" title="Estudantes na Turma">Estudantes</th>
                        <th class="text-center" title="Saldo de Vagas">Saldo</th>
                        <th width="10"></th>
                    </tr>
                    <?php
                    $somaTotalVagas = 0;
                    $somaTotalAlunos = 0;
                    $somaTotalSaldo = 0;

                    foreach($turmasFechadas as $tu):

                        $data = date('d/m/Y', strtotime($tu['data']));
                        $totalAlunos = totalAlunos($inep, $txtano, $tu['id']);
                        $cssClass = ($tu['id_grade']==$tu['id_serie']) ? '' : 'text-danger b';
                        $saldoTurma = $tu['t_vagas'] - $totalAlunos;
                        $serieGrade = serieGradeCurricular($tu['id_grade']);

                        $somaTotalVagas += $tu['t_vagas'];
                        $somaTotalAlunos += $totalAlunos;
                        $somaTotalSaldo += $saldoTurma;
                        ?>
                        <tr class="" title="<?= $tu["descvagas"];?>">
                            <td>
                                <div class="text-center btn-group btn-group-justified">
                                    <a class="btn btn-xs btn-primary" href="<?php url("escola/turma/form_altera_turma.php?codigo={$tu["id"]}") ?>" title="Editar turma">
                                        <i class="fa fa-edit fa-lg"></i>
                                    </a>
                                    <a class="btn btn-xs btn-default" href="<?php url("escola/turma/form_reabertura_turmas_encerradas.php?id_turma={$tu["id"]}") ?>" title="Reabrir turma">
                                        <i class="fa fa-unlock fa-lg"></i>
                                    </a>
                                </div>
                            </td>
                            <td width="10"><?= $tu['id'] ?></td>
                            <td><?= $tu["modalidade"];?></td>
                            <td><?= $tu["turmas"];?></td>
                            <td class="text-center"><?= $tu["turno"];?></td>
                            <td class="text-center"><?= $tu["sala"];?></td>
                            <td class="text-center"><?= $tu["semestre"];?></td>
                            <td class="text-center <?= $cssClass ?>" title="<?= empty($cssClass) ? '' : 'Aviso: Grade curricular diferente da s�rie atual.' ?>">
                                <?= empty($cssClass) ? '<i class="fa fa-check text-success"></i>' : $serieGrade ?>
                            </td>
                            <td class="text-center <?= ($tu['t_vagas'] < $totalAlunos) ? 'text-danger' : '' ?>"><?= $tu["t_vagas"];?></td>
                            <td class="text-center"><?= $totalAlunos;?></td>
                            <td class="text-center <?= ($saldoTurma < 0) ? 'text-danger' : '' ?>">
                                <?= $saldoTurma;?>
                            </td>
                            <td>
                                <button type="button" class="btn btn-xs btn-default" data-container="body" data-toggle="popover" data-placement="left"
                                        data-content="<small><?= $tu["descvagas"];?></small><br>Data: <?= $data;?><br>Usu�rio: <?= $tu["usuario"];?>">
                                    <i class="fa fa-info-circle fa-lg"></i>
                                </button>
                            </td>
                        </tr>
                    <?php endforeach ?>
                    <tr>
                        <th colspan="7"></th>
                        <th class="text-center">Total</th>
                        <td class="text-center"><?= $somaTotalVagas ?></td>
                        <td class="text-center"><?= $somaTotalAlunos ?></td>
                        <td class="text-center"><?= $somaTotalSaldo ?></td>
                        <th colspan="2"></th>
                    </tr>
                </table>
            </div>
        </fieldset>
    <?php endif ?>

    <fieldset>
        <legend>
            <i class="fa fa-pie-chart text-muted"></i>
            Estat�sticas das turmas
        </legend>

        <table class="table table-bordered table-condensed table-striped table-hover">
            <tr>
                <th class="col-md-2 text-center">Total de turmas</th>
                <th class="col-md-2 text-center">Turmas abertas</th>
                <th class="col-md-2 text-center">Turmas fechadas</th>
                <th class="col-md-2 text-center">Total de vagas</th>
                <th class="col-md-2 text-center">Total de estudantes</th>
                <th class="col-md-2 text-center">Saldo de vagas</th>
            </tr>
            <tr>
                <td class="text-center"><?= $t_qtda_turma;?></td>
                <td class="text-center"><?= $t_qtda_turma_abertas;?></td>
                <td class="text-center"><?= $t_qtda_turma_fechadas;?></td>
                <td class="text-center"><?= $t_vagas_sala;?></td>
                <td class="text-center"><?= $t_aluno_escola ;?></td>
                <td class="text-center <?= ($saldo < 0) ? 'text-danger' : '' ?>"><?= $saldo;?></td>
            </tr>
        </table>
    </fieldset>
</div>

<?php require_once page_footer(); ?>
<script type="text/javascript">
    $(function(){
        var id_modalidade_mediacao = '4';
        var $semestre = $('#semestre');

        $('#id_modalidade').change(function(){
            var this_value = $(this).val();

            if(this_value) {
                $('.carregando').show();

                $.getJSON('escola_muni.ajax.php?search=',{ cod_estado: $(this).val() }, function(j){
                    var options = '<option value=""></option>';
                    for (var i = 0; i < j.length; i++) {
                        options += '<option value="' + j[i].id + '">' + j[i].turmas + '</option>';
                    }
                    $('#id_serie').html(options).trigger('chosen:updated');
                    $('.carregando').hide();
                });

                if (this_value === id_modalidade_mediacao) {
                    $semestre.val(1).prop('disabled', true);
                } else {
                    $semestre.prop('disabled', false);
                }

            } else {
                $('#id_serie').html('<option value="">Escolha a modalidade</option>').trigger('chosen:updated');
            }
        });
        $('#id_serie').change(function() {
            var serie = $(this).val();
            $('#id_grade').val(serie).trigger('chosen:updated');
        });
    });
</script>
</body>
</html>