<?php
require_once '../../start.php';

$title = "Extens�es";

//Create
if (($_SERVER["REQUEST_METHOD"] === 'POST') && ($_POST["_method"] === 'POST')) {
    unset($_POST["_method"]);
    if (!Extensoes::create($_POST)) {
        Notification::error("N�o foi poss�vel cadastrar a extens�o!");
    } else {
        Notification::success("Extens�o cadastrada com sucesso!");
    }

    redirect("escola/turma/extensoes.php");
}

//Update
if (($_SERVER["REQUEST_METHOD"] === 'POST') && ($_POST["_method"] === 'PUT')) {
    $id = $_POST["id"];
    unset($_POST["id"]);
    unset($_POST["_method"]);

    if (!Extensoes::update($id, $_POST)) {
        Notification::error("N�o foi poss�vel atualizar a extens�o!");
    } else {
        Notification::success("Extens�o atualizada com sucesso!");
    }

    redirect("escola/turma/extensoes.php");
}

$extensoesGroup = [];

if ($_SERVER["REQUEST_METHOD"] === 'GET' && (isset($_GET["escola_codigo"]) || isset($_GET["search"]))) {
    $escola_id = empty($_GET["escola_codigo"]) ? null : (int) $_GET["escola_codigo"];
    $string = empty($_GET["search"]) ? null : trim($_GET["search"]);

    $extensoesGroup = array_reduce(Extensoes::search($string, $escola_id), function ($acc, $extensao) {
        $acc[$extensao['escola']][] = $extensao;

        return $acc;
    }, []);

    if (empty($extensoesGroup)) $extensoesGroup = null;
}

$municipios = Municipio::getAll();
$escolas = Escola::getList();
?>

<!doctype html>
<html lang="pt-Br">
<head>
    <?php require_once page_head()?>
</head>
<body>
    <?php require_once page_header()?>

    <div class="container">

        <!--Form/Create -->
        <div id="nova-extensao" style="display: none">
            <div class="well well-sm" >
                <h4>Nova extens�o</h4>

                <hr>

                <form method="POST" action="">
                    <input type="hidden" name="_method" value="POST">
                    <div class="row">
                        <div class="col-sm-3">
                            <div class="form-group">
                                <label for="descricao">Descri��o</label>
                                <input type="text" id="descricao" name="descricao" class="form-control text-uppercase" required>
                            </div>
                        </div>

                        <div class="col-sm-3">
                            <div class="form-group">
                                <label for="responsavel_local">Respons�vel Local</label>
                                <input type="text" id="responsavel_local" name="responsavel_local" class="form-control text-uppercase">
                            </div>
                        </div>

                        <div class="col-sm-2">
                            <div class="form-group">
                                <label for="telefone">Telefone</label>
                                <input type="text" id="telefone" name="telefone" class="form-control mask-telefone">
                            </div>
                        </div>

                        <div class="col-sm-4">
                            <div class="form-group">
                                <label for="escola_id">Escola</label>
                                <select id="escola_id" name="escola_id" class="form-control" required>
                                    <option value="">Selecione</option>
                                    <?php foreach ($escolas as $escola): ?>
                                        <option value="<?= $escola["codigo"]?>"><?= $escola["descricao"] ?></option>
                                    <?php endforeach; ?>
                                </select>
                            </div>
                        </div>
                    </div>

                    <div class="row">
                        <div class="col-sm-3">
                            <div class="form-group">
                                <label for="endereco">Endere�o</label>
                                <input type="text" id="endereco" name="endereco" class="form-control text-uppercase">
                            </div>
                        </div>

                        <div class="col-sm-2">
                            <div class="form-group">
                                <label for="cep">CEP</label>
                                <input type="text" id="cep" name="cep" class="form-control mask-cep">
                            </div>
                        </div>

                        <div class="col-sm-2">
                            <div class="form-group">
                                <label for="zona">Zona</label>
                                <select id="zona" name="zona" class="form-control" required>
                                    <option value="rural">Rural</option>
                                    <option value="urbana">Urbana</option>
                                </select>
                            </div>
                        </div>

                        <div class="col-sm-3">
                            <div class="form-group">
                                <label for="ex_municipio">Municipio</label>
                                <select id="ex_municipio" name="municipio_id" class="form-control" required>
                                    <option value="">Selecione</option>
                                    <?php foreach ($municipios as $municipio): ?>
                                        <option value="<?= $municipio["codigo"]?>"><?= $municipio["descricao"] ?></option>
                                    <?php endforeach; ?>
                                </select>
                            </div>
                        </div>

                        <div class="col-sm-2 col-xs-12">
                            <button type="submit" class="btn btn-primary btn-offset btn-block">
                                Salvar
                            </button>
                        </div>
                    </div>
                </form>
            </div>
        </div>

        <div class="row">
            <!-- Form/Busca-->
            <div class="col-sm-12">
                <div class="well well-sm">
                    <h4>
                        Buscar extens�es por escola
                        <button class="btn btn-success pull-right" id="btn-nova-extensao" type="button" data-toggle="collapse" data-target="#nova-extensao" aria-expanded="false" aria-controls="nova-extensao">
                            Nova extens�o
                        </button>
                    </h4>
                    <hr>
                    <form method="get">
                        <div class="row">
                            <div class="col-sm-5 col-xs-12">
                                <div class="form-group">
                                    <label for="search">Extens�o</label>
                                    <input type="text" class="form-control" id="search" name="search" value="<?= isset($_GET["search"]) ? $_GET["search"] : ''?>" placeholder="Busque pelo nome da extens�o">
                                </div>
                            </div>

                            <div class="col-sm-5 col-xs-12">
                                <div class="form-group">
                                    <label for="escola">Escola</label>
                                    <select class="form-control chosen" name="escola_codigo" id="escola">
                                        <option value="">Buscar em todas as escolas</option>
                                        <?php foreach ($escolas as $escola): ?>
                                            <option value="<?= $escola["codigo"]?>" <?= (isset($_GET["escola_codigo"]) && $escola["codigo"] === $_GET["escola_codigo"]) ? ' selected' : ''?> ><?= $escola["descricao"] ?></option>
                                        <?php endforeach; ?>
                                    </select>
                                </div>
                            </div>

                            <div class="col-sm-2 col-xs-12">
                                <button type="submit" class="btn btn-primary btn-block" style="margin-top: 25px">Buscar</button>
                            </div>
                        </div>
                    </form>
                </div>

                <?php if (!empty($extensoesGroup)): ?>
                    <?php foreach ($extensoesGroup as $escola => $extensoes): ?>
                        <div class="panel panel-default">
                            <div class="panel-heading">
                                <h3 class="panel-title"><?= $escola ?></h3>
                            </div>

                            <div class="panel-body">
                                <div class="list-group">
                                    <?php foreach ($extensoes as $extensao): ?>
                                        <div class="list-group-item">
                                            <a class="text-muted collapsed" role="button" data-toggle="collapse" data-parent="#accordion" href="#collapse<?= $extensao['id'] ?>" aria-expanded="false" aria-controls="collapse<?= $extensao['id'] ?>">
                                                <?= $extensao["descricao"] ?>, <small><?= $extensao["municipio"] ?></small>
                                            </a>

                                            <?php if ($extensao['ativo'] === 'S'): ?>
                                                <span class="label label-success" style="margin-left: 20px">ativa</span>
                                            <?php else: ?>
                                                <span class="label label-danger" style="margin-left: 20px">inativa</span>
                                            <?php endif; ?>

                                            <div class="pull-right">
                                                <button type="button" class="btn btn-primary btn-xs" data-toggle="modal" data-target="#extensao-<?= $extensao['id'] ?>">
                                                    editar
                                                </button>
                                            </div>

                                            <div class="modal fade" id="extensao-<?= $extensao['id'] ?>" tabindex="-1" role="dialog" aria-labelledby="extensao-<?= $extensao['id'] ?>">
                                                <div class="modal-dialog">
                                                    <div class="modal-content">
                                                        <div class="modal-header">
                                                            <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
                                                            <h4 class="modal-title">
                                                                Editar Extens�o
                                                            </h4>
                                                        </div>

                                                        <div class="modal-body">
                                                            <form method="POST">
                                                                <input type="hidden" name="_method" value="PUT">
                                                                <input type="hidden" name="id" value="<?= $extensao['id'] ?>">

                                                                <div class="row">
                                                                    <div class="col-sm-9 col-xs-12">
                                                                        <div class="form-group">
                                                                            <label for="descricao">Descri��o</label>
                                                                            <input type="text" id="descricao" name="descricao" class="form-control text-uppercase" value="<?= $extensao["descricao"] ?>" required>
                                                                        </div>
                                                                    </div>

                                                                    <div class="col-sm-3 col-xs-12">
                                                                        <div class="form-group">
                                                                            <label for="ativo">Ativo</label>
                                                                            <select name="ativo" id="ativo" class="form-control">
                                                                                <option value="S" <?= ($extensao["ativo"] === 'S') ? 'selected' : ''?>>Sim</option>
                                                                                <option value="N" <?= ($extensao["ativo"] === 'N') ? 'selected' : '' ?>>N�o</option>
                                                                            </select>
                                                                        </div>
                                                                    </div>
                                                                </div>

                                                                <div class="row">
                                                                    <div class="col-sm-8 col-xs-12">
                                                                        <div class="form-group">
                                                                            <label for="responsavel_local">Respons�vel Local</label>
                                                                            <input type="text" id="responsavel_local" name="responsavel_local" class="form-control text-uppercase" value="<?= $extensao["responsavel_local"] ?>">
                                                                        </div>
                                                                    </div>

                                                                    <div class="col-sm-4 col-xs-12">
                                                                        <div class="form-group">
                                                                            <label for="telefone">Telefone</label>
                                                                            <input type="text" id="telefone" name="telefone" class="form-control mask-telefone" value="<?= $extensao["telefone"] ?>">
                                                                        </div>
                                                                    </div>
                                                                </div>

                                                                <div class="row">
                                                                    <div class="col-sm-7 col-xs-12">
                                                                        <div class="form-group">
                                                                            <label for="endereco">Endere�o</label>
                                                                            <input type="text" id="endereco" name="endereco" class="form-control text-uppercase" value="<?= $extensao['endereco'] ?>">
                                                                        </div>
                                                                    </div>

                                                                    <div class="col-sm-5 col-xs-12">
                                                                        <div class="form-group">
                                                                            <label for="cep">CEP</label>
                                                                            <input type="text" id="cep" name="cep" class="form-control mask-cep" value="<?= $extensao['cep'] ?>">
                                                                        </div>
                                                                    </div>
                                                                </div>

                                                                <div class="row">
                                                                    <div class="col-sm-4 col-xs-12">
                                                                        <div class="form-group">
                                                                            <label for="zona">Zona</label>
                                                                            <select id="zona" name="zona" class="form-control" required>
                                                                                <option value="urbana" <?= ($extensao['zona'] === 'urbana') ? 'selected' : ''?>>Urbana</option>
                                                                                <option value="rural" <?= ($extensao['zona'] === 'rural') ? 'selected' : ''?>>Rural</option>
                                                                            </select>
                                                                        </div>
                                                                    </div>

                                                                    <div class="col-sm-8 col-xs-12">
                                                                        <div class="form-group">
                                                                            <label for="municipio">Munic�pio</label>
                                                                            <select id="municipio" name="municipio_id" class="form-control chosen" required>
                                                                                <option value="">Selecione</option>
                                                                                <?php foreach ($municipios as $municipio): ?>
                                                                                    <option value="<?= $municipio["codigo"]?>" <?= ($extensao["municipio_id"] === $municipio["codigo"]) ? ' selected' : '' ?>><?= $municipio["descricao"] ?></option>
                                                                                <?php endforeach; ?>
                                                                            </select>
                                                                        </div>
                                                                    </div>
                                                                </div>

                                                                <div class="row">
                                                                    <hr>

                                                                    <div class="col-sm-offset-8 col-sm-4 col-xs-12">
                                                                        <button class="btn btn-default">
                                                                            Cancelar
                                                                        </button>

                                                                        <button class="btn btn-primary">
                                                                            Salvar
                                                                        </button>
                                                                    </div>
                                                                </div>
                                                            </form>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>

                                        <div id="collapse<?= $extensao['id'] ?>" class="panel-collapse collapse" role="tabpanel" aria-labelledby="heading<?= $extensao['id'] ?>">
                                            <div class="panel-body">
                                                <div class="row">
                                                    <div class="col-sm-6">
                                                        <span class="text-muted">Responsvel:</span> <?= $extensao["responsavel_local"] ?>
                                                        <br>
                                                        <span class="text-muted">Zona:</span> <span class="label label-info"><?= $extensao["zona"] ?></span><br>
                                                    </div>

                                                    <div class="col-sm-6">
                                                        <span class="text-muted">Endereo:</span> <?= $extensao["endereco"] ?><br>
                                                        <span class="text-muted">Telefone:</span> <?= $extensao["telefone"] ?>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    <?php endforeach; ?>
                                </div>
                            </div>
                        </div>
                    <?php endforeach; ?>
                <?php endif; ?>
                <?php if (is_null($extensoesGroup)): ?>
                    <div >
                        <p class="alert alert-info">Extens�o n�o encontrada</p>
                    </div>
                <?php endif; ?>
            </div>
        </div>
    </div>

    <?php require_once page_footer()?>
    <script>
        $(function () {
            var $box_nova_extensao = $("#nova-extensao");
            var $extEscola = $("#escola_id");
            var $extMunicipio = $("#ex_municipio");

            $("#btn-nova-extensao").on('click', function () {
                $box_nova_extensao.toggle();
                $extEscola.chosen();
                $extMunicipio.chosen();
            });

        });
    </script>
</body>
</html>
