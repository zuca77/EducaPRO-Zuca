<?php
session_start();

if (isset($_SESSION["login_usuario"]))
  {
   // session_cache_expire(1);
	 $login     =  $_SESSION["login_usuario"];
     $nte       =  $_SESSION["nivel_usuario"];
	 $inep      =  $_SESSION["inep_usuario"] ;
     $ntelogin  =  $_SESSION["nte_login"];
     $cpf       = $_SESSION["cpf_usuario"];
     
	 include ("../funcoes.php");
     echo  saudacoes()."   ". "$login" ."  -  ". $nte."  ".dataextenso()." ".$inep;

  }
 else
  {
     		 header("../../Location: login.php");
  }


include ("../../conexao_mysql.php");

if(file_exists("../../conexao_mysql.php"))
{
        require "../../conexao_mysql.php";

} else
{
        echo "Conex�o nao foi encontrado";
        exit;
}

  $id_turmaprof_turma =  $_GET['codigo'];





// $cpf= substr($professor, $posicao);




    if ($id_turmaprof_turma!='')
        $_SESSION["turmaprofessor"] =$id_turmaprof_turma;
    else
       $id_turmaprof_turma  = $_SESSION["turmaprofessor"];


      $totalcaracter   = strlen($id_turmaprof_turma);
      $posicao         = strpos($id_turmaprof_turma, '*');
      $idturmaprofessor = substr($id_turmaprof_turma, 0, $posicao);
      $id_turma        = substr($id_turmaprof_turma, $posicao+1,  $totalcaracter);


/* $tabela_toda = "select * from dias_diario where id_turmaprofessor = '$id_turma'";
 $query = mysql_query($tabela_toda, $conexao) or die(mysql_error());
  while ( $linha1 = mysql_fetch_array( $query ))
    {
       $turmaprofessor  = $linha1["id_turmaprofessor"];
       
    }

  */

  $sql="select t.id,t.cpf,h.descricao as descdisciplina,tu.descricao as descturma,s.nome from turmaprofessor t,habilitacao h,turma tu,servidorrec s
  where t.id_disciplina = h.codigo and tu.id=t.id_turma and s.cpf=t.cpf and t.id  = '$idturmaprofessor'";
  $resultado=mysql_query($sql) or die (mysql_error());
  $linhas=mysql_num_rows($resultado);
  if($linhas>0)
    {
    while($pegar=mysql_fetch_array($resultado))
      {
                       $professor      =$pegar["nome"];
                       $descdisciplina =$pegar["descdisciplina"];
                       $descturma      =   $pegar["descturma"];
        }
     }






?>

<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01//EN"
	"http://www.w3.org/TR/html4/strict.dtd"><head>

    <meta http-equiv="content-type" content="text/html; charset=ISO-8859-1" />

	<title>Gerencia de Tecnologia da Informa��o</title>
	
	
	
	<link rel="stylesheet" href="style/forms.css" type="text/css" />
	<link rel="stylesheet" href="estilo.css" type="text/css" />
	<link rel="stylesheet" href="style/menu.css" type="text/css" />
	<link href="tablecloth/tablecloth.css" rel="stylesheet" type="text/css" media="screen" />
   <link rel="stylesheet" href="css/bootstrap.min.css" type="text/css" />

	
	<script type="text/javascript" src="tablecloth/tablecloth.js"></script>
	<script src="lib/jquery-1.4.2.js" type="text/javascript"></script>
	<script src="lib/validate.js" type="text/javascript"></script>
	<script src="lib/forms.js" type="text/javascript"></script>
	<script src="generic_dia_diario.js" type="text/javascript"></script>
    <script src="lib/jquery.maskedinput-1.1.1.js" type="text/javascript"></script>



 	<link type="text/css" href="jquery-ui-1.8.18.custom/css/ui-lightness/jquery-ui-1.8.18.custom.css" rel="stylesheet" />
	<script type="text/javascript" src="jquery-ui-1.8.18.custom/js/jquery-ui-1.8.18.custom.min.js"></script>


</head>
<body>
	<div id="warpper">
		<div id="header">
            <center>
           <img src= "../img/chamadaescolar.jpg"/>
            </center>
		</div>
    <div id="container">
			<div id="content">

				<form  name="form" class="form" action="insere_dia_diario.php" method="POST">
				 <div id="tema"> 
					   <p><center>Dia Di�rio Por Turma</center></p>
				  </div>




<div id="corpodetalhe" class="fontedetalhe">


<table border="1" width="100%" id = "dados" >


<tr>

 	   <p>
		 <label for="lblinep24" style="width:200px">Professor</label>
		 <font size="2" color="#0000FF"><?echo $professor;?>
 	   </p>

 	   <p>
		 <label for="lblinep24" style="width:200px">Disciplina</label>
		 <font size="2" color="#0000FF"><?echo $descdisciplina;?>
 	   </p>

 	   <p>
		 <label for="lblinep24" style="width:200px">Turma</label>
		 <font size="2" color="#0000FF"><?echo $descturma;?>
 	   </p>







<td align="center"><font size="2"><b>Bloqueio</b></td><td align="center"><b>Excluir</b></td>
     <td><b>Data</b></td><td><b>Semana</b></td><td><b>Mes</b></td><td><b>Ano</b></td><td><b>Tipo de Aula</b></td><td><b>Registrado</b></td><td><b>Tipo Bloqueio</b></td>
</tr>
<?
/* Seleciona toda tabela   */



/*
 $tabela_toda = "select * from dias_diario where id_turmaprofessor = '$idturmaprofessor' order by data";
 $query = mysql_query($tabela_toda, $conexao) or die(mysql_error());
*/


 $re = mysql_query("SELECT count(*) id from dias_diario where id_turmaprofessor = '$idturmaprofessor'");
 $total = mysql_result($re, 0, "id");

 $pagina = 1;
 $limite = 10000;

if(isset($_GET["pagina"]))
  {
	$pagina = $_GET["pagina"];
  }

 $paginas = ceil($total / $limite);

 $inicio = ($pagina-1) * $limite;


if ($inicio < 0)
  {
      $inicio=1;
  }


$sql2 = mysql_query("select *,d.id as iddiadiario,t.descricao as desctpaula,d.registrado,d.tpbloqueio  from dias_diario d,tipo_aula t where d.id_turmaprofessor = '$idturmaprofessor' and t.id = d.tipo_aula order by data");
$conta = mysql_num_rows($sql2);
if($conta == 0)
   {
     $pagina = $pagina-1;
   }


if($total >=1)
   {

  while ( $linha1 = mysql_fetch_array( $sql2 ))
   {
//      echo "passou";
 
      $tpbloqueio=($linha1["tpbloqueio"]);
       $semana=diasemana($linha1["data"]);
       $mes   =mesatual($linha1["mes"]);
       $data = date("d/m/Y",strtotime($linha1["data"]));
       $ano=$linha1["ano"];




  $sql="select * from bloqueia_aula where id  = '$tpbloqueio'";
  $resultado=mysql_query($sql) or die (mysql_error());
  $linhas=mysql_num_rows($resultado);
  if($linhas>0)
    {
    while($pegar=mysql_fetch_array($resultado))
      {
                       $descricaobloq      =$pegar["descricao"];
        }
     }




?>

<tr>
      <td align="center"><a href="form_bloqueio_aula.php?codigo=<?echo $linha1["iddiadiario"];?>" onClick="return confirm('Acessa tela de bloqueio da aula ?')"><img src="../img/pesquisa_usuario.png" title = "Acessa tela de bloqueio de aula"></a></td>
      <td align="center"><a href="exclui_dias_diario_detalhe.php?codigo=<?echo $linha1["iddiadiario"];?>" onClick="return confirm('Tem certeza da exclus�o do registro ?')"><img src="/public/img/deletar.png" title = "Exclui a data do di�rio independente de seu registro."></a></td>




       <td align="right"><?echo $data;?></a></td>
 	  <td><?echo $semana;?></td>
   	  <td><?echo $mes;?></td>
   	  <td><?echo $ano;?></td>
  	  <td><?echo $linha1["desctpaula"];?></td>
  	  <td><?echo $linha1["registrado"];?></td>
      <td><?echo $descricaobloq;?></td >







  </tr>
<?
}



 $sql = "select count(*) as total from dias_diario d,tipo_aula t where id_turmaprofessor = '$idturmaprofessor' and  t.id = d.tipo_aula and d.tipo_aula in(1,2 )";
 $resultado=mysql_query($sql) or die (mysql_error());
 $linhas=mysql_num_rows($resultado);
 while($pegar=mysql_fetch_array($resultado))
   {
     $total = $pegar["total"];
   }

 $sql = "select count(*) as total from dias_diario d,tipo_aula t where id_turmaprofessor = '$idturmaprofessor' and t.id = d.tipo_aula and d.registrado = 'S'
 and t.id = d.tipo_aula and d.tipo_aula in(1,2 )";

 $resultado=mysql_query($sql) or die (mysql_error());
 $linhas=mysql_num_rows($resultado);
 while($pegar=mysql_fetch_array($resultado))
   {
     $totalregistrada = $pegar["total"];
   }


 $sql = "select count(*) as total from dias_diario d,tipo_aula t where id_turmaprofessor = '$idturmaprofessor' and t.id = d.tipo_aula and d.registrado = 'N'
  and t.id = d.tipo_aula and d.tipo_aula in(1,2 )";

 $resultado=mysql_query($sql) or die (mysql_error());
 $linhas=mysql_num_rows($resultado);
 while($pegar=mysql_fetch_array($resultado))
   {
     $totalnregistrada = $pegar["total"];
   }




 /*AULA DE RECUPERA��O*/
 $sql = "select count(*) as total from dias_diario d,tipo_aula t where id_turmaprofessor = '$idturmaprofessor' and  t.id = d.tipo_aula and d.tipo_aula in(3)";
 $resultado=mysql_query($sql) or die (mysql_error());
 $linhas=mysql_num_rows($resultado);
 while($pegar=mysql_fetch_array($resultado))
   {
     $totalrec = $pegar["total"];
   }


 $sql = "select count(*) as total from dias_diario d,tipo_aula t where id_turmaprofessor = '$idturmaprofessor' and t.id = d.tipo_aula and d.registrado = 'S'
 and t.id = d.tipo_aula and d.tipo_aula in(3)";

 $resultado=mysql_query($sql) or die (mysql_error());
 $linhas=mysql_num_rows($resultado);
 while($pegar=mysql_fetch_array($resultado))
   {
     $totalrecregistrada = $pegar["total"];
   }



  $sql = "select count(*) as total from dias_diario d,tipo_aula t where id_turmaprofessor = '$idturmaprofessor' and t.id = d.tipo_aula and d.registrado = 'N'
  and t.id = d.tipo_aula and d.tipo_aula in(3 )";

 $resultado=mysql_query($sql) or die (mysql_error());
 $linhas=mysql_num_rows($resultado);
 while($pegar=mysql_fetch_array($resultado))
   {
     $totalrecnregistrada = $pegar["total"];
   }



if ($total>0)
  {
?>

  <tr><td><font size="2"> <b><center>Aula = Normal + Reposi��o</center></b></td><td>******* </td>
  </tr>

  <tr><td>Total aula(s) prevista(s) Tipo (N+R)</td>
    	  <td><font size="2"> <?echo $total;?>
  </tr>

  <tr><td>Total de Aula(s) Registrada(s)</td>
    	  <td><font size="2"> <?echo  $totalregistrada;?>
  </tr>

  <tr><td>Total de Aula(s) N�o Registrada(s)</td>
    	  <td><font size="2"> <?echo  $totalnregistrada;?>
  </tr>

  <tr><td><font size="2"> <b><center>Aula = Recupera��o</center></b></td><td>******* </td>
  </tr>

  <tr><td>Total Aula Prevista de Recupera��o</td>
    	  <td><font size="2"> <?echo  $totalrec;?>
  </tr>


  <tr><td>Total Aula de Recupera��o Registrada</td>
    	  <td><font size="2"> <?echo  $totalrecregistrada;?>
  </tr>


  <tr><td>Total Aula de Recupera��o N�o Registrada</td>
    	  <td><font size="2"> <?echo  $totalrecnregistrada;?>
  </tr>




<?
}
else
{
?>

<tr><td>Total</td>
   	  <td><font size="2"> <?echo $total;?> </td>
  </tr>


<?
 } //else

}
else
{

echo "<html><head><title>Resposta !!!</title></head>";
echo "<body background=\"background_mensagens.jpg\" style=\"background-attachment:fixed; background-repeat:no-repeat\">";
echo "<br><br><br>";
echo "<center><img src=\"faleconosco/atencao.gif\" alt=\"\"><p><font color=\"#ff6600\" face=\"Verdana\" size=\"4\">Turma sem previs�o de aula ! <b></b></font></center>";
echo "<br><br><center><a href=\"form_dia_diario_professor.php\"><img src=\"faleconosco/button_voltar2_.gif\" alt=\"Voltar\" border=\"0\" /></a></center>";
echo "</body></html>";
exit;



}
?>
</table>
      <script>
        cor_tabela("tabzebra");
    </script>
 </div><!-- Div corpodetalhe-->
</div><!-- Div corpo2-->

<?
  //mysql_free_result( $resposta );
 // mysql_close($conexao);



function diasemana($data) {
	$ano =  substr("$data", 0, 4);
	$mes =  substr("$data", 5, -3);
	$dia =  substr("$data", 8, 9);

	$diasemana = date("w", mktime(0,0,0,$mes,$dia,$ano) );

	switch($diasemana) {
		case"0": $diasemana = "Domingo";       break;
		case"1": $diasemana = "Segunda-Feira"; break;
		case"2": $diasemana = "Ter�a-Feira";   break;
		case"3": $diasemana = "Quarta-Feira";  break;
		case"4": $diasemana = "Quinta-Feira";  break;
		case"5": $diasemana = "Sexta-Feira";   break;
		case"6": $diasemana = "S�bado";        break;
	}

     return $diasemana;
}




function mesatual($mes){

	switch($mes) {
		case"01": $mes = "Janeiro";       break;
		case"02": $mes = "Fevereiro"; break;
		case"03": $mes = "Mar�o";   break;
		case"04": $mes = "Abril";  break;
		case"05": $mes = "Maio";  break;
		case"06": $mes = "Junho";   break;
		case"07": $mes = "Julho";        break;
        case"08": $mes = "Agosto";        break;
		case"09": $mes = "Setembro";        break;
		case"10": $mes = "Outubro";        break;
		case"11": $mes = "Novembro";        break;
		case"12": $mes = "Dezembro";        break;
	}

     return $mes;
}





/*
function mesatual($mes)
     {
        $mes = 4;
        $meses  = array("JANEIRO","FEVEREIRO","MAR�O","ABRIL","MAIO","JUNHO","JULHO","AGOSTO","SETEMBRO","OUTUBRO","NOVEMBRO","DEZEMBRO");
        $mes    = date("m");
        $mes1   = $meses[date("m",mktime(0,0,0,$mes-1,0,0))*1];
        $mes2   = $meses[date("m",mktime(0,0,0,$mes-2,0,0))*1];
        $mes3   = $meses[date("m",mktime(0,0,0,$mes-3,0,0))*1];
        $mes    = $meses[$mes-1];
        return $mes;
     }
*/

?>
	<p id="finish">
             <button type="button" class="btn" onclick="location.href='form_pesquisa_professor_dia_dairio.php';">Voltar</button>
		</p>
				</form>
			</div>
		</div>

	</div>
</body>






