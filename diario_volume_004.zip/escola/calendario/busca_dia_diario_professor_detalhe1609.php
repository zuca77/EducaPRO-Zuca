<?php
session_start();

if (isset($_SESSION["login_usuario"]))
  {
   // session_cache_expire(1);
	 $login     =  $_SESSION["login_usuario"];
     $nte       =  $_SESSION["nivel_usuario"];
	 $inep      =  $_SESSION["inep_usuario"] ;
     $ntelogin  =  $_SESSION["nte_login"];
     $cpf1       = $_SESSION["cpf_usuario"];

	 include ("../funcoes.php");

  }
 else
  {
     		 header("../../Location: login.php");
  }


include ("../../conexao_mysql.php");

if(file_exists("../../conexao_mysql.php"))
{
        require "../../conexao_mysql.php";

} else
{
        echo "Conex�o nao foi encontrado";
        exit;
}





function diasemana($data) {
	$ano =  substr("$data", 0, 4);
	$mes =  substr("$data", 5, -3);
	$dia =  substr("$data", 8, 9);
    $diasemana = date("w", mktime(0,0,0,$mes,$dia,$ano) );
	switch($diasemana) {
		case"0": $diasemana = "Domingo";       break;
		case"1": $diasemana = "Segunda-Feira"; break;
		case"2": $diasemana = "Terca-Feira";   break;
		case"3": $diasemana = "Quarta-Feira";  break;
		case"4": $diasemana = "Quinta-Feira";  break;
		case"5": $diasemana = "Sexta-Feira";   break;
		case"6": $diasemana = "Sabado";        break;
	}

     return $diasemana;
}




function mesatual($mes){

	switch($mes) {
		case"01": $mes = "Janeiro";       break;
		case"02": $mes = "Fevereiro"; break;
		case"03": $mes = "Mar�o";   break;
		case"04": $mes = "Abril";  break;
		case"05": $mes = "Maio";  break;
		case"06": $mes = "Junho";   break;
		case"07": $mes = "Julho";        break;
        case"08": $mes = "Agosto";        break;
		case"09": $mes = "Setembro";        break;
		case"10": $mes = "Outubro";        break;
		case"11": $mes = "Novembro";        break;
		case"12": $mes = "Dezembro";        break;
	}

     return $mes;
}




$id=$_GET["valor"];


 $totalcaracter     = strlen($id);
 $posicao           = strpos($id, '*');
 $idturmaprofessor   = substr($id, 0, $posicao);
 $id_etapa          = substr($id, $posicao+1,  $totalcaracter);



if(!empty($_GET["valor"]))
 {



/******************************************************************************************************/
$sql="SELECT ano, situacao FROM ano where situacao = 'A' and inep = '$inep'";
$resultado=mysql_query($sql) or die (mysql_error());
$linhas=mysql_num_rows($resultado);
if ($linhas>0)
 {
    while($pegar=mysql_fetch_array($resultado))
   {
         $txtano       = $pegar["ano"];
   }
 }


/*
$sqlgerencia = "select * from  etapa_liberacao where inep  = '$inep'
               and ano= '$txtano'
               and id_etapa = '$id_etapa'
               and situacao = 'F'";
$resultadoger=mysql_query($sqlgerencia) or die (mysql_error());
$linhas   =mysql_num_rows($resultadoger);
if($linhas>0)
{
*/ 
/************* O lan�amento est� dentro do prazo*****************************/
/*  
                    echo "<html><head><title>Resposta !!!</title></head>";
                      echo "<body background=\"background_mensagens.jpg\" style=\"background-attachment:fixed; background-repeat:no-repeat\">";
                      echo "<br><br><br>";
                      echo "<center><img src=\"faleconosco/atencao.gif\" alt=\"\"><p><font color=\"#FF0000\" face=\"Verdana\" size=\"4\">
                      <b>Etapa encerrado.</b></font></center>";
                      echo "<br><br><center><a href=\"../mnprofessor.php\"><img src=\"faleconosco/button_voltar2_.gif\" alt=\"Voltar\" border=\"0\" /></a></center>";
                      echo "</body></html>";
                      exit;
}

*/
$sqlgerencia = "select * from  etapa_liberacao where inep  = '$inep'
               and ano= '$txtano'
               and situacao = 'A'
               and id_etapa = '$id_etapa'";
$resultadoger=mysql_query($sqlgerencia) or die (mysql_error());
$linhas   =mysql_num_rows($resultadoger);
if($linhas<=0)
{
    /************* O lan�amento est� dentro do prazo*****************************/
                      echo "<html><head><title>Resposta !!!</title></head>";
                      echo "<body background=\"background_mensagens.jpg\" style=\"background-attachment:fixed; background-repeat:no-repeat\">";
                      echo "<br><br><br>";
                      echo "<center><img src=\"faleconosco/atencao.gif\" alt=\"\"><p><font color=\"#FF0000\" face=\"Verdana\" size=\"4\"><b>Periodo nao definido.</b></font></center>";
                      echo "<br><br><center><a href=\"../mnprofessor.php\"><img src=\"faleconosco/button_voltar2_.gif\" alt=\"Voltar\" border=\"0\" /></a></center>";
                      echo "</body></html>";
                      exit;
}




$sqlgerencia = "select * from  etapa_liberacao where inep  = '$inep'
               and ano= '$txtano'
               and situacao  = 'A'
               and id_etapa  = '$id_etapa'";
$resultadoger=mysql_query($sqlgerencia) or die (mysql_error());
$linhas   =mysql_num_rows($resultadoger);
if($linhas>0)
{
     while ( $pega_dados = mysql_fetch_array( $resultadoger ))
        {
          $dt_inicio   = $pega_dados["dt_inicio"];
          $dt_fim       = $pega_dados["dt_fim"];
        }
}
else
{

                      echo "<html><head><title>Resposta !!!</title></head>";
                      echo "<body background=\"background_mensagens.jpg\" style=\"background-attachment:fixed; background-repeat:no-repeat\">";
                      echo "<br><br><br>";
                      echo "<center><img src=\"faleconosco/atencao.gif\" alt=\"\"><p><font color=\"#FF0000\" face=\"Verdana\" size=\"4\"><b>Lan�amento de nota fora do per�do.</b></font></center>";
                      echo "<br><br><center><a href=\"../mnprofessor.php\"><img src=\"faleconosco/button_voltar2_.gif\" alt=\"Voltar\" border=\"0\" /></a></center>";
                      echo "</body></html>";
                      exit;


}




/**********************************************************************************************************************************************/










  $sql="select t.id,tu.id as id_turma,t.cpf,h.descricao as descdisciplina,tu.descricao as descturma,s.nome,h.codigo
  from turmaprofessor t,habilitacao h,turma tu,servidorrec s
  where t.id_disciplina = h.codigo and tu.id=t.id_turma and s.cpf=t.cpf and t.id  = '$idturmaprofessor'";
  $resultado=mysql_query($sql) or die (mysql_error());
  $linhas=mysql_num_rows($resultado);
  if($linhas>0)
    {
      while($pegar_turma=mysql_fetch_array($resultado))
          {
                         $id_turma_prof           =$pegar_turma["id_turma"];
                         $cpf_prof                =$pegar_turma["cpf"];
                         $id_disc_prof            =$pegar_turma["codigo"];
                         
          }










?>
<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01//EN"
	"http://www.w3.org/TR/html4/strict.dtd"><head>
<head>
    <meta http-equiv="content-type" content="text/html; charset=ISO-8859-1" />
    <link rel="stylesheet" href="../css/bootstrap.min.css" type="text/css" />
</head>
<body>

<table class="table-hover">
<tr>
<td align="center"><font size="2"><b>Bloqueio</b></td><td align="center"><b>Excluir</b></td>
     <td><b>Data</b></td><td><b>Semana</b></td><td><b>Mes</b></td><td><b>Ano</b></td><td><b>Tipo de Aula</b></td><td><b>Registrado</b></td><td><b>Tipo Bloqueio</b></td>
</tr>

<?

 $re = mysql_query("SELECT count(*) id from dias_diario where id_turmaprofessor = '$idturmaprofessor'");
 $total = mysql_result($re, 0, "id");

 $pagina = 1;
 $limite = 10000;

if(isset($_GET["pagina"]))
  {
	$pagina = $_GET["pagina"];
  }

 $paginas = ceil($total / $limite);

 $inicio = ($pagina-1) * $limite;


if ($inicio < 0)
  {
      $inicio=1;
  }


/*echo "$id_turma_prof*";
echo "$idturmaprofessor*";
echo "$id_disc_prof*";
echo "$dt_inicio*";
echo "$dt_fim";
*/
$sql2 = mysql_query("select *,d.id as iddiadiario,t.descricao as desctpaula,d.registrado,d.tpbloqueio
from dias_diario d,tipo_aula t where d.id_turmaprofessor = '$idturmaprofessor'
and t.id = d.tipo_aula and (d.data >= '$dt_inicio' and  d.data <= '$dt_fim') and d.id_disciplina = '$id_disc_prof'
and d.id_turma = '$id_turma_prof' order by data");
$conta = mysql_num_rows($sql2);
if($conta == 0)
   {
     $pagina = $pagina-1;
   }


if($total >=1)
   {

  while ( $linha1 = mysql_fetch_array( $sql2 ))
   {


       $tpbloqueio=($linha1["tpbloqueio"]);
       $semana= diasemana ($linha1["data"]);
       $mes   = mesatual($linha1["mes"]);
       $data = date("d/m/Y",strtotime($linha1["data"]));
       $ano=$linha1["ano"];







  $sql="select * from bloqueia_aula where id  = '$tpbloqueio'";
  $resultado=mysql_query($sql) or die (mysql_error());
  $linhas=mysql_num_rows($resultado);
  if($linhas>0)
    {
    while($pegar=mysql_fetch_array($resultado))
      {
                       $descricaobloq      =$pegar["descricao"];
        }
     }




?>



<tr>


      <td align="center"><a href="form_bloqueio_aula.php?codigo=<?echo $linha1["iddiadiario"];?>" onClick="return confirm('Acessa tela de bloqueio da aula ?')"><img src="../img/pesquisa_usuario.png" title = "Acessa tela de bloqueio de aula"></a></td>
      <td align="center"><a href="exclui_dias_diario_detalhe.php?codigo=<?echo $linha1["iddiadiario"];?>" onClick="return confirm('Tem certeza da exclus�o do registro ?')"><img src="/public/img/deletar.png" title = "Exclui a data do di�rio independente de seu registro."></a></td>




       <td align="right"><?echo $data;?></a></td>
 	  <td><?echo $semana;?></td>
   	  <td><?echo $mes;?></td>
   	  <td><?echo $ano;?></td>
  	  <td><?echo $linha1["desctpaula"];?></td>
  	  <td><?echo $linha1["registrado"];?></td>
      <td><?echo $descricaobloq;?></td >


  </tr>
<?
}




 $sql = "select count(*) as total from dias_diario d,tipo_aula t where id_turmaprofessor = '$idturmaprofessor' and  t.id = d.tipo_aula
 and d.tipo_aula in(1,2 ) and t.id = d.tipo_aula and (d.data >= '$dt_inicio' and  d.data <= '$dt_fim') and d.id_disciplina = '$id_disc_prof'";
 $resultado=mysql_query($sql) or die (mysql_error());
 $linhas=mysql_num_rows($resultado);
 while($pegar=mysql_fetch_array($resultado))
   {
     $total = $pegar["total"];
   }

 $sql = "select count(*) as total from dias_diario d,tipo_aula t where id_turmaprofessor = '$idturmaprofessor' and t.id = d.tipo_aula and d.registrado = 'S'
 and t.id = d.tipo_aula and d.tipo_aula in(1,2 ) and t.id = d.tipo_aula and (d.data >= '$dt_inicio' and  d.data <= '$dt_fim') and d.id_disciplina = '$id_disc_prof'";

 $resultado=mysql_query($sql) or die (mysql_error());
 $linhas=mysql_num_rows($resultado);
 while($pegar=mysql_fetch_array($resultado))
   {
     $totalregistrada = $pegar["total"];
   }


 $sql = "select count(*) as total from dias_diario d,tipo_aula t where id_turmaprofessor = '$idturmaprofessor' and t.id = d.tipo_aula and d.registrado = 'N'
  and t.id = d.tipo_aula and d.tipo_aula in(1,2 ) and t.id = d.tipo_aula and (d.data >= '$dt_inicio' and  d.data <= '$dt_fim') and d.id_disciplina = '$id_disc_prof'";

 $resultado=mysql_query($sql) or die (mysql_error());
 $linhas=mysql_num_rows($resultado);
 while($pegar=mysql_fetch_array($resultado))
   {
     $totalnregistrada = $pegar["total"];
   }




 /*AULA DE RECUPERA��O*/
 $sql = "select count(*) as total from dias_diario d,tipo_aula t where id_turmaprofessor = '$idturmaprofessor'
 and  t.id = d.tipo_aula and d.tipo_aula in(3) and t.id = d.tipo_aula and (d.data >= '$dt_inicio' and  d.data <= '$dt_fim') and d.id_disciplina = '$id_disc_prof'";
 $resultado=mysql_query($sql) or die (mysql_error());
 $linhas=mysql_num_rows($resultado);
 while($pegar=mysql_fetch_array($resultado))
   {
     $totalrec = $pegar["total"];
   }


 $sql = "select count(*) as total from dias_diario d,tipo_aula t where id_turmaprofessor = '$idturmaprofessor' and t.id = d.tipo_aula and d.registrado = 'S'
 and t.id = d.tipo_aula and d.tipo_aula in(3) and t.id = d.tipo_aula and (d.data >= '$dt_inicio' and  d.data <= '$dt_fim') and d.id_disciplina = '$id_disc_prof'";

 $resultado=mysql_query($sql) or die (mysql_error());
 $linhas=mysql_num_rows($resultado);
 while($pegar=mysql_fetch_array($resultado))
   {
     $totalrecregistrada = $pegar["total"];
   }



  $sql = "select count(*) as total from dias_diario d,tipo_aula t where id_turmaprofessor = '$idturmaprofessor' and t.id = d.tipo_aula and d.registrado = 'N'
  and t.id = d.tipo_aula and d.tipo_aula in(3) and t.id = d.tipo_aula and (d.data >= '$dt_inicio' and  d.data <= '$dt_fim') and d.id_disciplina = '$id_disc_prof'";

 $resultado=mysql_query($sql) or die (mysql_error());
 $linhas=mysql_num_rows($resultado);
 while($pegar=mysql_fetch_array($resultado))
   {
     $totalrecnregistrada = $pegar["total"];
   }



if ($total>0)
  {
?>

  <tr><td><font size="2"> <b><center>Aula = Normal + Reposicao</center></b></td><td>******* </td>
  </tr>

  <tr><td>Total aula(s) prevista(s) Tipo (N+R)</td>
    	  <td><font size="2"> <?echo $total;?>
  </tr>

  <tr><td>Total de Aula(s) Registrada(s)</td>
    	  <td><font size="2"> <?echo  $totalregistrada;?>
  </tr>

  <tr><td>Total de Aula(s) Nao Registrada(s)</td>
    	  <td><font size="2"> <?echo  $totalnregistrada;?>
  </tr>

  <tr><td><font size="2"> <b><center>Aula = Recuperacao</center></b></td><td>******* </td>
  </tr>

  <tr><td>Total Aula Prevista de Recuperacao</td>
    	  <td><font size="2"> <?echo  $totalrec;?>
  </tr>


  <tr><td>Total Aula de Recuperacao Registrada</td>
    	  <td><font size="2"> <?echo  $totalrecregistrada;?>
  </tr>


  <tr><td>Total Aula de Recuperacao Nao Registrada</td>
    	  <td><font size="2"> <?echo  $totalrecnregistrada;?>
  </tr>




<?
}
else
{
?>

<tr><td>Total</td>
   	  <td><font size="2"> <?echo $total;?> </td>
  </tr>


<?
 } //else

}
else
{

echo "<html><head><title>Resposta !!!</title></head>";
echo "<body background=\"background_mensagens.jpg\" style=\"background-attachment:fixed; background-repeat:no-repeat\">";
echo "<br><br><br>";
echo "<center><img src=\"faleconosco/atencao.gif\" alt=\"\"><p><font color=\"#ff6600\" face=\"Verdana\" size=\"4\">Turma sem previs�o de aula ! <b></b></font></center>";
echo "<br><br><center><a href=\"form_dia_diario_professor.php\"><img src=\"faleconosco/button_voltar2_.gif\" alt=\"Voltar\" border=\"0\" /></a></center>";
echo "</body></html>";
exit;



}
?>
</table>
 </div><!-- Div corpodetalhe-->
</div><!-- Div corpo2-->

<?




    }
   }
?>
				</form>
			</div>
		</div>

	</div>
</form>
</body>
</html>





