<?php
session_start();

if (isset($_SESSION["login_usuario"]))
  {
   // session_cache_expire(1);
	 $login     =  $_SESSION["login_usuario"];
     $nte       =  $_SESSION["nivel_usuario"];
	 $inep      =  $_SESSION["inep_usuario"] ;
     $ntelogin  =  $_SESSION["nte_login"];
     $cpf1       = $_SESSION["cpf_usuario"];
     $txtano_fechado    =  $_SESSION["txtano_fechado"];
     $form_menu         =  $_SESSION["form_menu"];

	 include ("../funcoes.php");

  }
 else
  {
     		 header("../../Location: login.php");
  }


include ("../../conexao_mysql.php");

if(file_exists("../../conexao_mysql.php"))
{
        require "../../conexao_mysql.php";

} else
{
        echo "Conex�o nao foi encontrado";
        exit;
}




$sql="SELECT ano, situacao FROM ano where situacao = 'A' and inep = '$inep'";
$resultado=mysql_query($sql) or die (mysql_error());
$linhas=mysql_num_rows($resultado);
if ($linhas>0)
 {
    while($pegar=mysql_fetch_array($resultado))
   {
          $txtano          = $pegar["ano"];
   }
 }


$sql="SELECT ano, situacao FROM ano where situacao = 'A' and inep = '$inep'";
$resultado=mysql_query($sql) or die (mysql_error());
$linhas=mysql_num_rows($resultado);
if ($linhas>0)
 {
    while($pegar=mysql_fetch_array($resultado))
   {
          $txtano          = $pegar["ano"];
   }
 }


if ($form_menu=='mnadmescola_ano_fechado')
    {
        $txtano     =   $txtano_fechado;
        $txtano_bd  =   $txtano_fechado;
        if ($txtano_fechado <= '2014')
            $txtano_bd  ="";
    }
else  if  ($txtano  >= 2015)
           $txtano_bd =  $txtano;
else
          $txtano_bd ="";





if($_SERVER["REQUEST_METHOD"] == "POST")
{

$id_turma_professor	         = $_POST['id'];
$turmadiario	             = $_POST['txtidturma'];
$data                        = $_POST['selectmes'];

$id_tp_rel                  = $_POST['selecttp_pesquisa'];
$id_etapa                    = $_POST['txtetapa'];


 $turmadiario =$id_turma_professor;

}


               if($id_tp_rel=="")
                  {
                      echo "<html><head><title>Resposta !!!</title></head>";
                      echo "<body background=\"background_mensagens.jpg\" style=\"background-attachment:fixed; background-repeat:no-repeat\">";
                      echo "<br><br><br>";
                      echo "<center><img src=\"faleconosco/atencao.gif\" alt=\"\"><p><font color=\"#FF0000\" face=\"Verdana\" size=\"4\"><b>Selecione o tipo de relat�rio.</b></font></center>";
                      echo "</body></html>";
                      exit;
                   }



               if (($id_etapa == "") && ($data == ""))
                  {
                      echo "<html><head><title>Resposta !!!</title></head>";
                      echo "<body background=\"background_mensagens.jpg\" style=\"background-attachment:fixed; background-repeat:no-repeat\">";
                      echo "<br><br><br>";
                      echo "<center><img src=\"faleconosco/atencao.gif\" alt=\"\"><p><font color=\"#FF0000\" face=\"Verdana\" size=\"4\"><b>Selecione a etapa ou o m�s.</b></font></center>";
                      echo "</body></html>";
                      exit;
                   }



$sqlturmaprof="SELECT id_turma,cpf,id_disciplina FROM turmaprofessor where id = '$id_turma_professor'";
$resultadoturmaprof=mysql_query($sqlturmaprof) or die (mysql_error());
$linhasturmaprof=mysql_num_rows($resultadoturmaprof);
if ($linhasturmaprof > 0)
 {
    while($pegarturmaprof=mysql_fetch_array($resultadoturmaprof))
   {
         $txtturma_prof                 = $pegarturmaprof["id_turma"];
         $cpf_prof                      = $pegarturmaprof["cpf"];
         $id_disciplina_prof            = $pegarturmaprof["id_disciplina"];
         $idurma = $txtturma_prof; // variavel usada la embaixo
   }
 }

$sqlturma="SELECT modalidade,semestre FROM turma where inep = '$inep' and id = '$txtturma_prof'";
$resultadoturma=mysql_query($sqlturma) or die (mysql_error());
$linhasturma=mysql_num_rows($resultadoturma);
if ($linhasturma>0)
 {
    while($pegarturma=mysql_fetch_array($resultadoturma))
   {
         $txtmodalidade       = $pegarturma["modalidade"];
         $id_semestre         = $pegarturma["semestre"];
   }
 }


/*******************************Verificando se as etapas estao definidas ou nao*********************************************************************/


if($id_tp_rel=="E")
{

if (($txtmodalidade=='1') || ($txtmodalidade =='3'))
{


               $sqlgerencia = "select * from  etapa_liberacao
               where inep  = '$inep'
               and   ano= '$txtano'
               and id_modalidade = '$txtmodalidade'
               and id_etapa = '$id_etapa'";


               $resultadoger=mysql_query($sqlgerencia) or die (mysql_error());
               $linhas   =mysql_num_rows($resultadoger);
               if($linhas<=0)
                  {
                      echo "<html><head><title>Resposta !!!</title></head>";
                      echo "<body background=\"background_mensagens.jpg\" style=\"background-attachment:fixed; background-repeat:no-repeat\">";
                      echo "<br><br><br>";
                      echo "<center><img src=\"faleconosco/atencao.gif\" alt=\"\"><p><font color=\"#FF0000\" face=\"Verdana\" size=\"4\"><b>Per�odo n�o definido.</b></font></center>";
                      echo "</body></html>";
                      exit;
                   }
 }
else
{
               $sqlgerencia = "select * from  etapa_liberacao where inep  = '$inep'
               and ano= '$txtano'
               and id_modalidade = '$txtmodalidade'
               and semestre  = '$id_semestre'
               and id_etapa = '$id_etapa'";
               $resultadoger=mysql_query($sqlgerencia) or die (mysql_error());
               $linhas   =mysql_num_rows($resultadoger);
               if($linhas<=0)
                   {
                      echo "<html><head><title>Resposta !!!</title></head>";
                      echo "<body background=\"background_mensagens.jpg\" style=\"background-attachment:fixed; background-repeat:no-repeat\">";
                      echo "<br><br><br>";
                      echo "<center><img src=\"faleconosco/atencao.gif\" alt=\"\"><p><font color=\"#FF0000\" face=\"Verdana\" size=\"4\"><b>Per�odo n�o definido ou j� fechado.</b></font></center>";
                      echo "</body></html>";
                      exit;
                   }
  }
}



if($id_tp_rel=="E")
{
if (($txtmodalidade=='1') || ($txtmodalidade=='3'))
{




$sqlgerencia = "select * from  etapa_liberacao where inep  = '$inep'
               and ano= '$txtano'
               and id_modalidade = '$txtmodalidade'
               and id_etapa  = '$id_etapa'";
	$resultadoger=mysql_query($sqlgerencia) or die (mysql_error());
	$linhas   =mysql_num_rows($resultadoger);
	if($linhas>0)
	{
	     while ( $pega_dados = mysql_fetch_array( $resultadoger ))
              {
            $dt_inicio   = $pega_dados["dt_inicio"];
            $dt_fim       = $pega_dados["dt_fim"];

               }
	}
}
else
{
              $sqlgerencia = "select * from  etapa_liberacao where inep  = '$inep'
               and ano= '$txtano'
               and id_modalidade = '$txtmodalidade'
               and semestre  = '$id_semestre'
               and id_etapa  = '$id_etapa'";
	$resultadoger=mysql_query($sqlgerencia) or die (mysql_error());
	$linhas   =mysql_num_rows($resultadoger);
	if($linhas>0)
	{
	     while ( $pega_dados = mysql_fetch_array( $resultadoger ))
              {
            $dt_inicio   = $pega_dados["dt_inicio"];
            $dt_fim       = $pega_dados["dt_fim"];
               }
	}


}
}



/**********************************************************************************************************************************************/






/*echo "id_turma_prof  $id_turma_professor";
echo "tturma         $turmadiario";
echo "data           $data";
echo "pesquisa       $selecttp_pesquisa";
echo "etapa          $txtetapa";
  */

$sqlgerencia = "select e.inep,e.descricao as descescola,e.fone,e.regularizada, e.endereco,e.bairro,e.numero,m.descricao as descmuni from escola e , municipio m
where inep = '$inep' and e.municipio = m.codigo";
$resultadoger=mysql_query($sqlgerencia) or die (mysql_error());
$linhas   =mysql_num_rows($resultadoger);
if($linhas>0)
{
   while($pegar=mysql_fetch_array($resultadoger))
	{

    	$descescola    =$pegar["descescola"];
    	$descmunici    =$pegar["descmuni"];

    	$endereco      =$pegar["endereco"];
    	$bairro        =$pegar["bairro"];
    	$numero        =$pegar["numero"];

    	$fone         =$pegar["fone"];
    	$regularizada        =$pegar["regularizada"];



    }
 }





$sql="SELECT t.id, h.descricao AS descdisciplina, tu.descricao AS descturma, s.nome, h.codigo as disciplina, t.id as idturma, s.cpf, tu.id AS idturma
FROM turmaprofessor t, habilitacao h, turma tu, servidorrec s
WHERE t.id_disciplina = h.codigo
AND tu.id = t.id_turma
AND s.cpf = t.cpf
AND t.id = '$id_turma_professor'";

  $resultado=mysql_query($sql) or die (mysql_error());
  $linhas=mysql_num_rows($resultado);
  if($linhas>0)
    {

?>


<html>
<head>

<title>:: DIARIO ELETRONCIO ::</title>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1">
<link href="../biblioteca/menu/menu.css" rel="stylesheet" type="text/css">
<script language="JavaScript" src="../biblioteca/menu/JSCookMenu.js" type="text/javascript"></script>
<script language="JavaScript" src="../biblioteca/menu/theme.js" type="text/javascript"></script>
<link rel="stylesheet" type="text/css" href="../biblioteca/padraoestilo.css">

<script type="text/javascript" src="../biblioteca/sortabletable.js"></script>
<link type="text/css" rel="StyleSheet" href="../biblioteca/sortabletable.css" />
</head>

<style>
.titulopagina
{
    font-size: 11px;
    color:    #000099;
	background-color:#E8E8E8;
	height:25px;
    font-family: verdana , arial
}

table.bordasimples {border-collapse: collapse;}

table.bordasimples tr td {border:1px solid #CCCCCC;}

.subtitulo
{
	font-family: verdana ;
	font-size: 10pt;
    color: #22408f;
	font-weight: bold;
}

.nomecampo
{
    font-size: 10px;
    color: midnightblue;
    font-family: verdana, arial;
	font-weight: bold;
}
.escrita
{
    font-size: 10px;
    color: #000000;
    font-family: verdana, arial
}
.escritanormal
{
    font-size: 10px;
    color: #000000;
    font-family: verdana, arial;
	font-weight: normal;
}



</style>
<table width="100%">
<tr>
<td>&nbsp;  </td>
</tr>
<tr>
<td>
<table border="0"  class="bordasimples" cellspacing="0"  align="center" width="100%" bgcolor=#ffffff>

<tr>
	<td colspan="6"  bgcolor="#EAEAEA"  class="subtitulo" align="center"><b>GOVERNO DO ESTADO DE ROND�NIA</b></td>
</tr>

<tr>
	<td colspan="6"  bgcolor="#EAEAEA"  class="subtitulo" align="center"><b>SECRETARIA DE ESTADO DA EDUCA��O</b></td>
</tr>

<tr>
	<td colspan="6"  bgcolor="#EAEAEA"  class="subtitulo" align="center"><b>GER�NCIA DE TECNOLOGIA DA INFORMA��O</b></td>
</tr>


<tr>
	<td colspan="6"  bgcolor="#EAEAEA"  class="subtitulo" align="center"><b>Dados da Escola</b></td>
</tr>
<tr>
	<td class="nomecampo"><b>C�digo INEP:</b></td>
	<td>&nbsp;<?echo $inep;?></td>
	<td class="nomecampo"><b>Raz�o Social:</b></td>
	<td class = "escrita">&nbsp;<?echo $descescola;?></td>
	<td class="nomecampo"><b>Zona:</b></td>
	<td>&nbsp;Urbana</td>

</tr>



<tr>
	<td class="nomecampo"><b>Endere�o:</b></td>
	<td class = "escrita">&nbsp;<?echo $endereco;?></td>
	<td class="nomecampo"><b>N�:</b></td>
	<td>&nbsp;<?echo $numero;?></td>
	<td class="nomecampo"><b>Bairro</b></td>
	<td class = "escrita">&nbsp;<?echo $bairro;?></td>

</tr>
<tr>
	<td class="nomecampo"><b>UF:</b></td>
    <td>&nbsp;RO</td>
	<td class="nomecampo"><b>Munic�pio:</b></td>
	<td class = "escrita">&nbsp;<?echo $descmunici;?></td>
	<td class="nomecampo"><b>Regularizada:</b></td>
	<td>&nbsp;<?echo $regularizada;?></td>

  </tr>

 <tr>

	<td class="nomecampo"><b>Telefone:</b></td>
	<td>&nbsp;<?echo $fone;?></td>
	<td class="nomecampo"><b>Dep. administrativa:</b></td>
	<td colspan="3">&nbsp;Estadual</td>
</tr>

</table>
<?

  while($pegar=mysql_fetch_array($resultado))
      {

        $iddisciplina           = $pegar["disciplina"];
        $idturma                = $pegar["idturma"];
        $cpfprofessor           = $pegar["cpf"];

?>



<table width="100%">
<tr>
<td>&nbsp;  </td>
</tr>
<tr>
<td>
<table border="0"  class="bordasimples" cellspacing="0"  align="center" width="100%" bgcolor=#ffffff>

<tr>
	<td colspan="6"  bgcolor="#EAEAEA"  class="subtitulo" align="center"><b>Dados do Professor(a)</b></td>
</tr>
<tr>
	<td class="nomecampo"><b>Nome:</b></td>
	<td>&nbsp;<?echo $pegar["nome"];?></td>
	<td class="nomecampo"><b>Disciplina</b></td>
	<td>&nbsp;<?echo $pegar["descdisciplina"];?></td>
</tr>
<tr>
	<td class="nomecampo"><b>Turma</b></td>
	<td colspan="5">&nbsp;<?echo $pegar["descturma"];?></td>
</tr>
</table>




<table border="0" class="bordasimples"  cellspacing="0"  align="center" width="100%" bgcolor=#ffffff>

<tr>
	<td colspan="6"  bgcolor="#EAEAEA"  class="subtitulo" align="center"><b>Aulas e Cont�udos Ministrados</b></td>
</tr>

<tr>
	<td class="nomecampo"><b>Data:</b></td>
	<td class="nomecampo"><b>Conte�do:</b></td>
</tr>

<?
     }






     if($id_tp_rel=="M")
            {
      $sql_conteudo="select id,id_professor,id_turma,inep,assunto,id_disciplina,data_chamada
      from frequencia_cabeca ".$txtano_bd." where  id_professor = '$cpfprofessor'
      and id_turma = '$idturma' and  inep= '$inep'  and id_disciplina= '$iddisciplina' and  Month(data_chamada) = '$data' ";
          }
     else // etapa
       {


         $sql_conteudo="select id,id_professor,id_turma,inep,assunto,id_disciplina,data_chamada
          from frequencia_cabeca".$txtano_bd."
          where  id_professor = '$cpfprofessor'
          and    id_turma = '$idturma'
          and    inep= '$inep'
          and    id_disciplina= '$iddisciplina'
          and   data_chamada >= '$dt_inicio'
          and  data_chamada<= '$dt_fim'
          order by data_chamada ";
       }

      $resultado_conteudo=mysql_query($sql_conteudo) or die (mysql_error());
      $linhas_conteudo=mysql_num_rows($resultado_conteudo);




      if($linhas_conteudo>0)
         {
           while($pegar_conteudo=mysql_fetch_array($resultado_conteudo))
          {

             $data_chamada      = date("d/m/Y",strtotime($pegar_conteudo["data_chamada"]));
             $assunto          = $pegar_conteudo["assunto"];

    ?>

<tr>
	<td>&nbsp;<?echo $data_chamada;?></td>
	<td class="escritanormal">&nbsp;<?echo $assunto;?></td>
</tr>



     <?

      }
     }
     else
         {

            echo "<html><head><title>Resposta !!!</title></head>";
            echo "<body background=\"background_mensagens.jpg\" style=\"background-attachment:fixed; background-repeat:no-repeat\">";
            echo "<br><br><br>";
            echo "<center><img src=\"faleconosco/atencao.gif\" alt=\"\"><p><font color=\"#ff6600\" face=\"Verdana\" size=\"4\">Turma sem registro de conte�do para o mes selecionado! <b></b></font></center>";
            echo "<br><br><center><a href=\"form_previa_diario_conteudo.php\"><img src=\"faleconosco/button_voltar2_.gif\" alt=\"Voltar\" border=\"0\" /></a></center>";
            echo "</body></html>";
            exit;

         }




 }
else
 {
	echo "<center><p><bl <font color=\"#ff6600\" face=\"Verdana\" size=\"3\"><b><blink>Turma n�o Localizado!!!! </blink><b></b></font></center>";
 }


?>

</table>


<?



if($id_tp_rel=="M")
 {
/*************Total de Aulas******************************/
 $sql = "select count(*) as total
 from dias_diario d,tipo_aula t
 where id_turma = '$idturma'
 and  t.id = d.tipo_aula
 and d.tipo_aula in(1,2 )
 and  Month(data) = '$data'
 and  cpf = '$cpfprofessor'
  and id_disciplina  = '$id_disciplina_prof'";
 $resultado=mysql_query($sql) or die (mysql_error());
 $linhas=mysql_num_rows($resultado);
 while($pegar=mysql_fetch_array($resultado))
   {
     $total = $pegar["total"];
   }
/*************Total de Aulas Registradas******************************/
    $sql = "select count(*) as total
    from dias_diario d,tipo_aula t
    where id_turma = '$idturma'
    and t.id = d.tipo_aula
    and d.registrado = 'S'
    and t.id = d.tipo_aula
    and d.tipo_aula in(1,2)
    and  Month(data) = '$data'
    and  cpf = '$cpfprofessor'
     and id_disciplina  = '$id_disciplina_prof'";

 $resultado=mysql_query($sql) or die (mysql_error());
 $linhas=mysql_num_rows($resultado);
 while($pegar=mysql_fetch_array($resultado))
   {
     $totalregistrada = $pegar["total"];
   }

/*************Total de Aulas n�o registradas******************************/
 $sql = "select count(*) as total
 from dias_diario d,tipo_aula t
 where id_turma = '$idturma'
 and t.id = d.tipo_aula
 and d.registrado = 'N'
 and t.id = d.tipo_aula
 and d.tipo_aula in(1,2 )
 and  Month(data) = '$data'
 and  cpf = '$cpfprofessor'
  and id_disciplina  = '$id_disciplina_prof'";

 $resultado=mysql_query($sql) or die (mysql_error());
 $linhas=mysql_num_rows($resultado);
 while($pegar=mysql_fetch_array($resultado))
   {
     $totalnregistrada = $pegar["total"];
   }




 /********************TOTAL DE AULA DE RECUPERA��O*****************************************/
 $sql = "select count(*) as total
 from dias_diario d,tipo_aula t
 where id_turma = '$idturma'
 and  t.id = d.tipo_aula
 and d.tipo_aula in(3)
 and  Month(data) = '$data'
 and  cpf = '$cpfprofessor'
  and id_disciplina  = '$id_disciplina_prof'";
 $resultado=mysql_query($sql) or die (mysql_error());
 $linhas=mysql_num_rows($resultado);
 while($pegar=mysql_fetch_array($resultado))
   {
     $totalrec = $pegar["total"];
   }

 /********************TOTAL DE AULA DE RECUPERA��O REGISTRADAS*****************************************/
 $sql = "select count(*) as total from dias_diario d,tipo_aula t
 where id_turma = '$idturma'
 and t.id = d.tipo_aula
 and d.registrado = 'S'
 and t.id = d.tipo_aula
 and d.tipo_aula in(3)
 and  Month(data) = '$data'
 and  cpf = '$cpfprofessor'
  and id_disciplina  = '$id_disciplina_prof'";

 $resultado=mysql_query($sql) or die (mysql_error());
 $linhas=mysql_num_rows($resultado);
 while($pegar=mysql_fetch_array($resultado))
   {
     $totalrecregistrada = $pegar["total"];
   }


 /********************TOTAL DE AULA DE RECUPERA��O N�O REGISTRADAS*****************************************/
  $sql = "select count(*) as total
  from dias_diario d,tipo_aula t
  where id_turma = '$idturma'
  and t.id = d.tipo_aula
  and d.registrado = 'N'
  and t.id = d.tipo_aula
  and d.tipo_aula in(3)
  and  Month(data) = '$data'
  and  cpf = '$cpfprofessor'
   and id_disciplina  = '$id_disciplina_prof'";

 $resultado=mysql_query($sql) or die (mysql_error());
 $linhas=mysql_num_rows($resultado);
 while($pegar=mysql_fetch_array($resultado))
   {
     $totalrecnregistrada = $pegar["total"];
   }

}


 /******************** ETAPAS****************************************/
else   /*Etapa*/
{




 $sql = "select count(*) as total from dias_diario d,tipo_aula t
  where id_turma = '$idturma'
 and  t.id = d.tipo_aula
 and  d.tipo_aula in(1,2)
 and  data >= '$dt_inicio'
 and  data <= '$dt_fim'
 and  cpf = '$cpfprofessor'
  and id_disciplina  = '$id_disciplina_prof'";
 $resultado=mysql_query($sql) or die (mysql_error());
 $linhas=mysql_num_rows($resultado);
 while($pegar=mysql_fetch_array($resultado))
   {
     $total = $pegar["total"];
   }

 $sql = "select count(*) as total from dias_diario d,tipo_aula t
  where id_turma = '$idturma'
 and t.id = d.tipo_aula
 and d.registrado = 'S'
 and t.id = d.tipo_aula
 and d.tipo_aula in(1,2)
 and  data >= '$dt_inicio'
 and  data <= '$dt_fim'
  and  cpf = '$cpfprofessor'
   and id_disciplina  = '$id_disciplina_prof'";

 $resultado=mysql_query($sql) or die (mysql_error());
 $linhas=mysql_num_rows($resultado);
 while($pegar=mysql_fetch_array($resultado))
   {
     $totalregistrada = $pegar["total"];
   }


 $sql = "select count(*) as total from dias_diario d,tipo_aula t
  where id_turma = '$idturma'
  and t.id = d.tipo_aula
  and d.registrado = 'N'
  and t.id = d.tipo_aula
  and d.tipo_aula in(1,2)
  and  data >= '$dt_inicio'
  and  data <= '$dt_fim'
  and  cpf = '$cpfprofessor'
  and id_disciplina  = '$id_disciplina_prof'";
  $resultado=mysql_query($sql) or die (mysql_error());
 $linhas=mysql_num_rows($resultado);
 while($pegar=mysql_fetch_array($resultado))
   {
     $totalnregistrada = $pegar["total"];
   }




 /*AULA DE RECUPERA��O*/
 $sql = "select count(*) as total from dias_diario d,tipo_aula t
  where id_turma = '$idturma'
 and  t.id = d.tipo_aula and d.tipo_aula in(3)
 and  data >= '$dt_inicio'
 and  data<= '$dt_fim'
 and  cpf = '$cpfprofessor'
  and id_disciplina  = '$id_disciplina_prof'";
 $resultado=mysql_query($sql) or die (mysql_error());
 $linhas=mysql_num_rows($resultado);
 while($pegar=mysql_fetch_array($resultado))
   {
     $totalrec = $pegar["total"];
   }


 $sql = "select count(*) as total from dias_diario d,tipo_aula t
  where id_turma = '$idturma'
 and t.id = d.tipo_aula
 and d.registrado = 'S'
 and t.id = d.tipo_aula
 and d.tipo_aula in(3)
 and  data >= '$dt_inicio' and  data <= '$dt_fim'
 and  cpf = '$cpfprofessor'
  and id_disciplina  = '$id_disciplina_prof'";
 $resultado=mysql_query($sql) or die (mysql_error());
 $linhas=mysql_num_rows($resultado);
 while($pegar=mysql_fetch_array($resultado))
   {
     $totalrecregistrada = $pegar["total"];
   }



  $sql = "select count(*) as total from dias_diario d,tipo_aula t
  where id_turma = '$idturma'
  and t.id = d.tipo_aula
  and d.registrado = 'N'
  and t.id = d.tipo_aula
  and d.tipo_aula in(3)
  and data >= '$dt_inicio' and  data <= '$dt_fim'
  and  cpf = '$cpfprofessor'
   and id_disciplina  = '$id_disciplina_prof'";

 $resultado=mysql_query($sql) or die (mysql_error());
 $linhas=mysql_num_rows($resultado);
 while($pegar=mysql_fetch_array($resultado))
   {
     $totalrecnregistrada = $pegar["total"];
   }


}





















if ($total>0)
  {
?>


<table>
  <tr><td><font size="2"> <center>
    <b><span class="style14">dia(s)/Aula(s) = Normal + Reposi��o</span>        </b>
      </center></td><td>******* </td>
  </tr>

  <tr><td class="style10">Total de dia(s)/Aula(s) prevista(s) Tipo (N+R)</td>
  <td><font size="2"> <?echo $total;?>  </tr>

  <tr><td><span class="style10">Total de dias/Aulas Registrada(s)</span></td>
    	  <td><font size="2"> <?echo  $totalregistrada;?>
  </tr>

  <tr><td><span class="style10">Total de dia(s)/Aula(s) N�o Registrada(s)</span></td>
    	  <td><font size="2"> <?echo  $totalnregistrada;?>
  </tr>

  <tr><td><font size="2"> <center>
    <b><span class="style14">dia(s)/Aula(s) = Recupera��o</span>        </b>
  </center></td><td>******* </td>
  </tr>

  <tr><td><span class="style14"><strong>Total de dia(s)/Aula(s) Prevista de Recupera��o</strong></span></td>
    	  <td><font size="2"> <?echo  $totalrec;?>
  </tr>


  <tr><td><span class="style10">Total de dia(s)/Aula(s) de Recupera��o Registrada</span></td>
    	  <td><font size="2"> <?echo  $totalrecregistrada;?>
  </tr>


  <tr><td><span class="style10">Total de dia(s)/Aula(s) de Recupera��o N�o Registrada</span></td>
    	  <td><font size="2"> <?echo  $totalrecnregistrada;?>
  </tr>




<?
}
?>
</table>





























<table width="100%">
<tr>
<td>&nbsp;  </td>
</tr>
<tr>
<td>
<table border="0"  class="bordasimples" cellspacing="0"  align="center" width="100%" bgcolor=#ffffff>

<tr>
	<td colspan="6"  bgcolor="#EAEAEA"  class="subtitulo" align="center"><b>Assinatura</b></td>
</tr>
<tr>
	<td class="nomecampo"><b>Professor</b></td>
	<td>&nbsp;</td>
	<td class="nomecampo"><b>Supervis�o</b></td>
	<td>&nbsp;</td>
</tr>
</table>

