<?php
session_start();
if (isset($_SESSION["login_usuario"]))
   {
   // session_cache_expire(1);
	 $login     =  $_SESSION["login_usuario"];
     $nte       =  $_SESSION["nivel_usuario"];
	 $inep      =  $_SESSION["inep_usuario"] ;
     $ntelogin  =  $_SESSION["nte_login"];
     $cpf       = $_SESSION["cpf_usuario"];
     $txtano_fechado    =  $_SESSION["txtano_fechado"];
     $form_menu         =  $_SESSION["form_menu"];

	 include ("../funcoes.php");
     echo  saudacoes()."   ". "$login" ."  -  ". $nte."  ".dataextenso()." ".$inep;

   }
 else
    {
     		 header("../../Location: login.php");
    }


include ("../../conexao_mysql.php");

if(file_exists("../../conexao_mysql.php"))
{
        require "../../conexao_mysql.php";

} else
{
        echo "Conex�o nao foi encontrado";
        exit;
}


if (!empty($_GET['codigo']))
  {
     $id=  $_GET['codigo'];
     $_SESSION["id_professorturma"]  =  $id;
 }
 else
  {
     $id=$_SESSION["id_professorturma"] ;
  }


if (!empty($_GET['codigo']))
  {
     $id=  $_GET['codigo'];
     $_SESSION["id_professorturma"]  =  $id;
 }
 else
  {
     $id=$_SESSION["id_professorturma"] ;
  }


if(!empty($id))
{

$sql="SELECT ano, situacao FROM ano where situacao = 'A' and inep = '$inep'";
$resultado=mysql_query($sql) or die (mysql_error());
$linhas=mysql_num_rows($resultado);
if ($linhas>0)
 {
    while($pegar=mysql_fetch_array($resultado))
   {
         $txtano       = $pegar["ano"];
   }
 }



if ($form_menu=='mnadmescola_ano_fechado')
       $txtano =   $txtano_fechado;




 if ($txtano < 2015)
       $ano_basedados = "";
 else
      $ano_basedados = $txtano;












  if ($form_menu=='mnadmescola_ano_fechado')
   {


$sql = "SELECT DISTINCT pd.id as id_turma_prof, t.id as id_turma,t.descricao as descturma, s.nome,h.descricao as descdisciplina,pd.cpf
FROM turmaprofessor pd, turma t, servidorrec s,habilitacao h
WHERE pd.id_turma = t.id and h.codigo= pd.id_disciplina
AND t.inep = '$inep' AND s.cpf = pd.cpf   and t.fechado = 'S'  and t.ano = '$txtano'  and pd.id ='$id'";
   }
else
  {
$sql = "SELECT DISTINCT pd.id as id_turma_prof, t.id as id_turma,t.descricao as descturma, s.nome,h.descricao as descdisciplina,pd.cpf
FROM turmaprofessor pd, turma t, servidorrec s,habilitacao h
WHERE pd.id_turma = t.id and h.codigo= pd.id_disciplina
AND t.inep = '$inep' AND s.cpf = pd.cpf    and ((t.fechado is null) or (t.fechado = 'N'))  and pd.id ='$id'";


  }





$resultado=mysql_query($sql) or die (mysql_error());
$linhas=mysql_num_rows($resultado);

if($linhas>0)
{
   while($pegar=mysql_fetch_array($resultado))
   {
    $id_turma_prof            =$pegar["id_turma_prof"];
    $id_turma                 =$pegar["id_turma"];
    $nome                     =$pegar["nome"];
    $turma                    =$pegar["descturma"];
    $disciplina               =$pegar["descdisciplina"];
    $cpf_prof                 =$pegar["cpf"];
 }

}

}









?>

<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01//EN"
	"http://www.w3.org/TR/html4/strict.dtd"><head>

    <meta http-equiv="content-type" content="text/html; charset=ISO-8859-1" />

	<title>Gerencia de Tecnologia da Informa��o</title>
	
	
	
	<link rel="stylesheet" href="style/forms.css" type="text/css" />
	<link rel="stylesheet" href="estilo.css" type="text/css" />
	<link rel="stylesheet" href="style/menu.css" type="text/css" />
	<link href="tablecloth/tablecloth.css" rel="stylesheet" type="text/css" media="screen" />
    <link rel="stylesheet" href="css/bootstrap.min.css" type="text/css" />

	
	<script type="text/javascript" src="tablecloth/tablecloth.js"></script>
	<script src="lib/jquery-1.4.2.js" type="text/javascript"></script>
	<script src="lib/validate.js" type="text/javascript"></script>
	<script src="lib/forms.js" type="text/javascript"></script>
	<script src="generic_dia_diario.js" type="text/javascript"></script>
    <script src="lib/jquery.maskedinput-1.1.1.js" type="text/javascript"></script>



 	<link type="text/css" href="jquery-ui-1.8.18.custom/css/ui-lightness/jquery-ui-1.8.18.custom.css" rel="stylesheet" />
	<script type="text/javascript" src="jquery-ui-1.8.18.custom/js/jquery-ui-1.8.18.custom.min.js"></script>


<script src="script.js"></script>




<script>
function tp_pesquisa()
{

	  if (document.form.selecttp_pesquisa.value == 'M')
            {

		     document.form.selectmes.disabled =false;
		     document.form.txtetapa.disabled =true;

		     document.form.txtetapa.value ="";
     		 }
     else
           {
		     document.form.selectmes.disabled =true;
		     document.form.txtetapa.disabled =false;

		     document.form.selectmes.value ="";
          }
  }

</script>




<script>
function pesquisa(form)
{

     var tp_pesq   = document.form.selecttp_pesquisa.value;
     var id_turma  = document.form.id.value;
     var id_etapa  = document.form.txtetapa.value;
     var id_mes    = document.form.selectmes.value;


     if (tp_pesq=="M")
         {

              var data = id_turma +"*" + id_mes + "-" + tp_pesq;
         }
       else
         {
              var data = id_turma +"*" + id_etapa + "-" + tp_pesq;
         }


          url = "busca_previa_diario_conteudo.php?valor="+data;
          ajax(url);
}
</script>




<script>
	$(function() {
		$( "#txtdata" ).datepicker({
			changeMonth: true,
			changeYear: true
		});
	});

$(function() {
        $("#txtdata").datepicker();
        $('#txtdata').datepicker('option', 'dateFormat', 'dd/mm/yy');
});





</script>


</head>
<body>
	<div id="warpper">
		<div id="header">
            <center>
           <img src= "../img/chamadaescolar.jpg"/>
            </center>
		</div>
    <div id="container">
			<div id="content">
				<form  name="form" class="form" action="rel_conteudo_diario.php" method="POST">
				 <div id="tema"> 
					   <p><center>Dia Di�rio</center></p>
				  </div>

<table border="0" width="100%" class="table table-striped">


<!--					<p>
						<label for="txtCPF">Id</label>
						<input type="text" name="id" class="input-mini"   maxlength="11" id="id"  value= "<? echo $id_turma_prof; ?>"   readonly="true"/>

					</p>
 -->



    				<p>
 						<label for="txtNome">Professor</label>
						<input type="text" class="input-xxlarge" name="txtprofessor" style="width:700px" maxlength="60" value= "<? echo $nome; ?>" id="txtprofessor" readonly="true"/>
					</p>


<!--
					<p>
 						<label for="txtNome">Id Turma</label>
						<input type="text" name="txtidturma" style="width:200px" maxlength="60" value= "<? echo $id_turma; ?>" id="txtidturma" readonly="true"/>
					</p>

					<p>
 						<label for="txtNome">Turma</label>
						<input type="text" name="txtturma" style="width:500px" maxlength="120" value= "<? echo $turma; ?>" id="txtturma" readonly="true"/>
					</p>


					<p>
 						<label for="txtNome">Disciplina</label>
						<input type="text" name="txtdisciplina" style="width:500px" maxlength="60" value= "<? echo $disciplina; ?>" id="txtdisciplina" readonly="true"/>
					</p>

    -->

                <p>
            		<label for="lblcod_cidades">Selecione a op��o:<img src= "../img/check.gif"/></label>
						<select name="id" id="id" style="width:700px">
			           <option value="">-- Escolha uma op��o --</option>
					<?php




                     if ($form_menu=='mnadmescola_ano_fechado')
                       {
						$sql = "SELECT DISTINCT pd.id as id_turma_prof,
                                t.id as id_turma,t.descricao as descturma, s.nome,h.descricao as descdisciplina,
                                 concat( t.descricao,' - ',h.descricao ) as descricao
                                FROM turmaprofessor pd, turma t, servidorrec s,habilitacao h
                                WHERE pd.id_turma = t.id
                                and h.codigo= pd.id_disciplina
                                AND t.inep = '$inep'
                                AND s.cpf = pd.cpf
                                and t.fechado = 'S'
                                and pd.cpf ='$cpf_prof'
                                and t.ano = '$txtano' order by t.descricao";
                       }
                      else
                       {
						$sql = "SELECT DISTINCT pd.id as id_turma_prof,
                                t.id as id_turma,t.descricao as descturma, s.nome,h.descricao as descdisciplina,
                                 concat( t.descricao,' - ',h.descricao ) as descricao
                                FROM turmaprofessor pd, turma t, servidorrec s,habilitacao h
                                WHERE pd.id_turma = t.id
                                and h.codigo= pd.id_disciplina
                                AND t.inep = '$inep'
                                AND s.cpf = pd.cpf
                                and ((t.fechado is null) or (t.fechado = 'N'))
                                and pd.cpf ='$cpf_prof' order by t.descricao";
                       }





						$resultado1 = mysql_query($sql);
						if($resultado1)
							{
							while($linhas = mysql_fetch_array($resultado1)){
							?>
								<option value="<?php echo $linhas['id_turma_prof']; ?>"
								<?php if($linhas['id_turma_prof'] == $id_turma_prof){ echo "selected";  } ?>>
								<?php echo $linhas['descricao'];  ?>
								</option>
								<?php } }
								 ?>
							</select>
    			</p>




					<p>
						<label for="selectsexo">Tipo Relat�rio<img src= "../img/check.gif"/></label>
  			               <select id="selecttp_pesquisa" name="selecttp_pesquisa" style="width:300px"       onChange = "tp_pesquisa(form)"/>
              		          <option value="E">Etapa</option>
            		          <option value="M">Mensal</option>

     		               </select>
					</p>


<!--					<p>
						<label for="selectsexo">Pesquisa<img src= "../img/check.gif"/></label>
 			               <select id="selecttp_pesquisa" name="selecttp_pesquisa" style="width:300px" onChange = "tp_pesquisa(form)"/>
            		          <option value="">Selecione o Tipo de pesquisa</option>
            		          <option value="E">Etapa</option>
              		          <option value="M">M�s</option>
    		               </select>
					</p>

-->

					<p>
         			<label for="cod_estados">Etapa<img src= "../img/check.gif"/></label>
					   	<select name="txtetapa" id="txtetapa" style="width:300px"  onChange = pesquisa(form)  />
					  	<option value="">Selecione a Etapa</option>
					<?php
							$sql = "SELECT id, descricao
									FROM etapa_ano
									ORDER BY id";
				     		$res = mysql_query( $sql );
							while ( $row = mysql_fetch_assoc( $res ) ) {
							echo '<option value="'.$row['id'].'">'.$row['descricao'].'</option>';
						}

					?>
				    	</select>
                   </p>



                   <p>
    					<label for="lblgerencia">M�s<img src= "../img/check.gif"/></label>
						<select name="selectmes" id="selectmes" style="width:150px"  onChange = pesquisa(form) disabled ="true"/>

						<option value="">-- Selecione M�s --</option>
					<?php
							$sql = "SELECT id, descricao
									FROM mes
									ORDER BY id";
						   $res = mysql_query($sql);
						   if($res)
							  {
								while($row = mysql_fetch_array($res)){

                                ?>
  			                    <option value="<?php echo $row['id']?>"
						        <?php if($row['id'] == $fornecedor){ echo "selected";}?>>
								<?php echo $row['descricao'];?>
								<?php
							      } }
						        ?>
					   </select>
     		       </p>




	<p class="botao">
            <input name="botao"  type="button"   class="btn btn-primary"  value="Pesquisar"  title="Processa Pesquisa" onclick="javascript: return pesquisa(form)">
            <input name="relatorio"  type="submit"  class="btn btn-warning"   value="Imprimir"  title="Processa Visualiza��o">
            <button type="button" class="btn"    title="Retorna a pesquisa professor frequencia."
            onclick="location.href='form_pesquisa_professor_conteudo.php';">Voltar</button>



		</p>
</table>

<table border="0" width="100%" class="table table-striped">
      	     <!-- AQUI SER� APRESENTADO O RESULTADO DA BUSCA DIN�MICA.. OU SEJA OS NOMES -->
					<p>
                        <div id="pagina">

                        </div>
             		</p>


</table>


 </div><!-- Div corpodetalhe-->
</div><!-- Div corpo2-->

<?



function diasemana($data) {
	$ano =  substr("$data", 0, 4);
	$mes =  substr("$data", 5, -3);
	$dia =  substr("$data", 8, 9);

	$diasemana = date("w", mktime(0,0,0,$mes,$dia,$ano) );

	switch($diasemana) {
		case"0": $diasemana = "Domingo";       break;
		case"1": $diasemana = "Segunda-Feira"; break;
		case"2": $diasemana = "Ter�a-Feira";   break;
		case"3": $diasemana = "Quarta-Feira";  break;
		case"4": $diasemana = "Quinta-Feira";  break;
		case"5": $diasemana = "Sexta-Feira";   break;
		case"6": $diasemana = "S�bado";        break;
	}

     return $diasemana;
}




function mesatual($mes){

	switch($mes) {
		case"01": $mes = "Janeiro";       break;
		case"02": $mes = "Fevereiro"; break;
		case"03": $mes = "Mar�o";   break;
		case"04": $mes = "Abril";  break;
		case"05": $mes = "Maio";  break;
		case"06": $mes = "Junho";   break;
		case"07": $mes = "Julho";        break;
        case"08": $mes = "Agosto";        break;
		case"09": $mes = "Setembro";        break;
		case"10": $mes = "Outubro";        break;
		case"11": $mes = "Novembro";        break;
		case"12": $mes = "Dezembro";        break;
	}

     return $mes;
}






?>
				</form>
			</div>
		</div>

	</div>
</body>






