<?php
require_once '../../start.php';
$pdo = new Conexao;

$title = 'Alterar frequ�ncia';

Auth::whiteList(array('PROF'));

$id_diadiario = isset($_GET['id_diadiario']) ? $_GET['id_diadiario'] : false;
$tfrequencia_cabeca = $txtano == 2014 ? "frequencia_cabeca" : "frequencia_cabeca".$txtano;
$tfrequencia_aluno = $txtano == 2014 ? "frequencia_aluno" : "frequencia_aluno".$txtano;

if (isset($_GET['excluir']) && !empty($_GET['excluir'])) {
	$sql = "DELETE FROM {$tfrequencia_aluno}
					WHERE id = :id
						AND ano = '{$txtano}'
						AND inep = '{$inep}';";
	$sth = $pdo->prepare($sql);
	$sth->bindParam(':id', $_GET['excluir']);
	try {
		if ($sth->execute()) {
			Notification::success('Frequ�ncia de aluno exclu�da com sucesso.');
		} else {
			Notification::error('N�o foi poss�vel excluir frequ�ncia.');
		}
	} catch (Exception $e) {
		Notification::ex($e);
	}

	redirect('escola/chamada/alterar_frequencia.php?id_diadiario='.$_GET['dd']);
}

if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['adicionar']) && $_POST['adicionar'] == 1) {
	$sql = "SELECT * FROM {$tfrequencia_cabeca} fc
					WHERE id = :id
						AND ano = '{$txtano}'
						AND inep = '{$inep}';";
	$sth = $pdo->prepare($sql);
	$sth->bindParam(':id', $_POST['id_frequencia_cabeca']);
	$frequenciaCabeca = $sth->execute() ? $sth->fetch() : null;

	$sql = "INSERT INTO {$tfrequencia_aluno} (professor, id_turma, id_disciplina, id_aluno,data, n_chamada, assunto, situacao, id_frequencia, data_chamada, inep, id_turma_prof, ano)
					VALUES (:id_professor, :id_turma, :id_disciplina, :id_aluno, NOW(),(select n_chamada from turma_aluno where id_aluno = :id_aluno and id_turma = :id_turma and situacao = 1),
					:obs, :freq, :id_frequenciacabeca, :data_chamada, '{$inep}', :id_turmaprofessor, '{$txtano}');";
	$sth = $pdo->prepare($sql);
	$sth->bindParam(':id_turma', $frequenciaCabeca['id_turma']);
	$sth->bindParam(':id_professor', $frequenciaCabeca["id_professor"]);
	$sth->bindParam(':id_disciplina', $frequenciaCabeca['id_disciplina']);
	$sth->bindParam(':data_chamada', $frequenciaCabeca['data_chamada']);
	$sth->bindParam(':id_frequenciacabeca', $frequenciaCabeca['id']);
	$sth->bindParam(':id_turmaprofessor', $frequenciaCabeca["id_turma_prof"]);
	$sth->bindParam(':obs', $_POST['obs']);
	$sth->bindParam(':freq', $_POST['frequencia']);
	$sth->bindParam(':id_aluno', $_POST['id_aluno']);
	try {
		if ($sth->execute()) {
			Notification::success('Frequ�ncia de estudante adicionada com sucesso.');
		} else {
			Notification::error('N�o foi poss�vel adicionar frequ�ncia de estudante.');
		}
	} catch (Exception $e) {
		Notification::ex($e);
	}
	redirectBack();
}

$sql = "SELECT dd.id, dd.data, t.id as id_turma, t.descricao as turma, h.descricao as disciplina, t.modalidade, dd.cpf, tp.id as id_turmaprofessor,
					tp.cpf as id_professor, dd.id_disciplina, fc.assunto as conteudo, fc.id as id_frequencia_cabeca
				FROM dias_diario dd
					INNER JOIN turmaprofessor tp ON tp.id_disciplina = dd.id_disciplina AND tp.id_turma = dd.id_turma
						AND tp.cpf = dd.cpf AND dd.inep = tp.inep
					INNER JOIN turma t on t.id = dd.id_turma
					INNER JOIN habilitacao h ON h.codigo = dd.id_disciplina
					INNER JOIN {$tfrequencia_cabeca} fc ON fc.id_turma = t.id AND fc.id_professor = tp.cpf
						AND fc.id_disciplina = h.codigo AND fc.data_chamada = dd.data
				WHERE dd.id = :id_diadiario";
$sth = $pdo->prepare($sql);
$sth->bindParam(':id_diadiario', $id_diadiario);
$diasDiario = $sth->execute() ? $sth->fetchAll() : null;

if($_SERVER["REQUEST_METHOD"] == "POST")  {
	$now = new DateTime();
	$now = $now->format('Y-m-d');

	if (!isset($_POST['conteudo'])) {
		Notification::warning('Informe o conte�do.');
	} else {
		foreach ($_POST['conteudo'] as $id_frequencia_cabeca => $conteudo) {
			$sql = "UPDATE {$tfrequencia_cabeca}
							SET assunto = :conteudo
							WHERE id = :id;";
			$sth = $pdo->prepare($sql);
			$sth->bindParam(':id', $id_frequencia_cabeca);
			$sth->bindParam(':conteudo', $conteudo);
			$sth->execute();
		}

		$sql = "UPDATE {$tfrequencia_aluno} fa
						SET fa.situacao = :freq, fa.assunto = :obs
						WHERE fa.id_aluno = :id_aluno
							AND fa.id_frequencia = :id_frequencia_cabeca;";
		$sth = $pdo->prepare($sql);

		foreach ($_POST['freq'] as $id_frequencia_cabeca => $frequencias) {
			foreach ($frequencias as $id_aluno => $freq) {
				$obs = isset($_POST['obs'][$id_frequencia_cabeca][$id_aluno]) ? $_POST['obs'][$id_frequencia_cabeca][$id_aluno] : '';
				$sth->bindParam(':obs', $obs);
				$sth->bindParam(':freq', $freq);
				$sth->bindParam(':id_aluno', $id_aluno);
				$sth->bindParam(':id_frequencia_cabeca', $id_frequencia_cabeca);
				$sth->execute();
			}
		}
	}

	executar_async(url("escola/chamada/atualizar_frequencia.php?id_diadiario={$id_diadiario}"));

	Notification::success('Frequ�ncia alterada com sucesso.');

	redirect("escola/chamada/exibir_frequencia.php?id_diadiario={$id_diadiario}");
}

?><!DOCTYPE HTML>
<html>
	<head>
		<?php require_once page_head(); ?>
	</head>
	<body>
		<?php require_once page_header(); ?>
		<div class="container">

			<?php if (isset($diasDiario[0])): ?>
			<table class="table table-condensed table-bordered">
				<tr>
					<th width="20">Turma</th>
					<th class="text-primary"><?php echo $diasDiario[0]['turma'] ?></th>
				</tr>
				<tr>
					<th width="20">Disciplina</th>
					<th class="text-danger"><?php echo $diasDiario[0]['disciplina'] ?></th>
				</tr>
			</table>
				
			<?php endif ?>

			<?php
				foreach ($diasDiario as $dia_diario):
					$dt = DateTime::createFromFormat('Y-m-d', $dia_diario['data']);
					$etapa = Etapa::getEtapaFromDate('Y-m-d', $dia_diario['data'], $dia_diario['modalidade'], $_SESSION['escola']['inep']);
					$id_frequencia_cabeca = $dia_diario['id_frequencia_cabeca'];
					$alunosSemFrequencia = Frequencia::alunosSemFrequencia($dia_diario['id_frequencia_cabeca'], $_SESSION['txtano']);
			?>

			<?php if (sizeof($alunosSemFrequencia) > 0): ?>
			<div class="modal fade" id="modal_<?php echo $id_frequencia_cabeca ?>" tabindex="-1" role="dialog">
			  <div class="modal-dialog" role="document">
			    <div class="modal-content">
			      <div class="modal-header">
			        <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
			        <h3 class="modal-title" style="border:none">Adicionar estudante na frequ�ncia</h3>
			      </div>
			      <div class="modal-body">
							<form method="POST">
								<input type="hidden" name="adicionar" value="1">
								<input type="hidden" name="id_frequencia_cabeca" value="<?php echo $id_frequencia_cabeca ?>">
								<div class="form-group">
									<label for="id_aluno">Estudante</label>
									<select name="id_aluno" id="id_aluno" class="form-control chosen" required>
										<?php foreach ($alunosSemFrequencia as $asf): ?>
											<option value="<?php echo $asf['id'] ?>">
												<?php echo $asf['n_chamada'] ?> <?php echo $asf['nome'] ?>
												(<?php echo $asf['situacao'] ?>)
											</option>
										<?php endforeach ?>
									</select>
								</div>

								<div class="row">
									<div class="col-md-4">
										<div class="form-group">
											<label for="frequencia">Frequ�ncia</label>
											<select name="frequencia" id="frequencia" class="form-control">
												<option value="P">PRESEN�A</option>
												<option value="F">FALTA</option>
											</select>
										</div>
									</div>
									<div class="col-md-8">
										<div class="form-group">
											<label for="obs">Observa��es</label>
											<textarea name="obs" id="obs" rows="2" class="form-control"></textarea>
										</div>
									</div>
								</div>
								<div>
									<button type="submit" class="btn btn-success btn-offset">ADICIONAR</button>
					        <button type="button" class="btn btn-default pull-right" data-dismiss="modal">Fechar</button>
								</div>
							</form>
			      </div>
			    </div>
			  </div>
			</div>
			<?php endif ?>

			<form method="POST">
				<div class="panel panel-default">
					<div class="panel-heading">
						<span class="h3">
							Conte�do de
							<?php echo $dt->format('d/m/Y') ?> 
							<small class="text-muted">(<?php echo Calendario::$diasSemana[date_format($dt, 'N')] ?>)</small>
						</span>

						<?php if (sizeof($alunosSemFrequencia) > 0): ?>
						<button type="button" class="btn btn-sm btn-success pull-right" data-toggle="modal" data-target="#modal_<?php echo $id_frequencia_cabeca ?>">
							<i class="fa fa-plus"></i>
						  ADICIONAR ESTUDANTE
						</button>
						<?php endif ?>

					</div>
					<div class="panel-body">
						<textarea name="conteudo[<?php echo $id_frequencia_cabeca ?>]" id="conteudo" rows="3" class="form-control"><?php echo $dia_diario['conteudo']; ?></textarea>
					</div>
					<div class="table-responsive">
						<table id="table_<?php echo $id_frequencia_cabeca ?>" class="table table-condensed table-striped table-bordered">
							<thead>
								<tr>
									<th class="text-center">N�</th>
									<th>Aluno</th>
									<th width="10">Situa��o</th>
									<th width="200" class="text-center">Frequ�ncia</th>
									<th>Observa��es</th>
									<th width="10"></th>
								</tr>
							</thead>
							<tbody>
								<?php
									$frequencia_aluno = Frequencia::frequenciaAlunos($dia_diario['id_frequencia_cabeca'], $tfrequencia_aluno);

									foreach ($frequencia_aluno as $fa):
										$situacao = SituacaoAluno::get($fa['situacao']);
										$freq = "freq[{$id_frequencia_cabeca}][{$fa['id_aluno']}]";
										$freqp = "freqp[{$id_frequencia_cabeca}][{$fa['id_aluno']}]";
										$freqf = "freqf[{$id_frequencia_cabeca}][{$fa['id_aluno']}]";
										$obs = "obs[{$id_frequencia_cabeca}][{$fa['id_aluno']}]";
									?>
									<tr>
										<td width="10" class="text-center"><?php echo $fa['n_chamada'] ?></td>
										<td><?php echo $fa['nome'] ?></td>
										<td><small><?php echo $situacao['descricao'] ?></small></td>
										<td>
											<div class="btn-group btn-group-xs">
												<label for="<?php echo $freqp ?>" class="btn btn-default <?php echo $fa['frequencia'] != 'F' ? 'active' : '' ?>">
													<input type="radio" name="<?php echo $freq ?>" id="<?php echo $freqp ?>" value="P" <?php checked($fa['frequencia'] != 'F') ?> autocomplete="off"> PRESEN�A
												</label>
												<label for="<?php echo $freqf ?>" class="btn btn-default <?php echo $fa['frequencia'] == 'F' ? 'active' : '' ?>">
													<input type="radio" name="<?php echo $freq ?>" id="<?php echo $freqf ?>" value="F" <?php checked($fa['frequencia'] == 'F') ?> autocomplete="off"> FALTA
												</label>
											</div>
										</td>
										<td>
											<?php if (!empty($fa['observacao'])): ?>
												<textarea class="form-control"  name="<?php echo $obs ?>" rows="2"><?php echo $fa['observacao'] ?></textarea>
											<?php else: ?>
												<button class="btn btn-primary btn-block btn-xs btn-toggle-ta">Adicionar observa��o</button>
												<textarea class="form-control" disabled style="display: none;" name="<?php echo $obs ?>" rows="2" placeholder="Adicionar observa��o"></textarea>
											<?php endif ?>
										</td>
										<td>
											<a href="?excluir=<?php echo $fa['id'] ?>&dd=<?php echo $id_diadiario ?>" class="btn btn-danger btn-xs"
												title="Excluir frequ�ncia de estudante" onclick="return confirm('Confirma excluir esse registro de frequ�ncia do estudante?')">
												<i class="fa fa-trash-o fa-lg"></i>
											</a>
										</td>
									</tr>
								<?php endforeach ?>
							</tbody>
						</table>
					</div>
					<div class="panel-footer">
						<button class="btn btn-primary btn-submit btn-submit-wait">SALVAR ALTERA��ES</button>
						<a class="btn btn-default pull-right" href="<?php echo url("escola/chamada/busca_turmas_frequencia.php?id_turmaprofessor={$dia_diario['id_turmaprofessor']}&id_etapa={$etapa['id']}") ?>">Voltar</a>
					</div>
				</div>
			</form>
			<hr>
			<?php endforeach ?>

		</div>
		<?php require_once page_footer(); ?>
		<script>
			$(function() {
				$('.btn-toggle-ta').on('click', function(e) {
					e.preventDefault();
					$(this).hide();
					$(this).parent().find('textarea').removeAttr('disabled').fadeIn(function() { $(this).focus(); });
				})
			});
		</script>
	</body>
</html>