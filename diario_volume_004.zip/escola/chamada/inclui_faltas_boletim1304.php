<?php

session_start();
if (isset($_SESSION["login_usuario"]))
  {
   // session_cache_expire(1);
     $login     =  $_SESSION["login_usuario"];
     $nte       =  $_SESSION["nivel_usuario"];
     $inep      =  $_SESSION["inep_usuario"] ;
     $ntelogin  =  $_SESSION["nte_login"];
     $cpf       = $_SESSION["cpf_usuario"];
     include ("../../funcoes.php");
     echo  saudacoes()."   ". "$login" ."  -  ". $nte."  ".dataextenso() ." - ".$inep;

  }
 else
  {
     		 header("Location: ../../login.php");
  }



include ("../../conexao_mysql.php");

if(file_exists("../../conexao_mysql.php"))
{
        require "../../conexao_mysql.php";

} else
{
        echo "Conex�o nao foi encontrado";
        exit;
}




$sql="SELECT ano, situacao FROM ano where situacao = 'A' and inep = '$inep'";
$resultado=mysql_query($sql) or die (mysql_error());
$linhas=mysql_num_rows($resultado);
if ($linhas>0)
 {
    while($pegar=mysql_fetch_array($resultado))
   {
         $txtano       = $pegar["ano"];
   }
 }



if($_SERVER["REQUEST_METHOD"] == "POST")
{
    $txtturmadiario	            = $_POST["cod_estado"];
    $txtdisciplina	            = $_POST["cod_cidades"];
    $txtcpf         	        = $_POST["txtcpf"];
    $txt_idetapa     	        = $_POST["txtetapa"];


//echo "$txtturmadiario";
//echo "$txtdisciplina";



if (trim($inep)=='')
   {
    echo "<html><head><title>Resposta !!!</title></head>";
    echo "<body background=\"background_mensagens.jpg\" style=\"background-attachment:fixed; background-repeat:no-repeat\">";
    echo "<br><br><br>";
    echo "<center><img src=\"faleconosco/atencao.gif\" alt=\"\"><p><font color=\"#FF0000\" face=\"Verdana\" size=\"4\"><b>Escola n�o localizada.!</b></font></center>";
    echo "<br><br><center><a href=\"form_fechamento_faltas.php\"><img src=\"faleconosco/button_voltar2_.gif\" alt=\"Voltar\" border=\"0\" /></a></center>";
    echo "</body></html>";
    exit;

   }



if (trim($txtdisciplina)=='')
   {
    echo "<html><head><title>Resposta !!!</title></head>";
    echo "<body background=\"background_mensagens.jpg\" style=\"background-attachment:fixed; background-repeat:no-repeat\">";
    echo "<br><br><br>";
    echo "<center><img src=\"faleconosco/atencao.gif\" alt=\"\"><p><font color=\"#FF0000\" face=\"Verdana\" size=\"4\"><b>Informe a disciplina! </b></font></center>";
    echo "<br><br><center><a href=\"form_fechamento_faltas.php\"><img src=\"faleconosco/button_voltar2_.gif\" alt=\"Voltar\" border=\"0\" /></a></center>";
    echo "</body></html>";
    exit;

   }

if (trim($txtturmadiario)=='')
   {
    echo "<html><head><title>Resposta !!!</title></head>";
    echo "<body background=\"background_mensagens.jpg\" style=\"background-attachment:fixed; background-repeat:no-repeat\">";
    echo "<br><br><br>";
    echo "<center><img src=\"faleconosco/atencao.gif\" alt=\"\"><p><font color=\"#FF0000\" face=\"Verdana\" size=\"4\"><b>Informe a turma.!</b></font></center>";
    echo "<br><br><center><a href=\"form_fechamento_faltas.php\"><img src=\"faleconosco/button_voltar2_.gif\" alt=\"Voltar\" border=\"0\" /></a></center>";
    echo "</body></html>";
    exit;

   }


if (trim($txt_idetapa)=='')
   {
    echo "<html><head><title>Resposta !!!</title></head>";
    echo "<body background=\"background_mensagens.jpg\" style=\"background-attachment:fixed; background-repeat:no-repeat\">";
    echo "<br><br><br>";
    echo "<center><img src=\"faleconosco/atencao.gif\" alt=\"\"><p><font color=\"#FF0000\" face=\"Verdana\" size=\"4\"><b>Etapa n�o localizada.!</b></font></center>";
    echo "<br><br><center><a href=\"form_fechamento_faltas.php\"><img src=\"faleconosco/button_voltar2_.gif\" alt=\"Voltar\" border=\"0\" /></a></center>";
    echo "</body></html>";
    exit;
   }



if (trim($txtcpf)=='')
   {
    echo "<html><head><title>Resposta !!!</title></head>";
    echo "<body background=\"background_mensagens.jpg\" style=\"background-attachment:fixed; background-repeat:no-repeat\">";
    echo "<br><br><br>";
    echo "<center><img src=\"faleconosco/atencao.gif\" alt=\"\"><p><font color=\"#FF0000\" face=\"Verdana\" size=\"4\"><b>Informe o professor.!</b></font></center>";
    echo "<br><br><center><a href=\"form_fechamento_faltas.php\"><img src=\"faleconosco/button_voltar2_.gif\" alt=\"Voltar\" border=\"0\" /></a></center>";
    echo "</body></html>";
    exit;
   }





       $sql_etapa = "SELECT id,id_etapa,dt_inicio,dt_fim  
       FROM etapa_liberacao where id = '$txt_idetapa'
       and inep = '$inep'  and situacao = 'A' ";
       $resultado_etapa=mysql_query($sql_etapa) or die (mysql_error());
        while( $linha_etapa = mysql_fetch_array($resultado_etapa))
         {
           $dt_inicio            =$linha_etapa["dt_inicio"];
           $dt_fim               =$linha_etapa["dt_fim"];
           $id_etapa_banco       =$linha_etapa["id_etapa"];
         }





//echo "INICIO $dt_inicio";
//echo "FIM $dt_fim";
//echo "disci $txtdisciplina";
/*Caso a disciplina seja pedagoogia series iniciais assume matematica*/

/*

1 - 1� bim
2 - 2� bim
3 - 3� bim
4 - 4� bim
5 - rec 1� bim
6 - rec 1� bim
7 - rec 1� bim
8 - rec 1� bim
9 ex final
10 rec semestrral
11 re anual

*/

$reg_atualizado = 0;
$reg_n_atualizado=0;


$sql_faltas="SELECT id_aluno, count( situacao ) as total_faltas FROM frequencia_aluno
             WHERE  id_turma = '$txtturmadiario'
             AND   inep = '$inep'
             AND    id_disciplina = '$txtdisciplina'
             and data_chamada between '$dt_inicio' and  '$dt_fim'
             GROUP BY id_aluno, situacao
             HAVING situacao = 'F' ";
$resultado_faltas=mysql_query($sql_faltas) or die (mysql_error());
while ( $linha_faltas = mysql_fetch_array( $resultado_faltas))
{

     $id_aluno            =$linha_faltas["id_aluno"];
     $total_faltas        =$linha_faltas["total_faltas"];




//echo "aluno $txtano";

/* 1� bimestre*/


if ($txtdisciplina=='28')
 $id_disciplina=1;
else
  $id_disciplina =$txtdisciplina;



 if ($id_etapa_banco=='1')
     {
        $sql = "update nota_aluno set  t_falta1 = '$total_faltas'
        where  id_aluno = '$id_aluno' and inep = '$inep' and id_disciplina = '$id_disciplina'
        and id_turma = '$txtturmadiario' and ano = '$txtano'";

       }

/* 2� bimestre*/
 else if ($id_etapa_banco=='2')
     {
        $sql = "update nota_aluno set  t_falta2 = '$total_faltas'
        where  id_aluno = '$id_aluno' and inep = '$inep' and id_disciplina = '$id_disciplina'
        and id_turma = '$txtturmadiario' and ano = '$txtano'";
     }

/* 3� bimestre*/
 else if ($id_etapa_banco=='3')
     {
        $sql = "update nota_aluno set  t_falta3 = '$total_faltas'
        where  id_aluno = '$id_aluno' and inep = '$inep' and id_disciplina = '$id_disciplina'
        and id_turma = '$txtturmadiario' and ano = '$txtano'";
     }

/* 4� bimestre*  t_falta_rec1*/
 else if ($id_etapa_banco=='4')
     {
        $sql = "update nota_aluno set  t_falta4 = '$total_faltas'
        where  id_aluno = '$id_aluno' and inep = '$inep' and id_disciplina = '$id_disciplina'
        and id_turma = '$txtturmadiario' and ano = '$txtano'";
     }


/* 5� bimestre*  t_falta_rec1*/
 else if ($id_etapa_banco=='5')
     {
        $sql = "update nota_aluno set  t_falta_rec1 = '$total_faltas'
        where  id_aluno = '$id_aluno' and inep = '$inep' and id_disciplina = '$id_disciplina'
        and id_turma = '$txtturmadiario' and ano = '$txtano'";
     }

/* 6� bimestre*  t_falta_rec1*/
 else if ($id_etapa_banco=='6')
     {
        $sql = "update nota_aluno set  t_falta_rec2 = '$total_faltas'
        where  id_aluno = '$id_aluno' and inep = '$inep' and id_disciplina = '$id_disciplina'
        and id_turma = '$txtturmadiario' and ano = '$txtano'";
     }

/* 7� bimestre*  t_falta_rec3*/
 else if ($id_etapa_banco=='7')
     {
        $sql = "update nota_aluno set  t_falta_rec3 = '$total_faltas'
        where  id_aluno = '$id_aluno' and inep = '$inep' and id_disciplina = '$id_disciplina'
        and id_turma = '$txtturmadiario' and ano = '$txtano'";
     }


/* 8� bimestre*  t_falta_rec3*/
 else if ($id_etapa_banco=='8')
     {
        $sql = "update nota_aluno set  t_falta_rec4 = '$total_faltas'
        where  id_aluno = '$id_aluno' and inep = '$inep' and id_disciplina = '$id_disciplina'
        and id_turma = '$txtturmadiario' and ano = '$txtano'";
     }

/* 9� bimestre*  t_falta_rec3*/
 else if ($id_etapa_banco=='10')
     {
        $sql = "update nota_aluno set  t_falta_rec1 = '$total_faltas'
        where  id_aluno = '$id_aluno' and inep = '$inep' and id_disciplina = '$id_disciplina'
        and id_turma = '$txtturmadiario' and ano = '$txtano'";
     }

 else if ($id_etapa_banco=='11')
     {
        $sql = "update nota_aluno set  t_falta_rec1 = '$total_faltas'
        where  id_aluno = '$id_aluno' and inep = '$inep' and id_disciplina = '$id_disciplina'
        and id_turma = '$txtturmadiario' and ano = '$txtano'";
     }





/*********************************************************************************************************************************/
  if(@mysql_query($sql))
   {
      $success = mysql_affected_rows();
     if($success ==true)
		{
          $reg_atualizado   += 1;
        }
      else
		{
           $reg_n_atualizado +=1;
        }
  }
 else
   {
        //verifico se nao estao tentando gravar um dado que ja existe, pois usei UNIQUE na tabela
        if(mysql_errno() == 1062)
		  {
                echo $erros[mysql_errno()];
                exit;
          }
		  else
		  {
                echo "Erro nao foi possivel efetuar o cadastro";
                exit;
          }
        @mysql_close();
     }


}



    echo "<html><head><title>Resposta !!!</title></head>";
    echo "<body background=\"background_mensagens.jpg\" style=\"background-attachment:fixed; background-repeat:no-repeat\">";
    echo "<br><br><br>";
    echo "<center><img src=\"faleconosco/atencao.gif\" alt=\"\"><p><font color=\"#FF0000\" face=\"Verdana\" size=\"4\"><b>Total de Registros Atualizados:.$reg_atualizado.</b></font></center>";
    echo "<center><img src=\"faleconosco/atencao.gif\" alt=\"\"><p><font color=\"#FF0000\" face=\"Verdana\" size=\"4\"><b>Total de Registros N�o Atualizados:.$reg_n_atualizado.</b></font></center>";
    echo "<br><br><center><a href=\"form_fechamento_faltas.php\"><img src=\"faleconosco/button_voltar2_.gif\" alt=\"Voltar\" border=\"0\" /></a></center>";
    echo "</body></html>";
    exit;

}//post



?>


