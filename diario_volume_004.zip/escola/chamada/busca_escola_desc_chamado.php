<?php
require_once '../../start.php';


  $id=  addslashes($_GET["valor"]);



//_turma__*_disciplina__@conteudo___

   $totalcaracter     = strlen($id);

   $posicao           = strpos($id, '*');

   $turmadiario       = substr($id, 0, $posicao);

   $posicao1          = strpos($id, '@');

   $disciplina        = substr($id, $posicao+1 , $posicao1-$posicao-1);

   $conteudo          = substr($id, $posicao1+1,  $totalcaracter-$posicao1);

   $id_provao = "";






/*echo  "turma $turmadiario";
echo  "Discipplina $disciplina";
*/
//echo "Conteu $id";



if (trim($turmadiario)=="")
 {
	       echo "<html><head><title>Resposta !!!</title></head>";
	       echo "<body background=\"background_mensagens.jpg\" style=\"background-attachment:fixed; background-repeat:no-repeat\">";
           echo "<br><br><br>";
	       echo "<center><img src=\"faleconosco/atencao.gif\" alt=\"\"><p><font color=\"#ff6600\" face=\"Verdana\" size=\"4\">Professor selecione a sua turma. <b></b></font></center>";
      	   echo "<br><br><center><a href=\"form_pesquisa_turma.php\"><img src=\"faleconosco/button_voltar2_.gif\" alt=\"Voltar\" border=\"0\" /></a></center>";
	       echo "</body></html>";
           exit;


 }



if (trim($disciplina)=="")
 {
	       echo "<html><head><title>Resposta !!!</title></head>";
	       echo "<body background=\"background_mensagens.jpg\" style=\"background-attachment:fixed; background-repeat:no-repeat\">";
           echo "<br><br><br>";
	       echo "<center><img src=\"faleconosco/atencao.gif\" alt=\"\"><p><font color=\"#ff6600\" face=\"Verdana\" size=\"4\">Professor selecione a sua disciplina. <b></b></font></center>";
      	   echo "<br><br><center><a href=\"form_pesquisa_turma.php\"><img src=\"faleconosco/button_voltar2_.gif\" alt=\"Voltar\" border=\"0\" /></a></center>";
	       echo "</body></html>";
           exit;


 }



if (trim($conteudo)=="")
 {
	       echo "<html><head><title>Resposta !!!</title></head>";
	       echo "<body background=\"background_mensagens.jpg\" style=\"background-attachment:fixed; background-repeat:no-repeat\">";
           echo "<br><br><br>";
	       echo "<center><img src=\"faleconosco/atencao.gif\" alt=\"\"><p><font color=\"#ff6600\" face=\"Verdana\" size=\"4\">Professor registre o seu conteudo. <b></b></font></center>";
      	   echo "<br><br><center><a href=\"form_pesquisa_turma.php\"><img src=\"faleconosco/button_voltar2_.gif\" alt=\"Voltar\" border=\"0\" /></a></center>";
	       echo "</body></html>";
           exit;


 }






//echo  "turma $turmadiario";



$sqlaluno="SELECT  t.id,tp.id as id_t_professor FROM turma t ,turmaprofessor tp
where t.inep = '$inep'
and id_disciplina = '$disciplina'
and tp.inep = t.inep
and tp.cpf = '$cpf'
and t.id= tp.id_turma
and ((fechado is null) or (fechado = 'N'))
and t.id = '$turmadiario'";
$resultadoaluno=mysql_query($sqlaluno) or die (mysql_error());
$linhasaluno=mysql_num_rows($resultadoaluno);
if ($linhasaluno>0)
 {
while($pegaraluno=mysql_fetch_array($resultadoaluno))
    {
         $id_t_professor       = $pegaraluno["id_t_professor"];

	}
 }






$sqldata="select * from  dias_diario where id_turma = '$turmadiario'
and cpf ='$cpf'
and id_disciplina = '$disciplina'
and inep = '$inep' and registrado <> 'S' ";
$resultado=mysql_query($sqldata) or die (mysql_error());
$linhasdata=mysql_num_rows($resultado);
if ($linhasdata<=0)
 {
	       echo "<html><head><title>Resposta !!!</title></head>";
	       echo "<body background=\"background_mensagens.jpg\" style=\"background-attachment:fixed; background-repeat:no-repeat\">";
           echo "<br><br><br>";
	       echo "<center><img src=\"faleconosco/atencao.gif\" alt=\"\"><p><font color=\"#ff6600\" face=\"Verdana\" size=\"4\">Nao existe aula  prevista para esta turma. <b></b></font></center>";
      	   echo "<br><br><center><a href=\"form_pesquisa_turma.php\"><img src=\"faleconosco/button_voltar2_.gif\" alt=\"Voltar\" border=\"0\" /></a></center>";
	       echo "</body></html>";
           exit;


 }



/*
$sql="select * from  turmaprofessor where id = '$turmadiario'";
$resultado=mysql_query($sql) or die (mysql_error());
$linhas=mysql_num_rows($resultado);
if ($linhas>0)
 {
while($pegar=mysql_fetch_array($resultado))
    {
   //   $id_turma = $pegar["id_turma"];
        $cpf = $pegar["cpf"];
        $id_prof_turma = $pegar["id_prof_turma"];


    }
 }

*/


if(!empty($_GET["valor"]))
 {

//echo "turma dia $turmadiario";
//echo " inep $inep";
//echo " cpf1 $cpf";
//echo " $id_t_professor";

$sql="SELECT distinct  a.id as idaluno,ta.id_turma, ta.n_chamada,ta.id_aluno,a.nome,ta.situacao,tp.id as id_prof_turma
     FROM  turmaprofessor tp, turma_aluno ta,aluno a
      WHERE tp.id_turma = ta.id_turma
      and   tp.id_turma = '$turmadiario'
      and tp.inep = '$inep'  and a.id=ta.id_aluno and  tp.cpf = '$cpf' and tp.id = '$id_t_professor'  order by ta.n_chamada";

$resultado=mysql_query($sql) or die (mysql_error());
$linhas=mysql_num_rows($resultado);

if($linhas>0)
 {


//echo "* $turmadiario";
//echo "* $id_t_professor";



?>
<html>
<head>
 <script language="javascript" src="alteracao.js"></script>
</head>
<body>
<form name="formbuscaescola" action="inclui_frequencia_aluno.php" method="post">



 	   <p>
		 Conteudo -><font size="5" color="#FF0000" style="width:300px"><?echo $conteudo;?></font>
 	   </p>

<table border="0" width="100%" id="tabzebra">
    <tr>
                  <td>
					    <label for="cod_estados" >Selecione a Data:<img src= "../img/check.gif"/></label>
						<select name="select_data" id="select_data" style="width:200px">
						<option value="">-- Selecione a Data --</option>
                         <?php




                                                            /*  $sql = "SELECT id, data
									FROM dias_diario where inep = '$inep' and cpf = '$cpf' and id_disciplina ='$disciplina'
                                                               and id_turmaprofessor = '$id_t_professor'
                                                               and registrado <> 'S'
                                                               and tpbloqueio = '1'   order by data";

                                                              */

                                                              $sql = "SELECT id, data
									FROM dias_diario where inep = '$inep' and cpf = '$cpf' and id_disciplina ='$disciplina'
                                                               and id_turma = '$turmadiario'
                                                               and registrado <> 'S'
                                                               and tpbloqueio = '1'   order by data";



							     	      $res = mysql_query( $sql );
							             while ( $row = mysql_fetch_assoc( $res ) ) {
                            echo '<option value="'.$row['id'].'">'.date("d/m/Y",strtotime($row['data'])).'</option>';
						}




                              ?>
					</select>
                    </td>
     </tr>


</table>




<table border="0" width="100%" id="tabzebra">
  <input type="hidden" name="txtid_turma_prof" style="width:150px" maxlength="100" value="<?echo $id_t_professor;?>" id="txtid_turma_prof" readonly="true" />



<tr>
  <td width="20"><b>ID Estadual</b>
  <td width="10"><b>N�</b>
  <td><b>Nome</b>
  <td><b>Situacao</b></td>
  <td><b>P ou F</b></td>
  <td><b>Obs Individual</b></td>
</tr>


      <input type="hidden"  id="txtturmadiario" name="txtturmadiario"  value = "<?echo $turmadiario;?>"  style="width:35px" maxlength="5"   onKeyPress="return Enum(event)" readonly="true"/></td>
      <input type="hidden"  id="txtdisciplina" name="txtdisciplina"  value = "<?echo $disciplina;?>"  style="width:35px" maxlength="5"   onKeyPress="return Enum(event)" readonly="true"/></td>
      <input type="hidden"  id="txtconteudo" name="txtconteudo"  value = "<?echo $conteudo;?>"  style="width:35px" maxlength="5"   onKeyPress="return Enum(event)" readonly="true"/></td>



<?
while($pegar=mysql_fetch_array($resultado))
{








    $aluno =  $pegar["idaluno"];

/*
1 	PROVAO
2 	ENEM
3 	CONSELHO DE PROF
4 	MODULAR
5 	TELENSINO
6 	RECLASSIFICACAO
7 	PROENCO
8 	ENCCEJA
9 	PRENCHIMENTO DE LACUNA

id_ensino - 1 fundamental
          - 2 m�dio

cso seja reclassifica��o tem que ser no mesmo ano.
*/


$tp_avaliacao_especial=0;
$media_promovido="-";
$sql_prova_especial="select tp.id,tp.descricao,c.nota,c.obs,h.descricao as desc_disciplina,tp.id as id_provao,tp.legenda,c.id_ensino,c.ano
                     from componente_eliminado c, tp_provao tp,habilitacao h
                     where id_aluno = '$aluno'
                     and c.ano = '{$txtano}'
                     and id_disciplina = '$disciplina'
                     and tp.id= c.tp_avaliacao
                     and tp.id in(1,2,4,5,6,7,8,9)
                     and  c.cancelado = 'N'";
$resultado_prova_especial=mysql_query($sql_prova_especial) or die (mysql_error());
$linhas_prova_especial=mysql_num_rows($resultado_prova_especial);
if ($linhas_prova_especial > 0)
   {
while($pegar_prova_especial=mysql_fetch_array($resultado_prova_especial))
       {
           $id_provao                 =  $pegar_prova_especial["id_provao"];
           $ano_provao                =  $pegar_prova_especial["ano"];


       }
    }











?>


<tr>
        <td><input type="text"   name="txtidaluno[]"  style="width:50px"   value="<?echo $pegar["idaluno"];?>" id="txtidaluno" readonly="true" />      </td>
        <td><input type="text"  name="txtnchamada[]" style="width:20px"   value="<?echo $pegar["n_chamada"];?>" id="txtnchamada" readonly="true" />  </td>
        <td><font> <?echo $pegar["nome"];?> </td>
        <td><font> <?echo $pegar["situacao"];?> </td>

 <?
  if (($pegar["situacao"]==1) || ($pegar["situacao"]==8))
  {

    if(!in_array($id_provao, array('1', '2', '4', '5', '6', '7', '8', '9'))) { 
                             ?>

 			              <td> <select id="opc[]" name="opc[]" style="width:50px">
   	        		          <option value=".">P</option>
            		          <option value="F">F</option>
    		               </select>
                          </td>
   	  <td><input type="text"     name="obsaluno[]" style="width:380px" maxlength="100" value="" id="obsaluno" /></td>
<?php  } else { ?>
 			              <td> <select id="opc[]" name="opc[]" style="width:50px">
      	        		          <option value="E">E</option>
    		               </select>
                          </td>
                          <td><input type="text"     name="obsaluno[]" style="width:380px" maxlength="100" value="Aproveitamento de  Estudo" id="obsaluno" readonly="true" /></td>

            <?
           }


 }
  else
  {
?>
 			              <td> <select id="opc[]" name="opc[]" style="width:50px">
              	        		          <option value="T">T</option>
    		               </select>
                          </td>

 <td><input type="text"     name="obsaluno[]" style="width:380px" maxlength="100" value="" id="obsaluno" readonly="true" /></td>

<?
  }
?>





  </tr>
<?

  $id_provao="";
   }//while
 }
}
 $sql = "select count(*) as total FROM  turmaprofessor tp, turma_aluno ta,aluno a
      WHERE tp.id_turma = ta.id_turma and tp.id_turma = '$turmadiario' and tp.inep = '$inep'  and a.id=ta.id_aluno and  tp.cpf = '$cpf'  and tp.id = '$id_t_professor' order by ta.n_chamada";

 $resultado=mysql_query($sql) or die (mysql_error());
 $linhas=mysql_num_rows($resultado);
 while($pegar=mysql_fetch_array($resultado))
{
     $total = $pegar["total"];
}//while
if ($total>0)
  {
?>
<tr><td>Total</td>
   	  <td><font size="2"> <?echo $total;?> </td>
  </tr>

  <tr><td></td>
     <td><input type="submit"   class="btn btn-primary"  value="Registrar" onClick="return confirm('Confirma o processo ?')"/></td>

  </tr>



<?
}
else
{
?>

<tr><td>Turma Sem Aluno - > Total</td>
   	  <td><font size="2"> <?echo $total;?> </td>
  </tr>

<br>
<br>
<tr>
<td align="center" bgcolor="#CCCCCC"><strong><font color="#FF0000" size="1" face="Verdana, Arial, Helvetica, sans-serif">
</tr>

<?
 }



?>

</table>
  <script>
   cor_tabela("tabzebra");
 </script>
</body>
</html>
