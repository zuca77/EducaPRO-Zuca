<?
session_start();
if (isset($_SESSION["login_usuario"]))
  {
	 $login     =  $_SESSION["login_usuario"];
     $nte       =  $_SESSION["nivel_usuario"];
	 $inep      =  $_SESSION["inep_usuario"] ;
     $ntelogin  =  $_SESSION["nte_login"];
     $cpf       =  $_SESSION["cpf_usuario"];
	 include ("../funcoes.php");
     echo  saudacoes()."   ". "$login" ."  -  ". $nte."  ".dataextenso() ." - ".$inep;


  }
 else
  {
     		 header("../../Location: login.php");
  }

if(file_exists("../../conexao_mysql.php"))
{
        require "../../conexao_mysql.php";
        mysql_query("SET NAMES 'latin1_swedish_ci'");
} else
{
        echo "Arquivo conexao_mysql nao foi encontrado";
        exit;
}




if($_SERVER["REQUEST_METHOD"] == "POST")
{
$txtid_turmaaluno = $_POST['txtid']; //id da tabela turma_aluno
$txtid_aluno      = $_POST['txtid_aluno'];
$txttpmov         = $_POST['txttpmov'];
$txtobs           = $_POST['txtobs'];
$txtid_turma      = $_POST['txtid_turma'];
$txtstatus         = $_POST['txtstatus']; //informa��o do banco
}



$sql="select * from ano where  inep = '$inep'  and situacao = 'A'";
$resultado=mysql_query($sql) or die (mysql_error());
$linhas=mysql_num_rows($resultado);
 if ($linhas>0)
  {
       while($pegargrade=mysql_fetch_array($resultado))
       {
           $txtano      =  $pegargrade["ano"];
         }
  }
 else
  {
    echo "<html><head><title>Resposta !!!</title></head>";
    echo "<body background=\"background_mensagens.jpg\" style=\"background-attachment:fixed; background-repeat:no-repeat\">";
    echo "<br><br><br>";
    echo "<center><img src=\"faleconosco/atencao.gif\" alt=\"\"><p><font color=\"#FF0000\" face=\"Verdana\" size=\"4\"><blink>Processo n�o pode ser realizado . Usu�rio! n�o existe ano aberto.</blink> <b></b></font></center>";
    echo "<br><br><center><a href=\"../mnadmescola.php\"><img src=\"faleconosco/button_voltar2_.gif\" alt=\"Voltar\" border=\"0\" /></a></center>";
    echo "</body></html>";
    exit;

  }
 /*******************************************************/

$sql="select * from turma_aluno  where  id = '$txtid_turmaaluno'";
$resultado=mysql_query($sql) or die (mysql_error());
$linhas=mysql_num_rows($resultado);
 if ($linhas>0)
  {
       while($pegargrade=mysql_fetch_array($resultado))
       {
           $txtano      =  $pegargrade["ano"];
         }
  }


/********************************************************/



if (($txtstatus =='2') and  ($txttpmov !=6))
                                     {
                                      echo "<html><head><title>Resposta !!!</title></head>";
                                      echo "<body background=\"background_mensagens.jpg\" style=\"background-attachment:fixed; background-repeat:no-repeat\">";
                                      echo "<br><br><br>";
                                      echo "<center><img src=\"faleconosco/atencao.gif\" alt=\"\"><p><font color=\"#ff6600\" face=\"Verdana\" size=\"4\"><b>Usu�rio ! Aluno com situa��o de Remanejado, �nica op��o aceita � de exclus�o! </b></font></center>";
                                      echo "<br><br><center><a href=\"../mnadmescola.php\"><img src=\"faleconosco/button_voltar2_.gif\" alt=\"Voltar\" border=\"0\" /></a></center>";
                                      echo "</body></html>";
                                      exit;
                                    }





$dia = date('d');
$mes = date('m');
$ano = date('Y');
$data1 =$ano.".".$mes.".".$dia;

if($txttpmov!=6)
 {
    $sql="update turma_aluno set situacao = '$txttpmov' where id = '$txtid_turmaaluno' and ano ='$txtano'";

                             if(@mysql_query($sql))
                              {
                               $success = mysql_affected_rows();
                                 if($success ==true)
                                    {

                                    }
                                }
                            else
                                {
                                  //verifico se nao estao tentando gravar um dado que ja existe, pois usei UNIQUE na tabela
                                    if(mysql_errno() == 1062)
                                    		  {
                                                        echo $erros[mysql_errno()];
                                                                        exit;
                                              }
                                         else
                                             {
                                                       echo "Erro nao foi possivel efetuar atualiza��o do aluno";
                                                        exit;
                                             }
                                              @mysql_close();
                                    }


 }
else
 {

$sqlgerencia = "select * from nota_aluno where inep ='$inep' and id_aluno = '$txtid_aluno' and ano='$txtano' and id_turma = '$txtid_turma'
and ((nota1 > 0) or (nota2 > 0) or (nota3 > 0) or (nota4 >0))";
$resultadoger=mysql_query($sqlgerencia) or die (mysql_error());
$linhas   =mysql_num_rows($resultadoger);
if($linhas>0)
{
   echo "<html><head><title>Resposta !!!</title></head>";
   echo "<body background=\"background_mensagens.jpg\" style=\"background-attachment:fixed; background-repeat:no-repeat\">";
   echo "<br><br><br>";
   echo "<center><img src=\"faleconosco/atencao.gif\" alt=\"\"><p><font color=\"#ff6600\" face=\"Verdana\" size=\"4\">Aluno n�o pode ser exclu�do. Existe(m) notas com valor expressivo. <b></b></font></center>";
   echo "<br><br><center><a href=\"../mnadmescola.php\"><img src=\"faleconosco/button_voltar2_.gif\" alt=\"Voltar\" border=\"0\" /></a></center>";
   echo "</body></html>";
   exit;
}

/**************Deleta o aluno da turma*********/
                             $sql="delete from turma_aluno  where id_turma = '$txtid_turma' and id_aluno = '$txtid_aluno' and ano ='$txtano'
                             and inep ='$inep' and id ='$txtid_turmaaluno'";
                             if(@mysql_query($sql))
                              {
                               $success = mysql_affected_rows();
                                 if($success ==true)
                                    {

                                    }
                                }
                            else
                                {
                                  //verifico se nao estao tentando gravar um dado que ja existe, pois usei UNIQUE na tabela
                                    if(mysql_errno() == 1062)
                                    		  {
                                                        echo $erros[mysql_errno()];
                                                                        exit;
                                              }
                                         else
                                             {
                                                       echo "Erro nao foi possivel efetuar atualiza��o do aluno";
                                                        exit;
                                             }
                                              @mysql_close();
                                    }

/**********************Deleta as Notas desse aluno*********************/
                             $sql="delete from nota_aluno  where id_turma = '$txtid_turma' and id_aluno = '$txtid_aluno' and ano ='$txtano' and inep ='$inep'";
                             if(@mysql_query($sql))
                              {
                               $success = mysql_affected_rows();
                                 if($success ==true)
                                    {
                                    }
                                }
                            else
                                {
                                  //verifico se nao estao tentando gravar um dado que ja existe, pois usei UNIQUE na tabela
                                    if(mysql_errno() == 1062)
                                    		  {
                                                        echo $erros[mysql_errno()];
                                                                        exit;
                                              }
                                         else
                                             {
                                                       echo "Erro nao foi possivel efetuar atualiza��o do aluno";
                                                        exit;
                                             }
                                              @mysql_close();
                                    }

/**********************Deleta frequencia do aluno*********************/
                             $sql="delete from frequencia_aluno  where id_turma = '$txtid_turma' and id_aluno = '$txtid_aluno' and ano ='$txtano' and inep ='$inep'";
                             if(@mysql_query($sql))
                              {
                               $success = mysql_affected_rows();
                                 if($success ==true)
                                    {
                                    }
                                }
                            else
                                {
                                  //verifico se nao estao tentando gravar um dado que ja existe, pois usei UNIQUE na tabela
                                    if(mysql_errno() == 1062)
                                    		  {
                                                        echo $erros[mysql_errno()];
                                                                        exit;
                                              }
                                         else
                                             {
                                                       echo "Erro nao foi possivel efetuar atualiza��o do aluno";
                                                        exit;
                                             }
                                              @mysql_close();
                                    }




 }//else






$sqlgerencia = "select * from turma_aluno where inep ='$inep' and id_aluno = '$txtid_aluno' and ano= '$txtano' and situacao = '1'";
$resultadoger=mysql_query($sqlgerencia) or die (mysql_error());
$linhas   =  mysql_num_rows($resultadoger);
if($linhas<=0) // retorna para associar
{
             $sql="update aluno set id_turma='0', status ='$txttpmov' where id = '$txtid_aluno'";
             if(@mysql_query($sql))
                {
                   $success = mysql_affected_rows();
                   if($success ==true)
                      {
                          $sql = "insert into movimenta_aluno (id_aluno,id_movimento,id_turmaaluno,obs,data,usuario)
                          values ('$txtid_aluno','$txttpmov','$txtid_turmaaluno','$txtobs','$data1','$cpf')";
                            if(@mysql_query($sql))
                              {
                               $success = mysql_affected_rows();
                                 if($success ==true)
                                    {
                                      echo "<html><head><title>Resposta !!!</title></head>";
                                      echo "<body background=\"background_mensagens.jpg\" style=\"background-attachment:fixed; background-repeat:no-repeat\">";
                                      echo "<br><br><br>";
                                      echo "<center><img src=\"faleconosco/atencao.gif\" alt=\"\"><p><font color=\"#ff6600\" face=\"Verdana\" size=\"4\">Aluno Movimentado  Com Sucesso.!!!! <b></b></font></center>";
                                      echo "<br><br><center><a href=\"../mnadmescola.php\"><img src=\"faleconosco/button_voltar2_.gif\" alt=\"Voltar\" border=\"0\" /></a></center>";
                                      echo "</body></html>";
                                    }
                              }
                         else
                                {
                                  //verifico se nao estao tentando gravar um dado que ja existe, pois usei UNIQUE na tabela
                                    if(mysql_errno() == 1062)
                                    		  {
                                                        echo $erros[mysql_errno()];
                                                                        exit;
                                              }
                                         else
                                             {
                                                       echo "Erro nao foi possivel efetuar atualiza��o do aluno";
                                                        exit;
                                             }
                                              @mysql_close();
                                    }
                      }
                   }
                 else
                    {
                            //verifico se nao estao tentando gravar um dado que ja existe, pois usei UNIQUE na tabela
                                    if(mysql_errno() == 1062)
                                    		  {
                                                        echo $erros[mysql_errno()];
                                                                        exit;
                                              }
                                         else
                                             {
                                                       echo "Erro nao foi possivel efetuar atualiza��o do aluno";
                                                        exit;
                                             }
                                              @mysql_close();
                     }






}
else
                                    {
                                      echo "<html><head><title>Resposta !!!</title></head>";
                                      echo "<body background=\"background_mensagens.jpg\" style=\"background-attachment:fixed; background-repeat:no-repeat\">";
                                      echo "<br><br><br>";
                                      echo "<center><img src=\"faleconosco/atencao.gif\" alt=\"\"><p><font color=\"#ff6600\" face=\"Verdana\" size=\"4\">Aluno Movimentado  Com Sucesso.!!!! <b></b></font></center>";
                                      echo "<br><br><center><a href=\"../mnadmescola.php\"><img src=\"faleconosco/button_voltar2_.gif\" alt=\"Voltar\" border=\"0\" /></a></center>";
                                      echo "</body></html>";
                                    }


?>
