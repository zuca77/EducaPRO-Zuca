<?php

session_start();
if (isset($_SESSION["login_usuario"]))
  {
  	 $login     =  $_SESSION["login_usuario"];
     $nte       =  $_SESSION["nivel_usuario"];
	 $inep      =  $_SESSION["inep_usuario"] ;
     $ntelogin  =  $_SESSION["nte_login"];
	 include ("../../funcoes.php");
     echo  saudacoes()."   ". "$login" ."  -  ". $nte."  ".dataextenso() ." - ".$inep;

  }
 else
  {
     		 header("Location: login.php");
  }



if(file_exists("../../conexao_mysql.php"))
{
        require "../../conexao_mysql.php";

} else
{
        echo "Conex�o nao foi encontrado";
        exit;
}





$id=  $_GET['codigo'];


if(!empty($id))
{

   $sql="select id,id_turma,id_aluno,situacao from turma_aluno  where id = '$id'";
   $resultado=mysql_query($sql) or die (mysql_error());
   $linhas=mysql_num_rows($resultado);
   if($linhas>0)
    {
   while($pegar=mysql_fetch_array($resultado))
      {


      $id_aluno    = $pegar["id_aluno"];
      $id_turma    = $pegar["id_turma"];
      $situacao    = $pegar["situacao"];
      }
    }



   $sql="select * from turma  where id = '$id_turma'";
   $resultado=mysql_query($sql) or die (mysql_error());
   $linhas=mysql_num_rows($resultado);
   if($linhas>0)
    {
   while($pegar=mysql_fetch_array($resultado))
      {
      $desc_turma    = $pegar["DESCRICAO"];
      }
    }



                                 if(($situacao !=1) && ($situacao !=8 ) && ($situacao !=2 ))
                                    {
                                      echo "<html><head><title>Resposta !!!</title></head>";
                                      echo "<body background=\"background_mensagens.jpg\" style=\"background-attachment:fixed; background-repeat:no-repeat\">";
                                      echo "<br><br><br>";
                                      echo "<center><img src=\"faleconosco/atencao.gif\" alt=\"\"><p><font color=\"#ff6600\" face=\"Verdana\" size=\"4\">Somente aluno com situa��o matriculado pode ser movimentado.! <b></b></font></center>";
                                      echo "<br><br><center><a href=\"../mnadmescola.php\"><img src=\"faleconosco/button_voltar2_.gif\" alt=\"Voltar\" border=\"0\" /></a></center>";
                                      echo "</body></html>";
                                      exit;

                                    }


$sql="SELECT * from aluno where id = '$id_aluno'";
$resultado=mysql_query($sql) or die (mysql_error());
$linhas=mysql_num_rows($resultado);
if($linhas>0)
{
   while($pegar=mysql_fetch_array($resultado))
   {
    $nome               =$pegar["nome"];
    $nome_mae           =$pegar["nome_mae"];
    $endereco           =$pegar["endereco"];
    $bairro             =$pegar["bairro"];
    $numero             =$pegar["numero"];
    $cep                =$pegar["cep"];
    $complemento        =$pegar["complemento"];
    $cidade             =$pegar["cidade"];
    $fonecontato        =$pegar["fonecontato"];
    $fonecelular        =$pegar["fonecelular"];
    $email              =$pegar["email"];
   }

}}


?>

<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01//EN"
	"http://www.w3.org/TR/html4/strict.dtd">
<head>
	<title>SEDUC-RO</title>
	<link rel="stylesheet" href="style/forms.css" type="text/css" />
	<link rel="stylesheet" href="estilo.css" type="text/css" />
	<link rel="stylesheet" href="style/menu.css" type="text/css" />

	
	<link href="tablecloth/tablecloth.css" rel="stylesheet" type="text/css" media="screen" />
	
	<script type="text/javascript" src="tablecloth/tablecloth.js"></script>
	<script src="lib/jquery-1.4.2.js" type="text/javascript"></script>
	<script src="lib/validate.js" type="text/javascript"></script>
	<script src="lib/forms.js" type="text/javascript"></script>
	<script src="generic_mov_aluno.js" type="text/javascript"></script>
    <script src="lib/jquery.maskedinput-1.1.1.js" type="text/javascript"></script>
	<meta http-equiv="Content-type" content="text/html; charset=utf-8" />





 	<link type="text/css" href="jquery-ui-1.8.18.custom/css/ui-lightness/jquery-ui-1.8.18.custom.css" rel="stylesheet" />
<!--	Versao nao trabalha com validade <script type="text/javascript" src="jquery-ui-1.8.18.custom/js/jquery-1.7.1.min.js"></script>-->
	<script type="text/javascript" src="jquery-ui-1.8.18.custom/js/jquery-ui-1.8.18.custom.min.js"></script>



    <script>
$(function() {
		$( "#txtdtmovimento" ).datepicker({
			changeMonth: true,
			changeYear: true
		});
	});

$(function() {
        $("#txtdtmovimento").datepicker();
        $('#txtdtmovimento').datepicker('option', 'dateFormat', 'dd/mm/yy');
});


</script>





<script>

function tp_movimento()
{

	  if (document.form.txttpmov.value == '3')
             {
		     document.form.txtstatus_mov.disabled=false;

 		     }

     else
           {

		     document.form.txtstatus_mov.disabled=true;
   		     document.form.txtstatus_mov.value='';
            }

}


</script>


















</head>
<body>
	<div id="warpper">
		<div id="header">
           <img src= "../img/chamadaescolar.jpg"/>
		</div>



			<div id="content">
				<form name = "form" class="form" action="inclusao_mov_aluno.php" method="post">

				 <div id="tema"> 
					   <p><center>Movimenta��o de Aluno</center></p>
				  </div>

					<p>
                        <label for="lblpai" style="width:150px">Turma<img src= "../img/check.gif"/></label>
                        <input type="text" name="txtid_turma" style="width:150px" maxlength="100" value="<?echo $id_turma;?>" id="txtid_turma" readonly="true" />
                        <input type="text" name="txt_descturma" style="width:400px" maxlength="100" value="<?echo $desc_turma;?>" id="txt_descturma" readonly="true" />
                        <input type="text" name="txtid" style="width:80px" maxlength="100" value="<?echo $id;?>" id="txtid" readonly="true" />
                	</p>


					<p>
                        <label for="lblpai" style="width:150px">ID Estadual<img src= "../img/check.gif"/></label>
                        <input type="text" name="txtid_aluno" style="width:150px" maxlength="100" value="<?echo $id_aluno;?>" id="txtid_aluno" readonly="true" />
                	</p>

					<p>
						<label for="lblpai">Nome do Aluno<img src= "../img/check.gif"/></label>
						<input type="text" name="txtnaluno" style="width:565px" maxlength="100" value="<?echo $nome;?>" id="txtnaluno" readonly="true"/>
					</p>


					<p>
						<label for="lblEndereco">Endere�o(Rua/Avenida)<img src= "../img/check.gif"/></label>
						<input type="text" name="txtEndereco" style="width:565px" value="<?echo $endereco;?>"  maxlength="100" size="40" id="txtEndereco" readonly="true"/>
					</p>
					<p>
						<label for="lblBairro">Bairro<img src= "../img/check.gif"/></label>
						<input type="text" name="txtBairro" value="<?echo $bairro;?>" id="txtBairro" maxlength="100" readonly="true"/>
						<label for="lblBairro">Nr<img src= "../img/check.gif"/></label>
						<input type="text" name="txtnr" style="width:60px" value="<?echo $numero;?>" id="txtnr"  maxlength="5" readonly="true"/>
			            <label for="txtCEP">CEP<img src= "../img/check.gif"/></label>
            			<input id="txtcep" name="txtcep" type="text" style="width:90px" maxlength="8" value="<?echo $cep;?>" onKeyPress="return Enum(event)" readonly="true"/>
					</p>

					<p>
						<label for="txtFoneSetor">Telefone Para Contato<img src= "../img/check.gif"/></label>
						<input type="text" name="txtcontato" style="width:110px" value="<?echo $fonecontato;?>" id="txtcontato" readonly="true"/>
						<label for="txtCelular">Celular<img src= "../img/check.gif"/></label>
						<input type="text" name="txtCelular" style="width:90px" value="<?echo $fonecelular;?>" id="txtCelular" maxlength="20" readonly="true"/>
					</p>
					<p>
						<label for="txtEmail1">E-mail</label>
						<input type="text" name="txtEmail" style="width:565px" value="<?echo $email;?>" id="txtEmail" maxlength="60" readonly="true"/>

					</p>


					<p>
						<label for="txtEmail1">Status</label>
						<input type="text" name="txtstatus" style="width:565px" value="<?echo $situacao;?>" id="txtstatus" maxlength="60" readonly="true"/>

					</p>


                <p>
          		<label for="lblcod_cidades">Selecione Tipo Mov:<img src= "../img/check.gif"/></label>
						<select name="txttpmov" id="txttpmov" style="width:200px" onChange = "tp_movimento(form)"/>
			           <option value="">-- Selecione Mov --</option>
					<?php
						$sqltpmov = "SELECT id, descricao
									FROM tipo_mov_aluno where id < 100
									ORDER BY id";
						  $resultado1 = mysql_query($sqltpmov);
                          if($resultado1)
                      		{
      	                   while($linhas = mysql_fetch_array($resultado1)){
			                 ?>
								<option value="<?php echo $linhas['id']; ?>"
								<?php if($linhas['id'] == $situacao){ echo "selected";  } ?>>
								<?php echo $linhas['descricao'];  ?>
								</option>
								<?php } }
								 ?>
							</select>
                 </p>





                <p>
            		<label for="lblcod_cidades">Selecione Situa��o do Aluno:<img src= "../img/check.gif"/></label>
 						<select name="txtstatus_mov" id="txtstatus_mov" style="width:200px"   disabled="disabled">
            	           <option value="">-- Escolha a Situa��o --</option>

					<?php
						$sqltpmov = "SELECT id, descricao
									FROM status_aluno_declaracao
									ORDER BY descricao";
						  $resultado1 = mysql_query($sqltpmov);
                          if($resultado1)
                      		{
      	                   while($linhas = mysql_fetch_array($resultado1)){
			                 ?>
								<option value="<?php echo $linhas['id']; ?>"
								<?php if($linhas['id'] == $situacao){ echo "selected";  } ?>>
								<?php echo $linhas['descricao'];  ?>
								</option>
								<?php } }
								 ?>
							</select>
                 </p>





    		       <p>
						<label for="lbldtnascimento">Data<img src= "../img/check.gif"/></label>
						<input type="text" name="txtdtmovimento" value="" style="width:70px" maxlength="10" id="txtdtmovimento" />

                    </p>


   	    <p>
            <label for="lblcod_cpf">Obs.:<img src= "../img/check.gif"/></label>
 			<textarea name = "txtobs"  maxlength= "200" cols="80" rows = "10" id = "txtobs"  type = "text"  onkeyup="blocTexto(txtdescvolume.value)"></textarea>
       </p>







    		<p id="finish">
               <input type="submit" value="Gravar"  onClick="return confirm('Confirma a movimenta��o do aluno ?')"/>
               <input type="button" value=" Voltar " onclick="location.href='../mnadmescola.php';">
	    	</p>
				</form>
			</div>
		</div>
		<div id="footer">
			<p>Todos direitos reservados SEDUC-RO</p>
   </p>
		</div>
	</div>
</body>

