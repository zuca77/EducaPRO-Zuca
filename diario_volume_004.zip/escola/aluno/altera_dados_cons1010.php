<?
session_start();
if (isset($_SESSION["login_usuario"]))
  {
	 $login     =  $_SESSION["login_usuario"];
     $nte       =  $_SESSION["nivel_usuario"];
	 $inep      =  $_SESSION["inep_usuario"] ;
     $ntelogin  =  $_SESSION["nte_login"];
     $cpf       =  $_SESSION["cpf_usuario"];
	 include ("../../funcoes.php");
     echo  saudacoes()."   ". "$login" ."  -  ". $nte."  ".dataextenso()." ".$inep;

  }
 else
  {
     		 header("../../Location: login.php");
  }



if($_SERVER["REQUEST_METHOD"] == "POST")
{
$id                  = $_POST['txtid'];
$txtnaluno           = $_POST['txtnaluno'];
$cod_estado          = $_POST['cod_estado'];
$cod_cidades         = $_POST['cod_cidades'];
$cod_muni            = $_POST['cod_muni'];
$cpfpai              = $_POST['cpfpai'];
$cpfresp             = $_POST['cpf'];
$selectsexo	         = $_POST['selectsexo'];
$txtBairro           = $_POST['txtBairro'];
$txtCelular          = $_POST['txtCelular'];
$txtEmail            = $_POST['txtEmail'];
$txtEndereco         = $_POST['txtEndereco'];
$txtOrgaoExpmae      = $_POST['txtOrgaoExpmae'];
$txtOrgaoExppai      = $_POST['txtOrgaoExppai'];
$txtRGpai            = $_POST['txtRGpai'];
$txtRGmae            = $_POST['txtRGmae'];
$txtcep              = $_POST['txtcep'];
$txtcertidaonovo    = $_POST['txtcertidaonovo'];
$txtcertidao         = $_POST['txtcertidao'];
$txtcomplemento      = $_POST['txtcomplemento'];
$txtcontato          = $_POST['txtcontato'];
$txtfolha            = $_POST['txtfolha'];
$txtlivro            = $_POST['txtlivro'];
$txtnr             = $_POST['txtnr'];
$txtobs            = $_POST['txtobs'];
$txtturma	             = $_POST['txtturma'];
$txtdtnascimento           = $_POST['txtdtnascimento'];
$txtmae                    = $_POST['txtmae'];
$txtpai                    = $_POST['txtpai'];
$txtdtemissaorgpai         = $_POST['txtdtemissaorgpai'];

$dtemissao_certidao       = $_POST['dtemissao_certidao'];
$txtdtemissaorgmae        = $_POST['txtdtemissaorgmae'];


$txtresponsavel           = $_POST['txtresponsavel'];
$selectgrauparente        = $_POST['selectgrauparente'];
$txtRGresp                = $_POST['txtRGresp'];
$txtOrgaoExpresp          = $_POST['txtOrgaoExpresp'];
$txtdtemissaorgresp       = $_POST['txtdtemissaorgresp'];

$selectbosaf              = $_POST['selectbosaf'];
$selecttipo_necessidade   = $_POST['selecttipo_necessidade'];
$selectdeficiente         = $_POST['selectdeficiente'];


$selectcorraca            = $_POST['selectcorraca'];
$nbolsa                   = $_POST['nbolsa'];
$filiacao                 = $_POST['filiacao'];
$idnacional               = $_POST['idnacional'];

$nsus                          = $_POST['nsus'];
$selecttransporte              = $_POST['selecttransporte'];
$selectacesso                 = $_POST['selectacesso'];



$txtdt_matricula           = $_POST['txtdt_matricula'];
$cpfaluno                  = $_POST['cpfaluno'];
$txtRGaluno                = $_POST['txtRGaluno'];
$txtdtemissaorgaluno       = $_POST['txtdtemissaorgaluno'];
$txtOrgaoExpaluno          = $_POST['txtOrgaoExpaluno'];
$select_altera_cod_acesso  =  $_POST['select_altera_cod_acesso'];




$cpfaluno                 = $_POST['cpfaluno'];
$txtRGaluno               = $_POST['txtRGaluno'];
$txtOrgaoExpaluno         = $_POST['txtOrgaoExpaluno'];
$txtdtemissaorgaluno      = $_POST['txtdtemissaorgaluno'];





$txtpaisestrangeiro       = $_POST['txtpaisestrangeiro'];
$txtestadoestrangeiro     = $_POST['txtestadoestrangeiro'];
$txtnacionalidade         = $_POST['txtnacionalidade'];
$txtmunicipioestrangeiro  = $_POST['txtmunicipioestrangeiro'];





//img_foto





if (($select_altera_cod_acesso == 'S'))
    {


      if (($txtresponsavel == '') || ($cpfresp == ''))
          {
            echo "<html><head><title>Resposta !!!</title></head>";
            echo "<body background=\"background_mensagens.jpg\" style=\"background-attachment:fixed; background-repeat:no-repeat\">";
            echo "<br><br><br>";
            echo "<center><img src=\"faleconosco/atencao.gif\" alt=\"\"><p><font color=\"#ff6600\" face=\"Verdana\" size=\"4\"><b>Para acesso ao portal do aluno os dados do respons�vel s�o obrigat�rios!</b></font></center>";
            echo "<br><br><center><a href=\"form_cons_altera_aluno.php\"><img src=\"faleconosco/button_voltar2_.gif\" alt=\"Voltar\" border=\"0\" /></a></center>";
            echo "</body></html>";
            exit;
           }

                 $senha_acesso                = md5($_POST['cpf']);


   }


if (($selectacesso == 'S'))
    {
      if (($txtresponsavel == '') || ($cpfresp == ''))
           {
            echo "<html><head><title>Resposta !!!</title></head>";
            echo "<body background=\"background_mensagens.jpg\" style=\"background-attachment:fixed; background-repeat:no-repeat\">";
            echo "<br><br><br>";
            echo "<center><img src=\"faleconosco/atencao.gif\" alt=\"\"><p><font color=\"#ff6600\" face=\"Verdana\" size=\"4\"><b>Para acesso ao portal os dados do respons�vel s�o obrigat�rios.!</b></font></center>";
            echo "<br><br><center><a href=\"form_cons_altera_aluno.php\"><img src=\"faleconosco/button_voltar2_.gif\" alt=\"Voltar\" border=\"0\" /></a></center>";
            echo "</body></html>";
            exit;
          }
   }





//echo "data nasc $txtdtnascimento";


$foto           = $_FILES["imagem"];



$foto           = $_FILES["imagem"];
/*Tratamento  Foto*/
$arquivo_g = isset($_FILES["imagem"]) ? $_FILES["imagem"] : FALSE;if($_FILES["imagem"]==''){echo '<script>confirm("Noticia sem imagem?")</script>';}

$arquivo_g = isset($_FILES["imagem"]) ? $_FILES["imagem"] : FALSE;if($_FILES["imagem"]=='')
   {echo '<script>confirm("Noticia sem imagem?")</script>';}
	if ($arquivo_g['name'] == '')
    {
		$imagem_g = 'null';
 	}
			else
	{
			$largura=370;$altura=260;
			$imagem_g = upImagemBig("g",$arquivo_g,370,260);
	}

/*tratamento das datas*/


$diai = substr($txtdtemissaorgresp, 0,2);
$anoi = substr($txtdtemissaorgresp, -4);
$mesi = substr($txtdtemissaorgresp, -7,2);
$txtdtemissaorgresp=$anoi.".".$mesi.".".$diai;

if ($txtdtemissaorgresp== '..')
     $txtdtemissaorgresp = '0000.00.00';



$diai = substr($dtemissao_certidao, 0,2);
$anoi = substr($dtemissao_certidao, -4);
$mesi = substr($dtemissao_certidao, -7,2);
$dtemissao_certidao=$anoi.".".$mesi.".".$diai;
if ($dtemissao_certidao== '..')
     $dtemissao_certidao = '0000.00.00';


//echo "emissao da certidao de nascimento $dtemissao_certidao";



$diai = substr($txtdtnascimento, 0,2);
$anoi = substr($txtdtnascimento, -4);
$mesi = substr($txtdtnascimento, -7,2);
$txtdtnascimento=$anoi.".".$mesi.".".$diai;
if ($txtdtnascimento== '..')
     $txtdtnascimento = '0000.00.00';



$diaf = substr($txtdtemissaorgpai, 0,2);
$anof = substr($txtdtemissaorgpai, -4);
$mesf = substr($txtdtemissaorgpai, -7,2);
$txtdtemissaorgpai=$anof.".".$mesf.".".$diaf;
if ($txtdtemissaorgpai== '..')
     $txtdtemissaorgpai = '0000.00.00';



$diaret = substr($txtdtemissaorgmae, 0,2);
$anoret = substr($txtdtemissaorgmae, -4);
$mesret = substr($txtdtemissaorgmae, -7,2);
$txtdtemissaorgmae=$anoret.".".$mesret.".".$diaret;
if ($txtdtemissaorgmae== '..')
     $txtdtemissaorgmae = '0000.00.00';

$diaret = substr($txtdt_matricula, 0,2);
$anoret = substr($txtdt_matricula, -4);
$mesret = substr($txtdt_matricula, -7,2);
$txtdt_matricula  =$anoret.".".$mesret.".".$diaret;
if ($txtdt_matricula== '..')
     $txtdt_matricula = '0000.00.00';



$diaret = substr($txtdtemissaorgaluno, 0,2);
$anoret = substr($txtdtemissaorgaluno, -4);
$mesret = substr($txtdtemissaorgaluno, -7,2);
$txtdtemissaorgaluno  =$anoret.".".$mesret.".".$diaret;
if ($txtdtemissaorgaluno== '..')
     $txtdtemissaorgaluno = '0000.00.00';











$dia = date('d');
$mes = date('m');
$ano = date('Y');
$data =$dia.".".$mes.".".$ano;
$data1 =$dia.".".$mes.".".$ano;

$data2 =$ano.".".$mes.".".$dia;





$sql = "select * from aluno where id = '$id'";
$resultado=mysql_query($sql) or die (mysql_error());
$linhas=mysql_num_rows($resultado);
if ($linhas > 0)
{

if ($select_altera_cod_acesso == 'S')
 {
   if  ($imagem_g != 'null')
    {
      $sql = "update aluno set
		nome                  ='$txtnaluno',
		dt_nascimento         ='$txtdtnascimento',
		sexo                  ='$selectsexo',
		termo_certidao        ='$txtcertidao',
		folha_certidao        ='$txtfolha',
       	livro_certidao        ='$txtlivro',
		uf_nascimento   	  ='$cod_estado',
		muni_nascimento		  ='$cod_cidades',
		nome_pai	          ='$txtpai',
		RG_PAI                ='$txtRGpai',
		ORGEXPRG_PAI          ='$txtOrgaoExppai',
		DTRG_PAI              ='$txtdtemissaorgpai',
		CPF                   ='$cpfpai',
		nome_mae			  ='$txtmae',
		RG_MAE                ='$txtRGmae',
		ORGEXPRG_MAE		  ='$txtOrgaoExpmae',
		DTRG_MAE	          ='$txtdtemissaorgmae',
        CPF_MAE                ='$cpfmae',
		endereco             ='$txtEndereco',
		bairro               ='$txtBairro',
		numero               ='$txtnr',
		cep			         ='$txtcep',
		complemento          ='$txtcomplemento',
		cidade               ='$cod_muni',
		FONECONTATO          ='$txtcontato',
		FONECELULAR          ='$txtCelular',
		EMAIL			      ='$txtEmail',
		OBS                  ='$txtobs',
		n_certidao_novo       ='$txtcertidaonovo',
		dtemissao_certidao    ='$dtemissao_certidao',
		foto                  ='$imagem_g',
        responsavel           ='$txtresponsavel',
        grau_parentesco       ='$selectgrauparente',
        rgresponsavel         ='$txtRGresp',
        orgaoexpresp          ='$txtOrgaoExpresp',
        dtemissaorgresp       ='$txtdtemissaorgresp',
        cpfresp               ='$cpfresp',
        status                ='1',
        inep                  ='$inep',
        tipo_necessidade       ='$selecttipo_necessidade',
        bolsa_familia          ='$selectbosaf',
        deficiente             ='$selectdeficiente',
        sus                    = '$nsus',
        transporte             ='$selecttransporte',
        car_raca               ='$selectcorraca',
        n_bolsa_fam             = '$nbolsa',
        filiacao                = '$filiacao',
        id_nacional             ='$idnacional',
        senha_acesso            = '$senha_acesso',
        acesso_portal           ='$selectacesso',
        orgaoexp_aluno          ='$txtOrgaoExpaluno',
        dtemissaorg_aluno       ='$txtdtemissaorgaluno',
        rg_aluno                ='$txtRGaluno',
        cpf_aluno               ='$cpfaluno',
        dt_matricula            ='$txtdt_matricula',


        orgaoexp_aluno    ='$txtOrgaoExpaluno',
        dtemissaorg_aluno ='$txtdtemissaorgaluno',
        rg_aluno          ='$txtRGaluno',
        cpf_aluno         ='$cpfaluno',
        dt_matricula      ='$txtdt_matricula',


        pais_estrangeiro  =     '$txtpaisestrangeiro',
        estado_estrangeiro=     '$txtestadoestrangeiro',
        municipio_estrangeiro = '$txtmunicipioestrangeiro',
        nacionalidade         = '$txtnacionalidade',
        usuario		            = '$cpf'
        where                   id='$id'";
      }
    else

     {
      $sql = "update aluno set
		nome                  ='$txtnaluno',
		dt_nascimento         ='$txtdtnascimento',
		sexo                  ='$selectsexo',
		termo_certidao        ='$txtcertidao',
		folha_certidao        ='$txtfolha',
       	livro_certidao        ='$txtlivro',
		uf_nascimento   	  ='$cod_estado',
		muni_nascimento		  ='$cod_cidades',
		nome_pai	          ='$txtpai',
		RG_PAI                ='$txtRGpai',
		ORGEXPRG_PAI          ='$txtOrgaoExppai',
		DTRG_PAI              ='$txtdtemissaorgpai',
		CPF                   ='$cpfpai',
		nome_mae			  ='$txtmae',
		RG_MAE                ='$txtRGmae',
		ORGEXPRG_MAE		  ='$txtOrgaoExpmae',
		DTRG_MAE	          ='$txtdtemissaorgmae',
        CPF_MAE                ='$cpfmae',
		endereco             ='$txtEndereco',
		bairro               ='$txtBairro',
		numero               ='$txtnr',
		cep			         ='$txtcep',
		complemento          ='$txtcomplemento',
		cidade               ='$cod_muni',
		FONECONTATO          ='$txtcontato',
		FONECELULAR          ='$txtCelular',
		EMAIL			      ='$txtEmail',
		OBS                  ='$txtobs',
		n_certidao_novo       ='$txtcertidaonovo',
		dtemissao_certidao    ='$dtemissao_certidao',
        responsavel           ='$txtresponsavel',
        grau_parentesco       ='$selectgrauparente',
        rgresponsavel         ='$txtRGresp',
        orgaoexpresp          ='$txtOrgaoExpresp',
        dtemissaorgresp       ='$txtdtemissaorgresp',
        cpfresp               ='$cpfresp',
        status                ='1',
        inep                  ='$inep',
        tipo_necessidade       ='$selecttipo_necessidade',
        bolsa_familia          ='$selectbosaf',
        deficiente             ='$selectdeficiente',
        sus                    = '$nsus',
        transporte             ='$selecttransporte',
        car_raca               ='$selectcorraca',
        n_bolsa_fam             = '$nbolsa',
        filiacao                = '$filiacao',
        id_nacional             ='$idnacional',
        acesso_portal           ='$selectacesso',
        senha_acesso            = '$senha_acesso',
        orgaoexp_aluno    ='$txtOrgaoExpaluno',
        dtemissaorg_aluno ='$txtdtemissaorgaluno',
        rg_aluno          ='$txtRGaluno',
        cpf_aluno         ='$cpfaluno',
        dt_matricula      ='$txtdt_matricula',

        pais_estrangeiro  =     '$txtpaisestrangeiro',
        estado_estrangeiro=     '$txtestadoestrangeiro',
        municipio_estrangeiro = '$txtmunicipioestrangeiro',
        nacionalidade         = '$txtnacionalidade',

        usuario		            = '$cpf'
        where                   id='$id'";
      }

  }
else
  {

     if  ($imagem_g != 'null')
    {

      $sql = "update aluno set
		nome                  ='$txtnaluno',
		dt_nascimento         ='$txtdtnascimento',
		sexo                  ='$selectsexo',
		termo_certidao        ='$txtcertidao',
		folha_certidao        ='$txtfolha',
       	livro_certidao        ='$txtlivro',
		uf_nascimento   	  ='$cod_estado',
		muni_nascimento		  ='$cod_cidades',
		nome_pai	          ='$txtpai',
		RG_PAI                ='$txtRGpai',
		ORGEXPRG_PAI          ='$txtOrgaoExppai',
		DTRG_PAI              ='$txtdtemissaorgpai',
		CPF                   ='$cpfpai',
		nome_mae			  ='$txtmae',
		RG_MAE                ='$txtRGmae',
		ORGEXPRG_MAE		  ='$txtOrgaoExpmae',
		DTRG_MAE	          ='$txtdtemissaorgmae',
        CPF_MAE                ='$cpfmae',
		endereco             ='$txtEndereco',
		bairro               ='$txtBairro',
		numero               ='$txtnr',
		cep			         ='$txtcep',
		complemento          ='$txtcomplemento',
		cidade               ='$cod_muni',
		FONECONTATO          ='$txtcontato',
		FONECELULAR          ='$txtCelular',
		EMAIL			      ='$txtEmail',
		OBS                  ='$txtobs',
		n_certidao_novo      ='$txtcertidaonovo',
		dtemissao_certidao   ='$dtemissao_certidao',
		foto                 ='$imagem_g',
        responsavel           ='$txtresponsavel',
        grau_parentesco       ='$selectgrauparente',
        rgresponsavel         ='$txtRGresp',
        orgaoexpresp          ='$txtOrgaoExpresp',
        dtemissaorgresp       ='$txtdtemissaorgresp',
        cpfresp               ='$cpfresp',
        status                 ='1',
        inep                  ='$inep',
        tipo_necessidade       ='$selecttipo_necessidade',
        bolsa_familia          ='$selectbosaf',
        deficiente             ='$selectdeficiente',
        sus                    = '$nsus',
        transporte             ='$selecttransporte',
        car_raca               ='$selectcorraca',
        n_bolsa_fam            = '$nbolsa',
        filiacao               = '$filiacao',
        id_nacional             ='$idnacional',
        acesso_portal           ='$selectacesso',

        orgaoexp_aluno    ='$txtOrgaoExpaluno',
        dtemissaorg_aluno ='$txtdtemissaorgaluno',
        rg_aluno          ='$txtRGaluno',
        cpf_aluno         ='$cpfaluno',
        dt_matricula      ='$txtdt_matricula',


        pais_estrangeiro  =     '$txtpaisestrangeiro',
        estado_estrangeiro=     '$txtestadoestrangeiro',
        municipio_estrangeiro = '$txtmunicipioestrangeiro',
        nacionalidade         = '$txtnacionalidade',
            usuario		            = '$cpf'
            where                id='$id'";
    }
  else
    {

/*        echo    "$txtpaisestrangeiro";
        echo    "$txtestadoestrangeiro";
        echo    "$txtmunicipioestrangeiro";
        echo    "$txtnacionalidade";
*/


      $sql = "update aluno set
		nome                  ='$txtnaluno',
		dt_nascimento         ='$txtdtnascimento',
		sexo                  ='$selectsexo',
		termo_certidao        ='$txtcertidao',
		folha_certidao        ='$txtfolha',
       	livro_certidao        ='$txtlivro',
		uf_nascimento   	  ='$cod_estado',
		muni_nascimento		  ='$cod_cidades',
		nome_pai	          ='$txtpai',
		RG_PAI                ='$txtRGpai',
		ORGEXPRG_PAI          ='$txtOrgaoExppai',
		DTRG_PAI              ='$txtdtemissaorgpai',
		CPF                   ='$cpfpai',
		nome_mae			  ='$txtmae',
		RG_MAE                ='$txtRGmae',
		ORGEXPRG_MAE		  ='$txtOrgaoExpmae',
		DTRG_MAE	          ='$txtdtemissaorgmae',
        CPF_MAE                ='$cpfmae',
		endereco             ='$txtEndereco',
		bairro               ='$txtBairro',
		numero               ='$txtnr',
		cep			         ='$txtcep',
		complemento          ='$txtcomplemento',
		cidade               ='$cod_muni',
		FONECONTATO          ='$txtcontato',
		FONECELULAR          ='$txtCelular',
		EMAIL			      ='$txtEmail',
		OBS                  ='$txtobs',
		n_certidao_novo      ='$txtcertidaonovo',
		dtemissao_certidao   ='$dtemissao_certidao',
        responsavel           ='$txtresponsavel',
        grau_parentesco       ='$selectgrauparente',
        rgresponsavel         ='$txtRGresp',
        orgaoexpresp          ='$txtOrgaoExpresp',
        dtemissaorgresp       ='$txtdtemissaorgresp',
        cpfresp               ='$cpfresp',
        status                 ='1',
        inep                  ='$inep',
        tipo_necessidade       ='$selecttipo_necessidade',
        bolsa_familia          ='$selectbosaf',
        deficiente             ='$selectdeficiente',

        sus                    = '$nsus',
        transporte             ='$selecttransporte',
        car_raca               ='$selectcorraca',
        n_bolsa_fam            = '$nbolsa',
        filiacao               = '$filiacao',
        id_nacional             ='$idnacional',
        acesso_portal           ='$selectacesso',

        orgaoexp_aluno    ='$txtOrgaoExpaluno',
        dtemissaorg_aluno ='$txtdtemissaorgaluno',
        rg_aluno          ='$txtRGaluno',
        cpf_aluno         ='$cpfaluno',
        dt_matricula      ='$txtdt_matricula',
        senha_acesso      ='$senha_acesso',

        pais_estrangeiro  =     '$txtpaisestrangeiro',
        estado_estrangeiro=     '$txtestadoestrangeiro',
        municipio_estrangeiro = '$txtmunicipioestrangeiro',
        nacionalidade         = '$txtnacionalidade',


            usuario		            = '$cpf'
            where                id='$id'";
    }

  }


if(@mysql_query($sql))
{
// if(mysql_affected_rows() == 1)
   {

/****************************************************************************************************************************************/


                    $sql_movimenta = "select * from movimenta_aluno where id_aluno = '$id'
                    and  inep =  '$inep' and dt_situacao = '$txtdt_matricula' ";
                    $resultado_movimenta=mysql_query($sql_movimenta) or die (mysql_error());
                    $linhas_movimenta=mysql_num_rows($resultado_movimenta);
                     if ($linhas_movimenta <= 0)
                        {


                            $sql_mov_aluno = "insert into movimenta_aluno (id_aluno,id_movimento,id_turmaaluno,obs,data,usuario,dt_situacao,inep,id_status)
                             values ('$id','1','0','MATRICULADO','$data2','$cpf','$txtdt_matricula','$inep','1')";
                        }
                    else
                      {
                            $sql_mov_aluno = "update  movimenta_aluno  set id_turmaaluno = '0'
                                              ,usuario = '$cpf'
                                              , data ='$data2'
                                               where id_aluno = '$id' and  inep =  '$inep' and dt_situacao = '$txtdt_matricula' ";

                      }
                           if(@mysql_query($sql_mov_aluno))
                              {
                               $success = mysql_affected_rows();
                                 if($success ==true)
                                    {
                                    }
                              }
                         else
                                {
                                  //verifico se nao estao tentando gravar um dado que ja existe, pois usei UNIQUE na tabela
                                    if(mysql_errno() == 1062)
                                    		  {
                                                        echo $erros[mysql_errno()];
                                                                        exit;
                                              }
                                         else
                                             {
                                                       echo "Erro nao foi possivel efetuar atualiza��o do aluno";
                                                        exit;
                                             }
                                              @mysql_close();
                                    }



/***************************************************************************************************************************************/


      echo "<html><head><title>Resposta !!!</title></head>";
      echo "<body background=\"background_mensagens.jpg\" style=\"background-attachment:fixed; background-repeat:no-repeat\">";
      echo "<br><br><br>";
      echo "<center><img src=\"faleconosco/atencao.gif\" alt=\"\"><p><font color=\"#ff6600\" face=\"Verdana\" size=\"4\">Dados Alterado Com Sucesso.! <b></b></font></center>";
      echo "<br><br><center><a href=\"form_pesquisa_aluno_turma.php\"><img src=\"faleconosco/button_voltar2_.gif\" alt=\"Voltar\" border=\"0\" /></a></center>";
      echo "</body></html>";



// *******Arquivo de log********************************************************
                  $datalog=date("d-m-Y-H:i:s");
                  $fp = fopen("log/logs.txt", "a",0);
                 // Escreve "exemplo de escrita" no bloco1.txt
                 $assunto="alteracao de dados do aluno - altera_dados";
                 $escreve = fwrite($fp, "$cpf,$login,$inep,$nte,$ntelogin,$assunto,$datalog.\r\n");
                 // Fecha o arquivo
                    fclose($fp);


      exit;
     }
    }
 else 
    {
        //verifico se nao estao tentando gravar um dado que ja existe, pois usei UNIQUE na tabela 
        if(mysql_errno() == 1062) 
		  {
                echo $erros[mysql_errno()];
                exit;
          } 
		  else 
		  {        
                echo "Erro nao foi possivel efetuar o cadastro";
                exit;
          }       
        @mysql_close();
     }
}
else
{
echo "<html><head><title>Resposta !!!</title></head>";
echo "<body background=\"background_mensagens.jpg\" style=\"background-attachment:fixed; background-repeat:no-repeat\">";
echo "<br><br><br>";
echo "<center><img src=\"faleconosco/atencao.gif\" alt=\"\"><p><font color=\"#ff6600\" face=\"Verdana\" size=\"4\">Aluno n�o localizado.!!!! <b></b></font></center>";
echo "<br><br><center><a href=\"form_pesquisa_aluno_turma.php\"><img src=\"faleconosco/button_voltar2_.gif\" alt=\"Voltar\" border=\"0\" /></a></center>";
echo "</body></html>";
 }
}//if



function upImagemBig($tam,$arquivo,$largura,$altura_crop){
	$dir = "fotos/";

	// ler extensão de arquivo
	preg_match("/\.(gif|png|jpg|jpeg|JPG|JPEG){1}$/i", $arquivo["name"], $ext);

	if(eregi("png|jpg|jpeg|JPG|JPEG",$ext[1])){
		// Renomear arquivo para evitar quebras
		$file_nome = md5(uniqid(time())) ."-".$tam. "." . $ext[1];

		$imagem=$dir.$file_nome;
		//caminho com nome da imagem e local para guardar

		if(move_uploaded_file($_FILES['imagem']['tmp_name'],$imagem))//copy(,$imagem))
		//aqui nada especial so movo a tmp_name dando caminho

		redCropImagemBig($tam,$arquivo,$largura,$altura_crop,$imagem,$file_nome,$ext[1]);

		return $file_nome;
					}
		else
		{
		echo "G. Formato de imagem n&atilde;o suportado!"; exit();
			}
}



function redCropImagemBig($tam,$arquivo,$largura,$altura_crop,$imagem,$file_nome,$ext){
	// Pega as dimensões
	$imagesize = getimagesize($imagem);

	//regra de 3
	$largura_original = $imagesize[0]; // 0 será a largura.
	$altura_original = $imagesize[1]; // 1 será a altura.

	if($tam=='g'){$altura = ($altura_original*$largura)/$largura_original;}
	if($tam=='t'){$altura=$altura_crop;}
	if($tam=='in'){$altura=$altura_crop;}

	//criamos uma nova imagem ( que vai ser a redimensionada) a partir da imagem original
	//$imagem_orig = imagecreatefromjpeg($imagem);
	if($ext == "jpg" || $ext == "jpeg" || $ext == "JPEG" || $ext == "JPG") {
		$imagem_orig = imagecreatefromjpeg($imagem);
		}
	elseif ($ext == "png") {
		$imagem_orig = imagecreatefrompng($imagem);
		}
	if(!$imagem_orig) {
		echo("Erro ao carregar a imagem, talvez formato nao suportado");
		return false;
		exit;
	}

	//pegamos a altura e a largura da imagem original
	$pontox = imagesx($imagem_orig);
	$pontoy = imagesy($imagem_orig);

	//criamos a imagem redimensionada com a funcao imagecreatetruecolor para suportar um grande numero de cores
	$imagem_fin = imagecreatetruecolor($largura, $altura);

	//copiamos o conteudo da imagem original e passamos para o espaco reservado a redimencao
	imagecopyresampled($imagem_fin, $imagem_orig, 0, 0, 0, 0, $largura+1, $altura+1, $pontox, $pontoy);

	//salva a imagem
	//imagejpeg($imagem_fin, $imagem,100);
	if($ext == "jpg" || $ext == "jpeg" || $ext == "JPEG" || $ext == "JPG") {
		imagejpeg($imagem_fin, $imagem,100);
		return true;
		}
	elseif ($ext == "png") {
		imagepng($imagem_fin, $imagem);
		return true;
		}
	else {
		echo("Formato de arquivo nao suportado");
		return false;
	}

	#crop
	$LIMG=$largura;
	$AIMG=$altura_crop;
	$g_srcfile=$imagem;

	if(file_exists($g_srcfile)) {

	   $g_is = getimagesize($g_srcfile);

		$g_ih=$AIMG;
		$g_iw=($g_ih/$g_is[1])*$g_is[0];

		if($LIMG>$g_iw){
		   $g_iw=$LIMG;
		  $g_ih=($LIMG/$g_is[0])*$g_is[1];
		}

		// se a largura redimensionada($g_iw)  for
		// maior ou igual a altura redimensionada($g_ih)
		if($g_iw>=$g_ih){
		   $scr_x=0;
		   $src_y=0;
		}else{
		   $scr_x=0;
		   $src_y=0;
		}

	   $img_src=imagecreatefromjpeg($g_srcfile);
	   $img_dst=imagecreatetruecolor($LIMG, $AIMG);
	   imagecopyresampled($img_dst, $img_src, 0, 0, $scr_x, $src_y, $g_iw, $g_ih, $g_is[0], $g_is[1]);

	   //imagejpeg($img_dst,$imagem);
	    if($ext == "jpg" || $ext == "jpeg" || $ext == "JPEG" || $ext == "JPG") {
		imagejpeg($img_dst,$imagem,100);
		return true;
		}
		elseif ($ext == "gif") {
			imagepng($img_dst,$imagem);
			return true;
			}
		elseif ($ext == "png") {
			imagepng($img_dst,$imagem);
			return true;
			}
		else {
			echo("Formato de arquivo nao suportado");
			return false;
		}
	   imagedestroy($img_dst);
	   //libera a memoria
		imagedestroy ($imagem_orig);
		imagedestroy ($imagem_fin);

	}
}

function redCropImagemT($tam,$arquivo,$largura,$altura_crop,$imagem,$file_nome,$ext){


	#crop
	$LIMG=$largura;
	$AIMG=$altura_crop;
	$g_srcfile=$imagem;

	if(file_exists($g_srcfile)) {

	   $g_is = getimagesize($g_srcfile);

		$g_ih=$AIMG;
		$g_iw=($g_ih/$g_is[1])*$g_is[0];

		if($LIMG>$g_iw){
		   $g_iw=$LIMG;
		  $g_ih=($LIMG/$g_is[0])*$g_is[1];
		}

		// se a largura redimensionada($g_iw)  for
		// maior ou igual a altura redimensionada($g_ih)
		if($g_iw>=$g_ih){
		   $scr_x=0;
		   $src_y=0;
		}else{
		   $scr_x=0;
		   $src_y=0;
		}

	   $img_src=imagecreatefromjpeg($g_srcfile);
	   $img_dst=imagecreatetruecolor($LIMG, $AIMG);
	   imagecopyresampled($img_dst, $img_src, 0, 0, $scr_x, $src_y, $g_iw, $g_ih, $g_is[0], $g_is[1]);

	   //imagejpeg($img_dst,$imagem);
	    if($ext == "jpg" || $ext == "jpeg" || $ext == "JPEG" || $ext == "JPG") {
		imagejpeg($img_dst,$imagem,100);
		return true;
		}
		elseif ($ext == "gif") {
			imagepng($img_dst,$imagem);
			return true;
			}
		elseif ($ext == "png") {
			imagepng($img_dst,$imagem);
			return true;
			}
		else {
			echo("Formato de arquivo nao suportado");
			return false;
		}
	   imagedestroy($img_dst);
	   //libera a memoria
		imagedestroy ($imagem_orig);
		imagedestroy ($imagem_fin);

	}
}



?>



