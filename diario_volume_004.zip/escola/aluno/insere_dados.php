<?php
require_once '../../start.php';
$pdo = new Conexao;

if ($_SERVER["REQUEST_METHOD"] != "POST") {
    redirect('escola/aluno/form_inclusao_aluno.php');
}

if ($_POST['selectacesso'] == 'S' && empty($_POST['txtresponsavel']) || empty($_POST['cpfresp'])) {
    Notification::warning('Para acesso ao portal os dados de respons�vel s�o obrigat�rios.');
    redirectBack();
}

try {
  $_POST['txtnaluno'] = limpaNome($_POST['txtnaluno']);
  $_POST['txtpai'] = isset($_POST['txtpai']) ? limpaNome($_POST['txtpai']) : '';
  $_POST['txtmae'] = isset($_POST['txtmae']) ? limpaNome($_POST['txtmae']) : '';

  $data = date('Y.m.d');
  $datahora = date('Y.m.d H:i:s');
  $anoLetivo = date('Y');
  $dataNascimento = $_POST['txtdtnascimento'];
  $dataNascimentoConvertido = converteData($_POST['txtdtnascimento']);

  $sql = "SELECT COUNT(*) FROM aluno
          WHERE nome = :txtnaluno
          AND dt_nascimento = :txtdtnascimento ";
  if (!empty($_POST['txtmae'])) {
    $sql .= " AND nome_mae = :txtmae ";
  }
  if (!empty($_POST['cpf_aluno'])) {
    $sql .= " OR cpf_aluno = :cpf_aluno";
  }

  $sth = $pdo->prepare($sql);
  $sth->bindParam(':txtnaluno', $_POST['txtnaluno']);
  $sth->bindParam(':txtdtnascimento', $dataNascimentoConvertido);
  if (!empty($_POST['txtmae'])) {
    $sth->bindParam(':txtmae', $_POST['txtmae']);
  }
  if (!empty($_POST['cpf_aluno'])) {
    $sth->bindParam(':cpf_aluno', $_POST['cpfaluno']);
  }

  $countAluno = $sth->execute() ? $sth->fetchColumn() : 0;

  if ($countAluno > 0) {
    Notification::warning("J� existe o estudante <b>{$_POST['txtnaluno']}</b> com data de nascimento <b>{$_POST['txtdtnascimento']}</b> cadastrado.");
    redirectBack();
  }

  if (isset($_POST['txtturma'])) {
    $sql = "SELECT t_vagas FROM vagaschamadaescolar
            WHERE id = :id_vagaschamadaescolar;";
    $sth = $pdo->prepare($sql);
    $sth->bindParam(':id_vagaschamadaescolar', $_POST['txtturma']);
    $totalVagas = $sth->execute() ? $sth->fetchColumn() : 0;

    if ($totalVagas < 1) {
      Notification::error('N�o h� vagas para a turma selecionada.');
      redirectBack();
    }
  }

  $_POST['txtdtemissaorgpai'] = isset($_POST['txtdtemissaorgpai']) ? converteData($_POST['txtdtemissaorgpai']) : null;
  $_POST['txtdtemissaorgmae'] = isset($_POST['txtdtemissaorgmae']) ? converteData($_POST['txtdtemissaorgmae']) : null;
  $_POST['txtdtemissaorgresp'] = isset($_POST['txtdtemissaorgresp']) ? converteData($_POST['txtdtemissaorgresp']) : null;
  $_POST['txtdtnascimento'] = converteData($_POST['txtdtnascimento']);
  $_POST['txtdt_matricula'] = converteData($_POST['txtdt_matricula']);
  $_POST['dtemissao_certidao'] = converteData($_POST['dtemissao_certidao']);
  $_POST['txtdtemissaorgaluno'] = converteData($_POST['txtdtemissaorgaluno']);
  $_POST['equipamento_data_recebimento'] = empty($_POST['equipamento_data_recebimento']) ? null : converteData($_POST['equipamento_data_recebimento']);
  $_POST['equipamento_data_devolucao'] = empty($_POST['equipamento_data_devolucao']) ? null : converteData($_POST['equipamento_data_devolucao']);

  if (isset($_FILES) && isset($_FILES["imagem"]) && $_FILES['imagem']['size'] > 0) {
    $imagem_g = upImagemBig("g", $_FILES["imagem"], 280, 320);
  } else {
    $imagem_g = null;
  }

  $senhaAcesso = md5($_POST['cpfresp']);

  $sql = "INSERT INTO aluno(nome,dt_nascimento,sexo,mod_certidao,termo_certidao,folha_certidao,livro_certidao,uf_nascimento,muni_nascimento,
          nome_pai,rg_pai,orgexprg_pai,dtrg_pai,cpf,nome_mae,rg_mae,orgexprg_mae,dtrg_mae,cpf_mae,endereco,bairro,numero,cep,
          complemento,cidade,fonecontato,fonecelular,email,obs,n_certidao_novo,dtemissao_certidao,foto,inep,usuario,responsavel,
          grau_parentesco,rgresponsavel,orgaoexpresp,dtemissaorgresp,cpfresp,status,tipo_necessidade,bolsa_familia,deficiente,
          car_raca,n_bolsa_fam,filiacao,id_nacional,sus,transporte,acesso_portal,orgaoexp_aluno,dtemissaorg_aluno,rg_aluno,
          cpf_aluno,dt_matricula,senha_acesso,nacionalidade,pais_estrangeiro,estado_estrangeiro,municipio_estrangeiro,equipamento_programa,
          equipamento_nu_tombamento, equipamento_nu_serie, equipamento_chave_office, equipamento_data_recebimento, equipamento_data_devolucao, equipamento_obs,
          certidao_casamento)
          VALUES (UPPER(:txtnaluno),:txtdtnascimento,:selectsexo,:selecttp_certidao,:txtcertidao,:txtfolha,:txtlivro,:cod_estado,:cod_cidades,
          UPPER(:txtpai),:txtRGpai,UPPER(:txtOrgaoExppai),:txtdtemissaorgpai,:cpfpai,UPPER(:txtmae),:txtRGmae,UPPER(:txtOrgaoExpmae),
          :txtdtemissaorgmae,:cpfmae,UPPER(:txtEndereco),UPPER(:txtBairro),UPPER(:txtnr),:txtcep,UPPER(:txtcomplemento),:cod_muni,
          :txtcontato,:txtCelular,:txtEmail,:txtobs,:txtcertidaonovo,:dtemissao_certidao,:imagem_g,:inep,:usuario,UPPER(:txtresponsavel),
          :selectgrauparente,:txtRGresp,UPPER(:txtOrgaoExpresp),:txtdtemissaorgresp,:cpfresp,'1',:selecttipo_necessidade,:selectbosaf,
          :selectdeficiente,:selectcorraca,:nbolsa,:filiacao,:idnacional,:nsus,:selecttransporte,:selectacesso,UPPER(:txtOrgaoExpaluno),
          :txtdtemissaorgaluno,:txtRGaluno,:cpfaluno,:txtdt_matricula,:senha_acesso,UPPER(:txtnacionalidade),UPPER(:txtpaisestrangeiro),
          UPPER(:txtestadoestrangeiro),UPPER(:txtmunicipioestrangeiro),:equipamento_programa, :equipamento_nu_tombamento, :equipamento_nu_serie,
          :equipamento_chave_office, :equipamento_data_recebimento, :equipamento_data_devolucao, :equipamento_obs,:txtcertidaocasamento);";

  $sth = $pdo->prepare($sql);
  $sth->bindParam(':txtnaluno', $_POST['txtnaluno']);
  $sth->bindParam(':selectdeficiente', $_POST['selectdeficiente']);
  $sth->bindParam(':selectcorraca', $_POST['selectcorraca']);
  $sth->bindParam(':nbolsa', $_POST['nbolsa']);
  $sth->bindParam(':filiacao', $_POST['filiacao']);
  $sth->bindParam(':idnacional', $_POST['idnacional']);
  $sth->bindParam(':nsus', $_POST['nsus']);
  $sth->bindParam(':selecttransporte', $_POST['selecttransporte']);
  $sth->bindParam(':selectacesso', $_POST['selectacesso']);
  $sth->bindParam(':txtOrgaoExpaluno', $_POST['txtOrgaoExpaluno']);
  $sth->bindParam(':txtdtnascimento', $_POST['txtdtnascimento']);
  $sth->bindParam(':selectsexo', $_POST['selectsexo']);
  $sth->bindParam(':selecttp_certidao', $_POST['selecttp_certidao']);
  $sth->bindParam(':txtcertidao', $_POST['txtcertidao']);
  $sth->bindParam(':txtfolha', $_POST['txtfolha']);
  $sth->bindParam(':txtlivro', $_POST['txtlivro']);
  $sth->bindParam(':cod_estado', $_POST['cod_estado']);
  $sth->bindParam(':cod_cidades', $_POST['cod_cidades']);
  $sth->bindParam(':txtpai', $_POST['txtpai']);
  $sth->bindParam(':txtRGpai', $_POST['txtRGpai']);
  $sth->bindParam(':txtOrgaoExppai', $_POST['txtOrgaoExppai']);
  $sth->bindParam(':txtdtemissaorgpai', $_POST['txtdtemissaorgpai']);
  $sth->bindParam(':cpfpai', $_POST['cpfpai']);
  $sth->bindParam(':txtmae', $_POST['txtmae']);
  $sth->bindParam(':txtRGmae', $_POST['txtRGmae']);
  $sth->bindParam(':txtOrgaoExpmae', $_POST['txtOrgaoExpmae']);
  $sth->bindParam(':txtdtemissaorgmae', $_POST['txtdtemissaorgmae']);
  $sth->bindParam(':cpfmae', $_POST['cpfmae']);
  $sth->bindParam(':txtEndereco', $_POST['txtEndereco']);
  $sth->bindParam(':txtBairro', $_POST['txtBairro']);
  $sth->bindParam(':txtnr', $_POST['txtnr']);
  $sth->bindParam(':txtcep', $_POST['txtcep']);
  $sth->bindParam(':txtcomplemento', $_POST['txtcomplemento']);
  $sth->bindParam(':cod_muni', $_POST['cod_muni']);
  $sth->bindParam(':txtcontato', $_POST['txtcontato']);
  $sth->bindParam(':txtCelular', $_POST['txtCelular']);
  $sth->bindParam(':txtEmail', $_POST['txtEmail']);
  $sth->bindParam(':txtobs', $_POST['txtobs']);
  $sth->bindParam(':txtcertidaonovo', $_POST['txtcertidaonovo']);
  $sth->bindParam(':dtemissao_certidao', $_POST['dtemissao_certidao']);
  $sth->bindParam(':imagem_g', $imagem_g);
  $sth->bindParam(':inep', $inep);
  $sth->bindParam(':usuario', $cpf);
  $sth->bindParam(':txtresponsavel', $_POST['txtresponsavel']);
  $sth->bindParam(':selectgrauparente', $_POST['selectgrauparente']);
  $sth->bindParam(':txtRGresp', $_POST['txtRGresp']);
  $sth->bindParam(':txtOrgaoExpresp', $_POST['txtOrgaoExpresp']);
  $sth->bindParam(':txtdtemissaorgresp', $_POST['txtdtemissaorgresp']);
  $sth->bindParam(':cpfresp', $_POST['cpfresp']);
  $sth->bindParam(':selecttipo_necessidade', $_POST['selecttipo_necessidade']);
  $sth->bindParam(':selectbosaf', $_POST['selectbosaf']);
  $sth->bindParam(':txtdtemissaorgaluno', $_POST['txtdtemissaorgaluno']);
  $sth->bindParam(':txtRGaluno', $_POST['txtRGaluno']);
  $sth->bindParam(':cpfaluno', $_POST['cpfaluno']);
  $sth->bindParam(':txtdt_matricula', $_POST['txtdt_matricula']);
  $sth->bindParam(':senha_acesso', $senhaAcesso);
  $sth->bindParam(':txtnacionalidade', $_POST['txtnacionalidade']);
  $sth->bindParam(':txtpaisestrangeiro', $_POST['txtpaisestrangeiro']);
  $sth->bindParam(':txtestadoestrangeiro', $_POST['txtestadoestrangeiro']);
  $sth->bindParam(':txtmunicipioestrangeiro', $_POST['txtmunicipioestrangeiro']);
  $sth->bindParam(':equipamento_programa', $_POST['equipamento_programa']);
  $sth->bindParam(':equipamento_nu_tombamento', $_POST['equipamento_nu_tombamento']);
  $sth->bindParam(':equipamento_chave_office', $_POST['equipamento_chave_office']);
  $sth->bindParam(':equipamento_nu_serie', $_POST['equipamento_nu_serie']);
  $sth->bindParam(':equipamento_data_recebimento', $_POST['equipamento_data_recebimento']);
  $sth->bindParam(':equipamento_data_devolucao', $_POST['equipamento_data_devolucao']);
  $sth->bindParam(':equipamento_obs', $_POST['equipamento_obs']);
  $sth->bindParam(':txtcertidaocasamento', $_POST['txtcertidaocasamento']);

  if ($sth->execute()) {

    $id_aluno = $pdo->lastInsertId();

    $sql = "INSERT INTO movimenta_aluno (id_aluno,id_movimento,id_turmaaluno,obs,data,usuario,dt_situacao,inep,id_status)
            VALUES (:id_aluno,'1','0','MATRICULADO',:data,:cpf,:txtdt_matricula,:inep,'1');";
    $sth = $pdo->prepare($sql);
    $sth->bindParam(':cpf', $cpf);
    $sth->bindParam(':data', $data);
    $sth->bindParam(':inep', $inep);
    $sth->bindParam(':id_aluno', $id_aluno);
    $sth->bindParam(':txtdt_matricula', $_POST['txtdt_matricula']);

    if (!$sth->execute()) {
      Notification::warning('Erro ao inserir movimenta��o de estudante.');
      redirectBack();
    }

    if (isset($_POST['txtturma'])) {

      $sql = "INSERT INTO aluno_chamadaescolar(id_aluno,id_cha_escolar,ano,distorcao,usuario,inep,dt_matricula,datahora)
              VALUES (:id_aluno, :txtturma, :ano, :distorcao, :usuario, :inep, :data,:datahora);";
      $sth = $pdo->prepare($sql);
      $sth->bindParam(':ano', $anoLetivo);
      $sth->bindParam(':id_aluno', $id_aluno);
      $sth->bindParam(':inep', $inep);
      $sth->bindParam(':data', $data);
      $sth->bindParam(':datahora', $datahora);
      $sth->bindParam(':usuario', $cpf);
      $sth->bindParam(':distorcao', $_POST['distorcao']);
      $sth->bindParam(':txtturma', $_POST['txtturma']);

      if (!$sth->execute()) {
        Notification::warning('Erro ao inserir estudante na chamada escolar.');
        redirectBack();
      }

      $sql = "UPDATE vagaschamadaescolar
              SET t_vagas = t_vagas-1
              WHERE id = :txtturma;";
      $sth = $pdo->prepare($sql);
      $sth->bindParam(':txtturma', $_POST['txtturma']);

      if (!$sth->execute()) {
        Notification::warning('Erro ao diminuir vagas de chamada escolar.');
        redirectBack();
      }
    }

    redirect("escola/nota/rel_ficha_matricula.php?codigo={$id_aluno}");
  } else {
    Notification::error('N�o foi poss�vel cadastrar estudante.');
  }
} catch (Exception $e) {
  Notification::ex($e);
}

redirectBack();