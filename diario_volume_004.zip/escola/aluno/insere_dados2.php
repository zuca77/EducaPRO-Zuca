<?
session_start();

if (isset($_SESSION["login_usuario"]))
  {
   // session_cache_expire(1);
	 $login     =  $_SESSION["login_usuario"];
     $nte       =  $_SESSION["nivel_usuario"];
	 $inep      =  $_SESSION["inep_usuario"] ;
     $ntelogin  =  $_SESSION["nte_login"];
     $cpf       = $_SESSION["cpf_usuario"];

	 include ("../funcoes.php");
     echo  saudacoes()."   ". "$login" ."  -  ". $nte."  ".dataextenso()." ".$inep;

  }
 else
  {
     		 header("../../Location: login.php");
  }



if(file_exists("../../conexao_mysql.php"))
{
        require "../../conexao_mysql.php";

} else
{
        echo "Conex�o nao foi encontrado";
        exit;
}






include ("../../conexao_mysql.php");

if(file_exists("../../conexao_mysql.php"))
{
        require "../../conexao_mysql.php";

} else
{
        echo "Conex�o nao foi encontrado";
        exit;
}



if ($_POST['cadastrar'])
//if($_SERVER["REQUEST_METHOD"] == "POST")
{

$cod_estado          = $_POST['cod_estado'];
$cod_cidades         = $_POST['cod_cidades'];
$cod_muni            = $_POST['cod_muni'];
$cpfpai                 = $_POST['cpfpai'];
$cpf                 = $_POST['cpf'];
$selectsexo	         = $_POST['selectsexo'];
$txtBairro           = $_POST['txtBairro'];
$txtCelular          = $_POST['txtCelular'];
$txtEmail            = $_POST['txtEmail'];
$txtEndereco         = $_POST['txtEndereco'];
$txtOrgaoExpmae      = $_POST['txtOrgaoExpmae'];
$txtOrgaoExppai      = $_POST['txtOrgaoExppai'];
$txtRGpai            = $_POST['txtRGpai'];
$txtRGmae            = $_POST['txtRGmae'];
$txtcep              = $_POST['txtcep'];
$txtcertidaonovo    = $_POST['txtcertidaonovo'];
$txtcertidao         = $_POST['txtcertidao'];
$txtcomplemento      = $_POST['txtcomplemento'];
$txtcontato          = $_POST['txtcontato'];
$txtfolha            = $_POST['txtfolha'];
$txtlivro            = $_POST['txtlivro'];
$txtnaluno           = $_POST['txtnaluno'];
$txtnr             = $_POST['txtnr'];
$txtobs            = $_POST['txtobs'];
$txtturma	         = $_POST['txtturma'];
$txtdtnascimento     = $_POST['txtdtnascimento'];
$txtmae              = $_POST['txtmae'];
$txtpai              = $_POST['txtpai'];
$txtdtemissaorgpai   = $_POST['txtdtemissaorgpai'];

$dtemissao_certidao  = $_POST['dtemissao_certidao'];
$txtdtemissaorgmae   = $_POST['txtdtemissaorgmae'];

$txtdtnascimentoi     = $_POST['txtdtnascimento'];


$txtresponsavel         = $_POST['txtresponsavel'];
$selectgrauparente      = $_POST['selectgrauparente'];
$txtRGresp              = $_POST['txtRGresp'];
$txtOrgaoExpresp        = $_POST['txtOrgaoExpresp'];
$txtdtemissaorgresp     = $_POST['txtdtemissaorgresp'];
$cpfresp                = $_POST['cpf'];


$selectbosaf             = $_POST['selectbosaf'];
$selecttipo_necessidade  = $_POST['selecttipo_necessidade'];
$selectdeficiente         = $_POST['selectdeficiente'];



$selectcorraca            = $_POST['selectcorraca'];
$nbolsa                   = $_POST['nbolsa'];
$filiacao                 = $_POST['filiacao'];
$idnacional              = $_POST['idnacional'];

$nsus                          = $_POST['nsus'];
$selecttransporte              = $_POST['selecttransporte'];
$selectacesso                  = $_POST['selectacesso'];


$senha_acesso                = md5($_POST['cpf']);




$txtdt_matricula      = $_POST['txtdt_matricula'];
$cpfaluno             = $_POST['cpfaluno'];
$txtRGaluno           = $_POST['txtRGaluno'];
$txtdtemissaorgaluno  = $_POST['txtdtemissaorgaluno'];
$txtOrgaoExpaluno     = $_POST['txtOrgaoExpaluno'];













$foto           = $_FILES["imagem"];
/*Tratamento  Foto*/
$arquivo_g = isset($_FILES["imagem"]) ? $_FILES["imagem"] : FALSE;if($_FILES["imagem"]==''){echo '<script>confirm("Noticia sem imagem?")</script>';}

$arquivo_g = isset($_FILES["imagem"]) ? $_FILES["imagem"] : FALSE;if($_FILES["imagem"]=='')
   {echo '<script>confirm("Noticia sem imagem?")</script>';}
	if ($arquivo_g['name'] == '')
    {
		$imagem_g = 'null';
 	}
			else
	{
			$largura=370;$altura=260;
			$imagem_g = upImagemBig("g",$arquivo_g,370,260);
	}








/*tratamento das datas*************************************************************/


$diai = substr($txtdtemissaorgresp, 0,2);
$anoi = substr($txtdtemissaorgresp, -4);
$mesi = substr($txtdtemissaorgresp, -7,2);
$txtdtemissaorgresp = $anoi.".".$mesi.".".$diai;
if ($txtdtemissaorgresp== '..')
     $txtdtemissaorgresp = '0000.00.00';



$diai = substr($dtemissao_certidao, 0,2);
$anoi = substr($dtemissao_certidao, -4);
$mesi = substr($dtemissao_certidao, -7,2);
$dtemissao_certidao=$anoi.".".$mesi.".".$diai;
if ($dtemissao_certidao== '..')
     $dtemissao_certidao = '0000.00.00';




$diai = substr($txtdtnascimento, 0,2);
$anoi = substr($txtdtnascimento, -4);
$mesi = substr($txtdtnascimento, -7,2);
$txtdtnascimento=$anoi.".".$mesi.".".$diai;

if ($txtdtnascimento== '..')
     $txtdtnascimento = '0000.00.00';


$diaf = substr($txtdtemissaorgpai, 0,2);
$anof = substr($txtdtemissaorgpai, -4);
$mesf = substr($txtdtemissaorgpai, -7,2);
$txtdtemissaorgpai=$anof.".".$mesf.".".$diaf;

if ($txtdtemissaorgpai== '..')
     $txtdtemissaorgpai = '0000.00.00';

$diaret = substr($txtdtemissaorgmae, 0,2);
$anoret = substr($txtdtemissaorgmae, -4);
$mesret = substr($txtdtemissaorgmae, -7,2);
$txtdtemissaorgmae=$anoret.".".$mesret.".".$diaret;

if ($txtdtemissaorgmae== '..')
     $txtdtemissaorgmae = '0000.00.00';



$diaret = substr($txtdt_matricula, 0,2);
$anoret = substr($txtdt_matricula, -4);
$mesret = substr($txtdt_matricula, -7,2);
$txtdt_matricula  =$anoret.".".$mesret.".".$diaret;

if ($txtdt_matricula== '..')
     $txtdt_matricula = '0000.00.00';


$diaret = substr($txtdtemissaorgaluno, 0,2);
$anoret = substr($txtdtemissaorgaluno, -4);
$mesret = substr($txtdtemissaorgaluno, -7,2);
$txtdtemissaorgaluno  =$anoret.".".$mesret.".".$diaret;


if ($txtdtemissaorgaluno== '..')
     $txtdtemissaorgaluno = '0000.00.00';





$dia = date('d');
$mes = date('m');
$ano = date('Y');
$data =$dia.".".$mes.".".$ano;
$data1 =$dia.".".$mes.".".$ano;
$data2 =$ano.".".$mes.".".$dia;



/*****************************************************************/
$sql="select * from  aluno where nome = '$txtnaluno' and NOME_PAI='$txtpai' and NOME_MAE = '$txtmae' and responsavel =  '$txtresponsavel'";$resultado=mysql_query($sql) or die (mysql_error());
$linhas=mysql_num_rows($resultado);
if ($linhas>0)
 {

    echo "<html><head><title>Resposta !!!</title></head>";
    echo "<body background=\"background_mensagens.jpg\" style=\"background-attachment:fixed; background-repeat:no-repeat\">";
    echo "<br><br><br>";
    echo "<center><img src=\"faleconosco/atencao.gif\" alt=\"\"><p><font color=\"#FF0000\" face=\"Verdana\" size=\"4\"><blink>Aluno j� Cadastrado - Click em Voltar.!</blink> <b></b></font></center>";
    echo "<br><br><center><a href=\"form_pesquisa_aluno.php\"><img src=\"faleconosco/button_voltar2_.gif\" alt=\"Voltar\" border=\"0\" /></a></center>";
    echo "</body></html>";
    exit;
 }



$sql = "insert into aluno(nome,dt_nascimento,SEXO,termo_certidao,folha_certidao,livro_certidao,uf_nascimento,muni_nascimento,nome_pai,RG_PAI,
ORGEXPRG_PAI,DTRG_PAI,CPF,
nome_mae,RG_MAE,ORGEXPRG_MAE,DTRG_MAE,CPF_MAE,endereco,bairro,numero,cep,complemento,cidade,FONECONTATO,FONECELULAR,
EMAIL,OBS,n_certidao_novo,dtemissao_certidao,foto,inep,usuario,responsavel,grau_parentesco,rgresponsavel,orgaoexpresp,dtemissaorgresp
,cpfresp,status,
tipo_necessidade,bolsa_familia,deficiente,car_raca,n_bolsa_fam,filiacao,id_nacional,sus,transporte,acesso_portal,
orgaoexp_aluno,dtemissaorg_aluno,rg_aluno,cpf_aluno,dt_matricula,senha_acesso)
values (
'$txtnaluno','$txtdtnascimento','$selectsexo','$txtcertidao','$txtfolha','$txtlivro','$cod_estado','$cod_cidades','$txtpai','$txtRGpai',
'$txtOrgaoExppai','$txtdtemissaorgpai','$cpfpai','$txtmae','$txtRGmae','$txtOrgaoExpmae','$txtdtemissaorgmae','$cpfmae', '$txtEndereco',
'$txtBairro','$txtnr','$txtcep','$txtcomplemento','$cod_muni','$txtcontato','$txtCelular','$txtEmail','$txtobs','$txtcertidaonovo',
'$dtemissao_certidao','$imagem_g','$inep','$cpf', '$txtresponsavel','$selectgrauparente','$txtRGresp','$txtOrgaoExpresp','$txtdtemissaorgresp',
'$cpfresp','1','$selecttipo_necessidade','$selectbosaf','$selectdeficiente','$selectcorraca','$nbolsa','$filiacao','$idnacional',
'$nsus','$selecttransporte','$selectacesso','$txtOrgaoExpaluno','$txtdtemissaorgaluno','$txtRGaluno','$cpfaluno','$txtdt_matricula','$senha_acesso')";


if(@mysql_query($sql))
{
  if(mysql_affected_rows() == 1)
   {

   $sql = "select last_insert_id()";
   $resp= mysql_query($sql);
   $id  = mysql_fetch_array($resp);
   $id_aluno_mov = $id[0];


                            $sql = "insert into movimenta_aluno (id_aluno,id_movimento,id_turmaaluno,obs,data,usuario,dt_situacao,inep,id_status)
                             values ('$id_aluno_mov','1','0','Aluno Matriculado - Sem Turma','$data2','$cpf','$txtdt_matricula','$inep','1')";


                            if(@mysql_query($sql))
                              {
                               $success = mysql_affected_rows();
                                 if($success ==true)
                                    {
                                    }
                              }
                         else
                                {
                                  //verifico se nao estao tentando gravar um dado que ja existe, pois usei UNIQUE na tabela
                                    if(mysql_errno() == 1062)
                                    		  {
                                                        echo $erros[mysql_errno()];
                                                                        exit;
                                              }
                                         else
                                             {
                                                       echo "Erro nao foi possivel efetuar atualiza��o do aluno";
                                                        exit;
                                             }
                                              @mysql_close();
                                    }




/**********************************************************************************************************************************************/
  ?>
  

<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">

<script language="javascript">

function DoPrinting()
{
    if (!window.print) {
        alert("Netscape, Internet Explorer 4.0 ou superior!")
        return
    }
    window.print();
}
</script>

<head>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1" />
<title>:: Cadastro do Aluno ::</title>
<style type="text/css">
<!--
.style1 {
	font-size: large;
	font-weight: bold;
}
.style2 {
	font-size: x-large;
	font-weight: bold;
}
.style3 {
	font-size: large;
	font-family: Verdana, Arial, Helvetica, sans-serif;
}
.style5 {font-family: Verdana, Arial, Helvetica, sans-serif}
.style6 {font-size: xx-large; font-weight: bold; font-family: Verdana, Arial, Helvetica, sans-serif; }
.style7 {font-size: x-large; font-weight: bold; font-family: Verdana, Arial, Helvetica, sans-serif; }
.style8 {font-size: large; font-weight: bold; font-family: Verdana, Arial, Helvetica, sans-serif; }
-->
</style>
</head>

<body>
<div align="left">
  <table width="988" border="1" cellpadding="0" cellspacing="0" bordercolor="#000000">
    <tr>
      <td colspan="7" rowspan="4"><table width="100%" border="0" cellpadding="0" cellspacing="0">
          <tr>
            <td width="120" class="style5"><div align="center"><img src="../img/logo_brazil.jpg" width="113" height="118" /></div></td>
            <td width="706" class="style5"><p align="center" class="style2">GOVERNO DO ESTADO DE ROND�NIA<br>
			SECRETARIA DE ESTADO DE EDUCA��O - SEDUC<br>
			GERENCIA DE TECNOLOGIA DA INFORMA��O - GTI</p>
              <p align="center" class="style2"></p></td>
          </tr>
      </table></td>
      <td width="131" height="36" bgcolor="#CCCCCC"><div align="center" class="style3">DATA </div></td>
    </tr>
    <tr>
      <td height="46"><div align="center" class="style3"><span class="style5"></span><span class="style5"><? echo $data1 ?></span></div></td>
    </tr>
    <tr>
      <td height="47" bgcolor="#CCCCCC"><div align="center" class="style3">GTI</div></td>
    </tr>
    <tr>
      <td height="38" class="style3"><div align="center"><? echo $nte; ?></div></td>
    </tr>
    <tr>
      <td height="68" colspan="8" bgcolor="#999999"><div align="center" class="style7">Cadastro Aluno(a)<?echo $txtnaluno?> </div></td><br>
    </tr>

    <tr>
       <td height="49" colspan="8"><div align="left" class="style7"><span class="style8"><br />
        <img  src="fotos/<?echo $imagem_g;?>"  width='150' height='150' alt="<?echo $nome;?>"/><br>


        ID Estadual:      <?echo  $id[0]?>    <br>
        Nome:    <?echo $txtnaluno?> <br>
        Sexo:             <?echo $selectsexo?> <br>
        Nascimento:<?echo $txtdtnascimentoi?> <br>

        Certid�o Nova:         <?echo $txtcertidao?> <br>

        Certid�o:         <?echo $txtcertidao?> <br>
        Livro:            <?echo $txtlivro?> <br>
        Folha:            <?echo $txtfolha?> <br>
____________________________________________________________________________________________________<br>

        Nome da Pai:     <?echo $txtpai?> <br>
        CPF:             <?echo $cpfpai?> <br>

        Nome da M�e:     <?echo $txtmae?> <br>
        CPF:             <?echo $cpf?> <br>
____________________________________________________________________________________________________<br>


        Endere�o:          <?echo $txtEndereco?> <br>
        Bairro:            <?echo $txtBairro?> <br>
        Numero:            <?echo $txtnr?> <br>
        CEP:               <?echo $txtcep?> <br>

        Contato:           <?echo $txtcontato?> <br>
        Email:             <?echo $email?> <br>



		</div></td>
    </tr>


    <tr>
      <td height="20" colspan="8"><div align="center" class="style7">
      </td>
    </tr>

  <tr>
      <td height="2" colspan="2" bgcolor="#CCCCCC" class="style3"><div align="center" class="style5"><strong>Observa��o</strong></div>	  </td>
      <td colspan="6" bgcolor="#CCCCCC" class="style3"><div align="center" class="style5"><strong>DATA </strong></div></td>
    </tr>

    <tr>
      <td>
   <?echo  $txtobs?>
  	  </td>
  </tr>
 </table>
</div>

<tr>
<td>
&nbsp&nbsp
</td>
</tr>
<tr>
 <br/>
    <tr>
  	  <td height="2" colspan="2" bgcolor="#CCCCCC" class="style3"><div class="style5">
	  <strong><center><BR><BR>

	  <br>

	  <BR><BR><BR>
	 _________________________
	<BR>
      Secretaria
	 <BR><BR><BR>
	  </strong></div></td>
    </tr>



<td align="center">
<form>
  <input type="button"  value="Imprimir a p�gina"   onClick="DoPrinting()" />
  <input type="button" value=" Voltar " onclick="location.href='form_pesquisa_aluno.php';">
</form>
</td>
</tr>
</body>
</html>


 <?
/**********************************************************************************************************************************************/
exit;
   }

} else
   {
        //verifico se nao estao tentando gravar um dado que ja existe, pois usei UNIQUE na tabela
        if(mysql_errno() == 1062)
		  {
                echo $erros[mysql_errno()];
                exit;
          }
		  else
		  {
                echo "Erro nao foi possivel incluir o pedido";
                exit;
          }
        @mysql_close();
     }

 }//select kit

// }//post









function upImagemBig($tam,$arquivo,$largura,$altura_crop){
	$dir = "fotos/";

	// ler extensão de arquivo
	preg_match("/\.(gif|png|jpg|jpeg|JPG|JPEG){1}$/i", $arquivo["name"], $ext);

	if(eregi("png|jpg|jpeg|JPG|JPEG",$ext[1])){
		// Renomear arquivo para evitar quebras
		$file_nome = md5(uniqid(time())) ."-".$tam. "." . $ext[1];

		$imagem=$dir.$file_nome;
		//caminho com nome da imagem e local para guardar

		if(move_uploaded_file($_FILES['imagem']['tmp_name'],$imagem))//copy(,$imagem))
		//aqui nada especial so movo a tmp_name dando caminho

		redCropImagemBig($tam,$arquivo,$largura,$altura_crop,$imagem,$file_nome,$ext[1]);

		return $file_nome;
					}
		else
		{
		echo "G. Formato de imagem n&atilde;o suportado!"; exit();
			}
}



function redCropImagemBig($tam,$arquivo,$largura,$altura_crop,$imagem,$file_nome,$ext){
	// Pega as dimensões
	$imagesize = getimagesize($imagem);

	//regra de 3
	$largura_original = $imagesize[0]; // 0 será a largura.
	$altura_original = $imagesize[1]; // 1 será a altura.

	if($tam=='g'){$altura = ($altura_original*$largura)/$largura_original;}
	if($tam=='t'){$altura=$altura_crop;}
	if($tam=='in'){$altura=$altura_crop;}

	//criamos uma nova imagem ( que vai ser a redimensionada) a partir da imagem original
	//$imagem_orig = imagecreatefromjpeg($imagem);
	if($ext == "jpg" || $ext == "jpeg" || $ext == "JPEG" || $ext == "JPG") {
		$imagem_orig = imagecreatefromjpeg($imagem);
		}
	elseif ($ext == "png") {
		$imagem_orig = imagecreatefrompng($imagem);
		}
	if(!$imagem_orig) {
		echo("Erro ao carregar a imagem, talvez formato nao suportado");
		return false;
		exit;
	}

	//pegamos a altura e a largura da imagem original
	$pontox = imagesx($imagem_orig);
	$pontoy = imagesy($imagem_orig);

	//criamos a imagem redimensionada com a funcao imagecreatetruecolor para suportar um grande numero de cores
	$imagem_fin = imagecreatetruecolor($largura, $altura);

	//copiamos o conteudo da imagem original e passamos para o espaco reservado a redimencao
	imagecopyresampled($imagem_fin, $imagem_orig, 0, 0, 0, 0, $largura+1, $altura+1, $pontox, $pontoy);

	//salva a imagem
	//imagejpeg($imagem_fin, $imagem,100);
	if($ext == "jpg" || $ext == "jpeg" || $ext == "JPEG" || $ext == "JPG") {
		imagejpeg($imagem_fin, $imagem,100);
		return true;
		}
	elseif ($ext == "png") {
		imagepng($imagem_fin, $imagem);
		return true;
		}
	else {
		echo("Formato de arquivo nao suportado");
		return false;
	}

	#crop
	$LIMG=$largura;
	$AIMG=$altura_crop;
	$g_srcfile=$imagem;

	if(file_exists($g_srcfile)) {

	   $g_is = getimagesize($g_srcfile);

		$g_ih=$AIMG;
		$g_iw=($g_ih/$g_is[1])*$g_is[0];

		if($LIMG>$g_iw){
		   $g_iw=$LIMG;
		  $g_ih=($LIMG/$g_is[0])*$g_is[1];
		}

		// se a largura redimensionada($g_iw)  for
		// maior ou igual a altura redimensionada($g_ih)
		if($g_iw>=$g_ih){
		   $scr_x=0;
		   $src_y=0;
		}else{
		   $scr_x=0;
		   $src_y=0;
		}

	   $img_src=imagecreatefromjpeg($g_srcfile);
	   $img_dst=imagecreatetruecolor($LIMG, $AIMG);
	   imagecopyresampled($img_dst, $img_src, 0, 0, $scr_x, $src_y, $g_iw, $g_ih, $g_is[0], $g_is[1]);

	   //imagejpeg($img_dst,$imagem);
	    if($ext == "jpg" || $ext == "jpeg" || $ext == "JPEG" || $ext == "JPG") {
		imagejpeg($img_dst,$imagem,100);
		return true;
		}
		elseif ($ext == "gif") {
			imagepng($img_dst,$imagem);
			return true;
			}
		elseif ($ext == "png") {
			imagepng($img_dst,$imagem);
			return true;
			}
		else {
			echo("Formato de arquivo nao suportado");
			return false;
		}
	   imagedestroy($img_dst);
	   //libera a memoria
		imagedestroy ($imagem_orig);
		imagedestroy ($imagem_fin);

	}
}

function redCropImagemT($tam,$arquivo,$largura,$altura_crop,$imagem,$file_nome,$ext){


	#crop
	$LIMG=$largura;
	$AIMG=$altura_crop;
	$g_srcfile=$imagem;

	if(file_exists($g_srcfile)) {

	   $g_is = getimagesize($g_srcfile);

		$g_ih=$AIMG;
		$g_iw=($g_ih/$g_is[1])*$g_is[0];

		if($LIMG>$g_iw){
		   $g_iw=$LIMG;
		  $g_ih=($LIMG/$g_is[0])*$g_is[1];
		}

		// se a largura redimensionada($g_iw)  for
		// maior ou igual a altura redimensionada($g_ih)
		if($g_iw>=$g_ih){
		   $scr_x=0;
		   $src_y=0;
		}else{
		   $scr_x=0;
		   $src_y=0;
		}

	   $img_src=imagecreatefromjpeg($g_srcfile);
	   $img_dst=imagecreatetruecolor($LIMG, $AIMG);
	   imagecopyresampled($img_dst, $img_src, 0, 0, $scr_x, $src_y, $g_iw, $g_ih, $g_is[0], $g_is[1]);

	   //imagejpeg($img_dst,$imagem);
	    if($ext == "jpg" || $ext == "jpeg" || $ext == "JPEG" || $ext == "JPG") {
		imagejpeg($img_dst,$imagem,100);
		return true;
		}
		elseif ($ext == "gif") {
			imagepng($img_dst,$imagem);
			return true;
			}
		elseif ($ext == "png") {
			imagepng($img_dst,$imagem);
			return true;
			}
		else {
			echo("Formato de arquivo nao suportado");
			return false;
		}
	   imagedestroy($img_dst);
	   //libera a memoria
		imagedestroy ($imagem_orig);
		imagedestroy ($imagem_fin);

	}
}







?>
