<?php
session_start();
if (isset($_SESSION["login_usuario"]))
  {
  	 $login     =  $_SESSION["login_usuario"];
     $nte       =  $_SESSION["nivel_usuario"];
	 $inep      =  $_SESSION["inep_usuario"] ;
     $ntelogin  =  $_SESSION["nte_login"];
	 include ("../funcoes.php");
     echo  saudacoes()."   ". "$login" ."  -  ". $nte."  ".dataextenso() ." - ".$inep;

  }
 else
  {
     		 header("../../Location: login.php");
  }


include ("../../conexao_mysql.php");
/*
if(file_exists("../../conexao_mysql.php"))
{
        require "../../conexao_mysql.php";

} else
{
        echo "Conex�o nao foi encontrado";
        exit;
}

     include ("../funcoes.php");
 */
?>

<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01//EN"
	"http://www.w3.org/TR/html4/strict.dtd"><head>

    <meta http-equiv="content-type" content="text/html; charset=ISO-8859-1" />

	<title>Gerencia de Tecnologia da Informa��o</title>
	
	
	
	<link rel="stylesheet" href="style/forms.css" type="text/css" />
	<link rel="stylesheet" href="estilo.css" type="text/css" />
	<link rel="stylesheet" href="style/menu.css" type="text/css" />
	<link href="tablecloth/tablecloth.css" rel="stylesheet" type="text/css" media="screen" />
    <link rel="stylesheet" href="../css/bootstrap.min.css" type="text/css" />


	
	<script type="text/javascript" src="tablecloth/tablecloth.js"></script>
	<script src="lib/jquery-1.4.2.js" type="text/javascript"></script>
	<script src="lib/validate.js" type="text/javascript"></script>
	<script src="lib/forms.js" type="text/javascript"></script>
	<script src="generic1.js" type="text/javascript"></script>
    <script src="lib/jquery.maskedinput-1.1.1.js" type="text/javascript"></script>



 	<link type="text/css" href="jquery-ui-1.8.18.custom/css/ui-lightness/jquery-ui-1.8.18.custom.css" rel="stylesheet" />
	<script type="text/javascript" src="jquery-ui-1.8.18.custom/js/jquery-ui-1.8.18.custom.min.js"></script>


<script src="script.js"></script>

<script>
function pesquisa(form)
{

  var valor = document.form.txtturma.value;
  url="busca_kit.php?valor="+valor;
  ajax(url);
}
</script>



<script>
	$(function() {
		$( "#txtdtnascimento" ).datepicker({
			changeMonth: true,
			changeYear: true
		});
	});

$(function() {
        $("#txtdtnascimento").datepicker();
        $('#txtdtnascimento').datepicker('option', 'dateFormat', 'dd/mm/yy');
});




$(function() {
		$( "#txtdtemissaorgpai" ).datepicker({
			changeMonth: true,
			changeYear: true
		});
	});

$(function() {
        $("#txtdtemissaorgpai").datepicker();
        $('#txtdtemissaorgpai').datepicker('option', 'dateFormat', 'dd/mm/yy');
});



$(function() {
		$( "#txtdtemissaorgmae" ).datepicker({
			changeMonth: true,
			changeYear: true
		});
	});

$(function() {
        $("#txtdtemissaorgmae").datepicker();
        $('#txtdtemissaorgmae').datepicker('option', 'dateFormat', 'dd/mm/yy');
});


$(function() {
		$( "#dtemissao_certidao" ).datepicker({
			changeMonth: true,
			changeYear: true
		});
	});

$(function() {
        $("#dtemissao_certidao").datepicker();
        $('#dtemissao_certidao').datepicker('option', 'dateFormat', 'dd/mm/yy');
});



$(function() {
		$( "#txtdtemissaorgresp" ).datepicker({
			changeMonth: true,
			changeYear: true
		});
	});

$(function() {
        $("#txtdtemissaorgresp").datepicker();
        $('#txtdtemissaorgresp').datepicker('option', 'dateFormat', 'dd/mm/yy');
});



$(function() {
		$( "#txtd_matricula" ).datepicker({
			changeMonth: true,
			changeYear: true
		});
	});

$(function() {
        $("#txtd_matricula").datepicker();
        $('#txtd_matricula').datepicker('option', 'dateFormat', 'dd/mm/yy');
});


$(function() {
		$( "#txtdtemissaorgaluno" ).datepicker({
			changeMonth: true,
			changeYear: true
		});
	});

$(function() {
        $("#txtdtemissaorgaluno").datepicker();
        $('#txtdtemissaorgaluno').datepicker('option', 'dateFormat', 'dd/mm/yy');
});

</script>



<script>

function tp_certidao()
{
	  if (document.form.selecttp_certidao.value == '1')
            {
		     document.form.txtcertidaonovo.disabled =false;
		     document.form.txtcertidao.disabled =true;
		     document.form.txtfolha.disabled =true;
		     document.form.txtlivro.disabled =true;
		     document.form.dtemissao_certidao.disabled =true;


		     document.form.txtcertidao.value ="";
		     document.form.txtfolha.value ="";
		     document.form.txtlivro.value ="";
		     document.form.dtemissao_certidao.value ="";



     		 }
     else
           {
		     document.form.txtcertidaonovo.disabled=true;

		     document.form.txtcertidaonovo.value="";

		     document.form.txtcertidao.disabled = false;
		     document.form.txtfolha.disabled = false;
		     document.form.txtlivro.disabled =false;
		     document.form.dtemissao_certidao.disabled =false;
          }
  }







function tp_necessidade()
{
	  if (document.form.selectdeficiente.value == '0')
            {
		     document.form.selecttipo_necessidade.disabled =true;
		     document.form.selecttipo_necessidade.value="";
     		 }
     else
           {
		     document.form.selecttipo_necessidade.disabled=false;
          }
  }


function tp_bosa_familia()
{
	  if (document.form.selectbosaf.value == 'N')
            {
		     document.form.nbolsa.disabled =true;
             document.form.nbolsa.value="";
     		 }
     else
           {
		     document.form.nbolsa.disabled=false;
          }
  }





function tp_filiacao()
{
      if (document.form.filiacao.value == '0')
            {
		     document.form.txtpai.disabled =true;
		     document.form.cpfpai.disabled =true;
		     document.form.txtOrgaoExppai.disabled =true;
		     document.form.txtdtemissaorgpai.disabled =true;
		     document.form.txtRGpai.disabled =true;
		     document.form.txtmae.disabled =true;
		     document.form.txtRGmae.disabled =true;
		     document.form.txtOrgaoExpmae.disabled =true;
		     document.form.txtdtemissaorgmae.disabled =true;
		     document.form.cpfmae.disabled =true;




		     document.form.txtpai.value="";
		     document.form.cpfpai.value="";
		     document.form.txtOrgaoExppai.value="";
		     document.form.txtdtemissaorgpai.value="";
		     document.form.txtRGpai.value="";
		     document.form.txtmae.value="";
		     document.form.txtRGmae.value="";
		     document.form.txtOrgaoExpmae.value="";
		     document.form.txtdtemissaorgmae.value="";
		     document.form.cpfmae.value="";




     		 }
     else
           {
		     document.form.txtpai.disabled = false;
		     document.form.cpfpai.disabled =false;
		     document.form.txtOrgaoExppai.disabled =false;
		     document.form.txtdtemissaorgpai.disabled =false;
		     document.form.txtRGpai.disabled =false;
		     document.form.txtmae.disabled =false;
		     document.form.txtRGmae.disabled =false;
		     document.form.txtOrgaoExpmae.disabled =false;
		     document.form.txtdtemissaorgmae.disabled =false;
		     document.form.cpfmae.disabled =false;


          }
  }







</script>





</head>
<body>
	<div id="warpper">
		<div id="header">
            <center>
           <img src= "../img/chamadaescolar.jpg"/>
            </center>
		</div>
    <div id="container">
			<div id="content">

				<form  name="form" class="form" action="insere_dados.php" method="POST" enctype="multipart/form-data" style="padding-left:1px">
				 <div id="tema"> 
					   <p><center>Dados do Aluno</center></p>
				  </div>

      	     <!-- AQUI SER� APRESENTADO O RESULTADO DA BUSCA DIN�MICA.. OU SEJA OS NOMES -->
					<p>
                        <div id="pagina">
                        </div>
             		</p>


            <br>


					<p>
						<label for="lblpai">Nome do Aluno<img src= "../img/check.gif"/></label>
						<input type="text" name="txtnaluno" style="width:565px" maxlength="100" value="" id="txtnaluno" />
					</p>

					<p>
						<label for="txtCPF">ID Nacional</label>
						<input type="text" name="idnacional" style="width:250px" value="<?echo $cpf;?>" maxlength="20" id="idnacional"  onKeyPress="return Enum(event)"/>
					</p>



					<p>
						<label for="lbldtnascimento">Data Nascimento<img src= "../img/check.gif"/></label>
						<input type="text" name="txtdtnascimento" value="" style="width:100px" maxlength="10" id="txtdtnascimento" />


						<label for="selectsexo">Sexo<img src= "../img/check.gif"/></label>
 			               <select id="selectsexo" name="selectsexo" style="width:200px">
              		          <option value="">-Selecione o Sexo-</option>
              		          <option value="1">Masculino</option>
            		          <option value="2">Feminino</option>
    		               </select>
					</p>



					<p>
						<label for="selectsexo">Necessidade Especial<img src= "../img/check.gif"/></label>
 			               <select id="selectdeficiente" name="selectdeficiente" style="width:140px"       onChange = "tp_necessidade(form)"/>
            		          <option value="0">N�o</option>
              		          <option value="1">Sim</option>
    		               </select>
					</p>






                 <p>
					    <label for="cod_estados" >Selecione o tipo:</label>
						<select name="selecttipo_necessidade" id="selecttipo_necessidade" style="width:400px" disabled ="true"/>
						<option value="">-- Selecione o Tipo --</option>
                         <?php
							$sql = "SELECT id, descricao
									FROM tipo_necessidade order by descricao";
				     		$res = mysql_query( $sql );
							while ( $row = mysql_fetch_assoc( $res ) ) {
							echo '<option value="'.$row['id'].'">'.$row['descricao'].'</option>';
						}
					     ?>
  			   		</select>
                     </P>


    		<p>
						<label for="lblpai">Documentos </label>
                        <label for="lblpai">*************************************************************** </label>
     					</p>



					<p>
						<label for="selectsexo">Tipo de Certid�o<img src= "../img/check.gif"/></label>
 			               <select id="selecttp_certidao" name="selecttp_certidao" style="width:250px" onChange = "tp_certidao(form)"/>
            		          <option value="">Selecione o Tipo de Certid�o</option>
            		          <option value="1">Modelo Novo</option>
              		          <option value="2">Modelo Antigo</option>
    		               </select>
					</p>




 				 	<p>
						<label for="lblBairro" style="width:250px">Certid�o Nascimento Modelo Novo<img src= "../img/check.gif"/></label>
						<input type="text" name="txtcertidaonovo" value="" id="txtcertidaonovo" maxlength="40" style="width:300px" disabled ="true"/>
                   	</p>


                     <p>

						<label for="lblBairro">N da Certid�o Nascimento<img src= "../img/check.gif"/></label>
						<input type="text" name="txtcertidao" value=""    style="width:300px"  id="txtcertidao" maxlength="25" disabled="true"/>
                      	</p>
                       	<p>
                        <label for="lblBairro">Folha n<img src= "../img/check.gif"/></label>
						<input type="text" name="txtfolha" style="width:110px" value="" id="txtfolha"   maxlength="5"     disabled="true"/>
                        <label for="txtCEP">Livro n<img src= "../img/check.gif"/></label>
            			<input id="txtlivro" name="txtlivro" type="text" style="width:110px" maxlength="8"               disabled="true"/>
						<label for="lbldtnascimento">Data Emiss�o<img src= "../img/check.gif"/></label>
						<input type="text" name="dtemissao_certidao" value="" style="width:100px" maxlength="10" id="dtemissao_certidao" disabled="true"/>

					</p>
                    			


                     <p>
						<label for="txtRG">RG</label>
						<input type="text" name="txtRGaluno" style="width:110px" value="" id="txtRGaluno"  maxlength="20"/>
						<label for="txtOrgaoExp" >Org�o Exp</label>
						<input type="text" name="txtOrgaoExpaluno" value="" style="width:110px" id="txtOrgaoExpaluno"  maxlength="6"/>
						<label for="lblDataEmissao">Data Emiss�o</label>
						<input type="text" name="txtdtemissaorgaluno" value="" style="width:100px" id="txtdtemissaorgaluno" maxlength="10" />

                    </p>

					<p>
						<label for="txtCPF">CPF</label>
						<input type="text" name="cpfaluno" style="width:110px" value="" maxlength="11" id="cpfaluno"  onKeyPress="return Enum(event)"/>
					</p>

                <p>
            		<label for="lblcod_cidades">Cor/Ra�a:<img src= "../img/check.gif"/></label>
						<select name="selectcorraca" id="selectcorraca" style="width:200px">
			           <option value="">-- Escolha uma op��o --</option>
					<?php
						$sql = "select * from cor_raca";
						$resultado1 = mysql_query($sql);
						if($resultado1)
							{
							while($linhas = mysql_fetch_array($resultado1)){
							?>
								<option value="<?php echo $linhas['id']; ?>"
								<?php if($linhas['id'] == $selectgrauparente){ echo "selected";  } ?>>
								<?php echo $linhas['descricao'];  ?>
								</option>
								<?php } }
								 ?>
							</select>
    			</p>





    	<p>

					<label for="cod_estados">Naturalidade - Estado:<img src= "../img/check.gif"/></label>
						<select name="cod_estado" id="cod_estado">
						<option value=""></option>
					<?php
							$sql = "SELECT cod_estados, sigla
									FROM estados
									ORDER BY sigla";
				     		$res = mysql_query( $sql );
							while ( $row = mysql_fetch_assoc( $res ) ) {
							echo '<option value="'.$row['cod_estados'].'">'.$row['sigla'].'</option>';
						}

					?>
					</select>
          		<label for="cod_cidades">Cidade:<img src= "../img/check.gif"/></label>
          		        <select name="cod_cidades" id="cod_cidades">
			           <option value="">-- Escolha um estado --</option>
            	 </select>


		</p>






    		<p>
						<label for="lblpai">Dados do Pai - M�e </label>
                        <label for="lblpai">*************************************************************** </label>
     					</p>


  		       <p>

			<label for="selectsexo">Filia��o</label>
                      <select id="filiacao" name="filiacao" style="width:200px" onChange = "tp_filiacao(form)"/>
                               <option value="0">N�O DECLARADO</option>
                               <option value="1">PAI E/OU M�E</option>
						   </select>


                    </p>



					<p>
						<label for="lblpai">Nome Pai</label>
						<input type="text" name="txtpai" style="width:565px" maxlength="60" value="" id="txtpai" disabled ="true"/>
					</p>



					<p>
						<label for="txtRG">RG</label>
						<input type="text" name="txtRGpai" style="width:110px" value="" id="txtRGpai"  maxlength="20" disabled ="true"/>
						<label for="txtOrgaoExp" >Org�o Exp</label>
						<input type="text" name="txtOrgaoExppai" value="" style="width:70px" id="txtOrgaoExppai"  maxlength="6" disabled ="true"/>
						<label for="lblDataEmissao">Data Emiss�o</label>
						<input type="text" name="txtdtemissaorgpai" value="" style="width:100px" id="txtdtemissaorgpai" maxlength="10" disabled ="true"/>

                    </p>

					<p>
						<label for="txtCPF">CPF</label>
						<input type="text" name="cpfpai" style="width:110px" value="" maxlength="11" id="cpfpai"  onKeyPress="return Enum(event)" disabled ="true"/>
					</p>



					<p>
						<label for="lblmae">Nome M�e<img src= "../img/check.gif"/></label>
						<input type="text" name="txtmae" style="width:565px" maxlength="60" value="" id="txtmae" disabled ="true"/>
					</p>


					<p>
						<label for="txtRG">RG</label>
						<input type="text" name="txtRGmae" style="width:110px" value="" id="txtRGmae"  maxlength="20" disabled ="true"/>
						<label for="txtOrgaoExp" >Org�o Exp</label>
						<input type="text" name="txtOrgaoExpmae" value="" style="width:70px" id="txtOrgaoExpmae"  maxlength="6" disabled ="true"/>
						<label for="lblDataEmissao">Data Emiss�o</label>
						<input type="text" name="txtdtemissaorgmae" value="" style="width:100px" id="txtdtemissaorgmae" maxlength="10" disabled ="true"/>
                     </p>

    				<p>
						<label for="txtCPF">CPF</label>
						<input type="text" name="cpfmae" style="width:110px" value="" maxlength="11" id="cpfmae"  onKeyPress="return Enum(event)" disabled ="true"/>

					</p>





     					<p>
						<label for="lblpai">Dados do Respons�vel </label>
                        <label for="lblpai">*************************************************************** </label>
     					</p>
                 <p>
					    <label for="cod_estados" >Grau de Parentesco:<img src= "../img/check.gif"/></label>
						<select name="selectgrauparente" id="selectgrauparente" style="width:200px">
						<option value=""></option>
                         <?php
							$sql = "SELECT id, descricao
									FROM grau_parentesco order by id";
				     		$res = mysql_query( $sql );
							while ( $row = mysql_fetch_assoc( $res ) ) {
							echo '<option value="'.$row['id'].'">'.$row['descricao'].'</option>';
						}
					     ?>
					</select>
                     </P>



                	<p>
						<label for="lblmae">Nome Respons�vel<img src= "../img/check.gif"/></label>
						<input type="text" name="txtresponsavel" style="width:565px" maxlength="60" value="" id="txtresponsavel" />
					</p>

					<p>
						<label for="txtRG">RG<img src= "../img/check.gif"/></label>
						<input type="text" name="txtRGresp" style="width:110px" value="" id="txtRGresp"  maxlength="20"/>
						<label for="txtOrgaoExp" >Org�o Exp<img src= "../img/check.gif"/></label>
						<input type="text" name="txtOrgaoExpresp" value="" style="width:70px" id="txtOrgaoExpresp"  maxlength="6"/>
						<label for="lblDataEmissao">Data Emiss�o<img src= "../img/check.gif"/></label>
						<input type="text" name="txtdtemissaorgresp" value="" style="width:100px" id="txtdtemissaorgresp" maxlength="10" />

					<p>
						<label for="txtCPF">CPF<img src= "../img/check.gif"/></label>
						<input type="text" name="cpf" style="width:110px" value="" maxlength="11" id="cpf"  onKeyPress="return Enum(event)"/>

					</p>


     					<p>
						<label for="lblpai">Dados Logradouro </label>
                        <label for="lblpai">*************************************************************** </label>
					</p>




					<p>
						<label for="lblEndereco">Endere�o(Rua/Avenida)<img src= "../img/check.gif"/></label>
						<input type="text" name="txtEndereco" style="width:565px" value=""  maxlength="40" size="40" id="txtEndereco" />
					</p>
					<p>
						<label for="lblBairro">Bairro<img src= "../img/check.gif"/></label>
						<input type="text" name="txtBairro" value="" id="txtBairro" maxlength="25"/>
						<label for="lblBairro">Nr<img src= "../img/check.gif"/></label>
						<input type="text" name="txtnr" style="width:60px" value="" id="txtnr"  maxlength="5" onKeyPress="return Enum(event)"/>
			            <label for="txtCEP">CEP<img src= "../img/check.gif"/></label>
            			<input id="txtcep" name="txtcep" type="text" style="width:90px" maxlength="8" onKeyPress="return Enum(event)"/>
					</p>




					<p>
						<label for="lblcomplemento">Complemento</label>
						<input type="text" name="txtcomplemento" style="width:298px" value=""  maxlength="40" size="60" id="txtcomplemento"/>
					</p>
                 <p>
					<label for="lblcod_estados">Municipio<img src= "../img/check.gif"/></label>
					   <select name="cod_muni" id="cod_muni" >
					   <option value=""></option>
  					  <?php
						   $sql = "select codigo, descricao FROM municipio order by descricao";
						   $res = mysql_query($sql);
						   if($res)
							  {
								while($row = mysql_fetch_array($res)){
							    ?>
  			                    <option value="<?php echo $row['codigo']?>"
						        <?php if($row['codigo'] == $muni){ echo "selected";}?>>
								<?php echo $row['descricao'];?>
								<?php
							      } }
						        ?>
					   </select>
					</p>


					<p>
						<label for="txtFoneSetor">Telefone Para Contato<img src= "../img/check.gif"/></label>
						<input type="text" name="txtcontato" style="width:110px" value="" id="txtcontato" />
						<label for="txtCelular">Celular<img src= "../img/check.gif"/></label>
						<input type="text" name="txtCelular" style="width:90px" value="" id="txtCelular" maxlength="20"/>
					</p>
					<p>
						<label for="txtEmail1">E-mail</label>
						<input type="text" name="txtEmail" style="width:565px" value="" id="txtEmail" maxlength="60"/>
						
					</p>




					<p>
						<label for="selectsexo">Bolsa Familia<img src= "../img/check.gif"/></label>
 			               <select id="selectbosaf" name="selectbosaf" style="width:140px" onChange="tp_bosa_familia(form)"/>
            		          <option value="N">N�o</option>
              		          <option value="S">Sim</option>
    		               </select>
					</p>


					<p>
						<label for="txtCPF">N� Cart�o Bolsa Familia</label>
						<input type="text" name="nbolsa" style="width:250px" value="<?echo $cpf;?>" maxlength="13" id="nbolsa"  onKeyPress="return Enum(event)" disabled="true"/>
					</p>




					<p>
						<label for="txtCPF">N� Cart�o SUS</label>
						<input type="text" name="nsus" style="width:250px" value="" maxlength="20" id="nsus"  onKeyPress="return Enum(event)"/>
					</p>

					<p>
						<label for="selectsexo">Utiliza Transporte Escolar<img src= "../img/check.gif"/></label>
 			               <select id="selecttransporte" name="selecttransporte" style="width:140px">
            		          <option value="N">N�o</option>
              		          <option value="S">Sim</option>
    		               </select>
					</p>




  					<p>
						<label for="selectsexo">Permitir Acesso ao Portal<img src= "../img/check.gif"/></label>
 			               <select id="selectacesso" name="selectacesso" style="width:140px">
            		          <option value="N">N�o</option>
              		          <option value="S">Sim</option>
    		               </select>
					</p>






					<p>
						<label for="txtFoneSetor">Situa��o<img src= "../img/check.gif"/></label>
						<input type="text" name="txtsituacao" style="width:50px" value="" id="txtsituacao"        readonly="true"/>
					</p>


					<p>
						<label for="lblDataEmissao">Data Matricula<img src= "../img/check.gif"/></label>
						<input type="text" name="txtdt_matricula" value="" style="width:100px" id="txtdt_matricula" maxlength="10" />

					<p>






   	    <p>
            <label for="lblcod_cpf">Obs.:</label>
 			<textarea name = "txtobs"  maxlength= "200" cols="80" rows = "3" id = "txtobs"  type = "text"  onkeyup="blocTexto(txtdescvolume.value)"></textarea>
       </p>


					<p>

						<label for="txtCPF" style="width:120px">Foto</label>
                        <img  src="../fotos/<?echo $imagem;?>"  style="width:90px" />
                        <input type="file" name="imagem" />

					</p>













	<p id="finish">

            <input type="submit" class="btn btn-primary" value="Gravar" name = "cadastrar" />
            <input type="button" value=" Voltar " class="btn" onclick="location.href='form_pesquisa_aluno.php';">
					</p>
				</form>
			</div>
		</div>
		<div id="footer">
			<p>Todos direitos reservados SEDUC/GTI-RO</p>
		</div>
	</div>
</body>
