<?php
require_once '../../start.php';

$title = 'Dados do Aluno';

$pdo = new Conexao;

$id = $_GET['codigo'];
$txtano = Ano::get();

if (!empty($id)) {

    $sql = "SELECT * FROM aluno WHERE id = :id";
    $sth = $pdo->prepare($sql);
    $sth->bindParam(':id', $id);
    
    $aluno = $sth->execute() ? $sth->fetch() : null;
    
    if ($aluno) {
        $id = $aluno["id"];
        $nome = $aluno["nome"];

        $dt_nascimento = date("m/d/Y", strtotime($aluno["dt_nascimento"]));

        $sexo = $aluno["sexo"];
        $termo_certidao = $aluno["termo_certidao"];
        $folha_certidao = $aluno["folha_certidao"];
        $livro_certidao = $aluno["livro_certidao"];

        $dtemissao_certidao = date("m/d/Y", strtotime($aluno["dtemissao_certidao"]));

        $uf_nascimento = $aluno["uf_nascimento"];
        $muni_nascimento = $aluno["muni_nascimento"];
        $nome_pai = $aluno["nome_pai"];
        $rg_pai = $aluno["rg_pai"];
        $orgexprg_pai = $aluno["orgexprg_pai"];

        $dtrg_pai = $aluno["dtrg_pai"];
        $dtrg_pai = date("m/d/Y", strtotime($aluno["dtrg_pai"]));
        $cpf = $aluno["cpf"];

        $nome_mae = $aluno["nome_mae"];
        $rg_mae = $aluno["rg_mae"];
        $orgexprg_mae = $aluno["orgexprg_mae"];
        $dtrg_mae = $aluno["dtrg_mae"];
        $dtrg_mae = date("m/d/Y", strtotime($aluno["dtrg_mae"]));

        $cpf_mae = $aluno["cpf_mae"];
        $endereco = $aluno["endereco"];
        $bairro = $aluno["bairro"];
        $numero = $aluno["numero"];
        $cep = $aluno["cep"];
        $complemento = $aluno["complemento"];
        $cidade = $aluno["cidade"];

        $fonecontato = $aluno["fonecontato"];
        $fonecelular = $aluno["fonecelular"];
        $email = $aluno["email"];
        $obs = $aluno["obs"];

        $foto = $aluno["foto"];

        $txtresponsavel = $aluno["responsavel"];
        $selectgrauparente = $aluno["grau_parentesco"];
        $txtRGresp = $aluno["rgresponsavel"];
        $txtOrgaoExpresp = $aluno["orgaoexpresp"];
        $txtdtemissaorgresp = $aluno["dtemissaorgresp"];
        $txtdtemissaorgresp = date("m/d/Y", strtotime($aluno["dtemissaorgresp"]));

        $cpfresp = $aluno["cpfresp"];
        $n_bolsa_fam = $aluno["n_bolsa_fam"];
        $id_nacional = $aluno["id_nacional"];
        $filiacao = $aluno["filiacao"];
        $car_raca = $aluno["car_raca"];

        $inepbanco = $aluno["inep"];
        $status = $aluno["status"];

        $deficiente = $aluno["deficiente"];
        $tipo_necessidade = $aluno["tipo_necessidade"];
        $bolsa_familia = $aluno["bolsa_familia"];

        $inep = $aluno["inep"];
    }
}

$sql = "SELECT * FROM escola WHERE inep = :inep;";
$sth = $pdo->prepare($sql);
$sth->bindParam(':inep', $inep);

$escola = $sth->execute() ? $sth->fetch() : null;

if (($dt_nascimento == '31/12/1969') || ($dt_nascimento == '30/11/-0001')) {
    $dt_nascimento = '';
}

if (($dtemissao_certidao == '31/12/1969') || ($dtemissao_certidao == '30/11/-0001')) {
    $dtemissao_certidao = '';
}

if (($dtrg_pai == '31/12/1969') || ($dtrg_pai == '30/11/-0001')) {
    $dtrg_pai = '';
}

if (($dtrg_mae == '31/12/1969') || ($dtrg_mae == '30/11/-0001')) {
    $dtrg_mae = '';
}

if (($inepbanco) != '' && $status != '1') {
    Notification::warning('Aluno n�o possui situa��o Matriculado!');
    redirect('form_pesquisa_aluno_gti.php');        
}

?><!DOCTYPE HTML>
<html>
    <head>
        <?php require_once page_head(); ?>
    </head>
    <body>
        <?php require_once page_header(); ?>
        
        <div class="container">
            <form action="altera_dados_gti.php" method="POST" enctype="multipart/form-data">
                
                <div class="row">
                    <div class="col-md-2">
                        <div class="form-group">
                            <label for="txtid">ID Estadual</label>
                            <input type="text" name="txtid" class="form-control" value="<?php echo $id; ?>" id="txtid" readonly>
                        </div>
                    </div>
                    <div class="col-md-4">
                        <div class="form-group">
                            <label for="txtnaluno">Nome do Aluno</label>
                            <input type="text" name="txtnaluno" class="form-control" maxlength="100" value="<? echo $nome; ?>" id="txtnaluno" readonly>
                        </div>
                    </div>
                    <div class="col-md-2">
                        <div class="form-group">
                            <label for="idnacional">ID Nacional</label>
                            <input type="text" name="idnacional" class="form-control" value="<? echo $id_nacional; ?>" maxlength="20" id="idnacional"  onKeyPress="return Enum(event)" readonly="true" />
                        </div>
                    </div>
                    <div class="col-md-2">
                        <div class="form-group">
                            <label for="lbldtnascimento">Data Nascimento</label>
                            <input type="text" name="txtdtnascimento" value="<? echo $dt_nascimento; ?>" class="form-control" maxlength="10" id="txtdtnascimento" readonly="true" />
                        </div>
                    </div>
                    <div class="col-md-2">
                        <div class="form-group">
                            <label for="selectsexo">Sexo</label>
                            <select id="selectsexo" name="selectsexo" class="form-control" readonly>        
                                <option value="1" <?php echo ($sexo == '1') ? 'selected' : '' ?>>MASCULINO</option>
                                <option value="2" <?php echo ($sexo == '2') ? 'selected' : '' ?>>FEMININO</option>
                            </select>
                        </div>
                    </div>
                </div>
                
                <div class="row">
                    <div class="col-md-4">
                        <div class="form-group">
                            <label for="txtcertidaonovo">Certid�o Nascimento Modelo Novo</label>
                            <input type="text" name="txtcertidaonovo" class="form-control" value="<?php echo $termo_certidao; ?>" id="txtcertidaonovo" maxlength="25"readonly>
                        </div>                        
                    </div>
                    <div class="col-md-2">
                        <div class="form-group">
                            <label for="txtcertidao">N� Certid�o Nascimento</label>
                            <input type="text" name="txtcertidao" class="form-control" value="<? echo $termo_certidao; ?>" id="txtcertidao" maxlength="25" readonly>
                        </div>
                    </div>
                    <div class="col-md-2">
                        <div class="form-group">
                            <label for="txtfolha">Folha N�</label>
                            <input type="text" name="txtfolha" class="form-control" value="<? echo $folha_certidao; ?>" id="txtfolha"  maxlength="5"readonly>
                        </div>                            
                    </div>
                    <div class="col-md-2">
                        <div class="form-group">
                            <label for="txtlivro">Livro N�</label>
                            <input id="txtlivro" name="txtlivro" class="form-control" value="<? echo $livro_certidao; ?>" type="text" maxlength="8" onKeyPress="return Enum(event)"readonly>
                        </div>
                    </div>
                    <div class="col-md-2">
                        <div class="form-group">
                            <label for="lbldtnascimento">Data Emiss�o</label>
                            <input type="text" name="dtemissao_certidao" class="form-control" value="<? echo $dtemissao_certidao; ?>" maxlength="10" id="dtemissao_certidao" readonly>
                        </div>
                    </div>
                </div>
                
                <div class="row">
                    <div class="col-md-6">
                        <p>
                            <label for="txtmae">Nome da M�e</label>
                            <input type="text" name="txtmae" class="form-control" maxlength="60" value="<? echo $nome_mae; ?>" id="txtmae" readonly>
                        </p>
                    </div>
                    <div class="col-md-6">
                        <p>
                            <label for="txtpai">Nome do Pai</label>
                            <input type="text" name="txtpai" class="form-control" maxlength="60" value="<? echo $nome_pai; ?>" id="txtpai" readonly>
                        </p>
                    </div>
                </div>
                
                <hr>
                
                <fieldset class="well well-sm">
                    <legend>Escola atual</legend>
                    
                    <div class="row">
                        <div class="col-md-2">
                            <div class="form-group">
                                <label for="txtinep">INEP</label>
                                <input type="text" name="txtinep" class="form-control" value="<? echo $inep; ?>" id="txtinep" readonly>
                            </div>
                        </div>
                        <div class="col-md-8">
                            <div class="form-group">
                                <label for="txtescola">Escola</label>
                                <input type="text" name="txtescola" class="form-control" value="<? echo $escola["DESCRICAO"] ?>" id="txtescola" readonly>
                            </div>
                        </div>
                        <div class="col-md-2">
                            <div class="form-group">
                                <label for="txtsituacao">Situa��o</label>
                                <input type="text" name="txtsituacao" class="form-control" value="<? echo $status; ?>" id="txtsituacao"   readonly>
                            </div>
                        </div>
                    </div>
                </fieldset>
                
                
                <fieldset class="well well-sm">
                    <legend>
                        Escola Destino
                        <small><small class="text-warning"><i class="fa fa-warning"></i> Copia o aluno para situa��o de Transferido para ajuste</small></small>
                    </legend>
                    
                    <div class="row">
                        <div class="col-md-2">
                            <div class="form-group">
                                <label for="txtinep1">INEP</label>
                                <input type="text" name="txtinep1" value="" class="form-control" maxlength="8" id="txtinep1" onKeyPress="return Enum(event)">
                            </div>
                        </div>
                        <div class="col-md-8">
                            <div class="form-group">
                                <label for="txtdescescola1">Escola</label>
                                <select name="txtdescescola1" id="txtdescescola1" class="form-control">
                                    <option value="">-- Informe o INEP --</option>
                                </select>
                                <span class="carregando"></span>
                            </div>
                        </div>
                    </div>
                    
                    <div class="row">
                        <div class="col-md-2">
                            <div class="form-group">
                                <label for="txtnumero">N�</label>
                                <input type="text" name="txtnumero" value="" class="form-control" maxlength="2" id="txtnumero" onKeyPress="return Enum(event)">
                            </div>
                        </div>
                        <div class="col-md-8">
                            <div class="form-group">
                                <label for="selectturma">Turma</label>
                                <select name="selectturma" id="selectturma" class="form-control">
                                    <option value="">-- Selecione a Turma --</option>
                                </select>
                                <span class="carregando"></span>
                            </div>
                        </div>
                    </div>
                    
                    <div class="form-group">
                        <label for="txtobs">Justificativa</label>
                        <textarea name="txtobs" class="form-control" rows="5" id="txtobs" onkeyup="blocTexto(txtobs.value)"><?php echo $obs; ?></textarea>
                    </div>
                </fieldset>
                
                <hr>
                <p id="finish">
                    <input type="submit" value="Salvar" name="cadastrar" class="btn btn-primary">
                    <input type="button" value="Voltar" class="btn btn-default pull-right" onclick="location.href = 'form_pesquisa_aluno_gti.php';">
                </p>
            </form>
        </div>
        
        <?php require_once page_footer(); ?>
        <script type="text/javascript" src="tablecloth/tablecloth.js"></script>
        <script src="lib/jquery-1.4.2.js" type="text/javascript"></script>
        <script src="lib/validate.js" type="text/javascript"></script>
        <script src="lib/forms.js" type="text/javascript"></script>
        <script src="generic2.js" type="text/javascript"></script>
        <script src="lib/jquery.maskedinput-1.1.1.js" type="text/javascript"></script>

        <link type="text/css" href="jquery-ui-1.8.18.custom/css/ui-lightness/jquery-ui-1.8.18.custom.css" rel="stylesheet" />
        <script type="text/javascript" src="jquery-ui-1.8.18.custom/js/jquery-ui-1.8.18.custom.min.js"></script>
        <style type="text/css">
            div.fileinputs { position: relative; }
            div.fakefile { position: absolute; top: 0px; left: 0px; z-index: 1; }
            input.file { position: relative; text-align: right; -moz-opacity:0 ; filter:alpha(opacity: 0); opacity: 0;  }
        </style>
        <script src="script.js"></script>
        <script>
            function pesquisa(form) {
                var valor = document.form.txtturma.value;
                url = "busca_kit.php?valor=" + valor;
                ajax(url);
            }
        </script>
    </body>
</html>