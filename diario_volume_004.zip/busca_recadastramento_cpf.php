
<?php
include ("conexao_mysql.php");
 $cpf=  $_POST["cpf"];

if(!empty($_POST["cpf"])) 
{ 

$sql="select * from servidorrec where cpf = '$cpf'";
$resultado=mysql_query($sql) or die (mysql_error());
$linhas=mysql_num_rows($resultado);

if($linhas>0)
{
   while($pegar=mysql_fetch_array($resultado))
   {


    $id                 =$pegar["id"];
    $cpf                =$pegar["cpf"];
    $nome               =$pegar["nome"]; 	
    $endereco           =$pegar["endereco"]; 	
    $bairro             =$pegar["bairro"]; 	
    $fonesetor          =$pegar["fonesetor"]; 	
    $bairro             =$pegar["bairro"]; 	
    $mae                =$pegar["mae"]; 	
    $pai                =$pegar["pai"]; 	


$estado             =$pegar["estado"]; 	
$sqluf="select * from estados where cod_estados = '$estado'";
$resultadouf=mysql_query($sqluf) or die (mysql_error());
$linhasuf=mysql_num_rows($resultadouf);

if($linhasuf>0)
{
   while($pegaruf=mysql_fetch_array($resultadouf))
    {
       $estado   =$pegaruf["nome"];
	}
}


$cidade             =$pegar["cidade"]; 	
$sqlcid="select * from cidades where cod_cidades = '$cidade'";
$resultadocid=mysql_query($sqlcid) or die (mysql_error());
$linhascid=mysql_num_rows($resultadocid);

if($linhascid>0)
{
   while($pegarcid=mysql_fetch_array($resultadocid))
    {
       $cidade   =$pegarcid["nome"];
	}
}




$grauinstrucao     =$pegar["grauinstrucao"]; 	

$sqlinst="select * from grauinstrucao where codigo = '$grauinstrucao'";
$resultadoinst=mysql_query($sqlinst) or die (mysql_error());
$linhasinst=mysql_num_rows($resultadoinst);

if($linhasinst>0)
{
   while($pegarinst=mysql_fetch_array($resultadoinst))
    {
       $grauinstrucao   =$pegarinst["descricao"];
	}
}








    $preaposentadoria  =$pegar["preaposentadoria"]; 	
    $complemento       =$pegar["complemento"]; 	
    $fonecontato       =$pegar["fonecontato"]; 				
    $tpservidor     =$pegar["tpservidor"]; 	
    $ncontrato  =$pegar["ncontrato"]; 	
    $banco       =$pegar["banco"]; 	
    $agencia       =$pegar["agencia"]; 				
    $cc           =$pegar["cc"]; 	
    $numero       =$pegar["numero"]; 	
    $banco        =$pegar["banco"]; 	
    $agencia      =$pegar["agencia"]; 				


    $pis                =$pegar["pis"]; 	
    $rg                 =$pegar["rg"]; 	
	$orgaoexp           =$pegar["orgaoexp"]; 	
 
    $dtemissaorg        =$pegar["dtemissaorg"]; 	
    $dtemissaorg    = date("d/m/Y",strtotime($pegar["dtemissaorg"]));
	
	
	$te                 =$pegar["te"]; 	
    $secao              =$pegar["secao"]; 	
    $dtemissaote        =$pegar["dtemissaote"]; 	
    $dtemissaote    = date("d/m/Y",strtotime($pegar["dtemissaote"]));


    $estcivil           =$pegar["estcivil"]; 	
    $dtnascimento       =$pegar["dtnascimento"]; 						
    $dtnascimento    = date("d/m/Y",strtotime($pegar["dtnascimento"]));

    $sexo               =$pegar["sexo"]; 	
    $conjuge            =$pegar["conjuge"]; 		

 } 

     $dia = date('d');
     $mes = date('m');
     $ano = date('Y');
  
     $data1 =$dia.".".$mes.".".$ano;






?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<script language="javascript">
function DoPrinting() {
    if (!window.print) {
        alert("Netscape, Internet Explorer 4.0 ou superior!")
        return
    }
    window.print();
}
</script>

<head>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1" />
<title>:: Processo Seletivo::</title>
<style type="text/css">
<!--
.style1 {
	font-size: large;
	font-weight: bold;
}
.style2 {
	font-size: x-large;
	font-weight: bold;
}
.style3 {
	font-size: large;
	font-family: Verdana, Arial, Helvetica, sans-serif;
}
.style5 {font-family: Verdana, Arial, Helvetica, sans-serif}
.style6 {font-size: xx-large; font-weight: bold; font-family: Verdana, Arial, Helvetica, sans-serif; }
.style7 {font-size: x-large; font-weight: bold; font-family: Verdana, Arial, Helvetica, sans-serif; }
.style8 {font-size: large; font-weight: bold; font-family: Verdana, Arial, Helvetica, sans-serif; }
-->
</style>
</head>

<body>
<div align="left">
  <table width="988" border="1" cellpadding="0" cellspacing="0" bordercolor="#000000">
    <tr>
      <td colspan="7" rowspan="4"><table width="100%" border="0" cellpadding="0" cellspacing="0">
          <tr>
            <td width="120" class="style5"><div align="center"><img src="../img/logo_brazil.jpg" width="113" height="118" /></div></td>
            <td width="706" class="style5"><p align="center" class="style2">GOVERNO DO ESTADO DE ROND�NIA<br>
			SECRETARIA DE EDUCA��O DO ESTADO DE ROND�NIA<br>
			GERENCIA DE TECNOLOGIA DA INFORMA��O - SEDUC</p>
              <p align="center" class="style2">PROGRAMA DE TECNOLOGIA EDUCACIONAL/RO</p></td>
          </tr>
      </table></td>
      <td width="131" height="36" bgcolor="#CCCCCC"><div align="center" class="style3">Data </div></td>
    </tr>
    <tr>
      <td height="46"><div align="center" class="style3"><span class="style5"></span><span class="style5"><? echo $data1 ?></span></div></td>
    </tr>
    <tr>
      <td height="47" bgcolor="#CCCCCC"><div align="center" class="style3">NTE</div></td>
    </tr>
    <tr>
      <td height="38" class="style3"><div align="center"><? echo $nte; ?></div></td>
    </tr>
    <tr>
      <td height="68" colspan="8" bgcolor="#999999"><div align="center" class="style7">Recadastramento dos Servidores Estatudais Ativos da Secret�ria de Educa��o do Estado de Rond�nia</div></td><br>
    </tr>

    <tr>
      <td height="68" colspan="8" bgcolor="#999999"><div align="center" class="style7">Dados Pessoais</div></td><br>
    </tr>

  <tr>
      <td height="5" colspan="2"  class="style4"><div align="left"   class="style5"><strong>Nome:<?echo  $nome?> </strong></div></td>
      <td height="5" colspan="2"  class="style4"><div align="center" class="style5"><strong>CPF <? echo $cpf ?></strong></div></td>
  </tr>
  <tr>
   <td height="5" colspan="1"  class="style4"><div align="left" class="style5"><strong>Endere�o:<?echo  $endereco?> </strong></div>	  </td>
   <tr> 
      <td height="5" colspan="1"  class="style4"><div align="left" class="style5"><strong>Bairro:<?echo  $bairro?> </strong></div>	  </td>
 <tr>	  
      <td height="5" colspan="1"  class="style4"><div align="left" class="style5"><strong>Cidade:<?echo  $cidade?> </strong></div>	  </td>
 </tr>	  
   <tr> 
      <td height="5" colspan="1"  class="style4"><div align="left" class="style5"><strong>UF:<?echo  $estado?> </strong></div>	  </td>
 </tr>




 </tr>	  
   <tr> 
      <td height="5" colspan="1"  class="style4"><div align="left" class="style5"><strong>Complemento:<?echo  $complemento?> </strong></div>	  </td>
 </tr>

 </tr>	  
   <tr> 
      <td height="5" colspan="1"  class="style4"><div align="left" class="style5"><strong>Estado Civil:<?echo  $estcivil?> </strong></div>	  </td>
 </tr>

 </tr>	  
   <tr> 
      <td height="5" colspan="1"  class="style4"><div align="left" class="style5"><strong>Sexo:<?echo  $sexo?> </strong></div>	  </td>
 </tr>

 </tr>	  
   <tr> 
      <td height="5" colspan="1"  class="style4"><div align="left" class="style5"><strong>Nascimento:<?echo  $dtnascimento?> </strong></div>	  </td>
 </tr>



   <tr> 
      <td height="5" colspan="1"  class="style4"><div align="left" class="style5"><strong>Conjuge:<?echo  $conjuge?> </strong></div>	  </td>
 </tr>
   <tr> 
      <td height="5" colspan="1"  class="style4"><div align="left" class="style5"><strong>M�e:<?echo  $mae?> </strong></div>	  </td>
 </tr>
   <tr> 
      <td height="5" colspan="1"  class="style4"><div align="left" class="style5"><strong>Pai:<?echo  $pai?> </strong></div>	  </td>
 </tr>


  <tr>
      <td height="5" colspan="2"  class="style4"><div align="left"   class="style5"><strong>Fone1:<?echo  $fonesetor?> </strong></div></td>
      <td height="5" colspan="2"  class="style4"><div align="center" class="style5"><strong>Fone2:<?echo $fonecontato?></strong></div></td>
  </tr>


   <tr> 
      <td height="5" colspan="1"  class="style4"><div align="left" class="style5"><strong>Grau de Instru��o:<?echo  $grauinstrucao?> </strong></div>	  </td>
 </tr>
   <tr> 
      <td height="5" colspan="1"  class="style4"><div align="left" class="style5"><strong>Previs�o Aposentadoria:<?echo  $preaposentadoria?> </strong></div>	  </td>
 </tr>
   <tr> 
      <td height="5" colspan="1"  class="style4"><div align="left" class="style5"><strong>Servidor:<?echo  $tpservidor?> </strong></div>	  </td>
 </tr>
   <tr> 
      <td height="5" colspan="1"  class="style4"><div align="left" class="style5"><strong>Contratos:<?echo  $ncontrato?> </strong></div>	  </td>
 </tr>

   <tr> 
      <td height="5" colspan="1"  class="style4"><div align="left" class="style5"><strong>Banco:<?echo  $banco?> </strong></div>	  </td>
 </tr>
   <tr> 
      <td height="5" colspan="1"  class="style4"><div align="left" class="style5"><strong>Agencia:<?echo  $agencia?> </strong></div>	  </td>
 </tr>
   <tr> 
      <td height="5" colspan="1"  class="style4"><div align="left" class="style5"><strong>C/C:<?echo  $cc?> </strong></div>	  </td>
 </tr>



    <tr>
      <td height="68" colspan="8" bgcolor="#999999"><div align="center" class="style7">Documentos</div></td><br>
    </tr>

   <tr> 
      <td height="5" colspan="1"  class="style4"><div align="left" class="style5"><strong>PIS<?echo  $pis?> </strong></div>	  </td>
 </tr>


  <tr>
      <td height="5" colspan="2"  class="style4"><div align="left"   class="style5"><strong>R.G:<?echo  $rg?> </strong></div></td>
      <td height="5" colspan="2"  class="style4"><div align="center" class="style5"><strong>Org�o Expedidor: <? echo $orgaoexp ?></strong></div></td>
      <td height="5" colspan="2"  class="style4"><div align="center" class="style5"><strong>Data Emiss�o <? echo $dtemissaorg ?></strong></div></td>	  
  </tr>




  <tr>
      <td height="5" colspan="2"  class="style4"><div align="left"   class="style5"><strong>Titulo de Eleitor:<?echo  $te?> </strong></div></td>
      <td height="5" colspan="2"  class="style4"><div align="center" class="style5"><strong>Se��o <? echo $secao ?></strong></div></td>
      <td height="5" colspan="2"  class="style4"><div align="center" class="style5"><strong>Data Emiss�o <? echo $dtemissaote ?></strong></div></td>	  
  </tr>

    <tr>
      <td height="68" colspan="8" bgcolor="#999999"><div align="center" class="style7">Contrato</div></td><br>
    </tr>

<?

$sqlcontrato="select * from contrato where cpf = '$cpf'";
$resultadocontrato=mysql_query($sqlcontrato) or die (mysql_error());
$linhascontrato=mysql_num_rows($resultadocontrato);

if($linhascontrato>0)
{

   while($pegarcontrato=mysql_fetch_array($resultadocontrato))
    {

       $matricula       =$pegarcontrato["matricula"];
       $dtadmissao        =$pegarcontrato["dtadmissao"]; 	
       $dtadmissao    = date("d/m/Y",strtotime($pegarcontrato["dtadmissao"]));
       $lotadocontrato       =$pegarcontrato["lotado"];

       $chcontrato      =$pegarcontrato["chcontrato"];  	

$cargo       =$pegarcontrato["cargo"];	
$sqlcargo="select * from cargo where cod_cargo = '$cargo'";
$resultadocargo=mysql_query($sqlcargo) or die (mysql_error());
$linhascargo=mysql_num_rows($resultadocargo);

if($linhascargo>0)
{
   while($pegarcargo=mysql_fetch_array($resultadocargo))
    {
       $cargo   =$pegarcargo["descricao"];
	}
}



$funcao      =$pegarcontrato["funcao"];
$sqlfuncao="select * from funcao where cod_funcao = '$funcao'";
$resultadofuncao=mysql_query($sqlfuncao) or die (mysql_error());
$linhasfuncao=mysql_num_rows($resultadofuncao);

if($linhasfuncao>0)
{
   while($pegarfuncao=mysql_fetch_array($resultadofuncao))
    {
       $funcao   =$pegarfuncao["descricao"];
	}
}


$regimejuridico  =$pegarcontrato["regime"];
$sqlrj="select * from regimejuridico where id = '$regimejuridico'";
$resultadorj=mysql_query($sqlrj) or die (mysql_error());
$linhasrj=mysql_num_rows($resultadorj);

if($linhasrj>0)
{
   while($pegarrj=mysql_fetch_array($resultadorj))
    {
       $regimejuridico   =$pegarrj["descricao"];
	}
}

?>


  <tr>
      <td height="5" colspan="2"  class="style4"><div align="left"   class="style5"><strong>Matricula:<?echo  $matricula?> </strong></div></td>
      <td height="5" colspan="2"  class="style4"><div align="center" class="style5"><strong>cargo :<? echo $cargo ?></strong></div></td>
      <td height="5" colspan="2"  class="style4"><div align="center" class="style5"><strong>Fun��o: <? echo $funcao ?></strong></div></td>
  </tr>



  <tr>
      <td height="5" colspan="2"  class="style4"><div align="left"   class="style5"><strong>Regime Jur�dico :<?echo  $regimejuridico?> </strong></div></td>
      <td height="5" colspan="2"  class="style4"><div align="center" class="style5"><strong>Admiss�o :<? echo $dtadmissao ?></strong></div></td>
      <td height="5" colspan="2"  class="style4"><div align="center" class="style5"><strong>C.H :<? echo $chcontrato ?></strong></div></td>
  </tr>


    <tr>
      <td height="68" colspan="8" bgcolor="#999999"><div align="center" class="style7">Lota��o</div></td><br>
    </tr>






<?
	}
}

if ($lotadocontrato=='2')
{
$sqllotacao="select distinct(matricula),lotado,gerencia,departamento,inep from lotacao where cpf = '$cpf'  and matricula <> '' and inep <>''" ;
$resultadolotacao=mysql_query($sqllotacao) or die (mysql_error());
$linhaslotacao=mysql_num_rows($resultadolotacao);
}

else
{
$sqllotacao="select distinct(matricula) ,lotado,gerencia,departamento,inep from lotacao where cpf = '$cpf'  and matricula <> '' " ;
$resultadolotacao=mysql_query($sqllotacao) or die (mysql_error());
$linhaslotacao=mysql_num_rows($resultadolotacao);

}

if($linhaslotacao>0)
{

   while($pegarlotacao=mysql_fetch_array($resultadolotacao))
    {

       $matricula   = $pegarlotacao["matricula"];
       $lotado      = $pegarlotacao["lotado"];

	   if ($lotado=="1")
	      {
		     $lotadodesc="ADM"; 
			 $gerencia       = $pegarlotacao["gerencia"];
			 $sqlgerencia="select * from gerencia where codigo = '$gerencia'";
			 $resultadogerencia=mysql_query($sqlgerencia) or die (mysql_error());
			 $linhasgerencia=mysql_num_rows($resultadogerencia);

			 if($linhasgerencia>0)
				{
			   while($pegargerencia=mysql_fetch_array($resultadogerencia))
				    {
				       $gerencia   =$pegargerencia["descricao"];

				 	}
				}



			$departamento   = $pegarlotacao["departamento"];
			$sqldpto="select * from departamento where codigo_dpto = '$departamento'";
			$resultadodpto=mysql_query($sqldpto) or die (mysql_error());
			$linhasdpto=mysql_num_rows($resultadodpto);

			if($linhasdpto>0)
				{

				   while($pegardpto=mysql_fetch_array($resultadodpto))
			        {
			       $departamento   =$pegardpto["descricao"];

			     	}
		        }


		  }
	   else if ($lotado=="2")
	     {
		    $lotadodesc="ESCOLA";  

			$inep= $pegarlotacao["inep"];
			$sqlinep="select * from escola where inep = '$inep'";
			$resultadoinep=mysql_query($sqlinep) or die (mysql_error());
			$linhasinep=mysql_num_rows($resultadoinep);

			if($linhasinep>0)
				{
	
   				while($pegarinep=mysql_fetch_array($resultadoinep))
				    {
				       $descricaoescola   =$pegarinep["DESCRICAO"];
					
					}
				}
		 }







?>







  <tr>
      <td height="5" colspan="2"  class="style4"><div align="left"   class="style5"><strong>Matricula:<?echo  $matricula?> </strong></div>    </td>
      <td height="5" colspan="2"  class="style4"><div align="center" class="style5"><strong>Lotado :<? echo $lotadodesc ?></strong></div></td>
    
  </tr>

  <tr>
      <td height="5" colspan="2"  class="style4"><div align="left"   class="style5"><strong>INEP: <?echo  $inep?> </strong></div>    </td>
      <td height="5" colspan="2"  class="style4"><div align="center" class="style5"><strong>Escola :<? echo $descricaoescola ?></strong></div></td>
    
  </tr>



  <tr>
      <td height="5" colspan="2"  class="style4"><div align="left"   class="style5"><strong>Ger�ncia: <?echo  $gerencia?> </strong></div>    </td>
      <td height="5" colspan="2"  class="style4"><div align="center" class="style5"><strong>Departamento :<? echo $departamento ?></strong></div></td>
    
  </tr>


<?
   }
}
?>


    <tr>
      <td height="68" colspan="8" bgcolor="#999999"><div align="center" class="style7"></div>
	  




	  </td>
    </tr>
    <tr>
      <td height="20" colspan="8"><div align="center" class="style7">
      </td>
    </tr>

  <tr>
      <td height="2" colspan="2" bgcolor="#CCCCCC" class="style3"><div align="center" class="style5"><strong>Protocolo de Recadastramento<?echo  $id?> </strong></div>	  </td>
      <td colspan="6" bgcolor="#CCCCCC" class="style3"><div align="center" class="style5"><strong>Impresso <? echo $data1 ?></strong></div></td>
    </tr>


    <tr>
  </tr>
 </table>
</div>

<tr>
<td>
&nbsp&nbsp
</td>
</tr>
<br/>
    <tr>
  	  <td height="2" colspan="2" bgcolor="#CCCCCC" class="style3"><div align="left" class="style5"><strong>&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp;</strong></div></td>
      <td colspan="6" bgcolor="#CCCCCC" class="style3"><div align="left" class="style5"><strong>&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp;</strong></div></td>
    </tr>
<tr>
<td align="center">
<form>
  <input type="button"  value="Imprimir a p�gina"   onClick="DoPrinting()" />
</form>
</td>
</tr>
</body>
</html>

<?
 
 } 
else
{
echo "<html><head><title>Resposta !!!</title></head>";
echo "<body background=\"background_mensagens.jpg\" style=\"background-attachment:fixed; background-repeat:no-repeat\">";
echo "<br><br><br>";
echo "<center><img src=\"faleconosco/atencao.gif\" alt=\"\"><p><font color=\"#ff6600\" face=\"Verdana\" size=\"4\">Servidor nao localizado .!!!! <b></b></font></center>";
echo "<br><br><center><a href=\"nam/mnnam.php\"><img src=\"faleconosco/button_voltar2_.gif\" alt=\"Voltar\" border=\"0\" /></a></center>";
echo "</body></html>";

}

mysql_close($conexao);
}
?>


